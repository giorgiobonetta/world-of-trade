/* Le tre unità aggiunte a mano — carbonio, assicurazione, contratti — devono
   essere giocabili fino in fondo, non solo esistere nei dati. Ogni lezione
   viene aperta e completata rispondendo correttamente, e si verifica che una
   risposta sbagliata venga davvero rifiutata: un esercizio che accetta
   qualunque cosa è peggio di uno assente, perché insegna la cosa sbagliata. */
import { boot, solver, suite } from './harness.mjs';

const t = suite('Unità nuove giocabili');
const { w } = await boot();
const L = w.__LEARN__;
const S = solver(w, L);

const NUOVE = ['u10', 'u11', 'u12', 'u13', 'u14'];
const unita = L.UNITS.filter(u => NUOVE.includes(u.id));

t('le cinque unità sono nel percorso', unita.length === 5,
  unita.map(u => u.id).join(' ') || 'nessuna');

t('ogni unità porta sei livelli',
  unita.every(u => u.lessons.length === 6),
  unita.map(u => `${u.id}:${u.lessons.length}`).join(' '));

t('ogni unità porta trenta esercizi',
  unita.every(u => u.lessons.reduce((a, l) => a + l.exercises.length, 0) === 30),
  unita.map(u => `${u.id}:${u.lessons.reduce((a, l) => a + l.exercises.length, 0)}`).join(' '));

/* ── ogni lezione va aperta e portata a termine ── */
const nonFinite = [];
for (const u of unita) {
  for (const lez of u.lessons) {
    // la progressione blocca tutto ciò che non è la lezione successiva:
    // per giocarle tutte si segna la lezione come già superata
    if (!L.state.done.includes(lez.id)) L.state.done.push(lez.id);
    L.startLesson(lez.id);
    if (!await S.gioca()) nonFinite.push(lez.id);
  }
}
t('ogni lezione si completa rispondendo correttamente',
  nonFinite.length === 0,
  nonFinite.join(', ') || `${unita.reduce((a, u) => a + u.lessons.length, 0)} lezioni`);

/* ── una risposta sbagliata deve costare una vita ── */
const nonPunite = [];
for (const u of unita) {
  for (const lez of u.lessons) {
    if (!L.state.done.includes(lez.id)) L.state.done.push(lez.id);
    // ogni prova costa una vita: senza ripristino il fondo si esaurisce
    // dopo cinque lezioni e le rimanenti sembrerebbero non punire l'errore
    L.state.lives = L.MAX_LIVES;
    L.startLesson(lez.id);
    const ex = L.run?.current?.ex;
    if (!ex || !S.sbagliato(ex)) continue;   // order/pairs/build: non falsificabili qui
    const prima = S.$$('#hearts .h').filter(v => v.classList.contains('gone')).length;
    L.onCheck();
    const dopo = S.$$('#hearts .h').filter(v => v.classList.contains('gone')).length;
    if (dopo !== prima + 1) nonPunite.push(`${lez.id} (${ex.type})`);
  }
}
t('una risposta sbagliata non passa per corretta',
  nonPunite.length === 0, nonPunite.join(', ') || 'verificato su choice e numeric');

/* ── forma degli esercizi numerici ── */
const numerici = unita.flatMap(u => u.lessons.flatMap(l =>
  l.exercises.filter(e => e.type === 'numeric').map(e => ({ e, l: l.id }))));

t('ogni esercizio numerico dichiara l’unità di misura',
  numerici.every(x => x.e.unit && String(x.e.unit).trim()),
  `${numerici.length} numerici`);

const senzaRisultato = numerici.filter(({ e }) => {
  const cifre = (String(e.why).replace(/[$,]/g, '').match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
  return !cifre.some(v => Math.abs(v - e.answer) <= Math.max(Number(e.tolerance) || 0, 1e-9));
}).map(x => x.l);
t('la spiegazione contiene sempre il risultato accettato',
  senzaRisultato.length === 0, senzaRisultato.join(', '));

/* ── ogni esercizio spiega, non solo corregge ── */
const tutti = unita.flatMap(u => u.lessons.flatMap(l => l.exercises));
t('ogni esercizio ha una spiegazione di sostanza',
  tutti.every(e => e.why && e.why.length >= 80),
  `${tutti.length} esercizi, il più corto ${Math.min(...tutti.map(e => (e.why || '').length))} caratteri`);

/* ── il profilo deve sapere dove collocarle ── */
const G = w.WOT_GAME;
t('ogni unità nuova ha competenza e divisione',
  NUOVE.every(id => G.unitMeta[id]?.skill && G.unitMeta[id]?.division),
  NUOVE.map(id => G.unitMeta[id]?.skill || '—').join(' '));

t('le competenze richiamate esistono davvero',
  NUOVE.every(id => G.skills[G.unitMeta[id]?.skill]),
  NUOVE.map(id => G.skills[G.unitMeta[id]?.skill]?.name || 'MANCA').join(' · '));

t.fine();
