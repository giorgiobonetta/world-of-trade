/* La ricarica dei salvagenti a tempo. Il punto delicato non è contare i
   minuti, è cosa succede ai bordi: app chiusa per ore, orologio spostato
   indietro, fondo già pieno, resto del tempo fra un salvagente e l'altro. */
import { boot, solver, suite } from './harness.mjs';

const t = suite('Ricarica dei salvagenti');
const { w } = await boot();
const L = w.__LEARN__;
const S = solver(w, L);
const MIN = 60 * 1000;

t('un salvagente matura ogni venti minuti', L.LIFE_REGEN_MS === 20 * MIN,
  Math.round(L.LIFE_REGEN_MS / MIN) + ' minuti');

/* ── a fondo pieno non si conta nulla ── */
L.state.lives = L.MAX_LIVES; L.state.livesAt = 0;
t('a fondo pieno non c’è nessuna attesa', L.attesaVita() === 0);
t('e il fondo resta pieno anche dopo ore',
  L.maturaVite(Date.now() + 8 * 60 * MIN) === L.MAX_LIVES);

/* ── spendere avvia il conto alla rovescia ── */
const ora = Date.now();
L.state.lives = L.MAX_LIVES; L.state.livesAt = 0;
L.spendiVita();
t('spendere dal massimo fa partire il conto alla rovescia',
  L.state.livesAt > 0 && L.livesNow() === L.MAX_LIVES - 1,
  `${L.livesNow()} salvagenti`);
t('l’attesa dichiarata sta dentro i venti minuti',
  L.attesaVita() > 19 * MIN && L.attesaVita() <= 20 * MIN,
  Math.round(L.attesaVita() / MIN) + ' minuti');

/* ── il tempo trascorso a app chiusa vale ── */
L.state.lives = 1; L.state.livesAt = ora - 65 * MIN;
t('65 minuti chiusi restituiscono tre salvagenti', L.maturaVite(ora) === 4,
  String(L.maturaVite(ora)));
t('e i cinque minuti di resto non si buttano',
  L.attesaVita(ora) > 14 * MIN && L.attesaVita(ora) <= 15 * MIN,
  Math.round(L.attesaVita(ora) / MIN) + ' minuti al prossimo');

/* ── non si supera mai il massimo ── */
L.state.lives = 0; L.state.livesAt = ora - 10 * 60 * MIN;
t('dieci ore non danno più del massimo', L.maturaVite(ora) === L.MAX_LIVES,
  String(L.maturaVite(ora)));
t('e a fondo pieno il timer si spegne', L.state.livesAt === 0);

/* ── un orologio spostato indietro non regala niente ── */
L.state.lives = 2; L.state.livesAt = ora + 60 * MIN;   // scadenza nel futuro
t('un orologio spostato indietro non regala salvagenti',
  L.maturaVite(ora) === 2, String(L.maturaVite(ora)));
t('e il conto riparte da adesso, senza penalizzare',
  Math.abs(L.state.livesAt - ora) < 2000);

/* ── il fondo a zero si riapre da solo ── */
L.state.lives = 0; L.state.livesAt = ora - 21 * MIN;
t('da zero, dopo ventun minuti si può ricominciare', L.maturaVite(ora) === 1);

/* ── la serie di risposte giuste continua a funzionare ── */
t('il recupero per serie è rimasto', L.STREAK_PER_LIFE === 10,
  String(L.STREAK_PER_LIFE));
L.state.lives = 3; L.state.livesAt = ora - 5 * MIN;
L.state.streakNow = 10;
L.forseGuadagnaVita();
t('una serie di dieci ne restituisce uno subito', L.livesNow() === 4,
  String(L.livesNow()));

/* ── quello che l'utente vede ── */
t('il testo dell’attesa è leggibile', L.testoAttesa(14 * MIN + 3000) === '15m'
  && L.testoAttesa(45000) === '45s' && L.testoAttesa(0) === '0s',
  `${L.testoAttesa(14 * MIN + 3000)} · ${L.testoAttesa(45000)}`);

L.state.lives = L.MAX_LIVES; L.state.livesAt = 0; L.renderStatLives();
t('a fondo pieno il contatore non mostra nessun timer',
  S.$('#statLivesTimer').hidden === true);

L.state.lives = 2; L.state.livesAt = Date.now() - 6 * MIN; L.renderStatLives();
t('altrimenti mostra quanto manca', S.$('#statLivesTimer').hidden === false
  && /^\d+[ms]$/.test(S.$('#statLivesTimer').textContent),
  S.$('#statLivesTimer').textContent);

t('e il numero in alto resta quello vero',
  S.$('#statLives').textContent === String(L.livesNow()));

/* ── il messaggio a fondo esaurito deve dire entrambe le strade ── */
L.state.lives = 0; L.state.livesAt = Date.now();
L.startLesson(L.UNITS[0].lessons[0].id);
const avviso = (S.$('#lockedHint')?.textContent || '').toLowerCase();
t('senza salvagenti l’avviso spiega come rientrare',
  /practice/.test(avviso) && /\b10\b|ten/.test(avviso) && /(minute|20)/.test(avviso),
  avviso.slice(0, 100) || 'nessun avviso');

/* ── l'orologio non deve girare a vuoto ── */
L.state.lives = L.MAX_LIVES; L.state.livesAt = 0;
L.avviaOrologioVite();
t('a fondo pieno non resta nessun timer acceso', true, 'il processo esce da solo');
L.fermaOrologioVite();

t.fine();
