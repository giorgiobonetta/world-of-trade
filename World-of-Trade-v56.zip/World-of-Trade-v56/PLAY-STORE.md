# Pubblicare World of Trade sul Google Play Store

Stato del progetto: **pronto sul piano tecnico**, tranne la chiave di firma che
devi generare tu. `targetSdk` è già 36, quindi la scadenza del 31 agosto 2026 è
rispettata.

---

## Quello che serve, in ordine

### 1. Account sviluppatore Google Play
Registrazione su `play.google.com/console` con una quota **una tantum di circa 25 USD**.
Ti verrà chiesto un documento d'identità e la verifica può richiedere qualche giorno.

**Scelta importante:** account **personale** o **organizzazione**.

- **Personale** → sei soggetto al test chiuso obbligatorio: **12 tester per 14 giorni
  consecutivi** prima di poter chiedere l'accesso alla produzione. Vale per gli
  account personali creati dopo il 13 novembre 2023.
- **Organizzazione** (serve un numero D-U-N-S aziendale) → **esente** da quel
  requisito, pubblichi direttamente.

Se hai una società, conviene registrarsi come organizzazione: risparmi due settimane.

### 2. La chiave di firma
Una volta sola, da terminale nella cartella `android-app`:

```
keytool -genkey -v -keystore world-of-trade.jks -keyalg RSA -keysize 2048 \
        -validity 10000 -alias worldoftrade
```

Poi copia `keystore.properties.example` in `keystore.properties` e compila le
password. Il `.gitignore` che ho aggiunto impedisce che finiscano nel repository.

> **Conserva il file `.jks` e le password.** Se li perdi non puoi più aggiornare
> l'app pubblicata.

### 3. Il file da caricare: AAB, non APK
Il Play Store accetta solo **Android App Bundle**. Il workflow ora lo produce, ma
gli servono le credenziali nei *Secrets* del repository
(*Settings → Secrets and variables → Actions*):

| Secret | Valore |
|---|---|
| `KEYSTORE_BASE64` | il file `.jks` codificato: `base64 -w0 world-of-trade.jks` |
| `KEYSTORE_PASSWORD` | la password dello store |
| `KEY_ALIAS` | `worldoftrade` |
| `KEY_PASSWORD` | la password della chiave |

Senza questi secret il workflow salta l'AAB e produce solo l'APK di debug, quindi
non si rompe nulla. In alternativa, in locale: `gradle :app:bundleRelease`.

### 4. Privacy policy
Obbligatoria, serve un URL pubblico. Ho scritto `privacy.html`: caricandolo con il
resto del sito su Vercel diventa `https://iltuodominio/privacy`.

È accurata: il gioco non raccoglie nulla, non ha account, non ha analytics, non ha
pubblicità e funziona offline.

### 5. Modulo "Sicurezza dei dati"
Grazie a come è fatto il gioco, le risposte sono le più semplici possibili:

- Raccogli o condividi dati utente? → **No**
- L'app usa la crittografia in transito? → non applicabile, nessun dato trasmesso
- Gli utenti possono chiedere la cancellazione dei dati? → sì, disinstallando o
  azzerando la carriera dal gioco

### 6. Materiali per la scheda
- **Icona**: 512×512 PNG → hai `world-of-trade-premium-icon-512.png`
- **Immagine in evidenza**: 1024×500 → da produrre
- **Screenshot**: minimo 2 per telefono (16:9 o 9:16). Servono catture reali dal
  gioco: fai partire una carriera, apri il globo con un cargo in viaggio, il
  pannello di un'operazione e il riepilogo di chiusura.
- **Descrizione breve** (80 caratteri) e **completa** (4000)
- **Classificazione dei contenuti**: questionario. Nessuna violenza, nessuna chat,
  nessun acquisto → classificazione per tutti.
- **Categoria**: Giochi → Simulazione (oppure Strategia)

### 7. Test chiuso, se account personale
Crea una traccia di test chiuso, invita 12 persone via email o link, e aspetta che
restino iscritte 14 giorni consecutivi. Poi chiedi l'accesso alla produzione.
Conviene farlo partire subito: è il collo di bottiglia.

---

## Ordine consigliato

1. Registra l'account (la verifica richiede giorni, fallo per primo).
2. Genera la chiave e configura i secret.
3. Pubblica la privacy policy con il sito.
4. Fai girare il workflow e scarica l'AAB.
5. Carica sulla traccia di test chiuso e invita i 12 tester.
6. Mentre aspettano i 14 giorni, prepara screenshot, immagine in evidenza e testi.
7. Chiedi l'accesso alla produzione.

## Prima di tutto questo

Il gioco funziona e si compila, ma nessuno l'ha ancora giocato per mezz'ora di
fila — nemmeno tu. I 12 tester del test chiuso te lo diranno senza filtri e le loro
recensioni restano. Vale la pena giocarci prima.
