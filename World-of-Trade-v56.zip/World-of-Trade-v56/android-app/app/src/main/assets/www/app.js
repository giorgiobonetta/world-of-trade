(async () => {
  window.__WOT_MODULE_LOADED__ = true;
  window.__WOT_SET_BOOT_STATUS__?.('Loading 3D engine…', 18);

  let THREE;
  const threeCandidates = [
    './three.module.min.js',
    './vendor/three.module.min.js',
    'https://cdn.jsdelivr.net/npm/three@0.185.0/build/three.module.min.js',
    'https://unpkg.com/three@0.185.0/build/three.module.min.js'
  ];
  let lastThreeError = null;
  for (const candidate of threeCandidates) {
    try {
      THREE = await import(candidate);
      break;
    } catch (error) {
      lastThreeError = error;
      console.warn(`Three.js source unavailable: ${candidate}`, error);
      window.__WOT_SET_BOOT_STATUS__?.('Repairing missing 3D engine…', 24);
    }
  }
  if (!THREE) {
    const error = new Error('The Three.js engine could not be loaded from the repository or the recovery sources.');
    error.cause = lastThreeError;
    throw error;
  }

  window.__WOT_SET_BOOT_STATUS__?.('Preparing trading world…', 36);

(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  // v45 — HTML escaping for any user-controlled string injected via innerHTML
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[ch]));
  const cleanUserName = (value, fallback) => String(value ?? '').replace(/[<>&"'`\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 48) || fallback;
  const lerp = (a, b, t) => a + (b - a) * t;
  const deg = Math.PI / 180;
  const storageKey = 'wot-v35';
  const legacyStorageKeys = ['wot-v34', 'wot-v33', 'wot-v32', 'wot-v31', 'wot-v30', 'wot-v29', 'wot-v28', 'wot-v27', 'wot-v26', 'wot-v25', 'wot-v24', 'wot-v23', 'wot-v22', 'wot-v21', 'wot-v20', 'wot-v19', 'wot-v18', 'shippy-v17', 'shippy-v16', 'shippy-v15', 'shippy-v14', 'shippy-v13', 'shippy-v12', 'shippy-v11', 'shippy-v10', 'shippy-v9', 'shippy-v8', 'shippy-v7', 'shippy-v6', 'shippy-v5', 'global-commodity-trader-v3'];

  // v45 — sentinella: la migrazione da chiavi legacy deve avvenire una volta sola
  const legacyMigratedKey = 'wot-legacy-migrated';

  // ── v25 prestige (persists across career resets) ────────────────────────────
  const prestigeKey = () => (typeof activeSlot === 'number' && activeSlot > 1) ? `wot-prestige-slot-${activeSlot}` : 'wot-prestige';
  const VICTORY_VALUATION = 50_000_000;
  function loadPrestige() {
    try { return Math.max(0, parseInt(localStorage.getItem(prestigeKey()) || '0', 10) || 0); } catch (e) { return 0; }
  }
  function savePrestige(level) {
    try { localStorage.setItem(prestigeKey(), String(Math.max(0, level | 0))); } catch (e) { console.warn('[WoT] prestige not persisted', e); }
  }
  // Each prestige level: +12% starting cash, +8% credit line, +2 starting reputation
  function prestigeStartCash(base) { return Math.round(base * (1 + 0.12 * loadPrestige())); }
  function prestigeStartCredit(base) { return Math.round(base * (1 + 0.08 * loadPrestige())); }
  function prestigeStartReputation(base) { return Math.min(70, base + 2 * loadPrestige()); }

  // ── v27 multiple save slots ────────────────────────────────────────────────
  const SLOT_COUNT = 3;
  const activeSlotKey = 'wot-active-slot';
  let activeSlot = 1;
  function loadActiveSlot() {
    try { const n = parseInt(localStorage.getItem(activeSlotKey) || '1', 10); return (n >= 1 && n <= SLOT_COUNT) ? n : 1; } catch (e) { return 1; }
  }
  function setActiveSlot(n) {
    activeSlot = (n >= 1 && n <= SLOT_COUNT) ? n : 1;
    try { localStorage.setItem(activeSlotKey, String(activeSlot)); } catch (e) { console.warn('[WoT] active slot not persisted', e); }
  }
  function slotKey(n) { return `${storageKey}-slot-${n}`; }
  function currentStorageKey() { return slotKey(activeSlot); }
  function readSlotMeta(n) {
    let raw = null;
    try { raw = localStorage.getItem(slotKey(n)); } catch (e) { return { empty: false, corrupt: true, hasBackup: false }; }
    if (!raw) return null;
    try {
      const s = JSON.parse(raw);
      return {
        empty: false,
        corrupt: false,
        companyName: s.companyName || 'World of Trade Co.',
        profileName: s.profileName || 'Trader',
        completedDeals: s.completedDeals || 0,
        cash: s.cash || 0,
        prestigeLevel: s.prestigeLevel || 0,
        date: s.date || null,
        lastSavedAt: s.lastSavedAt || null,
      };
    } catch (e) {
      console.error(`[WoT] slot ${n} is corrupt`, e);
      let hasBackup = false;
      try { hasBackup = Boolean(localStorage.getItem(`${slotKey(n)}-backup`)); } catch (err) {}
      return { empty: false, corrupt: true, hasBackup };
    }
  }

  const money = (value, compact = false) => {
    const sign = value < 0 ? '-' : '';
    const abs = Math.abs(value);
    if (compact && abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(2)}M`;
    if (compact && abs >= 1_000) return `${sign}$${Math.round(abs / 1_000)}K`;
    return `${sign}$${Math.round(abs).toLocaleString('en-US')}`;
  };

  // ── v25 procedural audio (Web Audio API, no external assets) ────────────────
  const Sound = (() => {
    let ctx = null;
    let master = null;
    let unlocked = false;
    function ensure() {
      if (ctx) return ctx;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
        master = ctx.createGain();
        master.gain.value = 0.5;
        master.connect(ctx.destination);
      } catch (e) { ctx = null; }
      return ctx;
    }
    function unlock() {
      const c = ensure();
      if (c && c.state === 'suspended') c.resume().catch(() => {});
      unlocked = true;
    }
    function enabled() {
      return typeof state !== 'undefined' && state && state.soundEnabled !== false;
    }
    // A single tone with an ADSR-ish envelope
    function tone({ freq = 440, type = 'sine', start = 0, dur = 0.15, gain = 0.2, attack = 0.005, release = 0.08, glideTo = null }) {
      const c = ensure();
      if (!c) return;
      const t0 = c.currentTime + start;
      const osc = c.createOscillator();
      const g = c.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t0);
      if (glideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(1, glideTo), t0 + dur);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(gain, t0 + attack);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur + release);
      osc.connect(g); g.connect(master);
      osc.start(t0);
      osc.stop(t0 + dur + release + 0.02);
    }
    function chord(freqs, opts = {}) { freqs.forEach((f, i) => tone({ ...opts, freq: f, start: (opts.stagger || 0) * i })); }
    function play(name) {
      if (!enabled()) return;
      if (typeof _soundSuppressed !== 'undefined' && _soundSuppressed) return;
      const c = ensure();
      if (!c) return;
      if (c.state === 'suspended') c.resume().catch(() => {});
      switch (name) {
        case 'success': // rising major triad
          chord([523.25, 659.25, 783.99], { type: 'triangle', dur: 0.16, gain: 0.16, stagger: 0.05, release: 0.12 }); break;
        case 'deal': // richer success — deal closed
          chord([392, 523.25, 659.25, 783.99], { type: 'triangle', dur: 0.2, gain: 0.15, stagger: 0.06, release: 0.16 }); break;
        case 'error': // low descending buzz
          tone({ freq: 220, type: 'sawtooth', dur: 0.16, gain: 0.14, glideTo: 130, release: 0.1 }); break;
        case 'warning': // two-tone alert
          tone({ freq: 480, type: 'square', dur: 0.1, gain: 0.1 });
          tone({ freq: 360, type: 'square', dur: 0.12, gain: 0.1, start: 0.12 }); break;
        case 'info': // soft blip
          tone({ freq: 660, type: 'sine', dur: 0.08, gain: 0.09, release: 0.06 }); break;
        case 'click': // subtle tick
          tone({ freq: 900, type: 'sine', dur: 0.03, gain: 0.05, release: 0.03 }); break;
        case 'day': // soft whoosh tick for day advance
          tone({ freq: 300, type: 'sine', dur: 0.09, gain: 0.07, glideTo: 520, release: 0.08 }); break;
        case 'purchase': // cash-register-ish two-note
          tone({ freq: 784, type: 'triangle', dur: 0.07, gain: 0.13 });
          tone({ freq: 1046.5, type: 'triangle', dur: 0.12, gain: 0.12, start: 0.07, release: 0.12 }); break;
        case 'achievement': // fanfare
          chord([523.25, 659.25, 783.99, 1046.5], { type: 'triangle', dur: 0.26, gain: 0.16, stagger: 0.08, release: 0.22 }); break;
        case 'victory': // triumphant arpeggio
          chord([523.25, 659.25, 783.99, 1046.5, 1318.5], { type: 'triangle', dur: 0.32, gain: 0.17, stagger: 0.1, release: 0.3 }); break;
        default: break;
      }
    }
    return { unlock, play, enabled, ensure };
  })();

  let _soundSuppressed = false;
  const notificationHistory = [];
  let notificationsUnread = 0;

  // ── v26 glossary of trading terms + contextual tooltips ─────────────────────
  const glossaryTerms = [
    { key:'contango', term:'Contango', category:'Market structure', def:'When forward prices are higher than the spot price. The market pays you to hold inventory over time — a sign of ample near-term supply.' },
    { key:'backwardation', term:'Backwardation', category:'Market structure', def:'When forward prices are lower than the spot price. It signals tight near-term supply; holding physical now is more valuable than a future delivery.' },
    { key:'termstructure', term:'Term structure', category:'Market structure', def:'The shape of prices across delivery months. Contango slopes up, backwardation slopes down. It drives the economics of storage and hedging.' },
    { key:'forwardcurve', term:'Forward curve', category:'Market structure', def:'The set of prices for delivery at future dates (M1–M6 here). Its slope is the term structure.' },
    { key:'spot', term:'Spot price', category:'Market structure', def:'The price for immediate (prompt) delivery, as opposed to a future/forward date.' },
    { key:'basis', term:'Basis', category:'Market structure', def:'The difference between the local physical price at a hub and the benchmark/reference price. Trading basis is a core physical-merchant skill.' },
    { key:'hedge', term:'Hedge ratio', category:'Risk', def:'The share of a position protected with an offsetting paper trade. A 100% hedge locks the margin and removes flat-price risk; 0% leaves you fully exposed to price moves.' },
    { key:'margincall', term:'Margin call', category:'Risk', def:'A demand for additional cash collateral when a hedge moves against you. Enough liquidity to meet margin calls is essential to survive volatility.' },
    { key:'var', term:'Value at Risk (VaR)', category:'Risk', def:'An estimate of the maximum loss expected over a period at a given confidence level. A headline risk metric for the desk.' },
    { key:'kyc', term:'KYC', category:'Compliance', def:'Know Your Customer — the due-diligence process to verify a counterparty\'s identity, ownership and legitimacy before trading.' },
    { key:'compliance', term:'Compliance review', category:'Compliance', def:'A check that a route, counterparty or structure meets sanctions, AML and internal-policy requirements before a deal can proceed.' },
    { key:'demurrage', term:'Demurrage', category:'Logistics', def:'A penalty paid to a vessel owner when loading or discharge takes longer than the agreed laytime. A common cost when ports are congested.' },
    { key:'laycan', term:'Laycan', category:'Logistics', def:'The window (laydays/cancelling) during which a vessel must arrive to load. Missing it can void the charter.' },
    { key:'charter', term:'Time charter', category:'Logistics', def:'Hiring a vessel for a period at a daily rate. You control the voyages; the owner runs the ship. Owned vessels avoid the rate but carry maintenance.' },
    { key:'lc', term:'Letter of credit (L/C)', category:'Finance', def:'A bank guarantee that the buyer will pay once compliant shipping documents are presented. It reduces payment risk in cross-border trade.' },
    { key:'nav', term:'Net asset value (NAV)', category:'Finance', def:'The total value of the trading house: cash, open-position value and asset book value, net of what you owe.' },
    { key:'creditline', term:'Credit line', category:'Finance', def:'The revolving financing the bank extends to fund inventory and receivables. Using it costs interest; exceeding it blocks new deals.' },
    { key:'enterprisevalue', term:'Enterprise valuation', category:'Finance', def:'A forward-looking value of the whole business — NAV plus capitalised earnings, assets, relationships and execution track record. Reaching $50M wins the game.' },
    { key:'regime', term:'Market regime', category:'Market', def:'The prevailing market mood (balanced, risk-on, soft, freight-driven, squeeze) that shifts volatility, margins and acceptance across all commodities.' },
    { key:'tender', term:'Tender', category:'Commercial', def:'A competitive bid process where you and AI rivals compete to win a cargo. Conceding margin raises your win probability.' },
    { key:'prestige', term:'Prestige', category:'Progression', def:'A legacy reset: once you reach the top valuation tier you can restart with permanent bonuses (+12% capital, +8% credit, higher reputation per level).' },
  ];
  const glossaryMap = Object.fromEntries(glossaryTerms.map(t => [t.key, t]));

  let _tooltipEl = null;
  function ensureTooltipEl() {
    if (_tooltipEl) return _tooltipEl;
    _tooltipEl = document.createElement('div');
    _tooltipEl.className = 'term-tooltip';
    _tooltipEl.setAttribute('role', 'tooltip');
    document.body.appendChild(_tooltipEl);
    return _tooltipEl;
  }
  function showTermTooltip(target) {
    const key = target.getAttribute('data-term');
    const entry = glossaryMap[key];
    if (!entry) return;
    const tip = ensureTooltipEl();
    tip.innerHTML = `<strong>${entry.term}</strong><span>${entry.def}</span>`;
    tip.classList.add('visible');
    const r = target.getBoundingClientRect();
    const tw = Math.min(260, window.innerWidth - 20);
    tip.style.width = tw + 'px';
    let left = r.left + r.width/2 - tw/2;
    left = Math.max(10, Math.min(left, window.innerWidth - tw - 10));
    tip.style.left = left + 'px';
    // Place above if room, else below
    const th = tip.offsetHeight || 90;
    let top = r.top - th - 8;
    if (top < 10) top = r.bottom + 8;
    tip.style.top = top + 'px';
  }
  function hideTermTooltip() { if (_tooltipEl) _tooltipEl.classList.remove('visible'); }
  function bindTermTooltips() {
    document.addEventListener('mouseover', e => {
      const t = e.target.closest?.('[data-term]');
      if (t) showTermTooltip(t);
    });
    document.addEventListener('mouseout', e => {
      if (e.target.closest?.('[data-term]')) hideTermTooltip();
    });
    document.addEventListener('focusin', e => {
      const t = e.target.closest?.('[data-term]');
      if (t) showTermTooltip(t);
    });
    document.addEventListener('focusout', hideTermTooltip);
    window.addEventListener('scroll', hideTermTooltip, true);
  }
  function updateNotificationsBadge() {
    const badge = $('#notificationsBadge');
    if (!badge) return;
    if (notificationsUnread > 0) { badge.textContent = String(notificationsUnread); badge.classList.remove('hidden'); }
    else badge.classList.add('hidden');
  }
  function timeAgo(ts) {
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 45) return 'just now';
    if (s < 90) return '1 min ago';
    if (s < 3600) return `${Math.floor(s/60)} min ago`;
    if (s < 7200) return '1 hr ago';
    return `${Math.floor(s/3600)} hr ago`;
  }
  function openNotificationsDialog() {
    const dialog = $('#notificationsDialog');
    if (!dialog) return;
    const list = $('#notificationsList');
    if (list) {
      if (!notificationHistory.length) {
        list.innerHTML = '<div class="empty-card">No notifications yet. Your actions and market alerts will be logged here.</div>';
      } else {
        const icons = { success:'✓', error:'✕', warning:'!', info:'ℹ' };
        list.innerHTML = notificationHistory.map(n => `
          <div class="notif-entry notif-${n.kind}">
            <span class="notif-icon">${icons[n.kind] || 'ℹ'}</span>
            <div class="notif-body"><span class="notif-msg">${n.message.replace(/</g,'&lt;')}</span><span class="notif-time">${timeAgo(n.at)}</span></div>
          </div>`).join('');
      }
    }
    notificationsUnread = 0;
    updateNotificationsBadge();
    if (!dialog.open) dialog.showModal();
  }

  function openGlossaryDialog() {
    const dialog = $('#glossaryDialog');
    if (!dialog) return;
    const list = $('#glossaryDialogList');
    if (list) {
      const cats = [...new Set(glossaryTerms.map(t => t.category))];
      list.innerHTML = cats.map(cat => `
        <div class="glossary-cat">${cat}</div>
        ${glossaryTerms.filter(t => t.category === cat).map(t => `
          <div class="glossary-entry"><strong>${t.term}</strong><p>${t.def}</p></div>`).join('')}
      `).join('');
    }
    if (!dialog.open) dialog.showModal();
  }

  // ── v28 lightweight i18n (interface chrome) ─────────────────────────────────
  const translationsIT = {
    // Topbar & metrics
    'brand.subtitle': 'Comando Trading Fisico · HQ Ginevra',
    'metric.nav': 'NAV Portafoglio', 'metric.cash': 'Liquidità', 'metric.credit': 'Credito', 'metric.reputation': 'Reputazione',
    // Command dock
    'dock.desk': 'Scrivania', 'dock.shop': 'Negozio', 'dock.overview': 'Panoramica', 'dock.markets': 'Mercati',
    'dock.layers': 'Livelli', 'dock.search': 'Cerca', 'dock.briefing': 'Briefing', 'dock.keys': 'Tasti', 'dock.glossary': 'Glossario',
    // Buttons / titles
    'btn.newCareer': 'Nuova carriera', 'btn.notifications': 'Notifiche', 'btn.install': 'Installa World of Trade', 'btn.profile': 'Profilo giocatore',
    // Profile dialog
    'profile.eyebrow': 'Profilo giocatore', 'profile.title': 'Carriera e impostazioni',
    'profile.traderName': 'Nome trader', 'profile.house': 'Società di trading', 'profile.graphics': 'Qualità grafica',
    'profile.autosave': 'Salvataggio automatico', 'profile.motion': 'Movimento e animazioni', 'profile.sound': 'Effetti sonori',
    'profile.language': 'Lingua',
    'opt.enabled': 'Attivo', 'opt.disabled': 'Disattivato', 'opt.on': 'Attivo', 'opt.muted': 'Muto',
    'opt.auto': 'Auto', 'opt.high': 'Alta', 'opt.balanced': 'Bilanciata', 'opt.performance': 'Prestazioni',
    'opt.fullAnim': 'Animazioni complete', 'opt.reducedMotion': 'Movimento ridotto',
    'profile.export': 'Esporta carriera', 'profile.import': 'Importa carriera', 'profile.manageSlots': 'Gestisci slot',
    'profile.restartTour': 'Riavvia tour guidato',
    'profile.storageTitle': 'Salvataggio locale', 'profile.storageNote': 'La tua carriera è salvata in questo browser. Esporta un backup prima di cambiare dispositivo o cancellare i dati del browser.',
    'btn.cancel': 'Annulla', 'btn.save': 'Salva modifiche',
    // Dialog headers
    'dlg.glossary.eyebrow': 'Riferimento', 'dlg.glossary.title': 'Glossario del trading',
    'dlg.notif.eyebrow': 'Attività', 'dlg.notif.title': 'Notifiche',
    'dlg.slots.eyebrow': 'Carriere', 'dlg.slots.title': 'Slot di salvataggio',
    'dlg.shortcuts.title': 'Scorciatoie da tastiera',
    'shortcuts.nav': 'Navigazione', 'shortcuts.actions': 'Azioni e vista',
    'sc.command': 'Centro comandi', 'sc.search': 'Ricerca globale', 'sc.market': 'Mercato opportunità',
    'sc.risk': 'Dashboard rischio', 'sc.perf': 'Ufficio performance', 'sc.shop': 'Negozio impero',
    'sc.briefing': 'Briefing giornaliero', 'sc.day': 'Avanza di un giorno', 'sc.cinematic': 'Globo cinematografico',
    'sc.glossary': 'Glossario del trading', 'sc.help': 'Questo pannello',
    'sc.footer': 'Premi ? in qualsiasi momento per aprire questo pannello',
    // Time controls
    'time.pause': 'Pausa', 'time.day': '+1 giorno', 'time.event': 'Prossimo evento',
    'globe.date': 'Data di gioco',
    // Layers
    'layer.opportunities': 'Opportunità', 'layer.portfolio': 'Portafoglio', 'layer.risk': 'Rischio', 'layer.logistics': 'Logistica',
    // Daily reward
    'daily.eyebrow': 'Apertura mercato', 'daily.title': 'Bonus giornaliero', 'daily.claim': 'Riscuoti',
    'gold.title': "Lingotti d'oro",
  };
  const drawerLabelsIT = {
    portfolio:'Scrivania trading', inventory:'Inventario fisico', operations:'Centro operazioni', supply:'Controllo supply chain', contracts:'Contratti e credito',
    fleet:'Ufficio flotta', risk:'Dashboard rischio', opportunities:'Mercato opportunità', rivals:'Intelligence competitiva', strategy:'Strategia del board', expansion:'Ufficio crescita strategica',
    counterparties:'Rete commerciale', compliance:'Ufficio compliance', events:'Intelligence globale', finance:'Tesoreria', performance:'Ufficio performance',
    academy:'WoT Academy', empire:'Impero di trading', shop:'Negozio impero', hq:'Quartier generale',
    career:'Progressione carriera', leaderboard:'Career League'
  };
  function t(key) {
    if (state && state.language === 'it' && translationsIT[key] != null) return translationsIT[key];
    return null; // null → keep original
  }
  // v45 — le opzioni delle <select> e le etichette dei livelli avevano chiavi di
  // traduzione definite ma non collegate a nessun elemento: restavano in inglese.
  const optionTranslationKeys = {
    '#autosaveSelect':      { on: 'opt.enabled', off: 'opt.disabled' },
    '#soundSelect':         { on: 'opt.on', off: 'opt.muted' },
    '#reduceMotionSelect':  { on: 'opt.fullAnim', off: 'opt.reducedMotion' },
    '#graphicsQualitySelect': { auto: 'opt.auto', high: 'opt.high', balanced: 'opt.balanced', performance: 'opt.performance' },
  };
  function applyOptionLanguage(useIT) {
    Object.entries(optionTranslationKeys).forEach(([selector, mapping]) => {
      const select = $(selector);
      if (!select) return;
      [...select.options].forEach(option => {
        if (option._i18nEn == null) option._i18nEn = option.textContent;
        const key = mapping[option.value];
        option.textContent = (useIT && key && translationsIT[key] != null) ? translationsIT[key] : option._i18nEn;
      });
    });
    const layerLabels = { opportunities: 'layer.opportunities', portfolio: 'layer.portfolio', risk: 'layer.risk', logistics: 'layer.logistics' };
    $$('.layer-button[data-layer]').forEach(button => {
      const key = layerLabels[button.dataset.layer];
      const textNode = [...button.childNodes].find(node => node.nodeType === 3 && node.textContent.trim());
      if (!textNode || !key) return;
      if (button._i18nEn == null) button._i18nEn = textNode.textContent;
      textNode.textContent = (useIT && translationsIT[key] != null) ? translationsIT[key] : button._i18nEn;
    });
  }

  function applyLanguage(lang) {
    const useIT = lang === 'it';
    applyOptionLanguage(useIT);
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (el._i18nEn == null) el._i18nEn = el.textContent;
      el.textContent = (useIT && translationsIT[key] != null) ? translationsIT[key] : el._i18nEn;
    });
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
      const key = el.getAttribute('data-i18n-title');
      if (el._i18nTitleEn == null) el._i18nTitleEn = el.getAttribute('title') || '';
      const v = (useIT && translationsIT[key] != null) ? translationsIT[key] : el._i18nTitleEn;
      if (v) el.setAttribute('title', v);
    });
    document.documentElement.setAttribute('lang', useIT ? 'it' : 'en');
  }

  const formatDate = (date) => new Intl.DateTimeFormat('en-GB', {
    day: '2-digit', month: 'long', year: 'numeric'
  }).format(date);

  const hubs = [
    { id: 'geneva', name: 'Geneva', country: 'Switzerland', type: 'hq', lat: 46.2044, lon: 6.1432, subtitle: 'Geneva Commodity Trading Sàrl', description: 'The headquarters coordinates capital, risk, compliance and the desk’s banking relationships.', commodities: ['Base metals', 'Energy', 'Risk management'], risk: 'Low' },
    { id: 'brescia', name: 'Brescia', country: 'Italy', type: 'customer', lat: 45.5416, lon: 10.2118, subtitle: 'Lombardia Cables S.p.A.', description: 'Industrial district with demand for refined copper and strict quality requirements.', commodities: ['Copper cathodes', 'Aluminium', 'Scrap'], risk: 'Low' },
    { id: 'genova', name: 'Genoa', country: 'Italy', type: 'port', lat: 44.4056, lon: 8.9463, subtitle: 'Port of Genoa', description: 'Maritime gateway for deliveries to Northern Italy.', commodities: ['Containers', 'Bulk cargo', 'Warehousing'], risk: 'Medium' },
    { id: 'tallinn', name: 'Tallinn', country: 'Estonia', type: 'supplier', lat: 59.437, lon: 24.7536, subtitle: 'Baltic Metals OU', description: 'Fast, capital-light European supplier whose quality documentation requires verification.', commodities: ['Copper cathodes', 'Recycled metals'], risk: 'Low' },
    { id: 'santiago', name: 'Santiago', country: 'Chile', type: 'supplier', lat: -33.4489, lon: -70.6693, subtitle: 'Andean Copper Ltd.', description: 'Competitive access to Chilean production, with a long transit time and more capital tied up.', commodities: ['Copper cathodes', 'Copper concentrate', 'Molybdenum'], risk: 'Medium' },
    { id: 'dubai', name: 'Dubai', country: 'UAE', type: 'supplier', lat: 25.2048, lon: 55.2708, subtitle: 'Meridian Resources DMCC', description: 'Aggressive premiums, but higher counterparty and compliance risk.', commodities: ['Base metals', 'Oil products', 'Trade finance'], risk: 'High' },
    { id: 'casablanca', name: 'Casablanca', country: 'Morocco', type: 'supplier', lat: 33.5731, lon: -7.5898, subtitle: 'Atlas Fertilizers SA', description: 'North African fertilizer hub with short transit times into the Mediterranean.', commodities: ['Urea', 'Phosphates', 'Fertilizers'], risk: 'Medium', locked: true },
    { id: 'rotterdam', name: 'Rotterdam', country: 'Netherlands', type: 'port', lat: 51.9244, lon: 4.4777, subtitle: 'European Logistics Hub', description: 'Unlockable logistics hub with storage, blending and access to more European customers.', commodities: ['Metals', 'Energy', 'Storage'], risk: 'Low', locked: true },
    { id: 'singapore', name: 'Singapore', country: 'Singapore', type: 'port', lat: 1.3521, lon: 103.8198, subtitle: 'Asia Trading Hub', description: 'Advanced market unlocked by increasing reputation and capital.', commodities: ['Metals', 'Oil', 'Freight'], risk: 'Medium', locked: true },
    { id: 'santos', name: 'Santos', country: 'Brazil', type: 'supplier', lat: -23.9608, lon: -46.3336, subtitle: 'Santos Export Terminal', description: 'Main export gateway for Brazilian coffee and soft commodities.', commodities: ['Coffee', 'Sugar', 'Soybeans'], risk: 'Medium', locked: true },
    { id: 'rosario', name: 'Rosario', country: 'Argentina', type: 'supplier', lat: -32.9442, lon: -60.6505, subtitle: 'Paraná Grain Corridor', description: 'Agricultural origination with high seasonality, quality risk and river-level risk.', commodities: ['Wheat', 'Corn', 'Soymeal'], risk: 'Medium', locked: true },
    { id: 'port-hedland', name: 'Port Hedland', country: 'Australia', type: 'supplier', lat: -20.3107, lon: 118.6011, subtitle: 'Pilbara Bulk Export Hub', description: 'Large dry-bulk iron ore cargoes with heavy exposure to freight and port scheduling.', commodities: ['Iron ore', 'Manganese', 'Dry bulk'], risk: 'Low', locked: true },
    { id: 'shanghai', name: 'Shanghai', country: 'China', type: 'customer', lat: 31.2304, lon: 121.4737, subtitle: 'Yangtze Industrial Market', description: 'Large-scale steel and industrial demand with strict quality and laycan discipline.', commodities: ['Iron ore', 'Copper', 'Energy'], risk: 'Medium', locked: true },
    { id: 'doha', name: 'Doha', country: 'Qatar', type: 'supplier', lat: 25.2854, lon: 51.5310, subtitle: 'Qatar Energy Trading', description: 'World-class LNG infrastructure with competitive FOB loading programs and strict vessel vetting.', commodities: ['LNG', 'Condensates', 'Crude oil'], risk: 'Low', locked: true },
    { id: 'klang', name: 'Port Klang', country: 'Malaysia', type: 'supplier', lat: 3.0333, lon: 101.3833, subtitle: 'Malaysian Agri-Hub', description: 'Leading palm oil export terminal with grading, storage and RSPO sustainability documentation.', commodities: ['Palm oil', 'Tropical agris', 'Rubber'], risk: 'Low', locked: true },
    { id: 'abidjan', name: 'Abidjan', country: 'Ivory Coast', type: 'supplier', lat: 5.3600, lon: -4.0083, subtitle: "Côte d'Ivoire Cocoa Terminal", description: "World’s largest cocoa exporting port. Quality grading, humidity control and export certification are critical. High-margin origin for premium European buyers.", commodities: ['Cocoa', 'Cashew', 'Rubber'], risk: 'Medium', locked: true },
    { id: 'new-orleans', name: 'New Orleans', country: 'USA', type: 'supplier', lat: 29.9511, lon: -90.0715, subtitle: 'Gulf Coast Grain Export Hub', description: 'Dominant US grain and oilseed export corridor with access to Midwest origination, deep-water loading and competitive Gulf Coast basis.', commodities: ['Soybeans', 'Corn', 'Soy meal'], risk: 'Low', locked: true },
    { id: 'antwerp', name: 'Antwerp', country: 'Belgium', type: 'port', lat: 51.2194, lon: 4.4025, subtitle: 'ARA Chemical & Metals Hub', description: "Europe's largest chemical port and leading steel import terminal. Deep connections to Rhine hinterland and direct access to Northern European buyers.", commodities: ['Steel', 'Chemicals', 'Non-ferrous metals'], risk: 'Low', locked: true },
    { id: 'durban', name: 'Durban', country: 'South Africa', type: 'supplier', lat: -29.8587, lon: 31.0218, subtitle: 'Southern Africa Metals Gateway', description: 'Africa\'s busiest port and key conduit for Zambian copper, South African manganese and chrome ore. Deep-water quays handle Capesize bulk vessels.', commodities: ['Copper', 'Chrome ore', 'Zinc', 'Coal'], risk: 'Medium', locked: true },
    { id: 'houston', name: 'Houston', country: 'USA', type: 'supplier', lat: 29.7604, lon: -95.3698, subtitle: 'US Gulf Energy Hub', description: 'America\'s premier energy export gateway. Home to LNG liquefaction terminals, petrochemical complexes and grain elevator networks.', commodities: ['LNG', 'Crude', 'Petrochemicals', 'Grain'], risk: 'Low', locked: true }
  ];


  // ── v33 progressive trading-house expansion ────────────────────────────────
  const moduleUnlockLevels = {
    portfolio: 1,   opportunities: 1,   // aprire e seguire il primo cargo
    inventory: 2,   operations: 2,      // il cargo è in viaggio: merce e documenti
    events: 3,                          // il mondo comincia a interferire
    risk: 4,        contracts: 4,       // più posizioni, fatture da incassare
    counterparties: 5, finance: 5,      // relazioni e tesoreria
    fleet: 6,       academy: 6,
    rivals: 7,      supply: 7,
    compliance: 8,  career: 8,
    expansion: 9,   hq: 9,              // la casa di trading inizia a crescere
    strategy: 11,   performance: 11,
    shop: 13,       empire: 13,
    leaderboard: 15,
  };

  const commodityUnlockLevels = {
    'Copper': 1, 'Aluminium': 4, 'Urea': 6, 'Diesel': 8, 'Coffee': 10,
    'Wheat': 11, 'Palm oil': 13, 'Cocoa': 14, 'Iron ore': 16, 'Steel': 18,
    'Zinc': 20, 'LNG': 22, 'Nickel': 25, 'Soybeans': 26
  };
  const countryUnlockLevels = {
    'Switzerland': 1, 'Estonia': 1, 'Italy': 1, 'Chile': 2, 'UAE': 3,
    'Morocco': 6, 'Netherlands': 8, 'Belgium': 8, 'Brazil': 10,
    'Argentina': 11, 'Singapore': 12, 'Malaysia': 13, 'Ivory Coast': 14,
    'Australia': 16, 'China': 18, 'South Africa': 20, 'Qatar': 22, 'USA': 23
  };
  function countryAccessTier(country) {
    const level = countryRequiredLevel(country);
    if (level <= 1) return 'Starter corridor';
    if (level <= 6) return 'Developing origin';
    if (level <= 14) return 'Established commodity market';
    if (level <= 20) return 'Resource powerhouse';
    return 'Strategic resource market';
  }
  const expansionMilestones = [
    { level:1, title:'Geneva Micro Merchant', text:'Copper only · Baltic Metals OU → Lombardia Cables' },
    { level:2, title:'European Copper Desk', text:'Chile and a second copper supplier become accessible' },
    { level:3, title:'Emerging-Market Merchant', text:'The UAE copper corridor becomes accessible' },
    { level:4, title:'Base Metals Trader', text:'Aluminium unlocks' },
    { level:6, title:'Mediterranean Merchant', text:'Morocco and urea unlock' },
    { level:8, title:'ARA Trading House', text:'Netherlands, Belgium and diesel unlock' },
    { level:10, title:'Atlantic Softs Desk', text:'Brazil and coffee unlock' },
    { level:12, title:'International Merchant', text:'Singapore hub unlocks' },
    { level:16, title:'Bulk Commodity House', text:'Australia and iron ore unlock' },
    { level:20, title:'African Metals Merchant', text:'South Africa and zinc unlock' },
    { level:22, title:'Global Energy Trader', text:'Qatar and LNG unlock' },
    { level:25, title:'Integrated Global House', text:'Nickel and the hardest origins unlock' }
  ];
  function playerLevel() { return Math.max(1, Number(state?.xpLevel || 1)); }
  function commodityRequiredLevel(name) { return commodityUnlockLevels[name] || 1; }
  function countryRequiredLevel(country) { return countryUnlockLevels[country] || 1; }
  function commodityUnlocked(name) { return playerLevel() >= commodityRequiredLevel(name); }
  function countryUnlocked(country) { return playerLevel() >= countryRequiredLevel(country); }
  function opportunityProgressionRequirements(opp) {
    const routeHubs = [opp.origin, opp.destination, ...(opp.via || [])].map(getHub).filter(Boolean);
    const countryLevels = routeHubs.map(h => ({ country:h.country, level:countryRequiredLevel(h.country) }));
    const requiredLevel = Math.max(commodityRequiredLevel(opp.commodity), ...countryLevels.map(x=>x.level), 1);
    const lockedCountries = countryLevels.filter(x => playerLevel() < x.level);
    return { requiredLevel, commodityLevel:commodityRequiredLevel(opp.commodity), lockedCountries };
  }
  function expansionStage() {
    const level=playerLevel();
    return [...expansionMilestones].reverse().find(m=>level>=m.level) || expansionMilestones[0];
  }
  function nextExpansionUnlock() {
    const level=playerLevel();
    return expansionMilestones.find(m=>m.level>level) || null;
  }
  function newlyUnlockedAtLevel(level) {
    const countries=Object.entries(countryUnlockLevels).filter(([,v])=>v===level).map(([k])=>k);
    const commodities=Object.entries(commodityUnlockLevels).filter(([,v])=>v===level).map(([k])=>k);
    const offices=(typeof officeCatalog !== 'undefined' ? officeCatalog : []).filter(office=>office.id!=='geneva' && office.minLevel===level).map(office=>`${office.city} office`);
    return { countries, commodities, offices };
  }
  // ── v50 · requisiti di sblocco leggibili ────────────────────────────────────
  // Il gioco aveva due sistemi sovrapposti: i livelli XP (visibili, con tabelle di
  // commodity e paesi) e le funzioni `unlock` (invisibili, che chiedono uffici,
  // cargo chiusi e reputazione). Il secondo e' quello che decide davvero, ma il
  // giocatore vedeva solo "Requires a larger balance sheet, reputation or regional
  // office". Qui i predicati vengono letti e tradotti in requisiti espliciti.
  const _unlockCache = new Map();
  function unlockRequirements(opp) {
    if (!opp || typeof opp.unlock !== 'function') return { offices: [], officesMode: 'any', deals: 0, reputation: 0, parsed: true, always: true };
    if (_unlockCache.has(opp.id)) return _unlockCache.get(opp.id);
    const source = String(opp.unlock);
    const body = source.slice(source.indexOf('=>') + 2).trim();
    const result = { offices: [], officesMode: 'any', deals: 0, reputation: 0, parsed: false, always: false };
    if (/^true;?$/.test(body)) { result.parsed = true; result.always = true; _unlockCache.set(opp.id, result); return result; }

    const officeIds = [...body.matchAll(/officeOwned\('([a-z-]+)'\)/g)].map(m => m[1]);
    result.offices = [...new Set(officeIds)];
    // "A || B" = uno qualsiasi; "A && B" fra due uffici = servono entrambi
    const officeSegment = body.split('&&')[0];
    result.officesMode = (result.offices.length > 1 && !/\|\|/.test(officeSegment)) ? 'all' : 'any';
    const deals = body.match(/completedDeals\s*>=\s*(\d+)/);
    if (deals) result.deals = Number(deals[1]);
    const reputation = body.match(/reputation\s*>=\s*(\d+)/);
    if (reputation) result.reputation = Number(reputation[1]);
    // riconosciuto tutto? (nessun altro riferimento allo stato che non sappiamo leggere)
    const known = body.replace(/officeOwned\('[a-z-]+'\)/g, '')
      .replace(/s\.completedDeals\s*>=\s*\d+/g, '')
      .replace(/s\.reputation\s*>=\s*\d+/g, '')
      .replace(/[()&|\s;]/g, '');
    result.parsed = known.length === 0;
    _unlockCache.set(opp.id, result);
    return result;
  }

  // Elenco dei requisiti ancora mancanti, con il progresso attuale.
  function missingUnlockRequirements(opp) {
    const missing = [];
    if (!opp) return missing;
    const progression = opportunityProgressionRequirements(opp);
    if (playerLevel() < progression.commodityLevel) {
      missing.push({ kind: 'level', label: `${opp.commodity} trading licence at level ${progression.commodityLevel}`, progress: `level ${playerLevel()}/${progression.commodityLevel}` });
    }
    progression.lockedCountries.forEach(entry => {
      // v52 - reintegrata la descrizione del corridoio, persa nella riscrittura v50
      missing.push({ kind: 'level', label: `${entry.country} \u2014 ${countryAccessTier(entry.country).toLowerCase()} \u2014 at level ${entry.level}`, progress: `level ${playerLevel()}/${entry.level}` });
    });
    const requirements = unlockRequirements(opp);
    if (requirements.always) return missing;
    if (!requirements.parsed) {
      if (typeof opp.unlock === 'function' && !opp.unlock(state)) {
        missing.push({ kind: 'other', label: 'Additional balance-sheet or network requirements', progress: '' });
      }
      return missing;
    }
    const ownedOffices = requirements.offices.filter(id => officeOwned(id));
    const officeNames = requirements.offices.map(id => getOffice(id)?.city || id);
    if (requirements.offices.length) {
      const satisfied = requirements.officesMode === 'all' ? ownedOffices.length === requirements.offices.length : ownedOffices.length > 0;
      if (!satisfied) {
        missing.push({
          kind: 'office',
          label: requirements.officesMode === 'all' ? `Offices in ${officeNames.join(' and ')}` : `An office in ${officeNames.join(' or ')}`,
          progress: `${ownedOffices.length}/${requirements.officesMode === 'all' ? requirements.offices.length : 1}`,
          officeIds: requirements.offices.filter(id => !officeOwned(id)),
        });
      }
    }
    if (requirements.deals && (state.completedDeals || 0) < requirements.deals) {
      missing.push({ kind: 'deals', label: `${requirements.deals} cargoes settled`, progress: `${state.completedDeals || 0}/${requirements.deals}` });
    }
    if (requirements.reputation && (state.reputation || 0) < requirements.reputation) {
      missing.push({ kind: 'reputation', label: `Reputation ${requirements.reputation}`, progress: `${Math.round(state.reputation || 0)}/${requirements.reputation}` });
    }
    return missing;
  }

  // Versione compatta per le card: il primo ostacolo, piu' il conteggio del resto.
  function unlockReason(opp) {
    const missing = missingUnlockRequirements(opp);
    if (!missing.length) return '';
    const first = missing[0];
    const head = first.progress ? `${first.label} \u00b7 ${first.progress}` : first.label;
    return missing.length > 1 ? `${head} \u00b7 +${missing.length - 1} more` : head;
  }

  // Versione estesa per l'inspector: elenco con spunta e progresso.
  function unlockChecklistHtml(opp) {
    const missing = missingUnlockRequirements(opp);
    if (!missing.length) return '';
    const icons = { level: '\u2605', office: '\u2302', deals: '\u2713', reputation: '\u25C6', other: '\u2022' };
    return `<div class="unlock-checklist">
      <strong>To open this corridor you still need</strong>
      <ul>${missing.map(item => `<li class="unlock-need ${item.kind}"><i>${icons[item.kind] || '\u2022'}</i><span>${item.label}</span>${item.progress ? `<em>${item.progress}</em>` : ''}</li>`).join('')}</ul>
      ${missing.some(item => item.kind === 'office') ? '<button type="button" class="unlock-goto" data-empty-action="module:expansion">Open the growth office</button>' : ''}
    </div>`;
  }


  // ── v34 strategic growth: HQ, desk specialisation, franchise and playbooks ──
  const hqTierCatalog = [
    { tier:1, name:'Geneva Micro Office', minLevel:1, cost:0, buildDays:0, dailyCost:0, pnlBonus:0, acceptance:0, equityFactor:1, durationBonus:0, riskReduction:0, creditBonus:0, description:'A small Geneva office with one trader, outsourced operations and limited banking capacity.' },
    { tier:2, name:'Geneva Trading Floor', minLevel:3, cost:180_000, buildDays:5, dailyCost:450, pnlBonus:3_500, acceptance:1, equityFactor:.99, durationBonus:0, riskReduction:1, creditBonus:150_000, description:'A dedicated trading floor with basic middle-office support and stronger bank visibility.' },
    { tier:3, name:'Geneva Merchant House', minLevel:8, cost:650_000, buildDays:10, dailyCost:1_250, pnlBonus:9_000, acceptance:3, equityFactor:.97, durationBonus:1, riskReduction:3, creditBonus:500_000, description:'An established merchant platform with integrated risk, finance, operations and legal teams.' },
    { tier:4, name:'Global Trading Campus', minLevel:16, cost:2_100_000, buildDays:18, dailyCost:3_200, pnlBonus:20_000, acceptance:5, equityFactor:.94, durationBonus:2, riskReduction:6, creditBonus:1_250_000, description:'A global command centre coordinating regional desks, physical assets and bank syndicates.' },
    { tier:5, name:'Integrated Merchant Tower', minLevel:24, cost:6_000_000, buildDays:30, dailyCost:7_500, pnlBonus:42_000, acceptance:8, equityFactor:.90, durationBonus:3, riskReduction:10, creditBonus:3_000_000, description:'A fully integrated global merchant with institutional funding, specialist desks and permanent crisis capacity.' }
  ];

  const deskSpecializationCatalog = {
    generalist: { id:'generalist', name:'General Merchant', icon:'◇', commodities:[], pnlFactor:1, nonCorePnlFactor:1, acceptance:0, equityFactor:1, riskAdjustment:0, description:'Balanced across all physical markets with no concentration bonus or penalty.' },
    metals: { id:'metals', name:'Metals & Mining', icon:'◆', commodities:['Copper','Aluminium','Iron ore','Steel','Zinc','Nickel'], pnlFactor:1.09, nonCorePnlFactor:.97, acceptance:5, equityFactor:.95, riskAdjustment:-1, description:'Stronger premiums, assays, warehousing and producer relationships across metals.' },
    energy: { id:'energy', name:'Energy & Molecules', icon:'◉', commodities:['Diesel','LNG'], pnlFactor:1.10, nonCorePnlFactor:.96, acceptance:5, equityFactor:.95, riskAdjustment:1, description:'Expertise in oil products, LNG, tankage, vessel vetting and energy finance.' },
    agriculture: { id:'agriculture', name:'Agriculture & Softs', icon:'✦', commodities:['Coffee','Wheat','Palm oil','Cocoa','Urea','Soybeans'], pnlFactor:1.085, nonCorePnlFactor:.97, acceptance:5, equityFactor:.96, riskAdjustment:0, description:'Origination, seasonality, quality control and destination distribution expertise.' }
  };

  const crisisPlaybookCatalog = {
    diversify: { id:'diversify', name:'Alternative sourcing task force', icon:'↗', cost:25_000, lossFactor:.72, durationReduction:2, acceptance:2, equityFactor:.98, creditBonus:0, financingRateShock:0, description:'Activate backup suppliers, substitute ports and alternative logistics.' },
    freight: { id:'freight', name:'Freight & insurance cover', icon:'⌁', cost:38_000, lossFactor:.58, durationReduction:1, acceptance:1, equityFactor:1, creditBonus:0, financingRateShock:0, freightRelief:.30, description:'Secure priority capacity, war-risk cover and delay protection.' },
    liquidity: { id:'liquidity', name:'Emergency liquidity protocol', icon:'$', cost:52_000, lossFactor:.86, durationReduction:0, acceptance:0, equityFactor:.90, creditBonus:600_000, financingRateShock:-.012, description:'Pre-fund margin, draw contingency facilities and protect working capital.' }
  };

  function hqCurrentTier() {
    const tier = clamp(Number(state?.hqTier || 1), 1, hqTierCatalog.length);
    return hqTierCatalog.find(item => item.tier === tier) || hqTierCatalog[0];
  }
  function hqNextTier() { return hqTierCatalog.find(item => item.tier === hqCurrentTier().tier + 1) || null; }
  function hqAdjustments() {
    const hq = hqCurrentTier();
    return { ...hq, equityFactor:hq.equityFactor || 1, pnlBonus:hq.pnlBonus || 0, acceptance:hq.acceptance || 0, durationBonus:hq.durationBonus || 0, riskReduction:hq.riskReduction || 0, creditBonus:hq.creditBonus || 0 };
  }
  function hqBookValue() {
    const commissioned = hqTierCatalog.filter(item => item.tier <= hqCurrentTier().tier).reduce((sum,item)=>sum+(item.cost||0),0) * .82;
    const workInProgress = state?.hqUpgrade ? (state.hqUpgrade.cost || 0) * .68 : 0;
    return Math.round(commissioned + workInProgress);
  }
  function startHQUpgrade() {
    const next = hqNextTier();
    if (!next || state.hqUpgrade) return;
    if (playerLevel() < next.minLevel) return showToast(`${next.name} unlocks at company level ${next.minLevel}.`);
    if (state.cash < next.cost) return showToast(`The HQ project requires ${money(next.cost)} cash.`);
    state.cash -= next.cost;
    state.hqUpgrade = { targetTier:next.tier, daysRemaining:next.buildDays, cost:next.cost, startedAt:state.date };
    recordJournal('Expansion', `${next.name} construction started`, `${next.buildDays}-day Geneva headquarters project.`, -next.cost, `hq-${next.tier}`);
    saveState(); renderAll(); showToast(`${next.name} construction started.`);
  }
  function processHQUpgradeDay() {
    const project = state.hqUpgrade;
    if (!project) return;
    project.daysRemaining = Math.max(0, (project.daysRemaining || 0) - 1);
    if (project.daysRemaining > 0) return;
    const delivered = hqTierCatalog.find(item => item.tier === project.targetTier);
    state.hqTier = project.targetTier;
    state.hqUpgrade = null;
    state.reputation = clamp((state.reputation || 0) + 3, 0, 100);
    state.worldEventFeed.unshift({ type:'expansion', title:`${delivered?.name || 'Geneva HQ'} completed`, date:state.date, description:'The new headquarters capacity is operational and now supports every trading desk.' });
    state.worldEventFeed = state.worldEventFeed.slice(0,18);
    recordJournal('Expansion', `${delivered?.name || 'HQ upgrade'} delivered`, 'Permanent capital, execution and risk-management benefits are now active.', 0, `hq-${state.hqTier}`);
  }

  function activeDeskSpecialization() { return deskSpecializationCatalog[state?.deskSpecialization] || deskSpecializationCatalog.generalist; }
  function specializationMatches(opp, specialization = activeDeskSpecialization()) { return !specialization.commodities.length || specialization.commodities.includes(opp?.commodity); }
  function deskSpecializationAdjustments(opp) {
    const specialization = activeDeskSpecialization();
    const core = specializationMatches(opp, specialization);
    return {
      specialization,
      core,
      pnlFactor: core ? specialization.pnlFactor : specialization.nonCorePnlFactor,
      acceptance: core ? specialization.acceptance : specialization.id === 'generalist' ? 0 : -2,
      equityFactor: core ? specialization.equityFactor : 1.02,
      riskAdjustment: specialization.riskAdjustment || 0
    };
  }
  function chooseDeskSpecialization(id) {
    const next = deskSpecializationCatalog[id];
    if (!next || next.id === state.deskSpecialization) return;
    if (playerLevel() < 3) return showToast('Desk specialisation unlocks at company level 3.');
    const firstChoice = !state.specializationChosen;
    const cooldown = 30 - ((state.dayIndex || 0) - (state.specializationChangedDay || -99));
    if (!firstChoice && cooldown > 0) return showToast(`Board mandate can change again in ${cooldown} days.`);
    const cost = firstChoice ? 0 : 90_000;
    if (state.cash < cost) return showToast(`Changing the desk mandate costs ${money(cost)}.`);
    state.cash -= cost;
    state.deskSpecialization = id;
    state.specializationChosen = true;
    state.specializationChangedDay = state.dayIndex || 0;
    recordJournal('Strategy', `${next.name} mandate adopted`, firstChoice ? 'Initial desk specialisation selected.' : `Board transition cost ${money(cost)}.`, -cost, id);
    saveState(); renderAll(); showToast(`${next.name} is now the core desk specialisation.`);
  }

  function ensureMarketReputation() {
    state.marketReputation = state.marketReputation || { countries:{}, commodities:{} };
    state.marketReputation.countries = state.marketReputation.countries || {};
    state.marketReputation.commodities = state.marketReputation.commodities || {};
    if (!Number.isFinite(state.marketReputation.countries.Switzerland)) state.marketReputation.countries.Switzerland = 50;
    if (!Number.isFinite(state.marketReputation.countries.Estonia)) state.marketReputation.countries.Estonia = 35;
    if (!Number.isFinite(state.marketReputation.countries.Italy)) state.marketReputation.countries.Italy = 35;
    if (!Number.isFinite(state.marketReputation.commodities.Copper)) state.marketReputation.commodities.Copper = 35;
    return state.marketReputation;
  }
  function marketReputationAdjustments(opp) {
    const reputation = ensureMarketReputation();
    const origin = getHub(opp?.origin)?.country;
    const destination = getHub(opp?.destination)?.country;
    const countryScores = [origin, destination].filter(Boolean).map(country => reputation.countries[country] ?? 12);
    const commodityScore = reputation.commodities[opp?.commodity] ?? 12;
    const score = Math.round((commodityScore * 1.4 + countryScores.reduce((a,b)=>a+b,0)) / (1.4 + countryScores.length));
    return {
      score,
      acceptance: clamp(Math.round((score - 25) / 8), -3, 7),
      pnlBonus: Math.max(0, Math.round((score - 35) * 420)),
      equityFactor: clamp(1 - Math.max(0, score - 40) * .0011, .94, 1),
      complianceReduction: Math.max(0, Math.round((score - 25) * .22))
    };
  }
  function updateMarketReputationAfterDeal(opp, pnl, readiness) {
    const reputation = ensureMarketReputation();
    const move = pnl >= 0 && readiness >= 85 ? 4 : pnl < 0 || readiness < 70 ? -3 : 1;
    const countries = [getHub(opp.origin)?.country, getHub(opp.destination)?.country].filter(Boolean);
    countries.forEach(country => reputation.countries[country] = clamp((reputation.countries[country] ?? 12) + move, 0, 100));
    reputation.commodities[opp.commodity] = clamp((reputation.commodities[opp.commodity] ?? 12) + move, 0, 100);
  }

  function commercialFrameworkFor(oppId) {
    const framework = state?.commercialFrameworks?.[oppId];
    return framework && framework.status === 'active' && framework.daysRemaining > 0 ? framework : null;
  }
  function commercialFrameworkAdjustments(opp) {
    const framework = commercialFrameworkFor(opp?.id);
    if (!framework) return { framework:null, pnlBonus:0, acceptance:0, equityFactor:1, durationBonus:0 };
    return { framework, pnlBonus:framework.pnlBonus || 0, acceptance:framework.acceptance || 0, equityFactor:framework.equityFactor || 1, durationBonus:framework.durationBonus || 0 };
  }
  function signCommercialFramework(oppId) {
    const opp = getOpportunity(oppId);
    if (!opp || !isOpportunityUnlocked(opp)) return;
    state.commercialFrameworks = state.commercialFrameworks || {};
    if (commercialFrameworkFor(oppId)) return showToast('A framework agreement is already active on this corridor.');
    if (playerLevel() < 3 || state.completedDeals < 1) return showToast('Framework agreements require level 3 and at least one completed cargo.');
    const activeCount = Object.values(state.commercialFrameworks).filter(item => item?.status === 'active' && item.daysRemaining > 0).length;
    if (activeCount >= Math.max(1, hqCurrentTier().tier - 1)) return showToast('Upgrade Geneva HQ to manage more simultaneous framework agreements.');
    const cost = clamp(Math.round(opp.capital * .025), 45_000, 180_000);
    if (state.cash < cost) return showToast(`Signing and legal work require ${money(cost)}.`);
    const parties = partiesForOpportunity(opp);
    state.cash -= cost;
    state.commercialFrameworks[oppId] = {
      opportunityId:oppId, status:'active', signedAt:state.date, daysRemaining:120,
      commitments:3, lifts:0, cost, shortfallPenalty:Math.round(cost * 1.65),
      pnlBonus:Math.max(8_000, Math.round(opp.basePnl * .12)), acceptance:6,
      equityFactor:.95, durationBonus:2, supplierId:parties.supplierId, buyerId:parties.buyerId
    };
    recordJournal('Commercial', `${opp.title}: framework signed`, '120-day supplier and buyer framework with three committed cargoes.', -cost, oppId);
    saveState(); renderAll(); showToast(`Framework signed for ${opp.title}. Three cargoes committed.`);
  }
  function registerCommercialFrameworkLift(opp, deal) {
    const framework = commercialFrameworkFor(opp?.id);
    if (!framework) return;
    framework.lifts = (framework.lifts || 0) + 1;
    deal.commercialFrameworkId = opp.id;
    if (framework.lifts >= framework.commitments && !framework.fulfilledAt) {
      framework.fulfilledAt = state.date;
      state.reputation = clamp((state.reputation || 0) + 2, 0, 100);
      recordJournal('Commercial', `${opp.title}: commitment fulfilled`, `${framework.lifts}/${framework.commitments} framework cargoes booked.`, 0, opp.id);
    }
  }
  function processCommercialFrameworks() {
    Object.values(state.commercialFrameworks || {}).forEach(framework => {
      if (!framework || framework.status !== 'active') return;
      framework.daysRemaining = Math.max(0, (framework.daysRemaining || 0) - 1);
      if (framework.daysRemaining > 0) return;
      const opp = getOpportunity(framework.opportunityId);
      const shortfall = Math.max(0, (framework.commitments || 0) - (framework.lifts || 0));
      if (shortfall > 0) {
        const penalty = Math.round((framework.shortfallPenalty || 0) * shortfall / Math.max(1, framework.commitments || 1));
        state.cash -= penalty;
        state.realizedPnl -= penalty;
        state.reputation = clamp((state.reputation || 0) - Math.min(6, shortfall * 2), 0, 100);
        recordJournal('Commercial', `${opp?.title || 'Framework'}: take-or-pay shortfall`, `${shortfall} committed cargo${shortfall===1?'':'es'} not lifted.`, -penalty, framework.opportunityId);
      } else {
        state.reputation = clamp((state.reputation || 0) + 2, 0, 100);
        recordJournal('Commercial', `${opp?.title || 'Framework'} completed`, 'All committed cargoes were lifted within the contract period.', 0, framework.opportunityId);
      }
      framework.status = shortfall ? 'expired-shortfall' : 'fulfilled';
    });
  }

  function crisisResponseFor(eventId) {
    const response = state?.crisisResponses?.[eventId];
    if (!response || response.status !== 'active') return null;
    if (!state.activeGlobalEvents?.some(event => event.id === eventId)) return null;
    return response;
  }
  function crisisResponseAdjustments(event) {
    const response = crisisResponseFor(event?.id);
    const playbook = response ? crisisPlaybookCatalog[response.playbookId] : null;
    return playbook || { lossFactor:1, durationReduction:0, acceptance:0, equityFactor:1, creditBonus:0, financingRateShock:0 };
  }
  function activateCrisisResponse(eventId, playbookId) {
    const active = state.activeGlobalEvents?.find(event => event.id === eventId);
    const definition = activeEventDefinition(active || {});
    const playbook = crisisPlaybookCatalog[playbookId];
    if (!active || !definition || !playbook) return;
    state.crisisResponses = state.crisisResponses || {};
    if (crisisResponseFor(eventId)) return showToast('A crisis playbook is already active for this event.');
    if (state.cash < playbook.cost) return showToast(`${playbook.name} requires ${money(playbook.cost)} cash.`);
    state.cash -= playbook.cost;
    state.realizedPnl -= playbook.cost;
    let recovered = 0;
    let cargoes = 0;
    state.activeDeals.forEach(deal => {
      if (!(deal.globalEventImpacts || []).includes(eventId)) return;
      const recovery = definition.dealPnl < 0 ? Math.round(-definition.dealPnl * (1 - playbook.lossFactor)) : 0;
      deal.pnlAdjustments += recovery;
      deal.duration = Math.max(deal.elapsed + 1, deal.duration - (playbook.durationReduction || 0));
      recovered += recovery;
      cargoes += 1;
    });
    if (playbook.freightRelief && definition.freightShock > 0) state.freightIndex = clamp(state.freightIndex - definition.freightShock * playbook.freightRelief, 68, 175);
    state.crisisResponses[eventId] = { eventId, playbookId, status:'active', activatedAt:state.date, cost:playbook.cost, recovered, cargoes };
    state.riskLedger.unshift({ id:`response-${eventId}-${state.dayIndex}`, date:state.date, category:'Crisis response', title:playbook.name, severity:'low', impact:recovered-playbook.cost, affectedCargoes:cargoes, description:`Response to ${definition.title}.` });
    state.riskLedger = state.riskLedger.slice(0,40);
    recordJournal('Risk', `${definition.title}: ${playbook.name}`, `${cargoes} live cargoes protected · recovery ${money(recovered)}.`, recovered-playbook.cost, eventId);
    saveState(); renderAll(); showToast(`${playbook.name} activated for ${definition.title}.`);
  }

  const opportunities = [
    {
      id: 'baltic-copper', origin: 'tallinn', destination: 'brescia', via: [], commodity: 'Copper', quantity: 175,
      capital: 1_650_000, equity: 240_000, basePnl: 38_000, duration: 28, risk: 'Low', riskClass: 'low', priceKey: 'copper', recommendedHedge: 100, transportMode: 'Rail / Truck',
      title: 'Baltic Express', description: 'Short overland route, lower capital usage and manageable documentary risk.',
      unlock: () => true,
      event: {
        dayRatio: .43,
        title: 'Incomplete quality certificate',
        text: 'The certificate received is missing a specification required by the customer. The cargo is already in transit.',
        choices: [
          { id: 'inspect', label: 'Order an independent inspection', hint: 'Cost $7,500 · protects reputation and reduces the claim', pnl: -7_500, days: 1, reputation: 1, result: 'The inspection confirms compliance and the customer accepts the documents.' },
          { id: 'accept', label: 'Accept the documentary risk', hint: 'No immediate cost · possible claim at delivery', random: true, good: { pnl: 0, reputation: 0, result: 'The customer accepts the documentation without objection.' }, bad: { pnl: -24_000, reputation: -4, result: 'The customer applies a discount for incomplete documentation.' } }
        ]
      }
    },
    {
      id: 'andean-copper', origin: 'santiago', destination: 'brescia', via: ['genova'], commodity: 'Copper', quantity: 500,
      capital: 3_600_000, equity: 600_000, basePnl: 76_000, duration: 65, risk: 'Medium', riskClass: 'medium', priceKey: 'copper', recommendedHedge: 80, transportMode: 'Ocean / Truck',
      title: 'Andean Atlantic', description: 'Higher margin, strong production origin and a long ocean route via Genoa.',
      unlock: () => true,
      event: {
        dayRatio: .52,
        title: 'Atlantic storm',
        text: 'The vessel loses speed and may miss the delivery window in Brescia.',
        choices: [
          { id: 'wait', label: 'Maintain the route to Genoa', hint: 'Cost $15,000 · estimated delay 8 days', pnl: -15_000, days: 8, reputation: -1, result: 'The vessel arrives late, but the customer accepts the revised window.' },
          { id: 'reroute', label: 'Reroute to Rotterdam', hint: 'Cost $32,000 · reduces the delay to 4 days', pnl: -32_000, days: 4, reputation: 2, result: 'The rerouting protects the customer but compresses the margin.' }
        ]
      }
    },
    {
      id: 'meridian-copper', origin: 'dubai', destination: 'brescia', via: ['genova'], commodity: 'Copper', quantity: 500,
      capital: 3_200_000, equity: 480_000, basePnl: 104_000, duration: 48, risk: 'High', riskClass: 'high', priceKey: 'copper', recommendedHedge: 60, transportMode: 'Ocean / Truck',
      title: 'Meridian Premium', description: 'Attractive premium, but compliance and quality require deeper checks.',
      unlock: () => true,
      event: {
        dayRatio: .31,
        title: 'Counterparty compliance alert',
        text: 'The bank flags an opaque ownership structure before processing the letter of credit.',
        choices: [
          { id: 'kyc', label: 'Launch enhanced KYC', hint: 'Cost $12,000 · 5 days · reduces risk', pnl: -12_000, days: 5, reputation: 3, result: 'Enhanced due diligence clarifies the structure and the bank proceeds.' },
          { id: 'proceed', label: 'Proceed without further checks', hint: 'Preserve the margin · risk of blockage and sanctions', random: true, good: { pnl: 0, reputation: -1, result: 'The bank processes the payment, but the risk desk flags the decision.' }, bad: { pnl: -90_000, reputation: -12, result: 'The bank blocks the payment and the deal closes with a significant loss.' } },
          { id: 'cancel', label: 'Cancel the deal', hint: 'Certain $35,000 loss · preserves compliance', pnl: -139_000, days: 0, reputation: 1, result: 'The deal is terminated early and the remaining capital is released.', forceComplete: true }
        ]
      }
    },
    {
      id: 'rotterdam-alloy', origin: 'rotterdam', destination: 'brescia', via: [], commodity: 'Aluminium', quantity: 350,
      capital: 2_100_000, equity: 330_000, basePnl: 59_000, duration: 24, risk: 'Low', riskClass: 'low', priceKey: 'aluminium', recommendedHedge: 100, transportMode: 'Barge / Rail',
      title: 'Rhine–Alps Alloy', description: 'High-turnover European corridor available after opening the Rotterdam desk.',
      unlock: (s) => officeOwned('rotterdam')
    },
    {
      id: 'maghreb-urea', origin: 'casablanca', destination: 'brescia', via: ['genova'], commodity: 'Urea', quantity: 900,
      capital: 1_800_000, equity: 280_000, basePnl: 64_000, duration: 21, risk: 'Medium', riskClass: 'medium', priceKey: 'urea', recommendedHedge: 70, transportMode: 'Coaster / Truck',
      title: 'Maghreb Nutrients', description: 'Urea parcel from North Africa to the Italian agricultural market. Fast margin, but quality and port congestion require strong execution.',
      unlock: (s) => (officeOwned('casablanca') || officeOwned('genova')) && s.completedDeals >= 2,
      event: {
        dayRatio: .48,
        title: 'Congestion at the fertilizer terminal',
        text: 'The Genoa terminal reports a discharge delay. The cargo faces extra storage and a potential missed delivery.',
        choices: [
          { id: 'priority-berth', label: 'Buy berth priority', hint: 'Cost $11,000 · protects ETA and customer relationship', pnl: -11_000, days: 1, reputation: 2, result: 'The priority slot allows discharge close to schedule.' },
          { id: 'wait-urea', label: 'Wait for the standard slot', hint: 'No upfront cost · 4 days and claim risk', random: true, good: { pnl: -6_000, days: 4, reputation: 0, result: 'The delay remains manageable and the customer accepts the revised ETA.' }, bad: { pnl: -28_000, days: 6, reputation: -3, result: 'The customer files a claim and the terminal charges extra storage.' } }
        ]
      }
    },
    {
      id: 'asia-aluminium', origin: 'dubai', destination: 'singapore', via: [], commodity: 'Aluminium', quantity: 600,
      capital: 2_800_000, equity: 430_000, basePnl: 96_000, duration: 25, risk: 'Medium', riskClass: 'medium', priceKey: 'aluminium', recommendedHedge: 100, transportMode: 'Multipurpose vessel',
      title: 'Gulf–Asia Aluminium', description: 'Regional arbitrage into Singapore with high turnover and strict documentary discipline.',
      unlock: (s) => (officeOwned('singapore') || officeOwned('dubai')),
      event: {
        dayRatio: .36,
        title: 'Letter-of-credit discrepancy',
        text: 'The receiving bank identifies a mismatch between the cargo description and packing list.',
        choices: [
          { id: 'amend-lc', label: 'Request an immediate amendment', hint: 'Cost $8,500 · 2 days · protects settlement', pnl: -8_500, days: 2, reputation: 2, result: 'The amendment is accepted and the documents become compliant.' },
          { id: 'waiver', label: 'Request a waiver from the buyer', hint: 'Low cost · depends on the commercial relationship', random: true, good: { pnl: -2_000, days: 1, reputation: 1, result: 'The buyer grants the waiver and the bank processes the documents.' }, bad: { pnl: -35_000, days: 5, reputation: -4, result: 'The buyer rejects the waiver and payment is delayed.' } }
        ]
      }
    },
    {
      id: 'atlantic-diesel', origin: 'houston', destination: 'rotterdam', via: [], commodity: 'Diesel', quantity: 18000,
      capital: 8_600_000, equity: 1_250_000, basePnl: 210_000, duration: 27, risk: 'Medium', riskClass: 'medium', priceKey: 'crude', recommendedHedge: 90, transportMode: 'Product tanker',
      title: 'Gulf–ARA Distillates', description: 'Energy cargo from the Gulf Coast to the ARA market. Heavy working-capital use, crack/basis risk and strict quality management.',
      unlock: s => (officeOwned('houston') || officeOwned('rotterdam')) && s.completedDeals >= 3 && s.reputation >= 62,
      event: { dayRatio: .46, title: 'Off-spec sulfur test', text: 'The discharge laboratory reports sulphur content close to the contractual limit.', choices: [
        { id: 'retest-fuel', label: 'Appoint an independent inspector', hint: 'Cost $18,000 · protects the documentary position', pnl: -18_000, days: 2, reputation: 2, result: 'The retest confirms compliance and the buyer accepts the cargo.' },
        { id: 'blend-fuel', label: 'Arrange terminal blending', hint: 'Cost $42,000 · reduces claim and delay risk', pnl: -42_000, days: 3, reputation: 3, result: 'Blending brings the product fully on specification.' },
        { id: 'waive-fuel', label: 'Negotiate a discount with the buyer', hint: 'Fast · possible major margin reduction', random: true, good: { pnl: -26_000, days: 0, reputation: 0, result: 'The buyer accepts a small allowance.' }, bad: { pnl: -105_000, days: 2, reputation: -5, result: 'The buyer applies a significant quality claim.' } }
      ]}
    },
    {
      id: 'brazil-coffee', origin: 'santos', destination: 'brescia', via: ['genova'], commodity: 'Coffee', quantity: 600,
      capital: 3_150_000, equity: 470_000, basePnl: 102_000, duration: 38, risk: 'Medium', riskClass: 'medium', priceKey: 'coffee', recommendedHedge: 80, transportMode: 'Container / Truck',
      title: 'Santos Coffee Flow', description: 'Brazilian arabica origination for a European buyer. Quality differentials, FX and phytosanitary documents are central.',
      unlock: s => (officeOwned('santos') || officeOwned('genova')) && s.completedDeals >= 3 && s.reputation >= 58,
      event: { dayRatio: .58, title: 'Moisture deviation', text: 'The inspection detects moisture above the expected level in part of the bags.', choices: [
        { id: 'dry-coffee', label: 'Recondition and dry the cargo', hint: 'Cost $21,000 · 3 days · preserves quality', pnl: -21_000, days: 3, reputation: 2, result: 'The lot is reconditioned and delivered on specification.' },
        { id: 'discount-coffee', label: 'Grant a quality allowance', hint: 'No delay · uncertain commercial loss', random: true, good: { pnl: -16_000, days: 0, reputation: 1, result: 'The buyer accepts a limited allowance.' }, bad: { pnl: -54_000, days: 0, reputation: -2, result: 'The buyer imposes a large quality differential.' } }
      ]}
    },
    {
      id: 'argentina-wheat', origin: 'rosario', destination: 'brescia', via: ['genova'], commodity: 'Wheat', quantity: 5000,
      capital: 2_350_000, equity: 350_000, basePnl: 88_000, duration: 31, risk: 'Medium', riskClass: 'medium', priceKey: 'wheat', recommendedHedge: 75, transportMode: 'Handysize / Truck',
      title: 'Paraná Wheat Parcel', description: 'Grain origination from the Paraná to Northern Italy. Basis, protein content and river logistics determine the outcome.',
      unlock: s => (officeOwned('rosario') || officeOwned('genova')) && s.completedDeals >= 4 && s.reputation >= 60,
      event: { dayRatio: .28, title: 'Low river level', text: 'The Paraná river level reduces available draft and loadable quantity.', choices: [
        { id: 'lighten-wheat', label: 'Reduce the parcel and buy replacement cargo', hint: 'Cost $24,000 · protects delivery quantity', pnl: -24_000, days: 2, reputation: 2, result: 'The missing quantity is covered with a replacement purchase.' },
        { id: 'wait-river', label: 'Wait for the river level to improve', hint: '5 days · possible laycan penalty', random: true, good: { pnl: -9_000, days: 5, reputation: 0, result: 'The river level rises and the full cargo departs.' }, bad: { pnl: -48_000, days: 8, reputation: -3, result: 'The wait generates deadfreight and a late delivery.' } }
      ]}
    },
    {
      id: 'pilbara-iron', origin: 'port-hedland', destination: 'shanghai', via: [], commodity: 'Iron ore', quantity: 55000,
      capital: 7_400_000, equity: 1_150_000, basePnl: 245_000, duration: 34, risk: 'High', riskClass: 'high', priceKey: 'ironore', recommendedHedge: 70, transportMode: 'Panamax bulk carrier',
      title: 'Pilbara–Yangtze Ore', description: 'Large dry-bulk cargo to China. Freight, Fe grade, moisture and port congestion dominate P&L.',
      unlock: s => (officeOwned('port-hedland') || officeOwned('singapore')) && s.completedDeals >= 6 && s.reputation >= 70,
      event: { dayRatio: .64, title: 'Shanghai anchorage congestion', text: 'The vessel joins the queue and may exceed allowed laytime.', choices: [
        { id: 'priority-ore', label: 'Buy discharge priority', hint: 'Cost $36,000 · limits demurrage', pnl: -36_000, days: 1, reputation: 2, result: 'The terminal assigns a priority window.' },
        { id: 'queue-ore', label: 'Remain in the queue', hint: 'No upfront cost · uncertain demurrage', random: true, good: { pnl: -18_000, days: 3, reputation: 0, result: 'The queue clears faster than expected.' }, bad: { pnl: -92_000, days: 7, reputation: -4, result: 'The delay generates demurrage and a buyer claim.' } }
      ]}
    },
    {
      id: 'qatar-lng', origin: 'doha', destination: 'rotterdam', via: [], commodity: 'LNG', quantity: 65000,
      capital: 12_800_000, equity: 1_900_000, basePnl: 360_000, duration: 22, risk: 'Medium', riskClass: 'medium', priceKey: 'crude', recommendedHedge: 85, transportMode: 'LNG carrier',
      title: 'Qatar LNG Express', description: 'High-value LNG cargo from the Persian Gulf to the ARA market. Strict vetting, cargo quality control and a precision laycan make execution the decisive edge.',
      unlock: s => (officeOwned('doha') || officeOwned('rotterdam')) && s.completedDeals >= 5 && s.reputation >= 68,
      event: {
        dayRatio: .38,
        title: 'Cargo boil-off deviation',
        text: 'Voyage boil-off exceeds contractual tolerance, reducing deliverable volume and raising a quality query at Rotterdam.',
        choices: [
          { id: 'compensate-lng', label: 'Offer volume compensation', hint: 'Cost $28,000 · protects the buyer relationship', pnl: -28_000, days: 1, reputation: 2, result: 'The buyer accepts the compensation and the LC is settled on time.' },
          { id: 'dispute-lng', label: 'Dispute the measurement at discharge', hint: 'No upfront cost · 4 days · could resolve in your favour', random: true, good: { pnl: 0, days: 4, reputation: 1, result: 'An independent surveyor confirms the boil-off was within tolerance.' }, bad: { pnl: -68_000, days: 4, reputation: -4, result: 'The survey confirms the deviation and the buyer applies a material quantity claim.' } }
        ]
      }
    },
    {
      id: 'ivory-cocoa', origin: 'abidjan', destination: 'brescia', via: ['genova'], commodity: 'Cocoa', quantity: 800,
      capital: 5_600_000, equity: 820_000, basePnl: 168_000, duration: 42, risk: 'Medium', riskClass: 'medium', priceKey: 'coffee', recommendedHedge: 75, transportMode: 'Container / reefer',
      title: "Côte d'Ivoire Cocoa Flow", description: 'Premium West African cocoa for Italian fine-chocolate manufacturers. Grading certification, humidity control and traceability documentation are the execution-critical variables.',
      tender: true,
      unlock: s => (officeOwned('abidjan') || officeOwned('genova')) && s.completedDeals >= 5 && s.reputation >= 66,
      event: {
        dayRatio: .42,
        title: 'Off-grade bean discovery',
        text: 'Discharge sampling in Genoa finds a proportion of beans below contracted minimum grade, triggering a buyer quality dispute.',
        choices: [
          { id: 'regrade-cocoa', label: 'Commission independent regrading', hint: 'Cost $14,000 · 2 days · produces binding result', pnl: -14_000, days: 2, reputation: 2, result: 'Independent graders confirm the bulk of the parcel meets specification.' },
          { id: 'allowance-cocoa', label: 'Negotiate a quality allowance', hint: 'Fast · uncertain margin reduction', random: true, good: { pnl: -22_000, days: 0, reputation: 1, result: 'The buyer accepts a moderate allowance for the off-grade fraction.' }, bad: { pnl: -80_000, days: 2, reputation: -4, result: 'The buyer rejects the cargo and demands a full quality re-run, causing major margin erosion.' } }
        ]
      }
    },
    {
      id: 'gulf-soybeans', origin: 'new-orleans', destination: 'rotterdam', via: [], commodity: 'Soybeans', quantity: 25000,
      capital: 9_200_000, equity: 1_350_000, basePnl: 290_000, duration: 28, risk: 'Medium', riskClass: 'medium', priceKey: 'wheat', recommendedHedge: 85, transportMode: 'Panamax bulk carrier',
      title: 'Gulf–ARA Soybean Express', description: 'Large Panamax soybean cargo from the US Gulf to the ARA crushing complex. Basis risk (CBOT vs physical), moisture and protein differentials determine final P&L.',
      unlock: s => (officeOwned('houston') || officeOwned('rotterdam')) && s.completedDeals >= 6 && s.reputation >= 70,
      event: {
        dayRatio: .35,
        title: 'Moisture content above specification',
        text: 'Load-port analysis detects moisture levels at the upper limit of the contractual range, raising concerns at the European crushing plant.',
        choices: [
          { id: 'retest-soy', label: 'Request a reefer pre-treatment and retest', hint: 'Cost $26,000 · 3 days · brings cargo within spec', pnl: -26_000, days: 3, reputation: 2, result: 'Post-treatment moisture is within contract range and the buyer accepts the documentation.' },
          { id: 'accept-soy', label: 'Accept on current certificates', hint: 'No cost · buyer may apply arrival claim', random: true, good: { pnl: 0, days: 0, reputation: 0, result: 'Discharge analysis confirms moisture within tolerance; no claim is raised.' }, bad: { pnl: -88_000, days: 2, reputation: -4, result: 'Arrival analysis confirms an excess, and the crushing plant applies a significant quality differential.' } }
        ]
      }
    },
    {
      id: 'shanghai-steel', origin: 'shanghai', destination: 'antwerp', via: [], commodity: 'Steel', quantity: 8000,
      capital: 6_800_000, equity: 980_000, basePnl: 198_000, duration: 36, risk: 'High', riskClass: 'high', priceKey: 'ironore', recommendedHedge: 65, transportMode: 'General cargo vessel',
      title: 'Yangtze Steel Export', description: 'Chinese hot-rolled coil destined for European distribution. Anti-dumping duty risk, mill certificate compliance and strict EU import documentation make this the most legally complex corridor.',
      unlock: s => (officeOwned('shanghai') || officeOwned('singapore')) && s.completedDeals >= 7 && s.reputation >= 74,
      event: {
        dayRatio: .52,
        title: 'EU anti-dumping duty investigation',
        text: 'Customs authorities at Antwerp flag the cargo for enhanced documentary review under an active anti-dumping investigation.',
        choices: [
          { id: 'legal-steel', label: 'Engage trade counsel and expedite customs', hint: 'Cost $38,000 · 4 days · clears documentary position', pnl: -38_000, days: 4, reputation: 2, result: 'Trade counsel demonstrates conformity with EU rules of origin and the cargo clears.' },
          { id: 'wait-steel', label: 'Wait for standard customs clearance', hint: 'No upfront cost · major delay risk', random: true, good: { pnl: -12_000, days: 5, reputation: 0, result: 'Standard review concludes with no additional duty applied, but the delay generates storage costs.' }, bad: { pnl: -180_000, days: 12, reputation: -6, result: 'Anti-dumping duty is provisionally applied and the cargo is detained pending legal challenge.' } }
        ]
      }
    },
    {
      id: 'malaysia-palm', origin: 'klang', destination: 'brescia', via: ['singapore', 'genova'], commodity: 'Palm oil', quantity: 6000,
      capital: 4_200_000, equity: 650_000, basePnl: 128_000, duration: 39, risk: 'Medium', riskClass: 'medium', priceKey: 'crude', recommendedHedge: 70, transportMode: 'Vegetable oil tanker',
      title: 'Sunflower Corridor', description: 'Malaysian CPO for the Italian food industry via Singapore and Genoa. Sustainability certification, FFA assay and moisture control are the execution-critical variables.',
      unlock: s => (officeOwned('klang') || (officeOwned('singapore') && officeOwned('genova'))) && s.completedDeals >= 4 && s.reputation >= 64,
      event: {
        dayRatio: .55,
        title: 'FFA assay above specification',
        text: 'A discharge sample at Genoa shows free fatty acid levels above the contracted maximum, triggering a buyer quality query.',
        choices: [
          { id: 'blend-palm', label: 'Arrange shore-tank blending at Genoa', hint: 'Cost $22,000 · 2 days · brings the cargo on spec', pnl: -22_000, days: 2, reputation: 2, result: 'Blending restores the cargo to specification and the customer accepts delivery.' },
          { id: 'negotiate-palm', label: 'Negotiate a quality allowance with the buyer', hint: 'Fast · uncertain discount', random: true, good: { pnl: -18_000, days: 0, reputation: 1, result: 'The buyer accepts a modest allowance for the off-spec lot.' }, bad: { pnl: -72_000, days: 3, reputation: -3, result: 'The buyer rejects the cargo and demands a full quality re-analysis and price differential.' } }
        ]
      }
    },
    {
      id: 'zambia-zinc', origin: 'durban', destination: 'antwerp', via: [], commodity: 'Zinc',
      quantity: 1600, capital: 4_500_000, equity: 700_000, basePnl: 195_000, duration: 32,
      risk: 'Medium', riskClass: 'medium', priceKey: 'zinc', recommendedHedge: 75,
      transportMode: 'Supramax bulk', title: 'Zambia Zinc Concentrate', locked: true, unlock: s => (officeOwned('durban') || officeOwned('rotterdam')) && s.completedDeals >= 5 && s.reputation >= 68,
      description: 'High-grade zinc concentrate from Zambia\'s Copperbelt. FOB Durban for delivery to ARA smelters. Quality specs: min 52% Zn, max 1.5% Pb.',
      counterparties: { supplierId: 'zambia-zinc-co', buyerId: 'ara-zinc-smelter' },
      events: []
    },
    {
      id: 'indonesia-nickel', origin: 'singapore', destination: 'rotterdam', via: [], commodity: 'Nickel',
      quantity: 850, capital: 13_500_000, equity: 2_100_000, basePnl: 420_000, duration: 38,
      risk: 'High', riskClass: 'high', priceKey: 'nickel', recommendedHedge: 90, tender: true,
      transportMode: 'Supramax bulk', title: 'Indonesia Nickel Matte', locked: true, unlock: s => officeOwned('singapore') && officeOwned('rotterdam') && s.completedDeals >= 8 && s.reputation >= 75,
      description: 'Class I nickel matte from Indonesian HPAL operations. Competitive tender against two Asian trading houses. DES Rotterdam.',
      counterparties: { supplierId: 'indo-nickel-corp', buyerId: 'europe-battery-materials' },
      events: []
    },
    {
      id: 'us-lng-export', origin: 'houston', destination: 'rotterdam', via: [], commodity: 'LNG',
      quantity: 70000, capital: 8_800_000, equity: 1_400_000, basePnl: 380_000, duration: 22,
      risk: 'Medium', riskClass: 'medium', priceKey: 'lng', recommendedHedge: 80,
      transportMode: 'LNG carrier', title: 'US Gulf LNG Cargo', locked: true, unlock: s => (officeOwned('houston') || officeOwned('rotterdam')) && s.completedDeals >= 6 && s.reputation >= 72,
      description: 'FOB LNG from Sabine Pass liquefaction terminal. DES Rotterdam delivery for European utility off-take. Basis: JKM/TTF differential.',
      counterparties: { supplierId: 'gulf-lng-terminal', buyerId: 'dutch-utility-gas' },
      events: []
    }
  ];


  const opportunityParties = {
    'baltic-copper': { supplierId: 'baltic-metals', buyerId: 'lombardia-cables' },
    'andean-copper': { supplierId: 'andean-copper', buyerId: 'lombardia-cables' },
    'meridian-copper': { supplierId: 'meridian-resources', buyerId: 'lombardia-cables' },
    'rotterdam-alloy': { supplierId: 'northsea-alloys', buyerId: 'lombardia-cables' },
    'maghreb-urea': { supplierId: 'atlas-fertilizers', buyerId: 'po-valley-agri' },
    'asia-aluminium': { supplierId: 'meridian-resources', buyerId: 'straits-fabrication' },
    'atlantic-diesel': { supplierId: 'gulf-refining', buyerId: 'ara-fuels' },
    'brazil-coffee': { supplierId: 'santos-coffee', buyerId: 'italia-roasters' },
    'argentina-wheat': { supplierId: 'pampa-grains', buyerId: 'po-valley-agri' },
    'pilbara-iron': { supplierId: 'pilbara-mining', buyerId: 'yangtze-steel' },
    'qatar-lng': { supplierId: 'qatar-energy', buyerId: 'ara-lng' },
    'malaysia-palm': { supplierId: 'klang-agri', buyerId: 'italia-food-group' },
    'ivory-cocoa':    { supplierId: 'cdi-cocoa', buyerId: 'chocoitalia' },
    'gulf-soybeans':  { supplierId: 'gulf-grain-co', buyerId: 'ara-crushing' },
    'shanghai-steel': { supplierId: 'yangtze-trading', buyerId: 'ara-steel-dist' }
  };

  const counterpartyCatalog = [
    { id: 'lombardia-cables', name: 'Lombardia Cables S.p.A.', type: 'Buyer', country: 'Italy', credit: 84, creditRating: 'A', reliability: 89, kyc: 'Approved', description: 'Industrial manufacturer with recurring metals demand and strict quality discipline.' },
    { id: 'po-valley-agri', name: 'Po Valley Agri Coop', type: 'Buyer', country: 'Italy', credit: 72, creditRating: 'BBB', reliability: 80, kyc: 'Approved', description: 'Agricultural consortium sensitive to punctuality, moisture analysis and seasonality.' },
    { id: 'straits-fabrication', name: 'Straits Fabrication Pte.', type: 'Buyer', country: 'Singapore', credit: 88, creditRating: 'A', reliability: 86, kyc: 'Approved', description: 'Investment-grade Asian buyer with strict documentary discipline and LC payments.' },
    { id: 'baltic-metals', name: 'Baltic Metals OU', type: 'Supplier', country: 'Estonia', credit: 76, creditRating: 'BBB', reliability: 78, kyc: 'Approved', description: 'Fast and flexible supplier whose documentary quality must be monitored.' },
    { id: 'andean-copper', name: 'Andean Copper Ltd.', type: 'Supplier', country: 'Chile', credit: 86, creditRating: 'A', reliability: 91, kyc: 'Approved', description: 'Solid producer with competitive access to Chilean copper and a long transit time.' },
    { id: 'meridian-resources', name: 'Meridian Resources DMCC', type: 'Supplier', country: 'UAE', credit: 61, creditRating: 'BB', reliability: 67, kyc: 'Enhanced review', description: 'Price-aggressive trading counterparty with compliance risk and a complex corporate structure.' },
    { id: 'northsea-alloys', name: 'NorthSea Alloys BV', type: 'Supplier', country: 'Netherlands', credit: 82, creditRating: 'A', reliability: 88, kyc: 'Approved', description: 'European warehouse operator and merchant with access to LME stocks and barges.' },
    { id: 'atlas-fertilizers', name: 'Atlas Fertilizers SA', type: 'Supplier', country: 'Morocco', credit: 74, creditRating: 'BBB', reliability: 81, kyc: 'Approved', description: 'Regional fertilizer producer with good Mediterranean access.' },
    { id: 'gulf-refining', name: 'Gulf Refining & Trading LLC', type: 'Supplier', country: 'USA', credit: 87, creditRating: 'A', reliability: 89, kyc: 'Approved', description: 'Gulf Coast refinery with a regular cargo program and strict specifications.' },
    { id: 'ara-fuels', name: 'ARA Fuels BV', type: 'Buyer', country: 'Netherlands', credit: 90, creditRating: 'A', reliability: 91, kyc: 'Approved', description: 'Investment-grade European distributor active in the distillates market.' },
    { id: 'santos-coffee', name: 'Santos Coffee Export SA', type: 'Supplier', country: 'Brazil', credit: 78, creditRating: 'BBB', reliability: 83, kyc: 'Approved', description: 'Brazilian exporter with a network of cooperatives and quality laboratories.' },
    { id: 'italia-roasters', name: 'Italian Roasters Group', type: 'Buyer', country: 'Italy', credit: 81, creditRating: 'A', reliability: 86, kyc: 'Approved', description: 'European roaster sensitive to cup profile, moisture and traceability.' },
    { id: 'pampa-grains', name: 'Pampa Grains SA', type: 'Supplier', country: 'Argentina', credit: 70, creditRating: 'BBB', reliability: 79, kyc: 'Approved', description: 'Agricultural origination house on the Paraná corridor.' },
    { id: 'pilbara-mining', name: 'Pilbara Mining Ltd.', type: 'Supplier', country: 'Australia', credit: 92, creditRating: 'A', reliability: 94, kyc: 'Approved', description: 'High-volume mining producer with strong loading discipline.' },
    { id: 'yangtze-steel', name: 'Yangtze Steel Group', type: 'Buyer', country: 'China', credit: 85, creditRating: 'A', reliability: 84, kyc: 'Approved', description: 'Steel group with Panamax-scale iron ore demand.' },
    { id: 'qatar-energy', name: 'Qatar Energy Trading', type: 'Supplier', country: 'Qatar', credit: 96, creditRating: 'A', reliability: 95, kyc: 'Approved', description: 'State-affiliated energy company with world-class operational discipline and strict cargo programming.' },
    { id: 'ara-lng', name: 'ARA LNG Terminal BV', type: 'Buyer', country: 'Netherlands', credit: 91, creditRating: 'A', reliability: 93, kyc: 'Approved', description: 'Investment-grade European LNG terminal with regasification, pipeline and storage access.' },
    { id: 'klang-agri', name: 'Klang Agri Exports', type: 'Supplier', country: 'Malaysia', credit: 79, creditRating: 'BBB', reliability: 82, kyc: 'Approved', description: 'Integrated palm oil producer with RSPO certification and full traceability documentation.' },
    { id: 'italia-food-group', name: 'Italia Food Group SpA', type: 'Buyer', country: 'Italy', credit: 83, creditRating: 'A', reliability: 87, kyc: 'Approved', description: 'Diversified Italian food manufacturer with demand for tropical oils, grains and specialty ingredients.' },
    { id: 'cdi-cocoa', name: "Côte d'Ivoire Cocoa Export", type: 'Supplier', country: 'Ivory Coast', credit: 72, creditRating: 'BBB', reliability: 76, kyc: 'Approved', description: 'State-affiliated cocoa exporter with broad origination network and quality grading infrastructure in Abidjan.' },
    { id: 'chocoitalia', name: 'ChocoItalia Group S.p.A.', type: 'Buyer', country: 'Italy', credit: 85, creditRating: 'A', reliability: 88, kyc: 'Approved', description: 'Premium Italian fine-chocolate manufacturer requiring traceable, certified cocoa with strict humidity and grade specs.' },
    { id: 'gulf-grain-co', name: 'Gulf Grain & Oilseed Co.', type: 'Supplier', country: 'USA', credit: 86, creditRating: 'A', reliability: 90, kyc: 'Approved', description: 'US Gulf Coast origination house with direct elevator access, CBOT basis trading capability and reliable moisture management.' },
    { id: 'ara-crushing', name: 'ARA Crushing Complex BV', type: 'Buyer', country: 'Netherlands', credit: 88, creditRating: 'A', reliability: 87, kyc: 'Approved', description: 'Large-scale oilseed crushing facility in Rotterdam with continuous discharge capacity and strict protein/moisture specs.' },
    { id: 'yangtze-trading', name: 'Yangtze Steel Trading Co.', type: 'Supplier', country: 'China', credit: 78, creditRating: 'BBB', reliability: 80, kyc: 'Enhanced review', description: 'Shanghai-based steel trading arm of an integrated mill. Competitive pricing on HRC, but anti-dumping exposure requires careful documentation.' },
    { id: 'ara-steel-dist', name: 'ARA Steel Distribution NV', type: 'Buyer', country: 'Belgium', credit: 84, creditRating: 'A', reliability: 86, kyc: 'Approved', description: 'Antwerp-based service centre and steel distributor with demand for HRC and plate into construction and manufacturing.' },
  { id: 'zambia-zinc-co', name: 'Zambia Consolidated Zinc', type: 'Supplier', country: 'Zambia', credit: 68, reliability: 74, relationship: 40, tier: 'B', creditRating: 'BB', kyc: 'In progress', description: 'Copperbelt zinc concentrate producer. Exports primarily through Durban with long-term offtake obligations to European smelters.' },
  { id: 'ara-zinc-smelter', name: 'ARA Zinc Refinery NV', type: 'Buyer', country: 'Netherlands', credit: 83, reliability: 86, relationship: 50, tier: 'A', creditRating: 'BBB', kyc: 'Approved',    description: 'Rotterdam-based zinc smelter with 120,000 t/year refined zinc capacity. Buys concentrate on CIF ARA basis.' },
  { id: 'indo-nickel-corp', name: 'Indo Nickel Corporation', type: 'Supplier', country: 'Indonesia', credit: 72, reliability: 76, relationship: 35, tier: 'B', creditRating: 'BB', kyc: 'Approved',    description: 'HPAL nickel operator in Sulawesi. Produces Class I nickel matte for export into European battery supply chains.' },
  { id: 'europe-battery-materials', name: 'EuroBatt Materials GmbH', type: 'Buyer', country: 'Germany', credit: 89, reliability: 90, relationship: 55, tier: 'A', creditRating: 'A', kyc: 'Approved',    description: 'Düsseldorf-based battery precursor manufacturer. Buys nickel matte for cathode active material production.' },
  { id: 'gulf-lng-terminal', name: 'Gulf LNG Terminal LLC', type: 'Supplier', country: 'USA', credit: 88, reliability: 91, relationship: 60, tier: 'A', creditRating: 'BBB', kyc: 'Approved',    description: 'Operator of Sabine Pass LNG liquefaction trains. Provides FOB LNG cargo slots to third-party traders.' },
  { id: 'dutch-utility-gas', name: 'Dutch Utility Gas B.V.', type: 'Buyer', country: 'Netherlands', credit: 92, reliability: 93, relationship: 50, tier: 'A', creditRating: 'A', kyc: 'Approved',    description: 'Dutch gas utility and LNG importer. Buys LNG DES Rotterdam for regas and domestic distribution.' }
  ,
    { id: 'glencore-metals', name: 'Glencore Metal Trading SA', type: 'Both', country: 'Switzerland', credit: 92, creditRating: 'A', reliability: 94, kyc: 'Approved', description: 'Geneva-based arm of the world’s largest commodity trading house. Appetite for large-volume metals deals and highly competitive on pricing.' },
    { id: 'rio-tinto-commercial', name: 'Rio Tinto Commercial', type: 'Supplier', country: 'Australia', credit: 95, creditRating: 'A', reliability: 96, kyc: 'Approved', description: 'Anglo-Australian mining major. Reliable long-term supplier of iron ore, copper concentrate and aluminium smelter-grade material.' },
    { id: 'korean-steelworks', name: 'POSCO International Corp.', type: 'Buyer', country: 'South Korea', credit: 88, creditRating: 'A', reliability: 91, kyc: 'Approved', description: 'Procurement arm of Korea’s largest steelmaker. High-volume iron ore and coal buyer with rigorous quality and delivery specs.' },
    { id: 'sahel-fertilizer', name: 'Sahel Fertilizer Imports SARL', type: 'Buyer', country: 'Senegal', credit: 58, creditRating: 'BB', reliability: 65, kyc: 'In progress', description: 'West African agricultural input importer serving smallholder cooperative networks. Seasonal demand spikes around planting windows; payment terms require careful structuring.' }];

  const negotiationProfiles = {
    commercial: {
      competitive: { label: 'Competitive quote', pnl: -14_000, acceptance: 18 },
      market: { label: 'Market quote', pnl: 0, acceptance: 0 },
      premium: { label: 'Premium quote', pnl: 22_000, acceptance: -24 }
    },
    payment: {
      thirty: { label: '30 days after delivery', equityFactor: 1.12, acceptance: 9 },
      delivery: { label: 'Payment at delivery', equityFactor: 1, acceptance: 0 },
      prepay: { label: '20% advance', equityFactor: .8, acceptance: -16 }
    },
    pricing: {
      fixed: { label: 'Fixed price', pnl: 0, acceptance: 0, basisRisk: 0, description: 'Both physical legs are fixed around execution. Lowest residual basis risk.' },
      average: { label: 'Monthly average', pnl: 7_000, acceptance: 5, basisRisk: .12, description: 'Pricing follows a monthly average. Better client fit, but hedge timing creates basis risk.' },
      buyer: { label: 'Buyer pricing option', pnl: 16_000, acceptance: 10, basisRisk: .28, description: 'The buyer chooses the pricing date inside a window. Higher premium, materially higher optionality risk.' }
    },
    delivery: {
      priority: { label: 'Priority window', duration: -3, pnl: -9_000, acceptance: 10 },
      standard: { label: 'Standard window', duration: 0, pnl: 0, acceptance: 0 },
      flexible: { label: 'Flexible window', duration: 4, pnl: 7_000, acceptance: -9 }
    },
    incoterm: {
      exw: { label: 'EXW · Ex Works', pnl: -18_000, acceptance: -9, equityFactor: .9, duration: -5, description: 'Buyer collects at origin and bears all freight, insurance and risk. You net the least but tie up little capital and carry minimal logistics risk.' },
      fob: { label: 'FOB · Free On Board', pnl: 0, acceptance: 0, equityFactor: 1, duration: 0, description: 'You deliver over the ship\'s rail at the load port; the buyer arranges and pays ocean freight and insurance. The physical-trade benchmark.' },
      cfr: { label: 'CFR · Cost & Freight', pnl: 13_000, acceptance: 6, equityFactor: 1.06, duration: 2, description: 'You pay the ocean freight to the destination port (buyer insures). Captures freight margin but adds working capital and freight risk.' },
      cif: { label: 'CIF · Cost, Insurance & Freight', pnl: 18_000, acceptance: 9, equityFactor: 1.08, duration: 2, description: 'You pay freight and marine insurance to destination. Higher price and easier acceptance, more capital and execution exposure.' },
      ddp: { label: 'DDP · Delivered Duty Paid', pnl: 28_000, acceptance: 14, equityFactor: 1.16, duration: 5, description: 'You deliver cleared, duty-paid at the buyer\'s door and bear virtually all cost and risk. Best price and conversion, heaviest capital and operational load.' }
    }
  };

  const strategyDoctrineCatalog = {
    merchant: { id:'merchant', label:'Flow Merchant', icon:'↗', description:'Prioritise turnover, relationships and repeat business.', pnlFactor:.98, acceptance:5, equityFactor:.97, riskAdjustment:-1, overheadFactor:1, creditFactor:1.02 },
    arbitrage: { id:'arbitrage', label:'Margin Arbitrageur', icon:'⇄', description:'Target dislocations and optionality. Higher expected margin, higher volatility.', pnlFactor:1.10, acceptance:-5, equityFactor:1.03, riskAdjustment:8, overheadFactor:1.03, creditFactor:.98 },
    assetbacked: { id:'assetbacked', label:'Asset-backed Trader', icon:'▲', description:'Use terminals, production and downstream demand to compound structural advantages.', pnlFactor:1.03, acceptance:2, equityFactor:.94, riskAdjustment:-3, overheadFactor:1.12, creditFactor:1.05, assetMultiplier:1.25 },
    defensive: { id:'defensive', label:'Capital Preserver', icon:'◇', description:'Protect liquidity and credit quality through conservative deal selection.', pnlFactor:.92, acceptance:3, equityFactor:1.10, riskAdjustment:-12, overheadFactor:.96, creditFactor:1.08 }
  };

  const marketRegimeCatalog = {
    balanced: { id:'balanced', label:'Balanced market', tone:'balanced', volatility:1, pnlFactor:1, equityFactor:1, duration:0, acceptance:0, freightBias:0, description:'Normal liquidity, balanced physical premiums and orderly freight.' },
    riskon: { id:'riskon', label:'Risk-on expansion', tone:'positive', volatility:1.18, pnlFactor:1.12, equityFactor:1.04, duration:-1, acceptance:2, freightBias:0.25, description:'Strong industrial demand creates more flow, but prices move faster.' },
    soft: { id:'soft', label:'Soft demand', tone:'soft', volatility:.82, pnlFactor:.86, equityFactor:.95, duration:1, acceptance:-4, freightBias:-.35, description:'Weaker end-user demand compresses premiums and slows tender conversion.' },
    freight: { id:'freight', label:'Tight freight', tone:'warning', volatility:1.08, pnlFactor:.90, equityFactor:1.03, duration:4, acceptance:0, freightBias:1.5, description:'Scarce vessel capacity increases freight, delays and working-capital usage.' },
    squeeze: { id:'squeeze', label:'Supply squeeze', tone:'danger', volatility:1.35, pnlFactor:1.18, equityFactor:1.12, duration:2, acceptance:5, freightBias:.45, description:'Physical scarcity creates attractive margins but requires more capital and tighter execution.' }
  };


  const capitalPolicyCatalog = {
    preservation: {
      id:'preservation', label:'Capital Preservation', icon:'◇', reserveRatio:.35,
      pnlFactor:.94, equityFactor:1.08, financingRateFactor:.88, riskAdjustment:-11,
      description:'Protect liquidity, reduce leverage and retain a larger NAV reserve for margin calls and disruptions.'
    },
    balanced: {
      id:'balanced', label:'Balanced Mandate', icon:'◈', reserveRatio:.20,
      pnlFactor:1, equityFactor:1, financingRateFactor:1, riskAdjustment:0,
      description:'Balance growth, liquidity and risk capacity across the trading portfolio.'
    },
    growth: {
      id:'growth', label:'Growth Allocation', icon:'↗', reserveRatio:.10,
      pnlFactor:1.08, equityFactor:.92, financingRateFactor:1.12, riskAdjustment:10,
      description:'Deploy more capital into opportunities, accepting higher funding costs and liquidity risk.'
    }
  };

  const stressScenarioCatalog = {
    commodity: { id:'commodity', icon:'↓', label:'Commodity sell-off', subtitle:'Benchmarks fall 12% and basis widens', description:'Tests residual flat-price exposure and hedge effectiveness.' },
    freight: { id:'freight', icon:'⚓', label:'Freight capacity shock', subtitle:'Freight +35% and severe delays', description:'Tests ocean cargoes, congestion and working-capital duration.' },
    fx: { id:'fx', icon:'FX', label:'EUR/USD dislocation', subtitle:'EUR/USD moves 10% against the book', description:'Tests unhedged currency exposure and cross-border receivables.' },
    credit: { id:'credit', icon:'AR', label:'Buyer default wave', subtitle:'20% loss on unsecured receivables', description:'Tests buyer concentration, payment protection and cash conversion.' },
    liquidity: { id:'liquidity', icon:'!', label:'Global liquidity crisis', subtitle:'Margins rise and bank capacity falls', description:'Tests cash reserves, collateral and credit-line resilience.' }
  };

  // v48 - ogni desk rivale ha ora un profilo leggibile: come opera, su cosa punta
  // e come si comporta contro di te. I numeri di gara restano quelli di prima.
  const aiRivalDesks = [
    { id:'helios', name:'Helios Commodities', city:'Zurich', flag:'\u{1F1E8}\u{1F1ED}', specialties:['Copper','Aluminium','Diesel'], aggression:86, discipline:91,
      style:'Balance-sheet led', profile:'Deep bank lines and patient capital. Rarely overpays, but will sit on a corridor for months until the seller blinks.' },
    { id:'northsea', name:'NorthSea Trading', city:'Rotterdam', flag:'\u{1F1F3}\u{1F1F1}', specialties:['Diesel','Aluminium','Iron ore'], aggression:78, discipline:94,
      style:'Logistics led', profile:'Owns terminal slots in ARA. Wins on execution certainty rather than price, and almost never misses a delivery window.' },
    { id:'pacific', name:'Pacific Bulk Partners', city:'Singapore', flag:'\u{1F1F8}\u{1F1EC}', specialties:['Iron ore','Wheat','Coffee'], aggression:82, discipline:87,
      style:'Freight arbitrage', profile:'Charters ahead of the market and monetises the freight leg. Most dangerous when the Baltic index is moving.' },
    { id:'andean', name:'Andean Resources', city:'Santiago', flag:'\u{1F1E8}\u{1F1F1}', specialties:['Copper','Coffee'], aggression:74, discipline:90,
      style:'Producer aligned', profile:'Long-standing offtake with South American mines. Hard to displace at origin, weaker on the delivered leg.' },
    { id:'atlas', name:'Atlas Merchant Group', city:'London', flag:'\u{1F1EC}\u{1F1E7}', specialties:['Urea','Copper','Wheat'], aggression:88, discipline:84,
      style:'Volume hunter', profile:'Chases market share and will cut margin to hold a corridor. Overextends when several tenders land in the same week.' },
    { id:'stratus', name:'Stratus Energy', city:'Houston', flag:'\u{1F1FA}\u{1F1F8}', specialties:['Diesel','Urea'], aggression:92, discipline:76,
      style:'Opportunistic', profile:'The most aggressive bidder on the tape and the least disciplined. Takes flat-price risk others refuse.' },
    { id:'orion', name:'Orion Agri Trade', city:'Geneva', flag:'\u{1F1E8}\u{1F1ED}', specialties:['Coffee','Wheat','Urea'], aggression:72, discipline:89,
      style:'Seasonal specialist', profile:'Trades the agricultural calendar. Quiet out of season, then bids hard through harvest windows.' },
    { id:'rhine', name:'Rhine Metals Desk', city:'Geneva', flag:'\u{1F1E8}\u{1F1ED}', specialties:['Copper','Aluminium'], aggression:80, discipline:95,
      style:'Risk disciplined', profile:'Your closest neighbour and the most consistent desk in the league. Walks away from a tender rather than break a limit.' }
  ];

  // ── v48 · registro testa a testa ────────────────────────────────────────────
  // Conta solo esiti gia' prodotti dalla simulazione: non cambia nessuna probabilita'.
  function rivalRecord(rivalId) {
    state.rivalRecord = state.rivalRecord || {};
    if (!state.rivalRecord[rivalId]) state.rivalRecord[rivalId] = { won: 0, lost: 0, lastCycle: null, lastTitle: null, lastResult: null };
    return state.rivalRecord[rivalId];
  }
  function recordRivalOutcome(rivalId, playerWon, title) {
    if (!rivalId) return;
    const record = rivalRecord(rivalId);
    if (playerWon) record.won += 1; else record.lost += 1;
    record.lastCycle = state.marketCycle;
    record.lastTitle = title || null;
    record.lastResult = playerWon ? 'won' : 'lost';
  }

  const achievementCatalog = [
    { id:'first-cargo', icon:'01', title:'First Cargo', description:'Close your first physical commodity deal.', achieved:s=>s.completedDeals>=1 },
    { id:'five-cargoes', icon:'05', title:'Repeat Merchant', description:'Close five physical deals.', achieved:s=>s.completedDeals>=5 },
    { id:'clean-execution', icon:'✓', title:'Clean Execution', description:'Close a deal with at least 95% operational readiness.', achieved:s=>(s.history||[]).some(d=>(d.operationalReadiness||0)>=95) },
    { id:'hedge-discipline', icon:'H', title:'Hedge Discipline', description:'Close three deals with an average hedge ratio of at least 90%.', achieved:s=>(s.history||[]).length>=3 && (s.history||[]).slice(0,3).reduce((a,d)=>a+(d.hedgeRatio||0),0)/3>=90 },
    { id:'crisis-manager', icon:'!', title:'Crisis Manager', description:'Close a profitable deal affected by a global crisis.', achieved:s=>(s.history||[]).some(d=>d.pnl>0 && (d.globalEventImpacts||[]).length) },
    { id:'vertical-builder', icon:'V', title:'Vertical Builder', description:'Own at least one upstream, midstream and downstream asset.', achieved:s=>['upstream','midstream','downstream'].every(chain=>investmentCatalog.some(a=>a.chain===chain && (s.investments?.[a.id]?.level||0)>0)) },
    { id:'global-network', icon:'G', title:'Global Network', description:'Complete deals from four different origins.', achieved:s=>new Set((s.history||[]).map(d=>getOpportunity(d.opportunityId)?.origin).filter(Boolean)).size>=4 },
    { id:'liquidity-guardian', icon:'L', title:'Liquidity Guardian', description:'Close five deals without an emergency margin call.', achieved:s=>s.completedDeals>=5 && (s.marginCalls||0)===0 },
    { id:'tender-specialist', icon:'T', title:'Tender Specialist', description:'Win five competitive tenders against AI rival desks.', achieved:s=>(s.tenderWins||0)>=5 },
    { id:'credit-master', icon:'C', title:'Credit Master', description:'Close five deals with deferred payment and no material credit loss.', achieved:s=>(s.history||[]).filter(d=>d.commercialTerms?.payment==='thirty').length>=5 && (s.creditLosses||0)===0 },
    { id:'cash-conversion', icon:'AR', title:'Cash Conversion', description:'Collect three deferred-payment invoices.', achieved:s=>(s.history||[]).filter(d=>d.commercialTerms?.payment==='thirty' && d.invoiceStatus==='Paid').length>=3 },
    { id:'credit-committee', icon:'CC', title:'Credit Committee', description:'Secure an approved buyer credit-limit increase.', achieved:s=>Object.values(s.creditLimitRequests||{}).some(r=>r.status==='approved') },
    { id:'integrated-major', icon:'I', title:'Integrated Major', description:'Reach an enterprise value of $50 million.', achieved:s=>tradingHouseValuation().value>=50_000_000 },
    { id:'million-dollar-desk', icon:'$1M', title:'Million-Dollar Desk', description:'Reach $1 million of cumulative realized P&L.', achieved:s=>(s.realizedPnl||0)>=1_000_000 },
    { id:'energy-baron', icon:'⚡', title:'Energy Baron', description:'Close two profitable deals in energy commodities (Diesel or LNG).', achieved:s=>(s.history||[]).filter(d=>d.pnl>0&&['Diesel','LNG'].includes(d.commodity)).length>=2 },
    { id:'soft-commodity-house', icon:'☆', title:'Soft Commodity House', description:'Close deals in both Cocoa and Soybeans.', achieved:s=>(s.history||[]).some(d=>d.commodity==='Cocoa') && (s.history||[]).some(d=>d.commodity==='Soybeans') },
    { id:'steel-trader', icon:'▰', title:'Steel Corridor', description:'Close the Yangtze Steel Export deal.', achieved:s=>(s.history||[]).some(d=>d.opportunityId==='shanghai-steel') },
    { id:'silk-road', icon:'SR', title:'Silk Road Trader', description:'Complete deals from three different continents in the same career.', achieved:s=>{ const m={tallinn:'EU',rotterdam:'EU',genova:'EU',brescia:'EU',antwerp:'EU',casablanca:'AF',abidjan:'AF',dubai:'AS',singapore:'AS',klang:'AS',doha:'AS',shanghai:'AS','port-hedland':'OC',houston:'AM',santos:'AM',rosario:'AM',santiago:'AM','new-orleans':'AM'}; return new Set((s.history||[]).map(d=>{const o=getOpportunity(d.opportunityId);return o?m[o.origin]:null;}).filter(Boolean)).size>=3; } },
  { id:'metals-specialist', icon:'Zn', title:'Metals Specialist', description:'Close profitable deals in both zinc and nickel in the same career.', achieved: s => { const k=s.history||[]; return k.some(d=>d.priceKey==='zinc'&&(d.pnl||0)>0) && k.some(d=>d.priceKey==='nickel'&&(d.pnl||0)>0); } },
  { id:'lng-pioneer',       icon:'♨',  title:'LNG Pioneer',       description:'Complete your first LNG cargo deal.',                              achieved: s => (s.history||[]).some(d=>d.priceKey==='lng') },
  { id:'quarter-bonus',     icon:'★',  title:'Bonus Quarter',     description:'Hit a quarterly P&L target and earn a performance bonus.',         achieved: s => (s.quarterBonusPaid||0) > 0 },
  { id:'scenario-planner',  icon:'Σ',  title:'Scenario Planner',  description:'Run five board-level stress tests.', achieved: s => (s.stressTestsRun||0) >= 5 },
  { id:'merchant-house', icon:'⌂', title:'Merchant House', description:'Upgrade Geneva headquarters to Tier 3.', achieved:s=>(s.hqTier||1)>=3 },
  { id:'offtake-master', icon:'§', title:'Offtake Master', description:'Fulfil a long-term commercial framework without shortfall.', achieved:s=>Object.values(s.commercialFrameworks||{}).some(f=>f.status==='fulfilled') },
  { id:'crisis-commander', icon:'⚠', title:'Crisis Commander', description:'Activate three different crisis response playbooks.', achieved:s=>Object.values(s.crisisResponses||{}).length>=3 },
  { id:'multinational-house', icon:'🌍', title:'Multinational House', description:'Operate permanent offices in five countries.', achieved:s=>new Set(officeCatalog.filter(o=>(s.offices||[]).includes(o.id)).map(o=>o.country)).size>=5 },
  { id:'global-footprint', icon:'◎', title:'Global Footprint', description:'Open ten international offices outside Geneva.', achieved:s=>Math.max(0,(s.offices||[]).length-1)>=10 }
  ];

  const financingProfiles = {
    revolver: { label: 'Revolving credit facility', equityFactor: 1, pnl: 0, rate: .075, acceptance: 0, description: 'Flexible, but consumes credit capacity and accrues daily interest.' },
    lc: { label: 'LC-backed trade finance', equityFactor: .82, pnl: -6_000, rate: .064, acceptance: 4, description: 'Reduces equity needs and payment risk through compliant documents.' },
    inventory: { label: 'Borrowing-base / inventory finance', equityFactor: .66, pnl: -13_000, rate: .082, acceptance: 1, requiresStaff: 'trade-finance-manager', description: 'Efficient funding secured by cargo and receivables.' },
    balance: { label: 'Own balance sheet', equityFactor: 1.85, pnl: 8_000, rate: .025, acceptance: 0, description: 'More equity, less bank dependence and greater flexibility.' }
  };

  const insuranceProfiles = {
    basic: { label: 'Basic cargo cover', pnl: -2_500, lossFactor: 1, description: 'Minimum cover for physical loss and general average.' },
    allrisk: { label: 'All-risk + delay cover', pnl: -9_000, lossFactor: .55, description: 'Broader protection against damage, delays and deviations.' },
    self: { label: 'Self-insured retention', pnl: 3_000, lossFactor: 1.35, description: 'Higher margin, but the desk retains more risk.' }
  };

  const inspectionProfiles = {
    none: { label: 'Supplier certificates only', pnl: 3_500, readiness: -8, lossFactor: 1.25, description: 'Minimum cost, with heavy reliance on supplier documents.' },
    standard: { label: 'Standard load-port inspection', pnl: -4_000, readiness: 2, lossFactor: .9, description: 'Quantity and quality control at the load port.' },
    independent: { label: 'Independent load & discharge survey', pnl: -12_000, readiness: 9, lossFactor: .62, description: 'Dual independent inspection and a stronger position in claims.' }
  };

  const bankCatalog = [
    { id: 'alpine-bank', name: 'Alpine Trade Bank', type: 'Revolver', limitShare: .55, rate: .075, relationship: 68, description: 'Primary bank for working capital and hedge liquidity.' },
    { id: 'mercantile', name: 'Mercantile Commodity Finance', type: 'LC / borrowing base', limitShare: .30, rate: .066, relationship: 58, description: 'Specialist in documentary trade and inventory finance.' },
    { id: 'oceanic', name: 'Oceanic Bank Asia', type: 'Regional LC', limitShare: .15, rate: .071, relationship: 50, description: 'Regional capacity available after opening Singapore.' }
  ];

  const academyCatalog = [
    { id: 'deal-anatomy', title: 'Anatomy of a physical deal', concept: 'A deal links purchase, sale, funding, hedging, logistics and settlement. Commercial margin is not final P&L.', question: 'Which cost can turn a good gross margin into a loss?', options: ['Spot price only', 'Freight, finance, claims and demurrage', 'None once the buyer has accepted'], correct: 1 },
    { id: 'hedge-margin', title: 'Hedging and margin calls', concept: 'The hedge reduces flat-price risk, but a short futures position can require liquidity when prices rise.', question: 'Can a perfectly hedged cargo still create a liquidity crisis?', options: ['Yes, because of variation margin', 'No, the hedge eliminates every risk', 'Only with Incoterm DDP'], correct: 0 },
    { id: 'trade-finance', title: 'Trade finance', concept: 'LCs, revolving facilities and borrowing-base structures change equity needs, cost and payment risk.', question: 'What does a bank pay under a documentary LC?', options: ['The economic quality of the deal', 'Documents compliant with the LC terms', 'The trader’s reputation'], correct: 1 },
    { id: 'incoterms', title: 'Incoterms and transfer of risk', concept: 'Incoterms allocate costs, responsibilities and transfer of logistics risk; they do not automatically determine legal title.', question: 'Under FOB, who normally arranges the main ocean freight?', options: ['The buyer', 'The seller until final destination', 'The bank'], correct: 0 },
    { id: 'shipping', title: 'Laytime and demurrage', concept: 'Laytime is the contractually allowed time for port operations; demurrage is the cost of exceeding it.', question: 'When does demurrage typically arise?', options: ['When the price falls', 'When used laytime exceeds allowed laytime', 'When there is no futures hedge'], correct: 1 },
    { id: 'quality-docs', title: 'Quality, documents and claims', concept: 'Certificates, surveys and accurate documentary descriptions protect settlement and the ability to dispute claims.', question: 'Which choice most strengthens your position in a quality claim?', options: ['No inspection', 'Independent survey at load and discharge ports', 'Increase the credit limit'], correct: 1 },
    { id: 'pricing-basis', title: 'Pricing windows and basis risk', concept: 'A futures hedge may not perfectly offset a physical contract when the buyer can price on a different date or average.', question: 'Why can a 100% futures hedge still leave risk?', options: ['Because pricing dates and indices can differ', 'Because futures have no price', 'Only because of customs'], correct: 0 },
    { id: 'receivables', title: 'Trade credit and receivables', concept: 'Open-account sales create buyer credit exposure after delivery. Insurance, factoring and LCs transfer different parts of that risk.', question: 'Which tool converts a receivable into immediate cash at a discount?', options: ['Factoring', 'Demurrage', 'A voyage charter'], correct: 0 },
    { id: 'storage-optionality', title: 'Storage optionality', concept: 'Storage can create value by separating the timing of purchase, transport and sale, but carrying costs and financing continue to accrue.', question: 'When is storage economically valuable?', options: ['When expected optionality exceeds storage and financing costs', 'Whenever the warehouse is empty', 'Only when the cargo is fully hedged'], correct: 0 },
    { id: 'supply-resilience', title: 'Supply-chain resilience', concept: 'Priority capacity, diversified suppliers and framework agreements can protect execution, but commitments create reservation fees and take-or-pay risk.', question: 'What is the main risk of a minimum-lifting procurement agreement?', options: ['Paying a shortfall when committed cargoes are not lifted', 'Eliminating every freight cost', 'Removing the need for KYC'], correct: 0 },
    { id: 'stress-liquidity', title: 'Stress testing and liquidity', concept: 'A profitable desk can still fail when margin calls, delayed receivables and reduced bank capacity arrive together. Stress tests estimate survival before the shock happens.', question: 'What is the purpose of a liquidity stress test?', options: ['Predict the exact future price', 'Estimate whether cash and facilities can absorb a severe but plausible shock', 'Replace all hedging decisions'], correct: 1 }
  ];

  const glossaryCatalog = [
    ['Basis risk','Risk that the physical price and hedging instrument do not move perfectly together.'],
    ['Bill of Lading','Ocean transport document, cargo receipt and often a document of title.'],
    ['Borrowing base','Facility calculated on the eligible value of inventory and receivables.'],
    ['Demurrage','Amount payable when operations exceed contractual laytime.'],
    ['Flat-price risk','Exposure to the absolute movement in the commodity price.'],
    ['Laycan','Window in which the vessel must present ready to load.'],
    ['Letter of Credit','Bank undertaking to pay against presentation of compliant documents.'],
    ['Premium','Difference between the physical price and the benchmark or futures price.'],
    ['Quality allowance','Negotiated discount for off-specification or lower-quality cargo.'],
    ['Variation margin','Daily liquidity flow caused by changes in futures value.'],
    ['Take-or-pay','Contractual obligation to lift or pay for a minimum committed volume.'],
    ['Congestion premium','Incremental freight or handling cost caused by scarce logistics capacity.'],
    ['Liquidity reserve','Cash deliberately retained to absorb variation margin, delays, claims and funding shocks.'],
    ['Stress test','A severe but plausible scenario used to estimate losses, liquidity needs and limit breaches.']
  ];

  const globalEventCatalog = [
    { id: 'suez-disruption', title: 'Suez transit disruption', region: 'Middle East / Mediterranean', severity: 'high', duration: 8, description: 'Transit restrictions increase voyage time and freight for Gulf-origin ocean cargoes.', freightShock: 9, affects: opp => opp.origin === 'dubai' && transportClassForOpportunity(opp) === 'ocean', dealDays: 4, dealPnl: -14_000 },
    { id: 'genoa-strike', title: 'Genoa terminal strike', region: 'Northern Italy', severity: 'medium', duration: 6, description: 'Reduced shifts create congestion, storage pressure and uncertain discharge windows.', freightShock: 3, affects: opp => (opp.via || []).includes('genova'), dealDays: 3, dealPnl: -9_000 },
    { id: 'copper-rally', title: 'Copper supply squeeze', region: 'Global metals', severity: 'high', duration: 7, description: 'A supply shock pushes copper higher and increases variation-margin pressure.', commodity: 'copper', dailyDrift: 42, affects: opp => opp.priceKey === 'copper', dealDays: 0, dealPnl: 0 },
    { id: 'bank-tightening', title: 'Trade-finance tightening', region: 'Global banking', severity: 'medium', duration: 9, description: 'Banks temporarily reduce unsecured capacity and demand more equity on new transactions.', creditPenalty: 750_000, equityFactor: 1.12, affects: () => true, dealDays: 0, dealPnl: 0 },
    { id: 'med-weather', title: 'Severe Mediterranean weather', region: 'Mediterranean', severity: 'medium', duration: 5, description: 'Port rotations slow and short-sea freight becomes more expensive.', freightShock: 6, affects: opp => transportClassForOpportunity(opp) === 'ocean' && ((opp.via || []).includes('genova') || opp.origin === 'casablanca'), dealDays: 2, dealPnl: -6_000 },
    { id: 'atlantic-hurricane', title: 'Atlantic hurricane risk', region: 'Atlantic basin', severity: 'high', duration: 7, description: 'Weather reroutes tankers and container vessels, lifting freight and insurance.', freightShock: 11, affects: opp => ['houston','santos'].includes(opp.origin), dealDays: 4, dealPnl: -18_000 },
    { id: 'grain-drought', title: 'South American grain drought', region: 'South America', severity: 'high', duration: 8, description: 'Crop expectations deteriorate, increasing wheat and coffee volatility.', commodity: 'wheat', dailyDrift: 3.2, affects: opp => ['wheat','coffee'].includes(opp.priceKey), dealDays: 1, dealPnl: -5_000 },
    { id: 'china-steel-surge', title: 'Chinese steel restocking', region: 'North Asia', severity: 'medium', duration: 7, description: 'Steel mills accelerate purchases, lifting iron ore and dry-bulk demand.', commodity: 'ironore', dailyDrift: 1.7, freightShock: 5, affects: opp => opp.priceKey === 'ironore', dealDays: 2, dealPnl: 8_000 },
    { id: 'panama-drought', title: 'Panama Canal draft restrictions', region: 'Central America', severity: 'high', duration: 9, description: 'Low water levels force vessels to reduce cargo loads, adding voyage legs and pushing up freight on trans-oceanic routes.', freightShock: 14, affects: opp => ['houston', 'santos', 'rosario', 'doha', 'klang'].includes(opp.origin), dealDays: 5, dealPnl: -22_000 },
    { id: 'blacksea-disruption', title: 'Black Sea shipping corridor disruption', region: 'Black Sea / Eastern Europe', severity: 'high', duration: 8, description: 'Insurance suspensions and vessel rerouting raise costs and extend transit times on grain and fertilizer flows.', freightShock: 8, affects: opp => ['wheat', 'urea'].includes(opp.priceKey), dealDays: 3, dealPnl: -14_000 },
    { id: 'harmattan-disruption', title: 'West Africa Harmattan loading delays', region: 'West Africa', severity: 'medium', duration: 7, description: 'Dry season dust storms reduce visibility and delay vessel operations at Abidjan and Dakar, adding demurrage and shifting laycans.', freightShock: 5, affects: opp => ['abidjan'].includes(opp.origin), dealDays: 3, dealPnl: -12_000 },
    { id: 'us-gulf-flooding', title: 'US Midwest river flood restricts grain exports', region: 'North America', severity: 'high', duration: 8, description: 'Flooding on the Mississippi and Illinois rivers closes elevator access, reducing Gulf Coast loading schedules for grain and oilseeds.', freightShock: 4, affects: opp => ['new-orleans'].includes(opp.origin), dealDays: 5, dealPnl: -28_000 },
    { id: 'eu-steel-tariff', title: 'EU provisional steel safeguard measures', region: 'European Union', severity: 'high', duration: 10, description: 'EU trade authorities impose provisional anti-dumping measures on Asian steel imports, causing documentary delays and cost uncertainty at ARA ports.', affects: opp => opp.commodity === 'Steel', dealDays: 6, dealPnl: -45_000 },
    { id: 'lme-warehouse-crisis', title: 'LME warehouse queue build-up', region: 'Global metals', severity: 'medium', duration: 7, description: 'Queue times at key delivery points spike, creating backwardation, lifting physical premiums and increasing variation-margin pressure.', commodity: 'copper', dailyDrift: 28, affects: opp => ['copper', 'aluminium'].includes(opp.priceKey), dealDays: 2, dealPnl: 6_000 },
  { id: 'indonesia-nickel-ban', title: 'Indonesia Nickel Ore Export Ban', description: 'Jakarta reinstates ore export restrictions, cutting raw material supply to Chinese NPI producers and tightening Class I nickel availability.', duration: 14, freightBias: 0.4, equityFactor: 1, pnlFactor: 0.96, priceKey: 'nickel', dailyDrift: 62, affects: opp => opp.priceKey === 'nickel', dealDays: 1, dealPnl: 18_000 },
  { id: 'european-gas-crisis',  title: 'European Gas Supply Crunch',   description: 'Pipeline gas shortfalls trigger emergency LNG procurement by European utilities. Spot LNG prices spike sharply on short-term buying.', duration: 12, freightBias: 0.6, equityFactor: 1, pnlFactor: 0.97, priceKey: 'lng', dailyDrift: 0.3, affects: opp => opp.priceKey === 'lng', dealDays: 2, dealPnl: 22_000 },
  { id: 'zambia-power-outage',  title: 'Zambia Power Crisis Hits Mining', description: 'Load-shedding at Copperbelt mines forces zinc and copper production cuts. Concentrate exports fall sharply on curtailed output.', duration: 10, freightBias: 0.2, equityFactor: 1, pnlFactor: 0.95, priceKey: 'zinc', dailyDrift: 14, affects: opp => ['zinc','copper'].includes(opp.priceKey), dealDays: 1, dealPnl: 9_000 },
    { id:'el-nino-soft-commodities', title: 'El Niño Disrupts Tropical Crop Yields', region: 'Global', severity: 'high', duration: 18, description: 'El Niño weather pattern reduces rainfall across Southeast Asia and West Africa. Cocoa, coffee and palm oil production outlooks cut sharply, lifting prices and tightening basis.', freightShock: 3, equityFactor: 1.04, pnlFactor: 1.12, priceKey: 'coffee', dailyDrift: 22, affects: opp => ['coffee','cocoa','wheat'].includes(opp.priceKey), dealDays: 5, dealPnl: 28_000 },
    { id:'chinese-steel-stimulus', title: 'China Steel Stimulus Boosts Iron Ore Demand', region: 'Asia Pacific', severity: 'medium', duration: 12, description: 'Beijing announces infrastructure stimulus worth ¥800bn. Iron ore and coking coal futures jump on higher crude steel output expectations. Vale and Rio Tinto raise quarterly guidance.', freightShock: 7, equityFactor: 1.02, pnlFactor: 1.09, priceKey: 'ironore', dailyDrift: 18, affects: opp => ['ironore','steel'].includes(opp.priceKey), dealDays: 4, dealPnl: 22_000 },
    { id:'lng-supply-crunch', title: 'LNG Supply Crunch — Australian Strike Action', region: 'Asia Pacific', severity: 'high', duration: 10, description: 'Workers at North West Shelf LNG facilities vote for industrial action, threatening 8% of global LNG supply. Spot prices in Asia surge as buyers scramble for alternatives.', freightShock: 9, equityFactor: 1.03, pnlFactor: 1.14, priceKey: 'lng', dailyDrift: 30, affects: opp => ['lng','crude'].includes(opp.priceKey), dealDays: 3, dealPnl: 35_000 },
    { id:'eu-grain-import-ban', title: 'EU Imposes Temporary Grain Import Restrictions', region: 'Europe', severity: 'medium', duration: 8, description: 'Brussels announces emergency import quotas on Black Sea wheat and corn to protect domestic farmers. Spot basis in Rotterdam tightens sharply as import volumes are redirected.', freightShock: -4, equityFactor: 0.97, pnlFactor: 0.88, priceKey: 'wheat', dailyDrift: -15, affects: opp => ['wheat','urea'].includes(opp.priceKey), dealDays: 2, dealPnl: -18_000 }
  ];

  // v33 systemic risk library: events affect price, freight, financing, credit,
  // execution timing and ultimately the trading house P&L.
  globalEventCatalog.push(
    { id:'red-sea-escalation', category:'Geopolitical', title:'Red Sea security escalation', region:'Red Sea / Indian Ocean', severity:'high', duration:12, description:'Missile and piracy risk forces vessels around the Cape, increasing war-risk premia, bunker use and voyage duration.', freightShock:16, insuranceShock:0.018, affects:opp=>transportClassForOpportunity(opp)==='ocean' && ['dubai','doha','klang','singapore'].includes(opp.origin), dealDays:8, dealPnl:-48_000, pnlFactor:.93 },
    { id:'sanctions-metals', category:'Geopolitical', title:'Sanctions expand to a major metals producer', region:'Global metals', severity:'high', duration:14, description:'Banks and warehouses tighten screening. Deliverable supply falls while compliance costs and settlement risk rise.', creditPenalty:420_000, equityFactor:1.10, acceptanceShock:-6, affects:opp=>['Copper','Aluminium','Nickel','Zinc'].includes(opp.commodity), dealDays:4, dealPnl:-32_000, pnlFactor:.96 },
    { id:'fertilizer-export-curbs', category:'Geopolitical', commodity:'urea', title:'Fertilizer export restrictions', region:'North Africa / Middle East', severity:'high', duration:11, description:'Government export controls reduce prompt availability and create replacement-cost risk for committed urea cargoes.', dailyDrift:8, affects:opp=>opp.commodity==='Urea', dealDays:5, dealPnl:-36_000, pnlFactor:.91 },
    { id:'global-recession', category:'Macroeconomic', title:'Global industrial recession shock', region:'Global economy', severity:'high', duration:16, description:'PMIs contract, manufacturers destock and buyer demand weakens across metals, energy and dry bulk.', creditPenalty:300_000, acceptanceShock:-10, affects:opp=>['Copper','Aluminium','Iron ore','Steel','Zinc','Nickel','Diesel'].includes(opp.commodity), dealDays:2, dealPnl:-24_000, pnlFactor:.78 },
    { id:'rates-higher-longer', category:'Macroeconomic', title:'Central banks reprice rates higher for longer', region:'Global banking', severity:'medium', duration:15, description:'Trade-finance spreads widen and inventory carrying costs rise as policy-rate expectations reset.', creditPenalty:250_000, equityFactor:1.08, financingRateShock:.035, affects:()=>true, dealDays:0, dealPnl:-8_000, pnlFactor:.96 },
    { id:'usd-liquidity-squeeze', category:'Macroeconomic', title:'US dollar liquidity squeeze', region:'Global FX / Banking', severity:'high', duration:9, description:'Dollar funding becomes scarce, FX volatility jumps and banks demand additional collateral.', creditPenalty:600_000, equityFactor:1.15, financingRateShock:.055, firmPnl:-18_000, affects:()=>true, dealDays:1, dealPnl:-14_000, pnlFactor:.94 },
    { id:'rhine-low-water', category:'Weather', title:'Rhine water levels fall below critical threshold', region:'Northwest Europe', severity:'high', duration:13, description:'Barges sail part-loaded and ARA inland logistics require more rotations, sharply increasing delivered costs.', freightShock:10, affects:opp=>['rotterdam','antwerp'].includes(opp.destination)||['rotterdam','antwerp'].includes(opp.origin), dealDays:6, dealPnl:-42_000, pnlFactor:.90 },
    { id:'brazil-frost', category:'Weather', commodity:'coffee', title:'Brazilian frost threatens coffee crop', region:'Brazil', severity:'high', duration:10, description:'Frost damages arabica areas. Prices and differentials gap higher while exporters reassess availability.', dailyDrift:58, affects:opp=>opp.commodity==='Coffee', dealDays:3, dealPnl:22_000, pnlFactor:1.12 },
    { id:'pilbara-cyclone', category:'Weather', title:'Cyclone closes Pilbara export terminals', region:'Western Australia', severity:'high', duration:9, description:'Port Hedland suspends loading and bulk carriers queue offshore, tightening iron ore supply and dry-bulk capacity.', freightShock:12, affects:opp=>opp.origin==='port-hedland', dealDays:7, dealPnl:-55_000, pnlFactor:.88 },
    { id:'europe-heatwave', category:'Weather', title:'European heatwave curtails smelter output', region:'Europe', severity:'medium', duration:8, description:'Power prices spike and metals processors reduce output, changing physical premiums and customer demand.', affects:opp=>['Aluminium','Zinc','Copper'].includes(opp.commodity), dealDays:2, dealPnl:-16_000, pnlFactor:.94 },
    { id:'port-cyberattack', category:'Operational', title:'Cyberattack disrupts port and customs systems', region:'European logistics', severity:'high', duration:7, description:'Electronic bills of lading, customs declarations and terminal release systems become unavailable.', firmPnl:-28_000, affects:opp=>transportClassForOpportunity(opp)==='ocean', dealDays:5, dealPnl:-31_000, pnlFactor:.91 },
    { id:'piracy-surge', category:'Operational', title:'Piracy surge raises marine security costs', region:'Indian Ocean / West Africa', severity:'medium', duration:12, description:'Armed guards, route deviations and higher insurance deductibles increase voyage costs.', freightShock:7, affects:opp=>['abidjan','durban','klang','doha','dubai'].includes(opp.origin), dealDays:3, dealPnl:-23_000, pnlFactor:.94 },
    { id:'warehouse-fire', category:'Operational', title:'Regional warehouse fire tightens storage capacity', region:'ARA / Mediterranean', severity:'medium', duration:8, description:'Emergency storage and inspection costs rise while nearby terminals impose stricter handling controls.', firmPnl:-12_000, affects:opp=>['rotterdam','antwerp','genova'].includes(opp.destination)||(opp.via||[]).some(x=>['rotterdam','antwerp','genova'].includes(x)), dealDays:2, dealPnl:-18_000, pnlFactor:.95 },
    { id:'buyer-downgrade-wave', category:'Credit', title:'Industrial buyer downgrade wave', region:'Europe / Asia', severity:'high', duration:14, description:'Weak industrial earnings lead banks and insurers to reduce buyer limits and demand stronger payment security.', creditPenalty:850_000, equityFactor:1.12, acceptanceShock:-5, affects:()=>true, dealDays:0, dealPnl:-20_000, pnlFactor:.90 },
    { id:'argentina-currency-controls', category:'Political / FX', title:'Argentina tightens capital and currency controls', region:'Argentina', severity:'high', duration:12, description:'Export proceeds, documentary settlement and local basis become volatile as controls tighten.', financingRateShock:.02, affects:opp=>opp.origin==='rosario', dealDays:6, dealPnl:-46_000, pnlFactor:.86 },
    { id:'carbon-border-cost', category:'Regulatory', title:'EU carbon border costs increase', region:'European Union', severity:'medium', duration:18, description:'New embedded-emissions requirements raise documentation and landed cost for carbon-intensive imports.', acceptanceShock:-3, affects:opp=>['Steel','Aluminium','Iron ore'].includes(opp.commodity)&&['rotterdam','antwerp','brescia'].includes(opp.destination), dealDays:3, dealPnl:-27_000, pnlFactor:.92 },
    { id:'quality-fraud-alert', category:'Compliance', title:'Industry-wide quality certificate fraud alert', region:'Global trade compliance', severity:'high', duration:10, description:'Banks and buyers require independent inspection and enhanced document verification for new cargoes.', firmPnl:-10_000, equityFactor:1.04, acceptanceShock:-4, affects:()=>true, dealDays:2, dealPnl:-15_000, pnlFactor:.95 }
  );


  const logisticsAssets = {
    'baltic-copper': {
      carrier: 'Baltic Rail 7', mode: 'Intermodal rail / truck', booking: 'Confirmed',
      warehouse: 'Brescia Cross-Dock', warehouseHub: 'brescia', storageDays: 2,
      purchaseTerms: 'DAP Brescia · LME M+1 + premium', salesTerms: 'DDP Brescia · 30 days',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Certificate of origin', 'CMR / rail note', 'Insurance certificate', 'Customs release']
    },
    'andean-copper': {
      carrier: 'MV Aurora Star', mode: 'Supramax / truck', booking: 'Firm charter',
      warehouse: 'Genoa Metal Terminal', warehouseHub: 'genova', storageDays: 5,
      purchaseTerms: 'FOB San Antonio · LME 3M + premium', salesTerms: 'DDP Brescia · 30 days',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Certificate of origin', 'Bill of lading', 'Insurance certificate', 'Customs release']
    },
    'meridian-copper': {
      carrier: 'MV Meridian Ace', mode: 'Handysize / truck', booking: 'Subject to LC',
      warehouse: 'Genoa Bonded Warehouse', warehouseHub: 'genova', storageDays: 7,
      purchaseTerms: 'CIF Genoa · LC at sight', salesTerms: 'DDP Brescia · 30 days',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Certificate of origin', 'Bill of lading', 'Insurance certificate', 'Customs release', 'LC compliance']
    },
    'rotterdam-alloy': {
      carrier: 'Rhine Barge 22', mode: 'Barge / rail', booking: 'Confirmed',
      warehouse: 'Rotterdam LME Warehouse', warehouseHub: 'rotterdam', storageDays: 4,
      purchaseTerms: 'FCA Rotterdam · LME cash + premium', salesTerms: 'DAP Brescia · 15 days',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Warehouse release', 'CMR / rail note', 'Insurance certificate', 'Customs release']
    },
    'maghreb-urea': {
      carrier: 'MV Atlas Coast', mode: 'Coaster / truck', booking: 'Firm booking',
      warehouse: 'Genoa Fertilizer Terminal', warehouseHub: 'genova', storageDays: 4,
      purchaseTerms: 'FOB Jorf Lasfar · Fertilizer index + premium', salesTerms: 'DAP Brescia · payment at delivery',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Certificate of origin', 'Bill of lading', 'Insurance certificate', 'Customs release', 'Moisture analysis']
    },
    'asia-aluminium': {
      carrier: 'MV Eastern Bridge', mode: 'Multipurpose vessel', booking: 'Subject to clean LC',
      warehouse: 'Singapore Metal Terminal', warehouseHub: 'singapore', storageDays: 3,
      purchaseTerms: 'FCA Jebel Ali · LME 3M + premium', salesTerms: 'CIF Singapore · LC at sight',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Certificate of origin', 'Bill of lading', 'Insurance certificate', 'LC compliance', 'Terminal release']
    },
    'atlantic-diesel': { carrier: 'MT Gulf Horizon', mode: 'MR product tanker', booking: 'Subjects lifted', warehouse: 'Rotterdam Independent Tank Terminal', warehouseHub: 'rotterdam', storageDays: 5, purchaseTerms: 'FOB Houston · Platts-linked', salesTerms: 'CIF Rotterdam · 10 days', documentSet: ['Commercial invoice','Certificate of quality','Certificate of quantity','Certificate of origin','Bill of lading','Cargo manifest','Insurance certificate','Customs release'] },
    'brazil-coffee': { carrier: 'Atlantic Container Line', mode: 'Container / truck', booking: 'Confirmed', warehouse: 'Genoa Food Grade Warehouse', warehouseHub: 'genova', storageDays: 6, purchaseTerms: 'FOB Santos · ICE differential', salesTerms: 'DAP Brescia · 20 days', documentSet: ['Commercial invoice','Packing list','Quality certificate','Phytosanitary certificate','Certificate of origin','Bill of lading','Insurance certificate','Customs release'] },
    'argentina-wheat': { carrier: 'MV Paraná Trader', mode: 'Handysize bulk carrier', booking: 'Firm booking', warehouse: 'Genoa Grain Terminal', warehouseHub: 'genova', storageDays: 4, purchaseTerms: 'FOB Upriver · MATIF basis', salesTerms: 'DAP Brescia · payment at delivery', documentSet: ['Commercial invoice','Weight certificate','Protein certificate','Phytosanitary certificate','Certificate of origin','Bill of lading','Insurance certificate','Customs release'] },
    'pilbara-iron': { carrier: 'MV Southern Cape', mode: 'Panamax bulk carrier', booking: 'Firm charter', warehouse: 'Shanghai Bulk Terminal', warehouseHub: 'shanghai', storageDays: 2, purchaseTerms: 'FOB Port Hedland · index-linked', salesTerms: 'CFR Shanghai · LC at sight', documentSet: ['Commercial invoice','Draft survey','Fe assay certificate','Moisture certificate','Certificate of origin','Bill of lading','Insurance certificate','LC compliance'] },
    'qatar-lng': { carrier: 'MT Mercs Excellence', mode: 'LNG carrier', booking: 'Subject to vetting approval', warehouse: 'Rotterdam Gate Terminal', warehouseHub: 'rotterdam', storageDays: 2, purchaseTerms: 'FOB Ras Laffan · JKM-linked', salesTerms: 'DES Rotterdam · LC at sight', documentSet: ['Commercial invoice','Certificate of quality','Certificate of quantity','Certificate of origin','Bill of lading','Cargo manifest','Insurance certificate','LC compliance','IMO 9 document'] },
    'malaysia-palm': { carrier: 'MT Palmera Star', mode: 'Vegetable oil tanker', booking: 'Subject to sustainability docs', warehouse: 'Genoa Food Grade Terminal', warehouseHub: 'genova', storageDays: 5, purchaseTerms: 'FOB Port Klang · MPOB index + premium', salesTerms: 'DDP Brescia · 20 days', documentSet: ['Commercial invoice','Packing list','FFA assay certificate','Moisture certificate','RSPO certificate','Certificate of origin','Bill of lading','Insurance certificate','Customs release','Phytosanitary certificate'] },
    'ivory-cocoa':    { carrier: 'Maersk West Africa Line', mode: 'Container / reefer', booking: 'Confirmed FCL booking', warehouse: 'Genoa Food Grade Warehouse', warehouseHub: 'genova', storageDays: 5, purchaseTerms: 'FOB Abidjan · ICCO index + quality premium', salesTerms: 'DAP Brescia · 20 days', documentSet: ['Commercial invoice','Packing list','Quality grading certificate','Humidity certificate','Phytosanitary certificate','Certificate of origin','Bill of lading','Insurance certificate','Customs release','Traceability certificate'] },
    'gulf-soybeans':  { carrier: 'MV Gulf Horizon Trader', mode: 'Panamax bulk carrier', booking: 'Firm charter', warehouse: 'Rotterdam Grain Terminal', warehouseHub: 'rotterdam', storageDays: 3, purchaseTerms: 'FOB New Orleans · CBOT basis', salesTerms: 'CFR Rotterdam · LC at sight', documentSet: ['Commercial invoice','Weight certificate','Protein certificate','Moisture certificate','Phytosanitary certificate','Certificate of origin','Bill of lading','Insurance certificate','LC compliance'] },
    'shanghai-steel': { carrier: 'MV Pacific Iron', mode: 'General cargo vessel', booking: 'Subject to mill certificate', warehouse: 'Antwerp Steel Terminal', warehouseHub: 'antwerp', storageDays: 7, purchaseTerms: 'FOB Shanghai · mill price + premium', salesTerms: 'DAP Antwerp · 30 days', documentSet: ['Commercial invoice','Packing list','Mill certificate','Quality certificate','Certificate of origin','Bill of lading','Insurance certificate','Customs release','EU import declaration','Anti-dumping compliance'] }
  };


  const vesselCatalog = [
    {
      id: 'ocean-pioneer', name: 'MV Ocean Pioneer', vesselClass: 'Handysize', capacity: 32_000,
      transportClass: 'ocean', homeHub: 'santiago', charterDays: 75, charterCost: 95_000,
      bonusPnl: 22_000, durationBonus: 4, minReputation: 50, minDeals: 0,
      description: 'Versatile Handysize vessel for transatlantic routes. Reduces spot-market dependence and accelerates execution.'
    },
    {
      id: 'gulf-navigator', name: 'MV Gulf Navigator', vesselClass: 'Multipurpose', capacity: 18_000,
      transportClass: 'ocean', homeHub: 'dubai', charterDays: 60, charterCost: 75_000,
      bonusPnl: 18_000, durationBonus: 3, minReputation: 52, minDeals: 1,
      description: 'Multipurpose vessel positioned in the Gulf, suitable for parcel cargoes and routes into the Mediterranean.'
    },
    {
      id: 'rhine-link', name: 'Rhine Link 22', vesselClass: 'River barge', capacity: 2_200,
      transportClass: 'barge', homeHub: 'rotterdam', charterDays: 45, charterCost: 38_000,
      bonusPnl: 12_000, durationBonus: 2, minReputation: 58, minDeals: 2, requiresOffice: 'rotterdam',
      description: 'River barge for Rhine–Alps corridors. Ideal for metals and warehouse releases from Rotterdam.'
    },
    {
      id: 'atlas-coaster', name: 'MV Atlas Coaster', vesselClass: 'Coaster', capacity: 8_500,
      transportClass: 'ocean', homeHub: 'casablanca', charterDays: 40, charterCost: 46_000,
      bonusPnl: 13_000, durationBonus: 2, minReputation: 56, minDeals: 2, requiresOffice: 'genova',
      description: 'Mediterranean coaster for fertilizer and metals parcels between North Africa and Southern Europe.'
    },
    {
      id: 'eastern-merchant', name: 'MV Eastern Merchant', vesselClass: 'Multipurpose', capacity: 22_000,
      transportClass: 'ocean', homeHub: 'dubai', charterDays: 55, charterCost: 86_000,
      bonusPnl: 20_000, durationBonus: 3, minReputation: 68, minDeals: 5, requiresOffice: 'singapore',
      description: 'Regional asset for the Gulf–Asia corridor, with flexibility for parcel cargoes and port rotations.'
    },
    { id: 'gulf-product-tanker', name: 'MT Shippy Horizon', vesselClass: 'MR product tanker', capacity: 47000, transportClass: 'ocean', homeHub: 'houston', charterDays: 55, charterCost: 165000, bonusPnl: 46000, durationBonus: 3, minReputation: 64, minDeals: 3, requiresOffice: 'rotterdam', description: 'Tanker dedicated to Gulf Coast–ARA distillates, with tank segregation and full vetting.' },
    { id: 'parana-handy', name: 'MV River Plata', vesselClass: 'Handysize bulker', capacity: 33000, transportClass: 'ocean', homeHub: 'rosario', charterDays: 48, charterCost: 92000, bonusPnl: 26000, durationBonus: 2, minReputation: 61, minDeals: 4, requiresOffice: 'genova', description: 'Handysize vessel for grain parcels and draft-restricted ports.' },
    { id: 'pilbara-panamax', name: 'MV Iron Meridian', vesselClass: 'Panamax bulker', capacity: 76000, transportClass: 'ocean', homeHub: 'port-hedland', charterDays: 52, charterCost: 210000, bonusPnl: 62000, durationBonus: 3, minReputation: 72, minDeals: 6, requiresOffice: 'singapore', description: 'Panamax vessel dedicated to Australia–North Asia dry-bulk trades.' }
  ];


  // ── v35 global office network ──────────────────────────────────────────────
  const officeCatalog = [
    { id:'geneva', name:'Geneva Headquarters', city:'Geneva', country:'Switzerland', flag:'🇨🇭', region:'Group HQ', hub:'geneva', cost:0, buildDays:0, dailyCost:150, minLevel:1, minReputation:0, minDeals:0, minHqTier:1, pnlBonus:0, acceptance:0, equityReduction:0, durationBonus:0, riskReduction:0, creditBonus:0, coverageCountries:['Switzerland'], focusCommodities:[], description:'The group command centre for capital, risk, compliance, banks and global strategy.', benefit:'Controls the entire merchant network.' },
    { id:'genova', name:'Genoa Operations Office', city:'Genoa', country:'Italy', flag:'🇮🇹', region:'Southern Europe', hub:'genova', cost:120_000, buildDays:3, dailyCost:600, minLevel:2, minReputation:15, minDeals:1, minHqTier:1, pnlBonus:4_000, acceptance:2, equityReduction:.01, durationBonus:2, riskReduction:1, creditBonus:50_000, coverageCountries:['Italy'], focusCommodities:['Copper','Aluminium','Urea','Coffee','Wheat','Palm oil','Cocoa'], description:'Port operations, customs, bonded storage and final delivery into Northern Italy.', benefit:'Faster Italian deliveries and stronger buyer relationships.' },
    { id:'santiago', name:'Santiago Origination Office', city:'Santiago', country:'Chile', flag:'🇨🇱', region:'Andean Americas', hub:'santiago', cost:260_000, buildDays:5, dailyCost:850, minLevel:4, minReputation:21, minDeals:2, minHqTier:1, pnlBonus:9_000, acceptance:3, equityReduction:.015, durationBonus:1, riskReduction:1, creditBonus:100_000, coverageCountries:['Chile'], focusCommodities:['Copper'], description:'Mine relationships, concentrate expertise and local copper origination.', benefit:'Improves Chilean copper margin and supplier access.' },
    { id:'dubai', name:'Dubai Commercial Office', city:'Dubai', country:'UAE', flag:'🇦🇪', region:'Middle East', hub:'dubai', cost:390_000, buildDays:6, dailyCost:1_150, minLevel:6, minReputation:30, minDeals:3, minHqTier:2, pnlBonus:11_000, acceptance:4, equityReduction:.015, durationBonus:1, riskReduction:1, creditBonus:180_000, coverageCountries:['UAE','Qatar'], focusCommodities:['Copper','Aluminium','Diesel','LNG'], description:'Regional commercial coverage, Islamic trade finance and Gulf supplier access.', benefit:'Stronger Gulf negotiations and funding capacity.' },
    { id:'casablanca', name:'Casablanca Fertilizer Office', city:'Casablanca', country:'Morocco', flag:'🇲🇦', region:'North Africa', hub:'casablanca', cost:330_000, buildDays:6, dailyCost:900, minLevel:8, minReputation:34, minDeals:3, minHqTier:2, pnlBonus:10_000, acceptance:4, equityReduction:.018, durationBonus:2, riskReduction:2, creditBonus:120_000, coverageCountries:['Morocco'], focusCommodities:['Urea'], description:'Fertilizer origination, quality control and Mediterranean freight execution.', benefit:'Unlocks a durable North African sourcing franchise.' },
    { id:'rotterdam', name:'Rotterdam Trading Office', city:'Rotterdam', country:'Netherlands', flag:'🇳🇱', region:'Northern Europe', hub:'rotterdam', cost:520_000, buildDays:8, dailyCost:1_450, minLevel:9, minReputation:40, minDeals:4, minHqTier:2, pnlBonus:13_000, acceptance:4, equityReduction:.025, durationBonus:2, riskReduction:2, creditBonus:300_000, coverageCountries:['Netherlands','Belgium','Germany'], focusCommodities:['Aluminium','Diesel','Soybeans','Zinc','LNG'], description:'ARA storage, blending, barges, derivatives and access to industrial buyers.', benefit:'Major European hub with freight, financing and storage advantages.' },
    { id:'antwerp', name:'Antwerp Industrial Office', city:'Antwerp', country:'Belgium', flag:'🇧🇪', region:'Northern Europe', hub:'antwerp', cost:610_000, buildDays:9, dailyCost:1_550, minLevel:10, minReputation:44, minDeals:4, minHqTier:2, pnlBonus:15_000, acceptance:4, equityReduction:.02, durationBonus:2, riskReduction:2, creditBonus:250_000, coverageCountries:['Belgium','Netherlands','Germany'], focusCommodities:['Steel','Zinc','Nickel'], description:'EU customs, metals warehousing and industrial customer coverage.', benefit:'Reduces legal and execution friction on complex European imports.' },
    { id:'santos', name:'Santos Soft Commodities Office', city:'Santos', country:'Brazil', flag:'🇧🇷', region:'South America', hub:'santos', cost:680_000, buildDays:10, dailyCost:1_650, minLevel:12, minReputation:48, minDeals:5, minHqTier:2, pnlBonus:17_000, acceptance:5, equityReduction:.02, durationBonus:2, riskReduction:2, creditBonus:260_000, coverageCountries:['Brazil'], focusCommodities:['Coffee','Soybeans'], description:'Farm origination, quality grading, export documentation and port execution.', benefit:'Builds a premium Brazilian origination franchise.' },
    { id:'rosario', name:'Rosario Grain Office', city:'Rosario', country:'Argentina', flag:'🇦🇷', region:'South America', hub:'rosario', cost:720_000, buildDays:10, dailyCost:1_700, minLevel:13, minReputation:50, minDeals:5, minHqTier:2, pnlBonus:18_000, acceptance:5, equityReduction:.02, durationBonus:2, riskReduction:2, creditBonus:220_000, coverageCountries:['Argentina'], focusCommodities:['Wheat','Soybeans'], description:'Paraná River origination, elevation capacity and agricultural basis expertise.', benefit:'Improves grain margins and river disruption management.' },
    { id:'singapore', name:'Singapore Asia-Pacific Office', city:'Singapore', country:'Singapore', flag:'🇸🇬', region:'Asia-Pacific', hub:'singapore', cost:1_050_000, buildDays:12, dailyCost:2_500, minLevel:14, minReputation:56, minDeals:6, minHqTier:3, pnlBonus:23_000, acceptance:6, equityReduction:.03, durationBonus:2, riskReduction:3, creditBonus:600_000, coverageCountries:['Singapore','Malaysia','Indonesia'], focusCommodities:['Aluminium','Palm oil','Nickel','Iron ore','LNG'], description:'Regional trading, freight, trade finance and Asian counterparty coverage.', benefit:'A major gateway to Asian commodities and shipping markets.' },
    { id:'klang', name:'Port Klang Agri Office', city:'Port Klang', country:'Malaysia', flag:'🇲🇾', region:'Southeast Asia', hub:'klang', cost:850_000, buildDays:11, dailyCost:1_950, minLevel:15, minReputation:58, minDeals:6, minHqTier:3, pnlBonus:20_000, acceptance:5, equityReduction:.02, durationBonus:2, riskReduction:2, creditBonus:280_000, coverageCountries:['Malaysia','Indonesia'], focusCommodities:['Palm oil','Nickel'], description:'Sustainability certification, tropical oils and Southeast Asian logistics.', benefit:'Strengthens agri and battery-material origination.' },
    { id:'abidjan', name:'Abidjan West Africa Office', city:'Abidjan', country:'Ivory Coast', flag:'🇨🇮', region:'West Africa', hub:'abidjan', cost:920_000, buildDays:12, dailyCost:2_050, minLevel:16, minReputation:60, minDeals:7, minHqTier:3, pnlBonus:24_000, acceptance:6, equityReduction:.025, durationBonus:2, riskReduction:3, creditBonus:250_000, coverageCountries:['Ivory Coast'], focusCommodities:['Cocoa'], description:'Cocoa grading, traceability, local financing and export execution.', benefit:'Creates a high-margin West African soft-commodity franchise.' },
    { id:'shanghai', name:'Shanghai Industrial Office', city:'Shanghai', country:'China', flag:'🇨🇳', region:'North Asia', hub:'shanghai', cost:1_650_000, buildDays:16, dailyCost:3_100, minLevel:18, minReputation:66, minDeals:8, minHqTier:3, pnlBonus:32_000, acceptance:7, equityReduction:.035, durationBonus:2, riskReduction:3, creditBonus:750_000, coverageCountries:['China'], focusCommodities:['Iron ore','Steel','Copper','Nickel'], description:'Industrial demand, mill relationships, customs and local market intelligence.', benefit:'Access to the world’s largest industrial commodity demand centre.' },
    { id:'durban', name:'Durban Southern Africa Office', city:'Durban', country:'South Africa', flag:'🇿🇦', region:'Southern Africa', hub:'durban', cost:1_350_000, buildDays:15, dailyCost:2_650, minLevel:20, minReputation:68, minDeals:9, minHqTier:3, pnlBonus:29_000, acceptance:6, equityReduction:.03, durationBonus:2, riskReduction:4, creditBonus:450_000, coverageCountries:['South Africa','Zambia'], focusCommodities:['Zinc','Copper','Iron ore'], description:'Mine-to-port coordination, assay control and African corridor logistics.', benefit:'Reduces operational risk on strategic African metals.' },
    { id:'doha', name:'Doha LNG Office', city:'Doha', country:'Qatar', flag:'🇶🇦', region:'Middle East', hub:'doha', cost:2_100_000, buildDays:18, dailyCost:3_750, minLevel:22, minReputation:72, minDeals:10, minHqTier:4, pnlBonus:40_000, acceptance:8, equityReduction:.04, durationBonus:2, riskReduction:4, creditBonus:1_000_000, coverageCountries:['Qatar','UAE'], focusCommodities:['LNG'], description:'LNG scheduling, vessel vetting, energy contracts and sovereign counterparties.', benefit:'Institutional access to one of the world’s richest gas markets.' },
    { id:'houston', name:'Houston Energy Office', city:'Houston', country:'USA', flag:'🇺🇸', region:'North America', hub:'houston', cost:2_450_000, buildDays:20, dailyCost:4_150, minLevel:24, minReputation:75, minDeals:11, minHqTier:4, pnlBonus:44_000, acceptance:8, equityReduction:.04, durationBonus:2, riskReduction:4, creditBonus:1_200_000, coverageCountries:['USA'], focusCommodities:['Diesel','LNG','Soybeans'], description:'US Gulf energy, grain exports, derivatives and dollar funding.', benefit:'A deep balance-sheet platform in the largest commodity-finance market.' },
    { id:'port-hedland', name:'Pilbara Resources Office', city:'Port Hedland', country:'Australia', flag:'🇦🇺', region:'Oceania', hub:'port-hedland', cost:3_200_000, buildDays:24, dailyCost:5_100, minLevel:26, minReputation:80, minDeals:13, minHqTier:4, pnlBonus:55_000, acceptance:9, equityReduction:.05, durationBonus:3, riskReduction:5, creditBonus:1_500_000, coverageCountries:['Australia'], focusCommodities:['Iron ore'], description:'Mine allocations, Capesize scheduling and long-haul dry-bulk execution.', benefit:'Strategic access to a globally dominant resource origin.' }
  ];

  const staffCatalog = [
    { id: 'operations-coordinator', role: 'Operations Coordinator', hireCost: 45_000, dailySalary: 250, minReputation: 50, description: 'Coordinates documents, terminals, customs and delivery windows.', benefit: 'Document expediting costs 40% less and adds 5 readiness points.' },
    { id: 'risk-analyst', role: 'Risk Analyst', hireCost: 60_000, dailySalary: 320, minReputation: 54, description: 'Monitors hedges, concentration, liquidity buffers and desk limits.', benefit: 'Reduces the risk score and re-hedging costs by 35%.' },
    { id: 'freight-charterer', role: 'Freight Charterer', hireCost: 55_000, dailySalary: 300, minReputation: 56, description: 'Negotiates time charters, laycan, demurrage and route alternatives.', benefit: 'Reduces vessel upfront hire by 15%.' },
    { id: 'trade-finance-manager', role: 'Trade Finance Manager', hireCost: 75_000, dailySalary: 420, minReputation: 60, description: 'LC, borrowing-base and working-capital facility structure.', benefit: 'Increases the credit line by $1M and reduces required equity by 10%.' }
  ];

  const investmentCatalog = [
    { id:'atacama-copper', chain:'upstream', name:'Atacama Copper Mine', hub:'santiago', icon:'⛏', commodity:'Copper', maxLevel:3, baseCost:260000, buildDays:7, dailyIncome:1800, pnlBonus:9500, equityReduction:.025, minReputation:50, minDeals:0, description:'Mining offtake and production interest. Reduces copper sourcing cost and secures priority physical flows.' },
    { id:'atlas-urea-plant', chain:'upstream', name:'Atlas Urea Production', hub:'casablanca', icon:'◆', commodity:'Urea', maxLevel:3, baseCost:340000, buildDays:9, dailyIncome:2300, pnlBonus:12000, equityReduction:.02, minReputation:55, minDeals:1, description:'Industrial participation in urea production, with preferential access to Mediterranean volumes.' },
    { id:'santos-estate', chain:'upstream', name:'Santos Coffee Estate', hub:'santos', icon:'♨', commodity:'Coffee', maxLevel:3, baseCost:390000, buildDays:10, dailyIncome:2800, pnlBonus:14500, equityReduction:.02, minReputation:61, minDeals:3, description:'Captive origination, quality control and traceability across the Brazilian coffee chain.' },
    { id:'permian-production', chain:'upstream', name:'Permian Production Interest', hub:'houston', icon:'◉', commodity:'Diesel', priceKey:'crude', maxLevel:3, baseCost:620000, buildDays:14, dailyIncome:4500, pnlBonus:22000, equityReduction:.018, minReputation:66, minDeals:4, description:'Energy working interest that improves feedstock access and margins on refined products.' },
    { id:'genoa-terminal', chain:'midstream', name:'Genoa Multipurpose Terminal', hub:'genova', icon:'▤', routeHub:'genova', maxLevel:3, baseCost:220000, buildDays:6, dailyIncome:1600, pnlBonus:6000, durationBonus:1, minReputation:52, minDeals:1, description:'Berth priority, customs handling and dedicated storage for cargoes bound for Northern Italy.' },
    { id:'rotterdam-tanks', chain:'midstream', name:'Rotterdam Storage & Blending', hub:'rotterdam', icon:'▥', routeHub:'rotterdam', maxLevel:3, baseCost:470000, buildDays:11, dailyIncome:3400, pnlBonus:11000, durationBonus:1, minReputation:60, minDeals:2, description:'Tankage, warehouse receipts and blending optionality in Europe’s leading hub.' },
    { id:'ocean-logistics-pool', chain:'midstream', name:'Ocean Logistics Pool', hub:'geneva', icon:'◈', ocean:true, maxLevel:3, baseCost:360000, buildDays:8, dailyIncome:2100, pnlBonus:7500, durationBonus:1, minReputation:57, minDeals:2, description:'Pool of ocean capacity and COA contracts that reduce freight volatility and transit time.' },
    { id:'brescia-cable-mill', chain:'downstream', name:'Brescia Cable Mill', hub:'brescia', icon:'⌁', commodities:['Copper','Aluminium'], destination:'brescia', maxLevel:3, baseCost:310000, buildDays:8, dailyIncome:2600, pnlBonus:13500, acceptanceBonus:3, minReputation:54, minDeals:1, description:'Captive demand and conversion margin in copper and aluminium. Stabilizes sales and increases value per tonne.' },
    { id:'po-valley-distribution', chain:'downstream', name:'Po Valley Fertilizer Network', hub:'brescia', icon:'✦', commodity:'Urea', destination:'brescia', maxLevel:3, baseCost:280000, buildDays:7, dailyIncome:2200, pnlBonus:10500, acceptanceBonus:4, minReputation:58, minDeals:2, description:'Agricultural distribution network with local warehouses and captive seasonal demand.' },
    { id:'ara-fuel-blending', chain:'downstream', name:'ARA Fuel Blending Plant', hub:'rotterdam', icon:'◫', commodity:'Diesel', priceKey:'crude', destination:'rotterdam', maxLevel:3, baseCost:540000, buildDays:12, dailyIncome:4100, pnlBonus:20500, acceptanceBonus:3, minReputation:65, minDeals:4, description:'Blending and specification management turn feedstock into higher-margin saleable products.' },
    { id:'italian-roastery', chain:'downstream', name:'Italian Roastery Group', hub:'brescia', icon:'☕', commodity:'Coffee', destination:'brescia', maxLevel:3, baseCost:430000, buildDays:10, dailyIncome:3300, pnlBonus:17000, acceptanceBonus:3, minReputation:64, minDeals:4, description:'Roasting capacity and branded distribution to capture downstream margin in the coffee chain.' },
    { id:'yangtze-steel-interest', chain:'downstream', name:'Yangtze Steel Mill Interest', hub:'shanghai', icon:'▰', commodity:'Iron ore', destination:'shanghai', maxLevel:3, baseCost:780000, buildDays:16, dailyIncome:5900, pnlBonus:30000, acceptanceBonus:2, minReputation:72, minDeals:6, description:'Steel-industry interest that creates captive demand for large iron ore cargoes.' }
  ];

  const shopCatalog = [
    {
      id:'owned-handysize', category:'fleet', name:'Handysize Workhorse', icon:'🚢', vesselCatalogId:'ocean-pioneer',
      cost:1_150_000, buildDays:8, maxOwned:2, minReputation:54, minDeals:1, maintenance:1_450,
      description:'Purchase a versatile Handysize vessel instead of relying exclusively on short time-charters.',
      benefit:'Permanent vessel · 32,000 t capacity · no charter expiry'
    },
    {
      id:'owned-rhine-barge', category:'fleet', name:'Rhine Logistics Barge', icon:'⛴', vesselCatalogId:'rhine-link',
      cost:640_000, buildDays:6, maxOwned:2, minReputation:58, minDeals:2, requiresOffice:'rotterdam', maintenance:720,
      description:'Own a shallow-draft barge for metals and warehouse releases across the Rhine corridor.',
      benefit:'Permanent river capacity · strong European execution edge'
    },
    {
      id:'owned-product-tanker', category:'fleet', name:'MR Product Tanker', icon:'◉', vesselCatalogId:'gulf-product-tanker',
      cost:2_850_000, buildDays:12, maxOwned:1, minReputation:64, minDeals:3, requiresOffice:'rotterdam', maintenance:3_200,
      description:'A permanently controlled product tanker for Gulf Coast and ARA distillate flows.',
      benefit:'47,000 t tanker · +$46K freight edge · no charter expiry'
    },
    {
      id:'owned-panamax', category:'fleet', name:'Panamax Bulk Carrier', icon:'▰', vesselCatalogId:'pilbara-panamax',
      cost:3_650_000, buildDays:14, maxOwned:1, minReputation:72, minDeals:6, requiresOffice:'singapore', maintenance:4_100,
      description:'Acquire large dry-bulk capacity for ore, grains and long-haul industrial cargoes.',
      benefit:'76,000 t capacity · +$62K freight edge · strategic endgame asset'
    },
    {
      id:'genoa-bonded-warehouse', category:'storage', name:'Genoa Bonded Warehouse', icon:'▥', hub:'genova',
      cost:420_000, buildDays:6, maxOwned:3, minReputation:52, minDeals:1, requiresOffice:'genova', dailyCost:320, dailyIncome:900,
      matchHubs:['genova','brescia'], storageDiscount:.12, pnlBonus:4_500, equityReduction:.008,
      description:'Dedicated bonded capacity for metals, fertilizer and food-grade parcels entering Northern Italy.',
      benefit:'Lower storage cost · +$4.5K route edge per unit · working-capital relief'
    },
    {
      id:'rotterdam-tank-farm', category:'storage', name:'Rotterdam Tank Farm', icon:'▤', hub:'rotterdam',
      cost:880_000, buildDays:9, maxOwned:2, minReputation:60, minDeals:2, requiresOffice:'rotterdam', dailyCost:650, dailyIncome:2_100,
      matchHubs:['rotterdam','antwerp'], storageDiscount:.16, pnlBonus:9_000, equityReduction:.012,
      description:'Independent tankage and blending capacity in the ARA hub for energy and liquid commodities.',
      benefit:'Storage optionality · +$9K route edge · stronger financing base'
    },
    {
      id:'singapore-bonded-hub', category:'storage', name:'Singapore Bonded Logistics Hub', icon:'▦', hub:'singapore',
      cost:1_180_000, buildDays:11, maxOwned:2, minReputation:68, minDeals:5, requiresOffice:'singapore', dailyCost:820, dailyIncome:2_700,
      matchHubs:['singapore','klang'], storageDiscount:.18, pnlBonus:12_000, equityReduction:.014, acceptanceBonus:1,
      description:'A bonded regional warehouse for metals, energy parcels and high-value Asian cargoes.',
      benefit:'Asian storage capacity · +$12K route edge · improved buyer service'
    },
    {
      id:'project-office', category:'infrastructure', name:'Capital Projects Office', icon:'⌂', hub:'geneva',
      cost:520_000, buildDays:7, maxOwned:2, minReputation:56, minDeals:2, dailyCost:480, builderBonus:1,
      description:'Hire engineers, project managers and procurement specialists dedicated to expansion projects.',
      benefit:'+1 simultaneous project team per office'
    },
    {
      id:'genoa-handling-system', category:'infrastructure', name:'Genoa Priority Handling System', icon:'⚓', hub:'genova',
      cost:690_000, buildDays:8, maxOwned:2, minReputation:58, minDeals:2, requiresOffice:'genova', dailyCost:520, dailyIncome:1_100,
      matchHubs:['genova','brescia'], durationBonus:1, pnlBonus:7_000, acceptanceBonus:1,
      description:'Dedicated cranes, customs lanes and truck slots protect delivery windows in Northern Italy.',
      benefit:'-1 transit day · +$7K route edge · stronger execution promise'
    },
    {
      id:'intermodal-truck-fleet', category:'infrastructure', name:'Intermodal Truck Fleet', icon:'▣', hub:'brescia',
      cost:480_000, buildDays:6, maxOwned:2, minReputation:54, minDeals:1, dailyCost:390, dailyIncome:750,
      transportClass:'land', durationBonus:1, pnlBonus:5_000, acceptanceBonus:1,
      description:'Owned last-mile capacity for overland and port-to-customer movements.',
      benefit:'Faster land execution · +$5K deal edge · lower delivery risk'
    },
    {
      id:'digital-control-tower', category:'infrastructure', name:'Digital Trade Control Tower', icon:'⌁', hub:'geneva',
      cost:760_000, buildDays:9, maxOwned:1, minReputation:62, minDeals:3, dailyCost:620, dailyIncome:1_500,
      pnlBonus:4_000, equityReduction:.015, acceptanceBonus:2,
      description:'Integrates documentation, vessel tracking, inventory and counterparty alerts across the group.',
      benefit:'Global +$4K execution edge · lower equity · +2 acceptance'
    }
  ];

  const missionCatalog = [
    { id: 'first-cargo', title: 'First Cargo', description: 'Complete your first physical deal.', target: 1, progress: s => s.completedDeals, achieved: s => s.completedDeals >= 1, cash: 40_000, reputation: 2 },
    { id: 'risk-discipline', title: 'Risk Discipline', description: 'Close a profitable deal with at least an 80% hedge.', target: 1, progress: s => s.history.filter(h => h.pnl > 0 && (h.hedgeRatio || 0) >= 80).length, achieved: s => s.history.some(h => h.pnl > 0 && (h.hedgeRatio || 0) >= 80), cash: 55_000, reputation: 2 },
    { id: 'fleet-operator', title: 'Fleet Operator', description: 'Complete a deal using a time-chartered vessel.', target: 1, progress: s => s.history.filter(h => h.shippingStrategy === 'internal-fleet').length, achieved: s => s.history.some(h => h.shippingStrategy === 'internal-fleet'), cash: 75_000, reputation: 3 },
    { id: 'european-network', title: 'European Network', description: 'Open the Genoa and Rotterdam desks.', target: 2, progress: s => ['genova','rotterdam'].filter(id => officeOwned(id)).length, achieved: s => officeOwned('genova') && officeOwned('rotterdam'), cash: 100_000, credit: 500_000, reputation: 3 },
    { id: 'relationship-builder', title: 'Relationship Builder', description: 'Complete at least three deals and raise one commercial relationship above 60.', target: 4, progress: s => Math.min(3,s.completedDeals) + (Object.values(s.counterparties||{}).some(p => p.relationship >= 60) ? 1 : 0), achieved: s => s.completedDeals >= 3 && Object.values(s.counterparties||{}).some(p => p.relationship >= 60), cash: 85_000, reputation: 3 },
    { id: 'crisis-tested', title: 'Crisis Tested', description: 'Complete a deal affected by a global dislocation.', target: 1, progress: s => s.history.filter(h => (h.globalEventImpacts||[]).length).length, achieved: s => s.history.some(h => (h.globalEventImpacts||[]).length), cash: 90_000, reputation: 3 },
    { id: 'academy-graduate', title: 'Academy Graduate', description: 'Complete every Academy lesson.', target: academyCatalog.length, progress: s => Object.values(s.academyProgress||{}).filter(item=>item.completed).length, achieved: s => Object.values(s.academyProgress||{}).filter(item=>item.completed).length >= academyCatalog.length, cash: 120_000, reputation: 4 },
    { id: 'multi-commodity', title: 'Multi-Commodity Merchant', description: 'Close deals in at least three different commodities.', target: 3, progress: s => new Set((s.history||[]).map(item=>item.commodity)).size, achieved: s => new Set((s.history||[]).map(item=>item.commodity)).size >= 3, cash: 140_000, reputation: 4 },
    { id: 'liquidity-professional', title: 'Liquidity Professional', description: 'Close profitably a deal that required at least one margin call.', target: 1, progress: s => (s.history||[]).filter(item=>item.pnl>0&&(item.marginCalls||0)>0).length, achieved: s => (s.history||[]).some(item=>item.pnl>0&&(item.marginCalls||0)>0), cash: 110_000, credit: 350_000, reputation: 3 },
    { id: 'top-ten-merchant', title: 'Top 10 Merchant', description: 'Reach the Career League top 10 after closing at least three deals.', target: 10, progress: s => s.completedDeals < 3 ? 0 : Math.max(0, 11 - leaderboardPosition('overall')), achieved: s => s.completedDeals >= 3 && leaderboardPosition('overall') <= 10, cash: 150_000, reputation: 4 },
    { id: 'vertical-pioneer', title: 'Vertical Pioneer', description: 'Build at least one upstream, one midstream and one downstream asset.', target: 3, progress: s => ['upstream','midstream','downstream'].filter(chain => investmentCatalog.some(asset => asset.chain === chain && investmentLevel(asset.id) > 0)).length, achieved: s => ['upstream','midstream','downstream'].every(chain => investmentCatalog.some(asset => asset.chain === chain && investmentLevel(asset.id) > 0)), cash: 180_000, reputation: 5 },
    { id: 'industrial-empire', title: 'Industrial Empire', description: 'Reach a combined total of 10 industrial asset levels.', target: 10, progress: s => totalInvestmentLevels(), achieved: s => totalInvestmentLevels() >= 10, cash: 300_000, credit: 500_000, reputation: 6 },
    { id: 'first-owned-asset', title: 'Asset Owner', description: 'Commission your first permanent asset from the Empire Shop.', target: 1, progress: s => s.shopDeliveries||0, achieved: s => (s.shopDeliveries||0)>=1, cash: 100_000, reputation: 3 },
    { id: 'logistics-magnate', title: 'Logistics Magnate', description: 'Own a vessel, a warehouse and an infrastructure asset.', target: 3, progress: s => ['fleet','storage','infrastructure'].filter(category=>shopCatalog.some(item=>item.category===category&&shopOwnedQuantity(item.id)>0)).length, achieved: s => ['fleet','storage','infrastructure'].every(category=>shopCatalog.some(item=>item.category===category&&shopOwnedQuantity(item.id)>0)), cash: 350_000, credit: 500_000, reputation: 6 },
    { id: 'global-desk', title: 'Global Desk', description: 'Open Singapore and complete at least five deals.', target: 6, progress: s => Math.min(5, s.completedDeals) + (officeOwned('singapore') ? 1 : 0), achieved: s => officeOwned('singapore') && s.completedDeals >= 5, cash: 200_000, reputation: 5 },
    { id: 'energy-diversification', title: 'Energy & Agri Trader', description: 'Close at least one energy deal (Diesel or LNG) and one agricultural deal (Coffee, Wheat, or Palm oil).', target: 2, progress: s => (((s.history||[]).some(d=>['Diesel','LNG'].includes(d.commodity)))?1:0)+(((s.history||[]).some(d=>['Coffee','Wheat','Palm oil'].includes(d.commodity)))?1:0), achieved: s => (s.history||[]).some(d=>['Diesel','LNG'].includes(d.commodity)) && (s.history||[]).some(d=>['Coffee','Wheat','Palm oil'].includes(d.commodity)), cash: 130_000, reputation: 4 },
    { id: 'atlantic-originator', title: 'Atlantic Originator', description: 'Close deals from both the Americas (New Orleans or Santos) and West Africa (Abidjan) in the same career.', target: 2, progress: s => { const origins = new Set((s.history||[]).map(d=>{const o=getOpportunity(d.opportunityId); return o?.origin;})); return (['new-orleans','santos','rosario'].some(h=>origins.has(h))?1:0)+(['abidjan'].some(h=>origins.has(h))?1:0); }, achieved: s => { const origins = new Set((s.history||[]).map(d=>getOpportunity(d.opportunityId)?.origin)); return ['new-orleans','santos','rosario'].some(h=>origins.has(h)) && origins.has('abidjan'); }, cash: 175_000, reputation: 5 },
    { id: 'steel-specialist', title: 'Steel Specialist', description: 'Close the Yangtze Steel Export deal.', target: 1, progress: s => (s.history||[]).filter(d=>d.opportunityId==='shanghai-steel').length, achieved: s => (s.history||[]).some(d=>d.opportunityId==='shanghai-steel'), cash: 180_000, reputation: 5 },
    { id: 'lng-specialist', title: 'LNG Specialist', description: 'Close the Qatar LNG Express deal.', target: 1, progress: s => (s.history||[]).filter(d=>d.opportunityId==='qatar-lng').length, achieved: s => (s.history||[]).some(d=>d.opportunityId==='qatar-lng'), cash: 160_000, reputation: 5 },
    { id: 'strategic-sourcer', title: 'Strategic Sourcer', description: 'Fulfil a three-cargo procurement commitment without a shortfall.', target: 1, progress: s => s.commitmentsFulfilled || 0, achieved: s => (s.commitmentsFulfilled || 0) >= 1, cash: 135_000, reputation: 4 },
    { id: 'control-tower', title: 'Control Tower', description: 'Mitigate congestion on three live cargoes.', target: 3, progress: s => s.congestionMitigations || 0, achieved: s => (s.congestionMitigations || 0) >= 3, cash: 120_000, reputation: 3 },
    { id: 'scenario-ready', title: 'Scenario Ready', description: 'Run three board-level stress scenarios.', target: 3, progress: s => s.stressTestsRun || 0, achieved: s => (s.stressTestsRun || 0) >= 3, cash: 90_000, reputation: 3 },
    { id: 'geneva-merchant-house', title: 'Geneva Merchant House', description: 'Upgrade the headquarters to Tier 3.', target: 3, progress:s=>s.hqTier||1, achieved:s=>(s.hqTier||1)>=3, cash:180_000, credit:300_000, reputation:4 },
    { id: 'framework-merchant', title: 'Framework Merchant', description: 'Fulfil one three-cargo commercial framework.', target:1, progress:s=>Object.values(s.commercialFrameworks||{}).filter(f=>f.status==='fulfilled').length, achieved:s=>Object.values(s.commercialFrameworks||{}).some(f=>f.status==='fulfilled'), cash:160_000, reputation:4 },
    { id: 'crisis-room', title: 'Crisis Room', description: 'Activate two response playbooks during global disruptions.', target:2, progress:s=>Object.values(s.crisisResponses||{}).length, achieved:s=>Object.values(s.crisisResponses||{}).length>=2, cash:120_000, reputation:3 },
    { id:'multinational-network', title:'Multinational Network', description:'Operate offices in five different countries.', target:5, progress:s=>new Set(officeCatalog.filter(o=>(s.offices||[]).includes(o.id)).map(o=>o.country)).size, achieved:s=>new Set(officeCatalog.filter(o=>(s.offices||[]).includes(o.id)).map(o=>o.country)).size>=5, cash:280_000, credit:650_000, reputation:5 },
    { id:'global-office-platform', title:'Global Office Platform', description:'Open ten offices outside Geneva.', target:10, progress:s=>Math.max(0,(s.offices||[]).length-1), achieved:s=>Math.max(0,(s.offices||[]).length-1)>=10, cash:750_000, credit:1_500_000, reputation:8 }
  ];

  const continentPolygons = [
    [[-168,72],[-140,70],[-125,55],[-123,40],[-112,30],[-97,18],[-83,10],[-76,18],[-81,27],[-72,42],[-60,49],[-54,57],[-72,65],[-100,72],[-130,72]],
    [[-82,12],[-72,8],[-62,-4],[-52,-12],[-47,-25],[-55,-40],[-68,-55],[-76,-46],[-76,-30],[-81,-12]],
    [[-18,36],[-7,36],[5,32],[16,32],[31,31],[42,13],[51,11],[48,-8],[39,-22],[29,-35],[17,-35],[8,-27],[-2,-5],[-17,14]],
    [[-11,36],[2,44],[15,49],[28,48],[42,54],[62,55],[80,60],[100,56],[118,49],[136,54],[153,48],[170,58],[178,50],[160,35],[142,24],[122,16],[105,5],[92,9],[80,22],[64,28],[52,35],[39,38],[28,35],[18,42],[5,43]],
    [[110,-10],[126,-11],[141,-18],[151,-30],[145,-41],[129,-43],[115,-35],[111,-23]],
    [[-52,83],[-28,81],[-18,70],[-30,59],[-48,60],[-63,70]],
    [[-180,-70],[-140,-73],[-100,-72],[-60,-75],[-20,-71],[20,-74],[60,-72],[100,-75],[140,-72],[180,-70],[180,-90],[-180,-90]]
  ];

  const denseContinents = continentPolygons.map(poly => densifyPolygon(poly));
  const routeCache = new Map();

  function defaultState() {
    return {
      version: 35,
      profileName: 'Giorgio Bonetta',
      companyName: 'Geneva Commodity Trading Sàrl',
      leaderboardSnapshots: [],
      investments: {},
      constructionQueue: [],
      assetIncome: 0,
      date: '2026-09-01T00:00:00.000Z',
      cash: prestigeStartCash(500_000),
      creditLimit: prestigeStartCredit(1_500_000),
      reputation: prestigeStartReputation(12),
      prestigeLevel: loadPrestige(),
      victoryClaimed: false,
      realizedPnl: 0,
      completedDeals: 0,
      activeDeals: [],
      fleetAssets: [],
      offices: ['geneva'],
      officeProjects: [],
      officeSpend: 0,
      officeOpenings: 0,
      staff: [],
      completedMissions: [],
      overheadPaid: 0,
      history: [],
      navHistory: [500_000, 500_000, 500_000],
      startingCapital: prestigeStartCash(500_000),
      copperPrice: 9500,
      copperPrev: 9500,
      aluminiumPrice: 2450,
      aluminiumPrev: 2450,
      ureaPrice: 360,
      ureaPrev: 360,
      eurusd: 1.1000,
      eurusdPrev: 1.1000,
      freightIndex: 100,
      freightPrev: 100,
      crudePrice: 78.5,
      crudePrev: 78.5,
      wheatPrice: 245,
      wheatPrev: 245,
      ironorePrice: 108,
      ironorePrev: 108,
      coffeePrice: 4200,
      coffeePrev: 4200,
      zincPrice: 2800,
      zincPrev: 2800,
      nickelPrice: 16000,
      nickelPrev: 16000,
      lngPrice: 12.5,
      lngPrev: 12.5,
      sequence: 1,
      dayIndex: 0,
      marketCycle: 1,
      marketCycleDay: 0,
      negotiations: {},
      counterparties: {},
      activeGlobalEvents: [],
      worldEventFeed: [],
      nextGlobalEventDay: 14,
      difficulty: 'standard',
      onboardingComplete: false,
      academyProgress: {},
      academyScore: 0,
      marginCalls: 0,
      emergencyFundingCost: 0,
      totalInterestPaid: 0,
      tutorialEnabled: true,
      tutorialStep: 0,
      tutorialDismissed: false,
      graphicsQuality: 'auto',
      autosave: true,
      reduceMotion: false,
      xp: 0,
      xpLevel: 1,
      goldBars: 0,
      bonusBuilders: 0,
      loginStreak: 0,
      lastRewardDay: null,
      streakDay: null,
      insolventDays: 0,
      overdraft: 0,
      rivalRecord: {},
      seenModules: null,   // v51 - null = da inizializzare; [] = nuova carriera
      distressedOpportunity: null,
      distressedCargoDay: null,
      soundEnabled: true,
      language: 'en',
      lastSavedAt: null,
      briefingViewedDay: -1,
      marketRegime: 'balanced',
      rivalMarket: {},
      rivalFeed: [],
      tenderWins: 0,
      tenderLosses: 0,
      achievements: [],
      strategyDoctrine: 'merchant',
      strategyChangedDay: -30,
      creditLosses: 0,
      receivableProtectionCost: 0,
      storageOptionIncome: 0,
      valuationHigh: 1_000_000,
      intelCooldownDay: -99,
      intelReport: null,
      cpOutreachDays: {},
      termStructure: {},
      hubBasis: {},
      quarterNumber: 1,
      quarterTarget: 500000,
      quarterStartPnl: 0,
      quarterBonusPaid: 0,
      quarterMissed: 0,
      forwardCurve: {},
      priceHistory: {},
      pnlByCommodity: {},
      tradeCountByCommodity: {},
      complianceReviews: {},
      complianceIncidents: [],
      complianceSpend: 0,
      tradeJournal: [],
      counterpartyLimitOverrides: {},
      creditLimitRequests: {},
      receivablesCollected: 0,
      overdueReceivables: 0,
      contractIncidents: [],
      procurementAgreements: {},
      routeConditions: {},
      supplyChainSpend: 0,
      supplyChainSavings: 0,
      commitmentsFulfilled: 0,
      congestionMitigations: 0,
      supplyIncidents: [],
      capitalPolicy: 'balanced',
      capitalPolicyChangedDay: -30,
      stressTestsRun: 0,
      stressTestHistory: [],
      lastStressTest: null,
      shopAssets: {},
      shopOrders: [],
      shopSpent: 0,
      shopDeliveries: 0,
      riskPnlImpact: 0,
      riskLedger: [],
      unlockedCountriesSeen: ['Switzerland','Estonia','Italy'],
      unlockedCommoditiesSeen: ['Copper'],
      progressionMode: 'expansion',
      hqTier: 1,
      hqUpgrade: null,
      deskSpecialization: 'generalist',
      specializationChosen: false,
      specializationChangedDay: -99,
      marketReputation: { countries:{ Switzerland:50, Estonia:35, Italy:35 }, commodities:{ Copper:35 } },
      commercialFrameworks: {},
      crisisResponses: {},
      frameworkPenalties: 0
    };
  }

  // v45 - normalizzazione condivisa fra caricamento da localStorage e import di un file
  function normalizeState(loaded) {
    const migrated = { ...defaultState(), ...loaded, version: 35 };
    migrated.offices = [...new Set(['geneva', ...(migrated.offices || [])])];
    migrated.officeProjects = migrated.officeProjects || [];
    migrated.officeSpend = migrated.officeSpend || 0;
    migrated.officeOpenings = migrated.officeOpenings || Math.max(0, migrated.offices.length - 1);
    migrated.staff = migrated.staff || [];
    migrated.completedMissions = migrated.completedMissions || [];
    migrated.negotiations = migrated.negotiations || {};
    migrated.counterparties = migrated.counterparties || {};
    migrated.activeGlobalEvents = migrated.activeGlobalEvents || [];
    migrated.worldEventFeed = migrated.worldEventFeed || [];
    migrated.dayIndex = migrated.dayIndex || 0;
    migrated.marketCycle = migrated.marketCycle || 1;
    migrated.marketCycleDay = migrated.marketCycleDay || 0;
    migrated.nextGlobalEventDay = migrated.nextGlobalEventDay || 14;
    migrated.academyProgress = migrated.academyProgress || {};
    migrated.academyScore = migrated.academyScore || 0;
    migrated.marginCalls = migrated.marginCalls || 0;
    migrated.emergencyFundingCost = migrated.emergencyFundingCost || 0;
    migrated.totalInterestPaid = migrated.totalInterestPaid || 0;
    migrated.profileName = migrated.profileName || 'Giorgio Bonetta';
    migrated.companyName = migrated.companyName || 'World of Trade Co.';
    migrated.leaderboardSnapshots = migrated.leaderboardSnapshots || [];
    migrated.investments = migrated.investments || {};
    migrated.constructionQueue = migrated.constructionQueue || [];
    migrated.assetIncome = migrated.assetIncome || 0;
    migrated.difficulty = migrated.difficulty || 'standard';
    if (loaded.version < 8) migrated.onboardingComplete = true;
    migrated.tutorialEnabled = migrated.tutorialEnabled ?? true;
    migrated.tutorialStep = Number.isFinite(migrated.tutorialStep) ? migrated.tutorialStep : 0;
    migrated.tutorialDismissed = migrated.tutorialDismissed ?? false;
    migrated.graphicsQuality = ['auto','high','balanced','performance'].includes(migrated.graphicsQuality) ? migrated.graphicsQuality : 'auto';
    migrated.autosave = migrated.autosave !== false;
    migrated.reduceMotion = migrated.reduceMotion === true;
    migrated.xp = Number.isFinite(migrated.xp) ? migrated.xp : 0;
    migrated.xpLevel = Number.isFinite(migrated.xpLevel) && migrated.xpLevel >= 1 ? migrated.xpLevel : 1;
    migrated.goldBars = Number.isFinite(migrated.goldBars) ? migrated.goldBars : 0;
    migrated.bonusBuilders = Number.isFinite(migrated.bonusBuilders) ? migrated.bonusBuilders : 0;
    migrated.loginStreak = Number.isFinite(migrated.loginStreak) ? migrated.loginStreak : 0;
    migrated.lastRewardDay = migrated.lastRewardDay || null;
    migrated.streakDay = migrated.streakDay || null;
    migrated.insolventDays = Number.isFinite(migrated.insolventDays) ? migrated.insolventDays : 0;
    migrated.overdraft = Number.isFinite(migrated.overdraft) ? migrated.overdraft : 0;
    migrated.rivalRecord = (migrated.rivalRecord && typeof migrated.rivalRecord === 'object') ? migrated.rivalRecord : {};
    // v51 - una carriera esistente non deve vedere tutto marcato come nuovo:
    // si considerano gia' visti i moduli disponibili al livello raggiunto.
    if (!Array.isArray(migrated.seenModules)) {
      // salvataggio anteriore alla v51: tutto cio' che il livello raggiunto rende
      // disponibile si considera gia' visto, altrimenti apparirebbe tutto "nuovo"
      const reachedLevel = Math.max(1, Number(migrated.xpLevel) || 1);
      migrated.seenModules = Object.entries(moduleUnlockLevels)
        .filter(([, required]) => required <= reachedLevel)
        .map(([tab]) => tab);
    }
    migrated.soundEnabled = migrated.soundEnabled !== false;
    migrated.language = (migrated.language === 'it') ? 'it' : 'en';
    migrated.prestigeLevel = Number.isFinite(migrated.prestigeLevel) ? migrated.prestigeLevel : loadPrestige();
    migrated.victoryClaimed = migrated.victoryClaimed === true;
    migrated.marketRegime = marketRegimeCatalog[migrated.marketRegime] ? migrated.marketRegime : 'balanced';
    migrated.rivalMarket = migrated.rivalMarket || {};
    migrated.rivalFeed = migrated.rivalFeed || [];
    migrated.tenderWins = migrated.tenderWins || 0;
    migrated.tenderLosses = migrated.tenderLosses || 0;
    migrated.achievements = migrated.achievements || [];
    migrated.strategyDoctrine = strategyDoctrineCatalog[migrated.strategyDoctrine] ? migrated.strategyDoctrine : 'merchant';
    migrated.strategyChangedDay = Number.isFinite(migrated.strategyChangedDay) ? migrated.strategyChangedDay : -30;
    migrated.creditLosses = migrated.creditLosses || 0;
    migrated.receivableProtectionCost = migrated.receivableProtectionCost || 0;
    migrated.storageOptionIncome = migrated.storageOptionIncome || 0;
    migrated.valuationHigh = Number.isFinite(migrated.valuationHigh) ? migrated.valuationHigh : 1_000_000;
    migrated.intelCooldownDay = Number.isFinite(migrated.intelCooldownDay) ? migrated.intelCooldownDay : -99;
    migrated.intelReport = migrated.intelReport || null;
    migrated.cpOutreachDays = migrated.cpOutreachDays || {};
    migrated.termStructure = migrated.termStructure || {};
    migrated.forwardCurve = migrated.forwardCurve || {};
    migrated.priceHistory = migrated.priceHistory || {};
    migrated.pnlByCommodity = migrated.pnlByCommodity || {};
    migrated.tradeCountByCommodity = migrated.tradeCountByCommodity || {};
    migrated.complianceReviews = migrated.complianceReviews || {};
    migrated.complianceIncidents = migrated.complianceIncidents || [];
    migrated.complianceSpend = migrated.complianceSpend || 0;
    migrated.tradeJournal = migrated.tradeJournal || [];
    migrated.counterpartyLimitOverrides = migrated.counterpartyLimitOverrides || {};
    migrated.creditLimitRequests = migrated.creditLimitRequests || {};
    migrated.receivablesCollected = migrated.receivablesCollected || 0;
    migrated.overdueReceivables = migrated.overdueReceivables || 0;
    migrated.contractIncidents = migrated.contractIncidents || [];
    migrated.procurementAgreements = migrated.procurementAgreements || {};
    migrated.routeConditions = migrated.routeConditions || {};
    migrated.supplyChainSpend = migrated.supplyChainSpend || 0;
    migrated.supplyChainSavings = migrated.supplyChainSavings || 0;
    migrated.commitmentsFulfilled = migrated.commitmentsFulfilled || 0;
    migrated.congestionMitigations = migrated.congestionMitigations || 0;
    migrated.supplyIncidents = migrated.supplyIncidents || [];
    migrated.capitalPolicy = capitalPolicyCatalog[migrated.capitalPolicy] ? migrated.capitalPolicy : 'balanced';
    migrated.capitalPolicyChangedDay = Number.isFinite(migrated.capitalPolicyChangedDay) ? migrated.capitalPolicyChangedDay : -30;
    migrated.stressTestsRun = migrated.stressTestsRun || 0;
    migrated.stressTestHistory = migrated.stressTestHistory || [];
    migrated.lastStressTest = migrated.lastStressTest || null;
    migrated.shopAssets = migrated.shopAssets || {};
    migrated.shopOrders = migrated.shopOrders || [];
    migrated.shopSpent = migrated.shopSpent || 0;
    migrated.shopDeliveries = migrated.shopDeliveries || 0;
    migrated.startingCapital = migrated.startingCapital || (loaded.version >= 33 ? 500_000 : 1_000_000);
    migrated.riskPnlImpact = migrated.riskPnlImpact || 0;
    migrated.riskLedger = migrated.riskLedger || [];
    migrated.unlockedCountriesSeen = migrated.unlockedCountriesSeen || ['Switzerland','Estonia','Italy'];
    migrated.unlockedCommoditiesSeen = migrated.unlockedCommoditiesSeen || ['Copper'];
    migrated.progressionMode = migrated.progressionMode || 'expansion';
    migrated.hqTier = clamp(Number(migrated.hqTier || 1), 1, hqTierCatalog.length);
    migrated.hqUpgrade = migrated.hqUpgrade || null;
    migrated.deskSpecialization = deskSpecializationCatalog[migrated.deskSpecialization] ? migrated.deskSpecialization : 'generalist';
    migrated.specializationChosen = migrated.specializationChosen === true;
    migrated.specializationChangedDay = Number.isFinite(migrated.specializationChangedDay) ? migrated.specializationChangedDay : -99;
    migrated.marketReputation = migrated.marketReputation || { countries:{ Switzerland:50, Estonia:35, Italy:35 }, commodities:{ Copper:35 } };
    migrated.marketReputation.countries = migrated.marketReputation.countries || {};
    migrated.marketReputation.commodities = migrated.marketReputation.commodities || {};
    migrated.commercialFrameworks = migrated.commercialFrameworks || {};
    migrated.crisisResponses = migrated.crisisResponses || {};
    migrated.frameworkPenalties = migrated.frameworkPenalties || 0;
    migrated.hubBasis = migrated.hubBasis || {};
    migrated.quarterNumber   = Number.isFinite(migrated.quarterNumber) ? migrated.quarterNumber : 1;
    migrated.quarterTarget   = Number.isFinite(migrated.quarterTarget) ? migrated.quarterTarget : 500000;
    migrated.quarterStartPnl = Number.isFinite(migrated.quarterStartPnl) ? migrated.quarterStartPnl : 0;
    migrated.quarterBonusPaid = Number.isFinite(migrated.quarterBonusPaid) ? migrated.quarterBonusPaid : 0;
    migrated.quarterMissed   = Number.isFinite(migrated.quarterMissed) ? migrated.quarterMissed : 0;
    migrated.lastSavedAt = migrated.lastSavedAt || null;
    migrated.briefingViewedDay = Number.isFinite(migrated.briefingViewedDay) ? migrated.briefingViewedDay : -1;
    // v45 - nomi ripuliti: bloccano l'iniezione HTML tramite file di carriera importato
    migrated.profileName = cleanUserName(migrated.profileName, 'Trader');
    migrated.companyName = cleanUserName(migrated.companyName, 'World of Trade Co.');
    migrated.distressedOpportunity = (migrated.distressedOpportunity && typeof migrated.distressedOpportunity === 'object') ? migrated.distressedOpportunity : null;
    migrated.distressedCargoDay = Number.isFinite(migrated.distressedCargoDay) ? migrated.distressedCargoDay : null;
    migrated.history = (migrated.history || []).filter(entry => entry && typeof entry === 'object');
    // v45 - scarta i deal il cui catalogo non esiste piu': altrimenti ogni render andrebbe in crash
    migrated.activeDeals = (migrated.activeDeals || [])
      .filter(deal => {
        if (!deal || typeof deal !== 'object') return false;
        if (resolveOpportunityFor(deal)) return true;
        console.warn('[WoT] deal orfano scartato', deal.opportunityId);
        return false;
      })
      .map(deal => hydrateDealOperations(deal));
    migrated.fleetAssets = (migrated.fleetAssets || []).filter(asset => vesselCatalog.some(v => v.id === asset.catalogId));
    return migrated;
  }

  const SAVE_SCHEMA_VERSION = 35;

  function parseSave(raw) {
    const loaded = JSON.parse(raw);
    if (!loaded || typeof loaded !== 'object' || Array.isArray(loaded)) throw new Error('Save is not an object');
    const version = Number(loaded.version);
    if (!Number.isFinite(version) || version < 3) throw new Error('Unsupported save version: ' + loaded.version);
    if (version > SAVE_SCHEMA_VERSION) console.warn('[WoT] save produced by a newer build', version);
    return normalizeState(loaded);
  }

  function quarantineSave(key, raw) {
    try { if (raw) localStorage.setItem(`${key}-corrupt-${Date.now()}`, raw); }
    catch (e) { console.warn('[WoT] could not quarantine the damaged save', e); }
  }

  function loadState() {
    const key = currentStorageKey();
    let raw = null;
    try { raw = localStorage.getItem(key); } catch (e) { console.error('[WoT] localStorage unreadable', e); }

    // v45 - one-time legacy adoption: slot 1 only, and the source keys are cleared afterwards
    if (!raw && activeSlot === 1) {
      try {
        if (!localStorage.getItem(legacyMigratedKey)) {
          const source = localStorage.getItem(storageKey) ? storageKey
            : legacyStorageKeys.find(legacyKey => localStorage.getItem(legacyKey)) || null;
          if (source) raw = localStorage.getItem(source);
          localStorage.setItem(legacyMigratedKey, '1');
          [storageKey, ...legacyStorageKeys].forEach(legacyKey => { try { localStorage.removeItem(legacyKey); } catch (e) {} });
        }
      } catch (e) { console.warn('[WoT] legacy migration failed', e); }
    }

    if (raw) {
      try { return parseSave(raw); }
      catch (error) {
        console.error('[WoT] primary save unreadable, trying the backup', error);
        quarantineSave(key, raw);
        let backup = null;
        try { backup = localStorage.getItem(`${key}-backup`); } catch (e) {}
        if (backup) {
          try {
            const recovered = parseSave(backup);
            setTimeout(() => showToast('Damaged save detected \u2014 the backup copy was restored.', 'warning'), 1400);
            return recovered;
          } catch (backupError) { console.error('[WoT] the backup is unreadable too', backupError); }
        }
        // v45 - nothing recoverable: start fresh but keep autosave locked so nothing is overwritten
        const fresh = defaultState();
        fresh.__loadFailed = true;
        setTimeout(() => showToast('Save file unreadable. Autosave is paused \u2014 export or reset from your profile.', 'error'), 1400);
        return fresh;
      }
    }

    let backupOnly = null;
    try { backupOnly = localStorage.getItem(`${key}-backup`); } catch (e) {}
    if (backupOnly) { try { return parseSave(backupOnly); } catch (e) {} }
    return defaultState();
  }

  activeSlot = loadActiveSlot();
  let state = loadState();

  const complianceCountryRisk = {
    Switzerland: 4, Italy: 7, Netherlands: 6, Belgium: 6, Estonia: 8, Chile: 13,
    UAE: 24, Morocco: 16, Singapore: 7, USA: 8, Brazil: 18, Argentina: 24,
    Australia: 5, China: 22, Qatar: 12, Malaysia: 13, 'Ivory Coast': 28,
    'South Africa': 20, Zambia: 27, Indonesia: 23, Germany: 5
  };

  function recordJournal(category, title, detail, impact = 0, relatedId = null) {
    state.tradeJournal = state.tradeJournal || [];
    state.tradeJournal.unshift({
      id: `journal-${Date.now()}-${Math.round(Math.random()*1e6)}`,
      date: state.date,
      dayIndex: state.dayIndex,
      category,
      title,
      detail,
      impact,
      relatedId
    });
    state.tradeJournal = state.tradeJournal.slice(0, 80);
  }

  function complianceProfileForOpportunity(opp) {
    if (!opp) return { status:'Blocked', canTrade:false, score:100, flags:['Opportunity unavailable'], reviewed:false, cost:0 };
    const parties = partiesForOpportunity(opp);
    const supplier = getCounterparty(parties.supplierId);
    const buyer = getCounterparty(parties.buyerId);
    const counterparties = [supplier,buyer].filter(Boolean);
    const flags = [];
    let score = opp.riskClass === 'high' ? 24 : opp.riskClass === 'medium' ? 13 : 6;
    counterparties.forEach(cp => {
      score += Math.round((complianceCountryRisk[cp.country] || 15) * .55);
      if (cp.kyc === 'Enhanced review') flags.push(`${cp.name}: enhanced KYC review`);
      if (cp.kyc === 'In progress') flags.push(`${cp.name}: KYC file incomplete`);
      if (cp.kyc === 'Blocked') flags.push(`${cp.name}: blocked counterparty`);
      const credit = Number(cp.credit ?? 70);
      if (credit < 65) flags.push(`${cp.name}: weak credit profile`);
    });
    if ((opp.via || []).includes('genova') && state.activeGlobalEvents.some(event => /sanction|customs/i.test(event.title || ''))) {
      flags.push('Active customs or sanctions disruption on the route');
      score += 18;
    }
    const franchise = marketReputationAdjustments(opp);
    score = clamp(score - franchise.complianceReduction, 0, 100);
    const review = state.complianceReviews?.[opp.id];
    const reviewed = !!(review && review.cycle === state.marketCycle && review.status === 'approved');
    const blocked = counterparties.some(cp => cp.kyc === 'Blocked') || (review && review.cycle === state.marketCycle && review.status === 'rejected');
    const requiresReview = flags.length > 0 || score >= 34;
    const status = blocked ? 'Blocked' : reviewed ? 'Approved' : requiresReview ? 'Review required' : 'Clear';
    const cost = Math.max(7_000, Math.round((6_000 + score * 420) * (1 - Math.min(.28, franchise.complianceReduction * .008))));
    return { status, canTrade: !blocked && (!requiresReview || reviewed), score, flags, reviewed, requiresReview, cost, supplier, buyer };
  }

  function runComplianceReview(oppId) {
    const opp = getOpportunity(oppId);
    if (!opp) return;
    const profile = complianceProfileForOpportunity(opp);
    if (profile.status === 'Blocked') return showToast('Compliance has blocked this route for the current market cycle.');
    if (profile.reviewed || !profile.requiresReview) return showToast('This opportunity is already cleared for trading.');
    if (state.cash < profile.cost) return showToast(`Enhanced due diligence requires ${money(profile.cost)} cash.`);
    state.cash -= profile.cost;
    state.complianceSpend = (state.complianceSpend || 0) + profile.cost;
    state.complianceReviews[oppId] = {
      status: 'approved',
      cycle: state.marketCycle,
      reviewedAt: state.date,
      score: profile.score,
      flags: profile.flags,
      cost: profile.cost
    };
    recordJournal('Compliance', `${opp.title} cleared`, `Enhanced due diligence completed. ${profile.flags.length ? profile.flags.join(' · ') : 'No material red flags.'}`, -profile.cost, opp.id);
    saveState();
    renderAll();
    showToast(`Compliance review approved for ${opp.title}. Cost ${money(profile.cost)}.`);
  }

  initializeCounterparties();
  state.activeDeals = state.activeDeals.map(hydrateDealOperations);
  initializeCompetitiveMarket();
  evaluateAchievements(false);
  let selected = { type: 'hub', id: 'geneva' };
  let activeLeftTab = 'portfolio';
  let selectedLeaderboardMode = 'overall';
  const selectedHedgeRatios = Object.fromEntries(opportunities.map(o => [o.id, o.recommendedHedge || 100]));
  const selectedCarrierStrategies = Object.fromEntries(opportunities.map(o => [o.id, 'spot']));
  const selectedVesselClasses    = Object.fromEntries(opportunities.map(o => [o.id, 'supramax']));

  const vesselClasses = {
    handysize: { id:'handysize', label:'Handysize (28K DWT)', pnlMod:-0.06, durationMod:-2,
      eligible: null, desc: 'Flexible, port-agnostic. Higher freight cost per tonne.' },
    supramax:  { id:'supramax',  label:'Supramax (55K DWT)',  pnlMod: 0,    durationMod: 0,
      eligible: null, desc: 'Industry standard bulk carrier. Balanced cost and speed.' },
    panamax:   { id:'panamax',   label:'Panamax (75K DWT)',   pnlMod: 0.07, durationMod: 2,
      eligible: ['ironore','wheat','urea','aluminium','soybeans','steel','zinc'],
      desc: 'Efficient for large dry bulk. Requires 2 extra loading days.' },
    capesize:  { id:'capesize',  label:'Capesize (180K DWT)', pnlMod: 0.15, durationMod: 5,
      eligible: ['ironore','wheat','soybeans'],
      desc: 'Lowest freight cost per tonne. Slow, bulk ports only.' },
  };

  function vesselClassFor(oppId) { return vesselClasses[selectedVesselClasses[oppId]] || vesselClasses.supramax; }
  function availableVesselClasses(opp) {
    return Object.values(vesselClasses).filter(vc => !vc.eligible || vc.eligible.includes(opp.commodity));
  }
  const selectedFinancingStrategies = Object.fromEntries(opportunities.map(o => [o.id, 'revolver']));
  const selectedInsuranceStrategies = Object.fromEntries(opportunities.map(o => [o.id, 'basic']));
  const selectedInspectionStrategies = Object.fromEntries(opportunities.map(o => [o.id, 'standard']));
  const selectedFxHedgeRatios = Object.fromEntries(opportunities.map(o => [o.id, ['geneva','brescia','genova','rotterdam'].includes(o.destination) ? 80 : 100]));
  const selectedNegotiationDrafts = Object.fromEntries(opportunities.map(o => [o.id, null]));
  let layers = { opportunities: true, portfolio: true, risk: false, logistics: true };
  let runningSpeed = 0;
  let clockTimer = null;
  let toastTimer = null;
  let leftDrawerOpen = false;
  let inspectorOpen = false;
  let overviewOpen = false;
  let marketsOpen = false;
  let layersOpen = false;
  const globeOptions = { labels: true, clouds: true, night: true, autoRotate: false, cinematic: false };
  let geoBorderLines = null;
  let geoCoastlines = null;
  let hoveredTarget = null;
  let trackingDealId = null;
  let followCargo = false;
  let lastPointerPosition = { x: 0, y: 0 };
  let lastInteractionTime = performance.now();
  let searchItems = [];
  let searchActiveIndex = 0;
  let briefingOpen = false;
  let saveStatusTimer = null;


  function targetPixelRatio() {
    const base = window.devicePixelRatio || 1;
    const quality = state?.graphicsQuality || 'auto';
    if (quality === 'high') return Math.min(base, 2);
    if (quality === 'balanced') return Math.min(base, 1.5);
    if (quality === 'performance') return Math.min(base, 1);
    const constrained = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || window.matchMedia('(max-width: 900px)').matches;
    return Math.min(base, constrained ? 1.2 : 1.75);
  }

  function markSaveStatus(label = 'Saved', working = false) {
    const status = $('#saveStatus');
    if (!status) return;
    status.classList.toggle('saving', working);
    status.classList.toggle('error', label === 'Save failed');
    const text = $('b', status);
    if (text) text.textContent = label;
    clearTimeout(saveStatusTimer);
    if (label === 'Saved') {
      saveStatusTimer = setTimeout(() => {
        const date = state.lastSavedAt ? new Date(state.lastSavedAt) : null;
        if (text && date) text.textContent = `Saved ${date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
      }, 900);
    }
  }

  function downloadTextFile(filename, content, type = 'application/json') {
    if (window.WorldOfTradeNative?.saveTextFile) {
      try {
        window.WorldOfTradeNative.saveTextFile(filename, content, type);
        return;
      } catch (error) {
        console.warn('Native file export unavailable; using browser download.', error);
      }
    }
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  function exportCareer() {
    const payload = {
      product: 'World of Trade',
      schemaVersion: 35,
      exportedAt: new Date().toISOString(),
      state
    };
    const safeCompany = (state.companyName || 'WorldOfTrade').replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase();
    downloadTextFile(`${safeCompany || 'world-of-trade'}-career-day-${state.dayIndex}.json`, JSON.stringify(payload, null, 2));
    showToast('Career backup exported.');
  }

  async function importCareerFile(file) {
    if (!file) return;
    // v45 - prima lo stato importato veniva scritto su disco PRIMA di provare a
    // disegnarlo: un file malformato distruggeva la carriera esistente e rendeva
    // il gioco non piu' avviabile. Ora si valida, si disegna e solo dopo si salva.
    const previousState = state;
    const previousSelection = selected;
    try {
      const parsed = JSON.parse(await file.text());
      const imported = parsed?.state || parsed;
      if (!imported || typeof imported !== 'object' || Array.isArray(imported)) throw new Error('Invalid World of Trade career file');
      if (!Array.isArray(imported.activeDeals) || !Array.isArray(imported.history)) throw new Error('Invalid World of Trade career file');
      if (parsed?.product && parsed.product !== 'World of Trade') throw new Error('This backup belongs to another game');
      if (!Number.isFinite(Number(imported.cash))) throw new Error('Corrupt cash balance');

      state = normalizeState(imported);
      try {
        initializeCounterparties();
        initializeCompetitiveMarket();
        evaluateAchievements(false);
        selected = { type: 'hub', id: 'geneva' };
        runningSpeed = 0;
        dpr = targetPixelRatio();
        resizeCanvas();
        renderAll();
      } catch (renderError) {
        // rollback in memoria: niente e' stato ancora scritto su disco
        state = previousState;
        selected = previousSelection;
        renderAll();
        throw renderError;
      }
      saveState(true);
      cleanGlobeView();
      showToast('Career imported successfully.');
      $('#profileDialog')?.close();
    } catch (error) {
      console.error('[WoT] import failed', error);
      showToast('This file is not a valid World of Trade career backup.');
    } finally {
      const input = $('#importCareerInput');
      if (input) input.value = '';
    }
  }

  function openProfileDialog() {
    const dialog = $('#profileDialog');
    if (!dialog || dialog.open) return;
    $('#profileNameInput').value = state.profileName || '';
    $('#companyNameInput').value = state.companyName || '';
    $('#graphicsQualitySelect').value = state.graphicsQuality || 'auto';
    $('#autosaveSelect').value = state.autosave === false ? 'off' : 'on';
    if ($('#reduceMotionSelect')) $('#reduceMotionSelect').value = state.reduceMotion ? 'off' : 'on';
    if ($('#soundSelect')) $('#soundSelect').value = state.soundEnabled === false ? 'off' : 'on';
    if ($('#languageSelect')) $('#languageSelect').value = state.language === 'it' ? 'it' : 'en';
    dialog.showModal();
  }

  function applyProfileChanges() {
    state.profileName = cleanUserName($('#profileNameInput')?.value || state.profileName, 'Trader');
    state.companyName = cleanUserName($('#companyNameInput')?.value || state.companyName, 'World of Trade Co.');
    state.graphicsQuality = $('#graphicsQualitySelect')?.value || 'auto';
    state.autosave = $('#autosaveSelect')?.value !== 'off';
    state.reduceMotion = $('#reduceMotionSelect')?.value === 'off';
    document.body.classList.toggle('reduce-motion', !!state.reduceMotion);
    state.soundEnabled = $('#soundSelect')?.value !== 'off';
    if (state.soundEnabled) { try { Sound.unlock(); Sound.play('success'); } catch (e) {} }
    state.language = $('#languageSelect')?.value === 'it' ? 'it' : 'en';
    applyLanguage(state.language);
    dpr = targetPixelRatio();
    resizeCanvas();
    saveState(true);
    renderAll();
    showToast('Profile and performance settings updated.');
  }

  const canvas = $('#globeCanvas');
  const earthCanvas = $('#earthCanvas');
  const ctx = canvas.getContext('2d');
  let dpr = targetPixelRatio();
  let view = { lon: 6, lat: 18, zoom: 1, targetLon: null, targetLat: null };

  let earthRenderer = null;
  let earthScene = null;
  let earthCamera = null;
  let earthMesh = null;
  let earthMaterial = null;
  let cloudMesh = null;
  let atmosphereMesh = null;
  let starField = null;
  let sunLight = null;
  let earthWebGLReady = false;
  let _animationHandle = null;
  const earthProjectionVector = new THREE.Vector3();
  const earthCameraVector = new THREE.Vector3();
  const solarDirectionCache = new THREE.Vector3(1, 0.2, 1).normalize();
  let lastSolarMinute = -1;

  function realisticSolarDirection(date = new Date()) {
    const minuteKey = Math.floor(date.getTime() / 60000);
    if (minuteKey === lastSolarMinute) return solarDirectionCache;
    lastSolarMinute = minuteKey;
    const start = Date.UTC(date.getUTCFullYear(), 0, 0);
    const dayOfYear = Math.floor((date.getTime() - start) / 86400000);
    const gamma = (2 * Math.PI / 365) * (dayOfYear - 1 + (date.getUTCHours() - 12) / 24);
    const equationOfTime = 229.18 * (0.000075 + 0.001868 * Math.cos(gamma) - 0.032077 * Math.sin(gamma)
      - 0.014615 * Math.cos(2 * gamma) - 0.040849 * Math.sin(2 * gamma));
    const declination = 0.006918 - 0.399912 * Math.cos(gamma) + 0.070257 * Math.sin(gamma)
      - 0.006758 * Math.cos(2 * gamma) + 0.000907 * Math.sin(2 * gamma)
      - 0.002697 * Math.cos(3 * gamma) + 0.00148 * Math.sin(3 * gamma);
    const utcMinutes = date.getUTCHours() * 60 + date.getUTCMinutes() + date.getUTCSeconds() / 60;
    const subsolarLongitude = ((720 - utcMinutes - equationOfTime) / 4 + 540) % 360 - 180;
    solarDirectionCache.copy(geoVector3(subsolarLongitude, THREE.MathUtils.radToDeg(declination), 1)).normalize();
    return solarDirectionCache;
  }

  function geoVector3(lon, lat, radius = 1) {
    const phi = lat * deg;
    const lambda = lon * deg;
    return new THREE.Vector3(
      radius * Math.cos(phi) * Math.cos(lambda),
      radius * Math.sin(phi),
      -radius * Math.cos(phi) * Math.sin(lambda)
    );
  }

  function createStarField() {
    const quality = state?.graphicsQuality || 'auto';
    const count = quality === 'performance' ? 650 : quality === 'high' ? 1500 : 950;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      const radius = 5 + Math.random() * 11;
      const theta = Math.random() * Math.PI * 2;
      const u = Math.random() * 2 - 1;
      const spread = Math.sqrt(1 - u * u);
      positions[i * 3] = radius * spread * Math.cos(theta);
      positions[i * 3 + 1] = radius * u;
      positions[i * 3 + 2] = radius * spread * Math.sin(theta);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0xc8ddf4,
      size: 0.012,
      transparent: true,
      opacity: 0.58,
      depthWrite: false,
      sizeAttenuation: true
    });
    return new THREE.Points(geometry, material);
  }

  function createSolidTexture(r, g, b, a = 255) {
    const texture = new THREE.DataTexture(new Uint8Array([r, g, b, a]), 1, 1, THREE.RGBAFormat);
    texture.needsUpdate = true;
    return texture;
  }

  function earthGeometrySegments() {
    const quality = state?.graphicsQuality || 'auto';
    if (quality === 'high') return [144, 96];
    if (quality === 'balanced') return [112, 72];
    if (quality === 'performance') return [72, 48];
    const constrained = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || window.matchMedia('(max-width: 900px)').matches;
    return constrained ? [80, 52] : [112, 72];
  }

  function prepareEarthTexture(texture, srgb = false) {
    if (srgb) texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = Math.min(4, earthRenderer?.capabilities?.getMaxAnisotropy?.() || 1);
    return texture;
  }

  function deferNonCritical(callback, timeout = 900) {
    if ('requestIdleCallback' in window) window.requestIdleCallback(callback, { timeout });
    else setTimeout(callback, Math.min(timeout, 240));
  }

  const earthTextureFallbacks = {
    './earth_day_realistic_2048.webp': ['./earth_atmos_2048.jpg', './assets/earth/earth_atmos_2048.jpg'],
    './earth_day_realistic_4096.webp': ['./earth_day_realistic_2048.webp', './earth_atmos_2048.jpg'],
    './earth_night_realistic_2048.webp': ['./earth_lights_2048.png', './assets/earth/earth_lights_2048.png'],
    './earth_clouds_realistic_2048.webp': ['./earth_clouds_1024.png', './assets/earth/earth_clouds_1024.png'],
    './assets/earth/earth_atmos_2048.jpg': ['./earth_atmos_2048.jpg'],
    './assets/earth/earth_lights_2048.png': ['./earth_lights_2048.png'],
    './assets/earth/earth_normal_2048.jpg': ['./earth_normal_2048.jpg'],
    './assets/earth/earth_specular_2048.jpg': ['./earth_specular_2048.jpg'],
    './assets/earth/earth_clouds_1024.png': ['./earth_clouds_1024.png']
  };

  function loadEarthTexture(loader, localUrl, onLoad, onProgress, onError) {
    const candidates = [localUrl, ...(earthTextureFallbacks[localUrl] || [])];
    const tryCandidate = index => {
      if (index >= candidates.length) { onError?.(new Error(`Texture unavailable: ${localUrl}`)); return; }
      const candidate = candidates[index];
      loader.load(candidate, onLoad, onProgress, () => {
        console.warn(`Earth texture source unavailable: ${candidate}`);
        tryCandidate(index + 1);
      });
    };
    tryCandidate(0);
  }

  function initEarthRenderer() {
    try {
      earthRenderer = new THREE.WebGLRenderer({ canvas: earthCanvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
      earthRenderer.setPixelRatio(dpr);
      earthRenderer.outputColorSpace = THREE.SRGBColorSpace;
      earthRenderer.toneMapping = THREE.ACESFilmicToneMapping;
      earthRenderer.toneMappingExposure = 0.96;
      earthRenderer.setClearColor(0x02050a, 0);

      earthScene = new THREE.Scene();
      earthScene.fog = new THREE.FogExp2(0x010307, 0.0035);
      earthCamera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);

      const placeholderDay = createSolidTexture(20, 58, 76);
      const placeholderNight = createSolidTexture(0, 0, 0);
      const placeholderSpecular = createSolidTexture(25, 25, 25);
      const placeholderNormal = createSolidTexture(128, 128, 255);
      const placeholderCloud = createSolidTexture(0, 0, 0, 0);
      const [widthSegments, heightSegments] = earthGeometrySegments();
      const earthGeometry = new THREE.SphereGeometry(1, widthSegments, heightSegments);

      earthMaterial = new THREE.ShaderMaterial({
        uniforms: {
          dayMap: { value: placeholderDay },
          nightMap: { value: placeholderNight },
          specularMap: { value: placeholderSpecular },
          normalMap: { value: placeholderNormal },
          cloudMap: { value: placeholderCloud },
          nightIntensity: { value: 0.0 },
          cloudShadowStrength: { value: 0.085 },
          cloudOffset: { value: 0.0 },
          sunDirection: { value: realisticSolarDirection(new Date()).clone() },
          atmosphereColor: { value: new THREE.Color(0x73bde8) }
        },
        vertexShader: `
          varying vec2 vUv;
          varying vec3 vWorldNormal;
          varying vec3 vWorldPosition;
          void main() {
            vUv = uv;
            vWorldNormal = normalize(mat3(modelMatrix) * normal);
            vec4 worldPosition = modelMatrix * vec4(position, 1.0);
            vWorldPosition = worldPosition.xyz;
            gl_Position = projectionMatrix * viewMatrix * worldPosition;
          }
        `,
        fragmentShader: `
          uniform sampler2D dayMap;
          uniform sampler2D nightMap;
          uniform sampler2D specularMap;
          uniform sampler2D normalMap;
          uniform sampler2D cloudMap;
          uniform float nightIntensity;
          uniform float cloudShadowStrength;
          uniform float cloudOffset;
          uniform vec3 sunDirection;
          uniform vec3 atmosphereColor;
          varying vec2 vUv;
          varying vec3 vWorldNormal;
          varying vec3 vWorldPosition;
          void main() {
            vec3 baseNormal = normalize(vWorldNormal);
            vec3 mapN = texture2D(normalMap, vUv).xyz * 2.0 - 1.0;
            vec3 dp1 = dFdx(vWorldPosition);
            vec3 dp2 = dFdy(vWorldPosition);
            vec2 duv1 = dFdx(vUv);
            vec2 duv2 = dFdy(vUv);
            vec3 dp2perp = cross(dp2, baseNormal);
            vec3 dp1perp = cross(baseNormal, dp1);
            vec3 tangent = dp2perp * duv1.x + dp1perp * duv2.x;
            vec3 bitangent = dp2perp * duv1.y + dp1perp * duv2.y;
            float invmax = inversesqrt(max(dot(tangent, tangent), dot(bitangent, bitangent)));
            mat3 tbn = mat3(tangent * invmax, bitangent * invmax, baseNormal);
            vec3 normal = normalize(tbn * vec3(mapN.xy * 0.22, max(mapN.z, 0.42)));
            vec3 lightDir = normalize(sunDirection);
            vec3 viewDir = normalize(cameraPosition - vWorldPosition);
            float ndl = dot(normal, lightDir);
            float daylight = smoothstep(-0.12, 0.16, ndl);
            float directLight = max(ndl, 0.0);
            vec3 dayColor = texture2D(dayMap, vUv).rgb;
            vec3 nightTexture = texture2D(nightMap, vUv).rgb;
            float oceanMask = texture2D(specularMap, vUv).r;
            float cloudCover = texture2D(cloudMap, vUv + vec2(cloudOffset, 0.0)).a;
            float cloudShadow = 1.0 - cloudCover * cloudShadowStrength * smoothstep(0.02, 0.55, directLight);
            vec3 daylightSurface = dayColor * (0.135 + 0.91 * directLight) * cloudShadow;
            vec3 nightSurface = dayColor * vec3(0.010, 0.016, 0.030);
            float lightLuma = dot(nightTexture, vec3(0.2126, 0.7152, 0.0722));
            vec3 warmCityLights = nightTexture * vec3(1.28, 0.98, 0.68) * (0.56 + 0.80 * lightLuma);
            vec3 color = mix(nightSurface + warmCityLights * nightIntensity, daylightSurface, daylight);
            vec3 halfVector = normalize(lightDir + viewDir);
            float oceanGlint = pow(max(dot(normal, halfVector), 0.0), 105.0) * oceanMask * max(ndl, 0.0);
            color += vec3(0.66, 0.82, 0.92) * oceanGlint * 0.52;
            float fresnel = pow(1.0 - max(dot(normal, viewDir), 0.0), 4.2);
            float sunlitLimb = smoothstep(-0.2, 0.35, dot(baseNormal, lightDir));
            color += atmosphereColor * fresnel * (0.025 + 0.105 * sunlitLimb);
            float twilight = exp(-pow((ndl + 0.035) * 14.0, 2.0));
            color += vec3(0.34, 0.12, 0.045) * twilight * 0.075;
            gl_FragColor = vec4(color, 1.0);
          }
        `
      });
      earthMesh = new THREE.Mesh(earthGeometry, earthMaterial);
      earthScene.add(earthMesh);

      const cloudMaterial = new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        side: THREE.FrontSide,
        blending: THREE.NormalBlending,
        uniforms: {
          cloudMap: { value: placeholderCloud },
          sunDirection: { value: realisticSolarDirection(new Date()).clone() },
          cloudOpacity: { value: 0.0 }
        },
        vertexShader: `
          varying vec2 vUv;
          varying vec3 vWorldNormal;
          varying vec3 vWorldPosition;
          void main() {
            vUv = uv;
            vWorldNormal = normalize(mat3(modelMatrix) * normal);
            vec4 worldPosition = modelMatrix * vec4(position, 1.0);
            vWorldPosition = worldPosition.xyz;
            gl_Position = projectionMatrix * viewMatrix * worldPosition;
          }
        `,
        fragmentShader: `
          uniform sampler2D cloudMap;
          uniform vec3 sunDirection;
          uniform float cloudOpacity;
          varying vec2 vUv;
          varying vec3 vWorldNormal;
          varying vec3 vWorldPosition;
          void main() {
            float alpha = texture2D(cloudMap, vUv).a * cloudOpacity;
            if (alpha < 0.008) discard;
            vec3 normal = normalize(vWorldNormal);
            vec3 viewDir = normalize(cameraPosition - vWorldPosition);
            float sun = max(dot(normal, normalize(sunDirection)), 0.0);
            float rim = pow(1.0 - max(dot(normal, viewDir), 0.0), 2.4);
            vec3 cloudNight = vec3(0.10, 0.14, 0.20);
            vec3 cloudDay = vec3(0.92, 0.96, 1.0) * (0.42 + 0.72 * sun);
            vec3 cloudColor = mix(cloudNight, cloudDay, smoothstep(-0.08, 0.20, dot(normal, normalize(sunDirection))));
            cloudColor += vec3(0.30, 0.48, 0.64) * rim * 0.13;
            gl_FragColor = vec4(cloudColor, alpha);
          }
        `
      });
      cloudMesh = new THREE.Mesh(new THREE.SphereGeometry(1.008, widthSegments, heightSegments), cloudMaterial);
      earthScene.add(cloudMesh);

      const atmosphereMaterial = new THREE.ShaderMaterial({
        transparent: true,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        uniforms: {
          sunDirection: { value: realisticSolarDirection(new Date()).clone() },
          dayGlow: { value: new THREE.Color(0x5eb9ef) },
          twilightGlow: { value: new THREE.Color(0xf08a52) }
        },
        vertexShader: `
          varying vec3 vWorldNormal;
          varying vec3 vWorldPosition;
          void main() {
            vWorldNormal = normalize(mat3(modelMatrix) * normal);
            vec4 worldPosition = modelMatrix * vec4(position, 1.0);
            vWorldPosition = worldPosition.xyz;
            gl_Position = projectionMatrix * viewMatrix * worldPosition;
          }
        `,
        fragmentShader: `
          uniform vec3 sunDirection;
          uniform vec3 dayGlow;
          uniform vec3 twilightGlow;
          varying vec3 vWorldNormal;
          varying vec3 vWorldPosition;
          void main() {
            vec3 normal = normalize(vWorldNormal);
            vec3 viewDirection = normalize(cameraPosition - vWorldPosition);
            float limb = pow(1.0 - abs(dot(normal, viewDirection)), 3.35);
            float solar = dot(normal, normalize(sunDirection));
            float day = smoothstep(-0.25, 0.42, solar);
            float twilight = exp(-pow((solar + 0.035) * 8.0, 2.0));
            vec3 glow = mix(dayGlow * 0.16, dayGlow, day) + twilightGlow * twilight * 0.42;
            float alpha = limb * (0.055 + day * 0.17 + twilight * 0.08);
            gl_FragColor = vec4(glow, alpha);
          }
        `
      });
      atmosphereMesh = new THREE.Mesh(new THREE.SphereGeometry(1.028, Math.max(80, widthSegments), Math.max(54, heightSegments)), atmosphereMaterial);
      earthScene.add(atmosphereMesh);

      earthScene.add(new THREE.HemisphereLight(0x92b7ce, 0x010205, 0.065));
      sunLight = new THREE.DirectionalLight(0xfff8ed, 1.0);
      sunLight.position.set(4.5, 2.4, 5.2);
      earthScene.add(sunLight);
      const rimLight = new THREE.DirectionalLight(0x5b9fd2, 0.055);
      rimLight.position.set(-4, 1.2, -3);
      earthScene.add(rimLight);

      starField = createStarField();
      earthScene.add(starField);

      // Render immediately with a lightweight procedural globe. Real textures arrive progressively.
      earthWebGLReady = true;
      const loadingLabel = $('#earthLoading strong');
      if (loadingLabel) loadingLabel.textContent = 'Loading world map';

      const primaryLoader = new THREE.TextureLoader();
      loadEarthTexture(
        primaryLoader,
        './earth_day_realistic_2048.webp',
        texture => {
          prepareEarthTexture(texture, true);
          earthMaterial.uniforms.dayMap.value = texture;
          earthMaterial.needsUpdate = true;
          $('#earthLoading')?.classList.add('loaded');
          earthCanvas?.classList.add('earth-map-ready');

          const quality = state?.graphicsQuality || 'auto';
          const allowHighResolution = quality === 'high' || (quality === 'auto' && !window.matchMedia('(max-width: 1100px)').matches && (!navigator.deviceMemory || navigator.deviceMemory >= 4));
          if (allowHighResolution) deferNonCritical(() => {
            const highResolutionLoader = new THREE.TextureLoader();
            loadEarthTexture(highResolutionLoader, './earth_day_realistic_4096.webp', highTexture => {
              prepareEarthTexture(highTexture, true);
              const previousTexture = earthMaterial.uniforms.dayMap.value;
              earthMaterial.uniforms.dayMap.value = highTexture;
              earthMaterial.needsUpdate = true;
              if (previousTexture && previousTexture !== placeholderDay && previousTexture !== highTexture) previousTexture.dispose?.();
              earthCanvas?.classList.add('earth-hires-ready');
            }, undefined, () => {});
          }, 1700);

          deferNonCritical(() => {
            const detailLoader = new THREE.TextureLoader();
            loadEarthTexture(detailLoader, './earth_night_realistic_2048.webp', value => {
              prepareEarthTexture(value, true);
              earthMaterial.uniforms.nightMap.value = value;
              earthMaterial.uniforms.nightIntensity.value = globeOptions.night ? 0.92 : 0;
            }, undefined, () => {});
            loadEarthTexture(detailLoader, './earth_normal_2048.jpg', value => {
              prepareEarthTexture(value, false);
              earthMaterial.uniforms.normalMap.value = value;
            }, undefined, () => {});
            loadEarthTexture(detailLoader, './earth_specular_2048.jpg', value => {
              prepareEarthTexture(value, false);
              earthMaterial.uniforms.specularMap.value = value;
            }, undefined, () => {});
            loadEarthTexture(detailLoader, './earth_clouds_realistic_2048.webp', value => {
              prepareEarthTexture(value, false);
              cloudMaterial.uniforms.cloudMap.value = value;
              cloudMaterial.uniforms.cloudOpacity.value = 0.42;
              earthMaterial.uniforms.cloudMap.value = value;
              cloudMaterial.needsUpdate = true;
              earthMaterial.needsUpdate = true;
              earthCanvas?.classList.add('earth-detail-ready');
            }, undefined, () => {});
          }, 1200);
        },
        undefined,
        () => {
          if (loadingLabel) loadingLabel.textContent = 'Fast Earth fallback';
          setTimeout(() => $('#earthLoading')?.classList.add('loaded'), 700);
        }
      );
    } catch (error) {
      console.warn('WebGL Earth fallback', error);
      document.body.classList.add('webgl-fallback');
      $('#earthLoading')?.classList.add('loaded');
    }
  }

  function desiredGlobeRadius() {
    if (!canvasRect) return 1;
    return Math.min(canvasRect.width, canvasRect.height) * 0.43 * view.zoom;
  }

  function syncEarthProjection() {
    if (!earthCamera || !canvasRect) return;
    const width = Math.max(1, canvasRect.width);
    const height = Math.max(1, canvasRect.height);
    earthCamera.aspect = width / height;
    earthCamera.fov = 32;
    earthCamera.updateProjectionMatrix();

    const radiusPx = desiredGlobeRadius();
    const focalPx = height / (2 * Math.tan(THREE.MathUtils.degToRad(earthCamera.fov * .5)));
    const angularRadius = Math.atan(radiusPx / focalPx);
    const distance = 1 / Math.max(.11, Math.sin(angularRadius));
    earthCameraVector.copy(geoVector3(view.lon, view.lat, distance));
    earthCamera.position.copy(earthCameraVector);
    earthCamera.up.set(0, 1, 0);
    earthCamera.lookAt(0, 0, 0);
    earthCamera.updateMatrixWorld();
  }

  function renderEarth(timestamp = 0) {
    if (!earthRenderer || !earthScene || !earthCamera || !canvasRect) return;
    syncEarthProjection();
    if (cloudMesh) {
      cloudMesh.visible = globeOptions.clouds;
      cloudMesh.rotation.y = timestamp * 0.000006;
      if (earthMaterial?.uniforms?.cloudOffset) earthMaterial.uniforms.cloudOffset.value = (cloudMesh.rotation.y / (Math.PI * 2)) % 1;
    }
    if (starField) starField.rotation.y = timestamp * 0.0000015;
    if (earthMaterial?.uniforms?.nightIntensity) earthMaterial.uniforms.nightIntensity.value = globeOptions.night ? 0.92 : 0.0;
    const sunDirection = realisticSolarDirection(new Date());
    if (sunLight) sunLight.position.copy(sunDirection).multiplyScalar(6);
    earthMaterial?.uniforms?.sunDirection?.value.copy(sunDirection);
    cloudMesh?.material?.uniforms?.sunDirection?.value.copy(sunDirection);
    atmosphereMesh?.material?.uniforms?.sunDirection?.value.copy(sunDirection);
    earthRenderer.render(earthScene, earthCamera);
  }
  let dragging = false;
  let dragMoved = false;
  let dragStart = null;
  let markerHitboxes = [];
  let shipHitboxes = [];
  let fleetHitboxes = [];
  let investmentHitboxes = [];
  let simulationDayAnchor = performance.now();
  let selectedEmpireChain = 'all';
  let selectedShopCategory = 'all';
  let canvasRect = null;
  let animationTime = 0;
  let lastDrawTime = 0;

  function officeOwned(id) { return (state?.offices || []).includes(id); }
  function hasStaff(id) { return (state?.staff || []).includes(id); }
  function getOffice(id) { return officeCatalog.find(o => o.id === id); }
  function getStaff(id) { return staffCatalog.find(member => member.id === id); }
  function activeOfficeProject(id) { return (state?.officeProjects || []).find(project => project.officeId === id); }
  function activeOfficeProjectCount() { return (state?.officeProjects || []).length; }
  function officeUnlocked(office) {
    return playerLevel() >= (office.minLevel || 1)
      && state.reputation >= (office.minReputation || 0)
      && state.completedDeals >= (office.minDeals || 0)
      && hqCurrentTier().tier >= (office.minHqTier || 1);
  }
  function officeLockReason(office) {
    if (playerLevel() < (office.minLevel || 1)) return `Company level ${office.minLevel}`;
    if (hqCurrentTier().tier < (office.minHqTier || 1)) return `Geneva HQ Tier ${office.minHqTier}`;
    if (state.completedDeals < (office.minDeals || 0)) return `${office.minDeals} completed deals`;
    if (state.reputation < (office.minReputation || 0)) return `Reputation ${office.minReputation}`;
    return '';
  }
  function officeBookValue() {
    const commissioned = officeCatalog.filter(o => o.id !== 'geneva' && officeOwned(o.id)).reduce((sum,o)=>sum+(o.cost||0)*.82,0);
    const workInProgress = (state.officeProjects || []).reduce((sum,p)=>sum+(p.cost||0)*.68,0);
    return Math.round(commissioned + workInProgress);
  }
  function officeCountries() { return new Set(officeCatalog.filter(o=>officeOwned(o.id)).map(o=>o.country)); }
  function officeCoverageMatch(office, opp) {
    if (!opp || office.id === 'geneva') return { direct:false, regional:false, focus:false };
    const routeHubs=[opp.origin,opp.destination,...(opp.via||[])].map(getHub).filter(Boolean);
    const countries=new Set(routeHubs.map(h=>h.country));
    const direct = routeHubs.some(h=>h.id===office.hub) || countries.has(office.country);
    const regional = !direct && (office.coverageCountries||[]).some(country=>countries.has(country));
    const focus = (office.focusCommodities||[]).includes(opp.commodity);
    return { direct, regional, focus };
  }
  function officeNetworkAdjustments(opp) {
    const result={pnlBonus:0,durationBonus:0,acceptance:0,equityFactor:1,riskReduction:0,financingRateReduction:0,sources:[]};
    officeCatalog.filter(o=>officeOwned(o.id)).forEach(office=>{
      const match=officeCoverageMatch(office,opp);
      if (!match.direct && !match.regional) return;
      const weight=match.direct?1:.55;
      const focusBoost=match.focus?1.2:.85;
      result.pnlBonus += Math.round((office.pnlBonus||0)*weight*focusBoost);
      result.durationBonus += (office.durationBonus||0)*weight;
      result.acceptance += (office.acceptance||0)*weight*(match.focus?1.15:1);
      result.equityFactor *= Math.max(.82,1-(office.equityReduction||0)*weight*(match.focus?1.15:1));
      result.riskReduction += (office.riskReduction||0)*weight;
      result.financingRateReduction += Math.min(.012,(office.creditBonus||0)/150_000_000*weight);
      result.sources.push(office.name);
    });
    result.pnlBonus=Math.min(75_000,Math.round(result.pnlBonus));
    result.durationBonus=Math.min(5,Math.round(result.durationBonus));
    result.acceptance=Math.min(12,Math.round(result.acceptance));
    result.riskReduction=Math.min(15,Math.round(result.riskReduction));
    return result;
  }
  function officeNetworkRiskReduction() {
    return Math.min(14, officeCatalog.filter(o=>officeOwned(o.id)).reduce((sum,o)=>sum+(o.riskReduction||0),0)*.35);
  }
  function staffUnlocked(member) { return state.reputation >= member.minReputation; }
  // v45 — copertura automatica dello scoperto di cassa
  function handleCashShortfall() {
    if (state.cash >= 0) { state.insolventDays = 0; return; }
    const shortfall = -state.cash;
    const stats = portfolioStats();
    const headroom = Math.max(0, effectiveCreditLimit() - stats.creditUsed);
    const drawn = Math.min(shortfall, headroom);
    if (drawn > 0) {
      const fee = Math.max(1_500, Math.round(drawn * difficultySettings().emergencyRate));
      state.cash += drawn - fee;
      state.overdraft = (state.overdraft || 0) + drawn;
      state.emergencyFundingCost = (state.emergencyFundingCost || 0) + fee;
      state.worldEventFeed.unshift({ type: 'margin', title: 'Overdraft drawn', date: state.date, description: `Treasury drew ${money(drawn)} of emergency liquidity to cover the cash shortfall. Fee ${money(fee)}.` });
      state.worldEventFeed = state.worldEventFeed.slice(0, 18);
    }
    if (state.cash < 0) {
      state.insolventDays = (state.insolventDays || 0) + 1;
      state.reputation = clamp(state.reputation - 1, 0, 100);
      if (state.insolventDays === 1 || state.insolventDays % 5 === 0) {
        showToast(`Cash position negative (${money(state.cash)}) for ${state.insolventDays} day${state.insolventDays === 1 ? '' : 's'}. Close a position or reduce overhead.`, 'error');
        state.worldEventFeed.unshift({ type: 'margin', title: 'Board alert: negative cash position', date: state.date, description: `The desk has been overdrawn for ${state.insolventDays} consecutive days. Reputation is deteriorating.` });
        state.worldEventFeed = state.worldEventFeed.slice(0, 18);
      }
    } else {
      state.insolventDays = 0;
    }
  }

  function dailyOverhead() {
    const officeCost = officeCatalog.filter(o => officeOwned(o.id)).reduce((sum,o)=>sum+o.dailyCost,0);
    const salaryCost = staffCatalog.filter(member => hasStaff(member.id)).reduce((sum,member)=>sum+member.dailySalary,0);
    const assetOperatingCost = shopFacilityOperatingCost() + ownedFleetMaintenance();
    const hqOperatingCost = hqCurrentTier().dailyCost || 0;
    return Math.round((officeCost + salaryCost + assetOperatingCost + hqOperatingCost) * activeDoctrine().overheadFactor);
  }
  function shopDefinition(id) { return shopCatalog.find(item => item.id === id); }
  function shopAssetRecord(id) {
    state.shopAssets = state.shopAssets || {};
    return state.shopAssets[id] || { quantity:0, totalSpent:0 };
  }
  function shopOwnedQuantity(id) { return shopAssetRecord(id).quantity || 0; }
  function shopPendingQuantity(id) { return (state.shopOrders || []).filter(order => order.itemId === id).length; }
  function shopUnlocked(item) {
    return state.reputation >= item.minReputation && state.completedDeals >= item.minDeals && (!item.requiresOffice || officeOwned(item.requiresOffice));
  }
  function shopFacilityOperatingCost() {
    return shopCatalog.filter(item => item.category !== 'fleet').reduce((sum,item)=>sum+(item.dailyCost||0)*shopOwnedQuantity(item.id),0);
  }
  function ownedFleetMaintenance() {
    return (state.fleetAssets || []).filter(asset => asset.ownership === 'owned').reduce((sum,asset)=>sum+(asset.maintenance||0),0);
  }
  function shopDailyIncome() {
    return shopCatalog.reduce((sum,item)=>sum+(item.dailyIncome||0)*shopOwnedQuantity(item.id),0);
  }
  function shopBookValue() {
    return Object.values(state.shopAssets || {}).reduce((sum,record)=>sum+(record.totalSpent||0)*.82,0);
  }
  function shopBuilderBonus() {
    return shopCatalog.reduce((sum,item)=>sum+(item.builderBonus||0)*shopOwnedQuantity(item.id),0);
  }
  function activeShopOrders() { return (state.shopOrders || []).length; }
  function activeProjectCount() { return activeConstructionCount() + activeShopOrders() + activeOfficeProjectCount() + (state.hqUpgrade ? 1 : 0); }
  function shopItemMatches(item, opp) {
    if (item.category === 'fleet') return false;
    if (item.matchHubs && !item.matchHubs.some(hub => [opp.origin,opp.destination,...(opp.via||[])].includes(hub))) return false;
    if (item.transportClass && item.transportClass !== transportClassForOpportunity(opp)) return false;
    if (item.commodity && item.commodity !== opp.commodity) return false;
    return true;
  }
  function shopAdjustments(opp) {
    return shopCatalog.reduce((acc,item)=>{
      const quantity=shopOwnedQuantity(item.id);
      if (!quantity || !shopItemMatches(item,opp)) return acc;
      acc.pnlBonus += (item.pnlBonus||0)*quantity;
      acc.durationBonus += (item.durationBonus||0)*quantity;
      acc.acceptanceBonus += (item.acceptanceBonus||0)*quantity;
      acc.equityFactor *= Math.max(.75,1-(item.equityReduction||0)*quantity);
      acc.sources.push(`${item.name} ×${quantity}`);
      return acc;
    },{pnlBonus:0,durationBonus:0,acceptanceBonus:0,equityFactor:1,sources:[]});
  }
  function storageDiscountForHub(hubId) {
    return clamp(shopCatalog.reduce((sum,item)=>{
      const quantity=shopOwnedQuantity(item.id);
      return sum + (quantity && item.storageDiscount && (!item.matchHubs || item.matchHubs.includes(hubId)) ? item.storageDiscount*quantity : 0);
    },0),0,.55);
  }
  function buyShopItem(id) {
    const item=shopDefinition(id); if(!item) return;
    const owned=shopOwnedQuantity(id), pending=shopPendingQuantity(id);
    if (!shopUnlocked(item)) {
      const requirement=item.requiresOffice&&!officeOwned(item.requiresOffice)?getOffice(item.requiresOffice)?.name:`reputation ${item.minReputation} and ${item.minDeals} deals`;
      return showToast(`Locked: requires ${requirement}.`);
    }
    if (owned+pending >= item.maxOwned) return showToast('Maximum quantity already owned or under construction.');
    if (activeProjectCount() >= builderSlots()) return showToast('All project teams are busy. Finish a project or buy another Capital Projects Office.');
    if (state.cash < item.cost) return showToast('Insufficient liquidity for this purchase.');
    state.cash -= item.cost;
    state.shopSpent = (state.shopSpent||0) + item.cost;
    state.shopOrders = state.shopOrders || [];
    state.shopOrders.push({ id:`shop-order-${state.sequence++}`, itemId:id, daysRemaining:item.buildDays, totalDays:item.buildDays, orderedAt:state.date, cost:item.cost });
    recordJournal('Capital project', `${item.name} ordered`, `${item.buildDays}-day construction program started.`, -item.cost, id);
    activeLeftTab='shop';
    // v45 — addXp puo' far salire di livello e accreditare cash e lingotti:
    // va eseguita PRIMA di saveState, altrimenti il bonus non viene persistito.
    addXp(30, 'shop');
    saveState(); renderAll();
    try { Sound.play('purchase'); } catch (e) {}
    showToast(`${item.name} ordered. Delivery in ${item.buildDays} days.`);
  }
  function completeShopOrder(order) {
    const item=shopDefinition(order.itemId); if(!item) return;
    const record=shopAssetRecord(item.id);
    state.shopAssets[item.id]={ quantity:(record.quantity||0)+1, totalSpent:(record.totalSpent||0)+order.cost };
    state.shopDeliveries=(state.shopDeliveries||0)+1;
    if (item.category === 'fleet') {
      const vessel=getVesselCatalog(item.vesselCatalogId);
      if (vessel) state.fleetAssets.push({
        id:`owned-vessel-${item.vesselCatalogId}-${state.sequence++}`, catalogId:item.vesselCatalogId, name:vessel.name,
        status:'available', assignedDealId:null, positionHub:vessel.homeHub, ownership:'owned', maintenance:item.maintenance||0,
        purchaseCost:item.cost, acquired:state.date, daysRemaining:null, charterDays:null, charterCost:0
      });
    }
    state.reputation=clamp(state.reputation+1,0,100);
    state.worldEventFeed.unshift({type:'investment',title:`${item.name} delivered`,date:state.date,description:`The new ${item.category} asset is operational and its permanent benefits are active.`});
    recordJournal('Capital project', `${item.name} commissioned`, 'Construction completed and asset entered service.', 0, item.id);
    evaluateMissions();
  }
  function processShopDay() {
    const income=shopDailyIncome();
    if (income>0) { state.cash += income; state.assetIncome=(state.assetIncome||0)+income; }
    (state.shopOrders||[]).forEach(order=>{ order.daysRemaining=Math.max(0,order.daysRemaining-1); });
    const completed=(state.shopOrders||[]).filter(order=>order.daysRemaining<=0);
    completed.forEach(completeShopOrder);
    if (completed.length) state.shopOrders=(state.shopOrders||[]).filter(order=>order.daysRemaining>0);
  }

  function investmentDefinition(id) { return investmentCatalog.find(asset => asset.id === id); }
  function investmentRecord(id) {
    state.investments = state.investments || {};
    return state.investments[id] || { level:0, buildingTo:null, daysRemaining:0, totalSpent:0 };
  }
  function investmentLevel(id) { return investmentRecord(id).level || 0; }
  function totalInvestmentLevels() { return investmentCatalog.reduce((sum,asset)=>sum+investmentLevel(asset.id),0); }
  function activeConstructionCount() { return Object.values(state.investments || {}).filter(record => record.buildingTo && record.daysRemaining > 0).length; }
  function builderSlots() { return 1 + (officeOwned('rotterdam') ? 1 : 0) + (officeOwned('singapore') ? 1 : 0) + shopBuilderBonus() + (state.bonusBuilders || 0); }
  function builderGoldCost() { return 8 + (state.bonusBuilders || 0) * 6; }
  function buyExtraBuilder() {
    const cost = builderGoldCost();
    if ((state.goldBars || 0) < cost) { showToast(`You need ${cost} gold bars to hire another project team.`, 'error'); return; }
    if ((state.bonusBuilders || 0) >= 4) { showToast('Numero massimo di squadre extra raggiunto.', 'warning'); return; }
    state.goldBars -= cost;
    state.bonusBuilders = (state.bonusBuilders || 0) + 1;
    try { Sound.play('purchase'); } catch (e) {}
    addXp(25, 'builder');
    saveState(true);
    renderAll();
    showToast(`Nuova squadra di progetto assunta! Ora hai ${builderSlots()} builder.`, 'success');
  }
  function investmentCost(asset, targetLevel = investmentLevel(asset.id)+1) { return Math.round(asset.baseCost * Math.pow(1.72, targetLevel-1)); }
  function investmentBuildDays(asset, targetLevel = investmentLevel(asset.id)+1) { return Math.round(asset.buildDays * Math.pow(1.38, targetLevel-1)); }
  function investmentUnlocked(asset) { return state.reputation >= asset.minReputation && state.completedDeals >= asset.minDeals; }
  function investmentMatches(asset, opp) {
    const commodityMatch = asset.commodity ? asset.commodity === opp.commodity : asset.commodities ? asset.commodities.includes(opp.commodity) : asset.priceKey ? asset.priceKey === opp.priceKey : true;
    const routeMatch = asset.routeHub ? [opp.origin,opp.destination,...(opp.via||[])].includes(asset.routeHub) : asset.destination ? opp.destination === asset.destination : asset.ocean ? transportClassForOpportunity(opp) === 'ocean' : true;
    return commodityMatch && routeMatch;
  }
  function investmentAdjustments(opp) {
    return investmentCatalog.reduce((acc,asset)=>{
      const level=investmentLevel(asset.id);
      if (!level || !investmentMatches(asset,opp)) return acc;
      acc.pnlBonus += (asset.pnlBonus||0)*level*(activeDoctrine().assetMultiplier || 1);
      acc.durationBonus += (asset.durationBonus||0)*level;
      acc.acceptanceBonus += (asset.acceptanceBonus||0)*level;
      acc.equityFactor *= Math.max(.72,1-(asset.equityReduction||0)*level);
      acc.sources.push(`${asset.name} L${level}`);
      return acc;
    },{pnlBonus:0,durationBonus:0,acceptanceBonus:0,equityFactor:1,sources:[]});
  }
  function dailyInvestmentIncome() {
    return investmentCatalog.reduce((sum,asset)=>sum+(asset.dailyIncome||0)*investmentLevel(asset.id),0);
  }
  function investmentBookValue() {
    return Object.values(state.investments || {}).reduce((sum,record)=>sum+(record.totalSpent||0)*.88,0);
  }
  function startInvestment(id) {
    const asset=investmentDefinition(id); if (!asset) return;
    const record=investmentRecord(id);
    if (record.buildingTo) return showToast('This asset is already under construction.');
    if (record.level >= asset.maxLevel) return showToast('Asset already at maximum level.');
    if (!investmentUnlocked(asset)) return showToast(`You need reputation ${asset.minReputation} and ${asset.minDeals} completed deals.`);
    if (activeProjectCount() >= builderSlots()) return showToast('All project teams are busy. Wait for a project to complete or expand the Projects Office.');
    const target=record.level+1, cost=investmentCost(asset,target), days=investmentBuildDays(asset,target);
    if (state.cash < cost) return showToast('Insufficient liquidity for this investment.');
    state.cash -= cost;
    state.investments[id]={...record,buildingTo:target,daysRemaining:days,totalSpent:(record.totalSpent||0)+cost};
    state.constructionQueue=state.constructionQueue||[];
    if (!state.constructionQueue.includes(id)) state.constructionQueue.push(id);
    activeLeftTab='empire'; selected={type:'investment',id}; focusOnHub(asset.hub);
    addXp(30, 'empire');
    saveState(); renderAll();
    try { Sound.play('purchase'); } catch (e) {}
    showToast(`${asset.name}: level ${target} construction started (${days} days).`);
  }
  function processInvestmentDay() {
    let income=dailyInvestmentIncome();
    if (income>0) { state.cash += income; state.assetIncome=(state.assetIncome||0)+income; }
    Object.entries(state.investments||{}).forEach(([id,record])=>{
      if (!record.buildingTo || record.daysRemaining<=0) return;
      record.daysRemaining-=1;
      if (record.daysRemaining<=0) {
        record.level=record.buildingTo; record.buildingTo=null; record.daysRemaining=0;
        state.constructionQueue=(state.constructionQueue||[]).filter(item=>item!==id);
        const asset=investmentDefinition(id);
        state.reputation=clamp(state.reputation+1,0,100);
        state.worldEventFeed.unshift({type:'investment',title:`${asset.name} upgraded`,date:state.date,description:`Asset operational at level ${record.level}. New industrial benefits are active.`});
      }
    });
  }
  function initializeCounterparties() {
    state.counterparties = state.counterparties || {};
    counterpartyCatalog.forEach(party => {
      state.counterparties[party.id] = {
        relationship: 50,
        deals: 0,
        disputes: 0,
        ...state.counterparties[party.id]
      };
    });
  }
  function getCounterparty(id) { return counterpartyCatalog.find(p => p.id === id); }
  function getCounterpartyState(id) { return state.counterparties[id] || { relationship: 50, deals: 0, disputes: 0 }; }
  function partiesForOpportunity(opp) { return opportunityParties[opp.id] || opp?.counterparties || {}; }

  function counterpartyBaseCreditLimit(id) {
    const party = getCounterparty(id);
    if (!party) return 0;
    const relationship = getCounterpartyState(id).relationship || 50;
    const score = party.credit || 70;
    const ratingFactor = /^(AA|A)/.test(party.creditRating || '') ? 1.12 : /^BBB/.test(party.creditRating || '') ? 1 : .82;
    return Math.round((750_000 + score * 65_000) * (.72 + relationship / 180) * ratingFactor);
  }

  function counterpartyCreditLimit(id) {
    return Math.max(250_000, counterpartyBaseCreditLimit(id) + (state.counterpartyLimitOverrides?.[id] || 0));
  }

  function dealCreditExposure(deal) {
    if (!deal?.buyerId) return 0;
    const opp = getOpportunity(deal.opportunityId);
    if (!opp) return 0;
    const notional = deal.invoiceAmount || physicalNotional(opp, deal.quantity || opp.quantity, deal.capital);
    const payment = deal.commercialTerms?.payment || 'delivery';
    if (deal.delivered && (deal.paymentDaysRemaining || 0) > 0) return notional;
    if (payment === 'thirty') return notional * .72;
    if (payment === 'delivery') return notional * .14;
    return notional * .05;
  }

  function counterpartyExposure(id) {
    return state.activeDeals.reduce((sum, deal) => deal.buyerId === id ? sum + dealCreditExposure(deal) : sum, 0);
  }

  function counterpartyCreditHeadroom(id) {
    return Math.max(0, counterpartyCreditLimit(id) - counterpartyExposure(id));
  }

  function prospectiveCreditExposure(opp, economics = opportunityEconomics(opp)) {
    const payment = economics.terms?.payment || 'delivery';
    const notional = physicalNotional(opp, economics.quantity, economics.capital) + Math.max(0, economics.basePnl || 0);
    if (payment === 'thirty') return notional;
    if (payment === 'delivery') return notional * .14;
    return notional * .05;
  }

  function requestCreditLimit(counterpartyId) {
    const party = getCounterparty(counterpartyId);
    if (!party || state.creditLimitRequests?.[counterpartyId]?.daysRemaining > 0) return;
    const base = counterpartyBaseCreditLimit(counterpartyId);
    const increment = Math.max(500_000, Math.round(base * .25));
    const cost = Math.max(7_500, Math.round(increment * .004));
    if (state.cash < cost) return showToast('Insufficient cash for the credit committee review.');
    state.cash -= cost;
    state.creditLimitRequests[counterpartyId] = { counterpartyId, daysRemaining: 5, increment, cost, requestedAt: state.date, status: 'pending' };
    recordJournal('Credit', `${party.name}: limit increase requested`, `Requested ${money(increment)} additional buyer limit · committee fee ${money(cost)}`, -cost, counterpartyId);
    saveState(); renderAll(); showToast(`Credit committee review started for ${party.name}.`);
  }

  function processCreditLimitRequests() {
    Object.entries(state.creditLimitRequests || {}).forEach(([id, request]) => {
      if (!request || request.status !== 'pending') return;
      request.daysRemaining = Math.max(0, (request.daysRemaining || 0) - 1);
      if (request.daysRemaining > 0) return;
      const party = getCounterparty(id);
      const relationship = getCounterpartyState(id).relationship || 50;
      const approval = clamp((party?.credit || 65) * .58 + relationship * .34 - (state.difficulty === 'expert' ? 8 : 0), 20, 96);
      const roll = deterministicRandom(`${id}-credit-committee-${state.dayIndex}`) * 100;
      if (roll <= approval) {
        request.status = 'approved';
        state.counterpartyLimitOverrides[id] = (state.counterpartyLimitOverrides[id] || 0) + request.increment;
        state.worldEventFeed.unshift({ type:'credit', title:`Credit limit approved · ${party?.name || id}`, date:state.date, description:`The committee approved ${money(request.increment)} of additional buyer exposure.` });
        recordJournal('Credit', `${party?.name || id}: limit approved`, `Additional buyer limit ${money(request.increment)}`, 0, id);
      } else {
        request.status = 'declined';
        state.worldEventFeed.unshift({ type:'credit', title:`Credit limit declined · ${party?.name || id}`, date:state.date, description:'The committee declined the request. Improve payment security or reduce transaction size.' });
        recordJournal('Credit', `${party?.name || id}: limit declined`, `Committee approval probability was ${Math.round(approval)}%`, 0, id);
      }
      state.worldEventFeed = state.worldEventFeed.slice(0,18);
    });
  }

  function paymentDaysForDeal(deal) {
    return deal.commercialTerms?.payment === 'thirty' ? 30 : 0;
  }

  function activeEventDefinition(active) { return globalEventCatalog.find(event => event.id === active.id); }
  function activeCrisisDefinitions() { return (state.activeGlobalEvents || []).map(active => ({ ...activeEventDefinition(active), ...active })).filter(Boolean); }
  function effectiveCreditLimit() {
    const penalty = activeCrisisDefinitions().reduce((sum, event) => sum + (event.creditPenalty || 0), 0);
    const responseCredit = activeCrisisDefinitions().reduce((sum, event) => sum + (crisisResponseAdjustments(event).creditBonus || 0), 0);
    return Math.max(1_000_000, (state.creditLimit + hqAdjustments().creditBonus + responseCredit - penalty) * activeDoctrine().creditFactor);
  }
  function difficultySettings() {
    if (state.difficulty === 'guided') return { acceptance: 7, marginRate: .04, eventLoss: .82, emergencyRate: .009, riskPenalty: -6 };
    if (state.difficulty === 'expert') return { acceptance: -6, marginRate: .075, eventLoss: 1.22, emergencyRate: .025, riskPenalty: 8 };
    return { acceptance: 0, marginRate: .055, eventLoss: 1, emergencyRate: .016, riskPenalty: 0 };
  }
  function activeDoctrine() { return strategyDoctrineCatalog[state.strategyDoctrine] || strategyDoctrineCatalog.merchant; }
  function activeCapitalPolicy() { return capitalPolicyCatalog[state.capitalPolicy] || capitalPolicyCatalog.balanced; }
  function minimumCashReserve() {
    const nav = Math.max(0, portfolioStats().nav);
    return Math.max(100_000, Math.round(nav * activeCapitalPolicy().reserveRatio));
  }
  function capitalPolicyHeadroom() { return state.cash - minimumCashReserve(); }
  function canChangeCapitalPolicy() { return (state.dayIndex || 0) - (Number.isFinite(state.capitalPolicyChangedDay) ? state.capitalPolicyChangedDay : -30) >= 14; }
  function changeCapitalPolicy(id) {
    const policy = capitalPolicyCatalog[id];
    if (!policy || id === state.capitalPolicy) return;
    if (!canChangeCapitalPolicy()) return showToast(`Capital mandate can be changed again in ${14 - ((state.dayIndex||0) - (Number.isFinite(state.capitalPolicyChangedDay) ? state.capitalPolicyChangedDay : -30))} days.`);
    state.capitalPolicy = id;
    state.capitalPolicyChangedDay = state.dayIndex || 0;
    state.worldEventFeed.unshift({ type:'capital', title:`Capital policy: ${policy.label}`, date:state.date, description:`The board reset the minimum liquidity reserve to ${Math.round(policy.reserveRatio*100)}% of NAV.` });
    state.worldEventFeed = state.worldEventFeed.slice(0,18);
    recordJournal('Board', `Capital policy changed`, `${policy.label} · minimum reserve ${Math.round(policy.reserveRatio*100)}% of NAV`, 0, id);
    saveState(); renderAll(); showToast(`${policy.label} is now active.`);
  }
  function canChangeDoctrine() { return (state.dayIndex || 0) - (state.strategyChangedDay ?? -30) >= 14; }
  function changeDoctrine(id) {
    const doctrine = strategyDoctrineCatalog[id];
    if (!doctrine || id === state.strategyDoctrine) return;
    if (!canChangeDoctrine()) return showToast(`Board policy can be changed again in ${14 - ((state.dayIndex||0)-(state.strategyChangedDay??-30))} days.`);
    const transitionCost = 18_000 + state.activeDeals.length * 4_000;
    if (state.cash < transitionCost) return showToast('Insufficient liquidity for the strategy transition.');
    state.cash -= transitionCost;
    state.strategyDoctrine = id;
    state.strategyChangedDay = state.dayIndex || 0;
    state.worldEventFeed.unshift({ type:'strategy', title:`Doctrine changed: ${doctrine.label}`, date:state.date, description:`The board approved a new operating model. Transition cost ${money(transitionCost)}.` });
    saveState(); renderAll(); showToast(`${doctrine.label} is now active.`);
  }
  function unitMultiplierForOpportunity(opp) { return opp?.priceKey === 'crude' ? 7.45 : 1; }
  function physicalNotional(opp, quantity = null, capital = null) {
    const q = quantity ?? liveOffer(opp).quantity ?? opp.quantity;
    const market = marketPriceForOpportunity(opp) * q * unitMultiplierForOpportunity(opp);
    return Math.max(market, (capital || 0) * .92);
  }
  function fxExposureShare(opp) {
    if (['brescia','genova','rotterdam'].includes(opp.destination) && !['tallinn','rotterdam'].includes(opp.origin)) return .16;
    if (opp.destination === 'singapore' || opp.destination === 'shanghai') return .04;
    return .08;
  }
  function financingSelection(opp) { return selectedFinancingStrategies[opp.id] || 'revolver'; }
  function insuranceSelection(opp) { return selectedInsuranceStrategies[opp.id] || 'basic'; }
  function inspectionSelection(opp) { return selectedInspectionStrategies[opp.id] || 'standard'; }
  function financingAvailable(id) {
    const profile = financingProfiles[id];
    return Boolean(profile && (!profile.requiresStaff || hasStaff(profile.requiresStaff)));
  }
  function initialMarginFor(opp, hedgeRatio, quantity, capital = null) {
    return Math.round(physicalNotional(opp, quantity, capital) * clamp(hedgeRatio / 100, 0, 1.1) * difficultySettings().marginRate);
  }
  function structureForOpportunity(opp) {
    const financingId = financingSelection(opp);
    const financing = financingProfiles[financingId] || financingProfiles.revolver;
    const insuranceId = insuranceSelection(opp);
    const insurance = insuranceProfiles[insuranceId] || insuranceProfiles.basic;
    const inspectionId = inspectionSelection(opp);
    const inspection = inspectionProfiles[inspectionId] || inspectionProfiles.standard;
    const fxHedgeRatio = Number(selectedFxHedgeRatios[opp.id] ?? 80);
    return { financingId, financing, insuranceId, insurance, inspectionId, inspection, fxHedgeRatio };
  }

  function currentMarketRegime() {
    return marketRegimeCatalog[state.marketRegime] || marketRegimeCatalog.balanced;
  }

  function generateMarketRegime(cycle = state.marketCycle || 1) {
    const ids = Object.keys(marketRegimeCatalog);
    const month = currentDate().getUTCMonth();
    const seasonalTilt = month >= 9 || month <= 1 ? 1 : 0;
    const index = Math.floor(deterministicRandom(`regime-${cycle}-${month}-${seasonalTilt}`) * ids.length);
    return ids[index] || 'balanced';
  }

  function eligibleRivals(opp) {
    const matches = aiRivalDesks.filter(rival => rival.specialties.includes(opp.commodity));
    return matches.length ? matches : aiRivalDesks;
  }

  function initializeCompetitiveMarket(force = false) {
    state.rivalMarket = state.rivalMarket || {};
    opportunities.forEach(opp => {
      const existing = state.rivalMarket[opp.id];
      if (!force && existing?.cycle === state.marketCycle) return;
      const candidates = eligibleRivals(opp);
      const leader = candidates[Math.floor(deterministicRandom(`${opp.id}-${state.marketCycle}-rival`) * candidates.length)] || candidates[0];
      const base = 28 + deterministicRandom(`${opp.id}-${state.marketCycle}-pressure`) * 58;
      const valueBoost = clamp(opp.basePnl / 2500, 0, 18);
      const pressure = Math.round(clamp(base + valueBoost + (opp.riskClass === 'low' ? 5 : 0), 18, 96));
      const awardDay = 2 + Math.floor(deterministicRandom(`${opp.id}-${state.marketCycle}-award`) * 4);
      state.rivalMarket[opp.id] = { cycle: state.marketCycle, pressure, leaderId: leader.id, awardDay, status:'open', awardedTo:null };
    });
  }

  function rivalTenderFor(oppId) {
    initializeCompetitiveMarket();
    return state.rivalMarket?.[oppId] || null;
  }

  function rivalForTender(tender) {
    return aiRivalDesks.find(rival => rival.id === tender?.leaderId) || aiRivalDesks[0];
  }

  function competitionPenalty(opp) {
    const tender = rivalTenderFor(opp.id);
    const specialization = deskSpecializationAdjustments(opp);
    const franchise = marketReputationAdjustments(opp);
    const framework = commercialFrameworkAdjustments(opp);
    const hq = hqAdjustments();
    if (!tender || tender.status === 'player_reserved') return 0;
    return Math.max(0, (tender.pressure - 35) * .18);
  }

  function advanceRivalMarketDay() {
    initializeCompetitiveMarket();
    opportunities.forEach(opp => {
      const tender = rivalTenderFor(opp.id);
      if (!tender || tender.cycle !== state.marketCycle || tender.status !== 'open') return;
      const negotiation = state.negotiations?.[opp.id];
      if (negotiation?.status === 'accepted' || negotiation?.status === 'consumed') {
        tender.status = 'player_reserved';
        tender.awardedTo = 'player';
        return;
      }
      if (state.marketCycleDay < tender.awardDay) return;
      const closeRoll = deterministicRandom(`${opp.id}-${state.marketCycle}-${state.marketCycleDay}-close`) * 100;
      if (closeRoll > tender.pressure && state.marketCycleDay < 6) {
        tender.awardDay += 1;
        tender.pressure = clamp(tender.pressure + 4, 0, 99);
        return;
      }
      const rival = rivalForTender(tender);
      tender.status = 'awarded';
      tender.awardedTo = rival.id;
      state.tenderLosses = (state.tenderLosses || 0) + 1;
      // v48 - il testa a testa conta solo le gare davvero contestate: una gara
      // ignorata non e' una sconfitta contro quel desk.
      const contested = (tender.bidAttempts || 0) > 0
        || state.negotiations?.[opp.id]?.cycle === state.marketCycle;
      if (contested) recordRivalOutcome(rival.id, false, opp.title);
      state.rivalFeed.unshift({ date:state.date, cycle:state.marketCycle, opportunityId:opp.id, rivalId:rival.id, title:`${rival.name} wins ${opp.title}`, description:`${opp.commodity} tender awarded after ${tender.pressure}% competitive pressure.` });
      state.rivalFeed = state.rivalFeed.slice(0,18);
    });
  }

  function evaluateAchievements(notify = true) {
    state.achievements = state.achievements || [];
    const unlocked = [];
    achievementCatalog.forEach(item => {
      if (state.achievements.includes(item.id) || !item.achieved(state)) return;
      state.achievements.push(item.id);
      unlocked.push(item.title);
    });
    if (notify && unlocked.length) { setTimeout(() => showToast(`Achievement unlocked: ${unlocked.join(', ')}.`), 120); try { Sound.play('achievement'); } catch (e) {} addXp(35 * unlocked.length, 'achievement'); addGold(3 * unlocked.length, 'achievement'); }
  }

  function currentSeason() {
    const month = currentDate().getUTCMonth();
    if ([11,0,1].includes(month)) return { id:'winter', label:'Northern winter', icon:'❄' };
    if ([2,3,4].includes(month)) return { id:'spring', label:'Northern spring', icon:'✦' };
    if ([5,6,7].includes(month)) return { id:'summer', label:'Northern summer', icon:'☀' };
    return { id:'autumn', label:'Northern autumn', icon:'◒' };
  }
  function seasonalDemand(opp) {
    const month = currentDate().getUTCMonth();
    const key = opp.priceKey || 'copper';
    const cycles = {
      copper:[1.08,1.07,1.05,1.02,.98,.94,.91,.93,1.02,1.10,1.12,1.10],
      aluminium:[1.06,1.05,1.04,1.01,.98,.95,.93,.95,1.03,1.09,1.10,1.08],
      urea:[1.04,1.13,1.18,1.12,.96,.88,.86,.93,1.14,1.16,1.05,.98],
      crude:[1.08,1.05,.99,.96,1.02,1.10,1.14,1.12,1.01,.96,1.02,1.09],
      wheat:[.96,.98,1.02,1.08,1.12,1.06,.91,.88,.94,1.04,1.08,1.01],
      ironore:[1.12,1.10,1.07,1.03,.98,.94,.91,.93,1.01,1.07,1.11,1.13],
      coffee:[1.03,1.04,1.06,1.08,1.10,.94,.88,.90,1.01,1.09,1.11,1.07]
    };
    const factor = (cycles[key] || cycles.copper)[month];
    const label = factor >= 1.10 ? 'Peak demand' : factor >= 1.04 ? 'Firm demand' : factor <= .92 ? 'Seasonal low' : factor <= .97 ? 'Soft demand' : 'Normal demand';
    return { factor, label, acceptance: Math.round((factor-1)*28), pnlFactor: .84 + factor*.16, quantityFactor: .9 + factor*.1 };
  }
  function liveOffer(opp) {
    const cycle = state.marketCycle || 1;
    const qRand = deterministicRandom(`${opp.id}-${cycle}-quantity`);
    const pnlRand = deterministicRandom(`${opp.id}-${cycle}-pnl`);
    const capitalRand = deterministicRandom(`${opp.id}-${cycle}-capital`);
    const durationRand = deterministicRandom(`${opp.id}-${cycle}-duration`);
    const season = seasonalDemand(opp);
    const quantity = Math.max(100, Math.round((opp.quantity * (.88 + qRand * .26) * season.quantityFactor) / 25) * 25);
    const quantityFactor = quantity / opp.quantity;
    return {
      quantity,
      basePnl: Math.round(opp.basePnl * (.82 + pnlRand * .38) * quantityFactor * season.pnlFactor),
      capital: Math.round(opp.capital * quantityFactor * (.96 + capitalRand * .08)),
      equity: Math.round(opp.equity * quantityFactor * (.96 + capitalRand * .08)),
      duration: Math.max(12, opp.duration + Math.round((durationRand - .5) * 8)),
      expiresIn: Math.max(0, 7 - (state.marketCycleDay || 0)),
      cycle
    };
  }
  function negotiationFor(oppId) {
    const stored = state.negotiations?.[oppId];
    if (stored && stored.cycle === state.marketCycle) return stored;
    const transient = selectedNegotiationDrafts[oppId];
    if (transient && transient.cycle === state.marketCycle) return transient;
    const draft = { cycle: state.marketCycle, status: 'draft', commercial: 'market', payment: 'delivery', pricing: 'fixed', delivery: 'standard', incoterm: 'fob', attempts: 0 };
    selectedNegotiationDrafts[oppId] = draft;
    return draft;
  }
  function setNegotiationDraft(oppId, field, value) {
    const current = { ...negotiationFor(oppId), status: 'draft', [field]: value };
    selectedNegotiationDrafts[oppId] = current;
    state.negotiations[oppId] = current;
    saveState();
  }
  function negotiationAcceptance(opp, negotiation = negotiationFor(opp.id)) {
    const parties = partiesForOpportunity(opp);
    const buyer = getCounterparty(parties.buyerId);
    const relationship = getCounterpartyState(parties.buyerId).relationship;
    const commercial = negotiationProfiles.commercial[negotiation.commercial];
    const payment = negotiationProfiles.payment[negotiation.payment];
    const pricing = negotiationProfiles.pricing[negotiation.pricing || 'fixed'];
    const delivery = negotiationProfiles.delivery[negotiation.delivery];
    const incoterm = negotiationProfiles.incoterm[negotiation.incoterm || 'fob'] || negotiationProfiles.incoterm.fob;
    const financing = financingProfiles[financingSelection(opp)] || financingProfiles.revolver;
    const vertical = investmentAdjustments(opp);
    const shop = shopAdjustments(opp);
    const regime = currentMarketRegime();
    const season = seasonalDemand(opp);
    const doctrine = activeDoctrine();
    const capitalPolicy = activeCapitalPolicy();
    const procurement = procurementAgreementAdjustments(opp);
    const route = routeConditionFor(opp);
    const specialization = deskSpecializationAdjustments(opp);
    const franchise = marketReputationAdjustments(opp);
    const framework = commercialFrameworkAdjustments(opp);
    const hq = hqAdjustments();
    const office = officeNetworkAdjustments(opp);
    // Credit rating modifier: A=+3, BBB=0, BB=-4, B=-9
    const _ratingMod = { 'A': 3, 'BBB': 0, 'BB': -4, 'B': -9 };
    const _creditMod = _ratingMod[buyer?.creditRating] ?? 0;
    return clamp(54 + state.reputation * .18 + (relationship - 50) * .45 + (buyer?.credit || 70) * .08 + commercial.acceptance + payment.acceptance + pricing.acceptance + delivery.acceptance + incoterm.acceptance + (financing.acceptance || 0) + vertical.acceptanceBonus + shop.acceptanceBonus + difficultySettings().acceptance + regime.acceptance + season.acceptance + doctrine.acceptance + procurement.acceptance + specialization.acceptance + franchise.acceptance + framework.acceptance + hq.acceptance + office.acceptance - route.acceptancePenalty - competitionPenalty(opp) + _creditMod + crisisAdjustments(opp).acceptanceShock, 5, 97);
  }
  // ── v50 · impatto degli eventi proporzionale al cargo ───────────────────────
  // Gli eventi globali applicavano importi fissi (-5.000 … -45.000) a cargo con
  // margini da 38.000 a 520.000. Sul cargo iniziale un solo evento valeva fino al
  // 37% del margine: nella simulazione tre cargo su quattro chiudevano in perdita
  // pur essendo coperti al 100% e con esecuzione perfetta, e gli unici in utile
  // erano quelli che non avevano incontrato eventi. Ora l'importo del catalogo e'
  // riferito a un cargo di dimensione tipica (~150.000 di margine) e viene scalato.
  const EVENT_REFERENCE_MARGIN = 150_000;
  function scaleEventImpact(amount, opp) {
    if (!amount || !opp) return amount || 0;
    const margin = Math.abs(Number(opp.basePnl) || EVENT_REFERENCE_MARGIN);
    // fra 0,35x e 1,6x: i cargo piccoli restano colpiti, ma non annientati
    const factor = clamp(margin / EVENT_REFERENCE_MARGIN, 0.35, 1.6);
    return Math.round(amount * factor);
  }

  function crisisAdjustments(opp) {
    return activeCrisisDefinitions().filter(event => event.affects?.(opp)).reduce((acc, event) => {
      const response = crisisResponseAdjustments(event);
      acc.duration += Math.max(0, (event.dealDays || 0) - (response.durationReduction || 0));
      const rawPnl = scaleEventImpact(event.dealPnl || 0, opp);
      acc.pnl += rawPnl < 0 ? Math.round(rawPnl * (response.lossFactor || 1)) : rawPnl;
      acc.pnlFactor *= event.pnlFactor || 1;
      acc.equityFactor *= (event.equityFactor || 1) * (response.equityFactor || 1);
      acc.financingRateShock += (event.financingRateShock || 0) + (response.financingRateShock || 0);
      acc.acceptanceShock += (event.acceptanceShock || 0) + (response.acceptance || 0);
      acc.labels.push(response.id ? `${event.title} · ${response.name}` : event.title);
      return acc;
    }, { duration: 0, pnl: 0, pnlFactor: 1, equityFactor: 1, financingRateShock: 0, acceptanceShock: 0, labels: [] });
  }
  function opportunityEconomics(opp, negotiation = negotiationFor(opp.id)) {
    const offer = liveOffer(opp);
    const commercial = negotiationProfiles.commercial[negotiation.commercial] || negotiationProfiles.commercial.market;
    const payment = negotiationProfiles.payment[negotiation.payment] || negotiationProfiles.payment.delivery;
    const pricing = negotiationProfiles.pricing[negotiation.pricing || 'fixed'] || negotiationProfiles.pricing.fixed;
    const delivery = negotiationProfiles.delivery[negotiation.delivery] || negotiationProfiles.delivery.standard;
    const incoterm = negotiationProfiles.incoterm[negotiation.incoterm || 'fob'] || negotiationProfiles.incoterm.fob;
    const office = opportunityOfficeAdjustments(opp);
    const crisis = crisisAdjustments(opp);
    const vertical = investmentAdjustments(opp);
    const shop = shopAdjustments(opp);
    const structure = structureForOpportunity(opp);
    const regime = currentMarketRegime();
    const doctrine = activeDoctrine();
    const capitalPolicy = activeCapitalPolicy();
    const procurement = procurementAgreementAdjustments(opp);
    const route = routeConditionFor(opp);
    const specialization = deskSpecializationAdjustments(opp);
    const franchise = marketReputationAdjustments(opp);
    const framework = commercialFrameworkAdjustments(opp);
    const hq = hqAdjustments();
    const tender = rivalTenderFor(opp.id);
    // v50 - il costo della competizione era 240 $ per punto di pressione, uguale
    // per un cargo da 38k di margine e per uno da 520k: sul cargo iniziale valeva
    // il 24% del margine, su quelli grandi l'1%. Ora e' una quota del margine.
    // Il coefficiente e' tarato perche' un cargo da ~150k di margine paghi
    // esattamente quanto prima; cambia solo la distorsione agli estremi.
    const competitionPressure = Math.max(0, (tender?.pressure || 0) - 45);
    const competitionCost = Math.round(offer.basePnl * clamp(competitionPressure * 0.0016, 0, 0.10) * procurement.competitionFactor);
    const financeStaffFactor = hasStaff('trade-finance-manager') ? .9 : 1;
    const equity = Math.min(offer.capital, Math.round(offer.equity * payment.equityFactor * incoterm.equityFactor * financeStaffFactor * crisis.equityFactor * structure.financing.equityFactor * vertical.equityFactor * shop.equityFactor * regime.equityFactor * doctrine.equityFactor * procurement.equityFactor * capitalPolicy.equityFactor * specialization.equityFactor * franchise.equityFactor * framework.equityFactor * hq.equityFactor * office.equityFactor));
    const borrowed = Math.max(0, offer.capital - equity);
    const _carrierStrat = selectedCarrierStrategies[opp.id] || 'spot';
    const _vc = _carrierStrat === 'spot' ? vesselClassFor(opp.id) : vesselClasses.supramax;
    const vesselPnlBonus = Math.round(offer.basePnl * (_vc.pnlMod || 0));
    const basePnl = Math.round(offer.basePnl * regime.pnlFactor * doctrine.pnlFactor * capitalPolicy.pnlFactor * crisis.pnlFactor * specialization.pnlFactor) + commercial.pnl + pricing.pnl + delivery.pnl + incoterm.pnl + office.pnlBonus + crisis.pnl + structure.financing.pnl + structure.insurance.pnl + structure.inspection.pnl + vertical.pnlBonus + shop.pnlBonus + procurement.pnlBonus + franchise.pnlBonus + framework.pnlBonus + hq.pnlBonus - competitionCost - route.freightCost + vesselPnlBonus;
    const financingRate = Math.max(.018, structure.financing.rate * capitalPolicy.financingRateFactor + crisis.financingRateShock - office.financingRateReduction);
    const estimatedInterest = borrowed * financingRate * Math.max(10, offer.duration + delivery.duration + incoterm.duration - office.durationBonus - vertical.durationBonus - shop.durationBonus + crisis.duration + regime.duration) / 360;
    const expectedPnl = basePnl - estimatedInterest;
    return {
      ...offer,
      quantity: offer.quantity,
      capital: offer.capital,
      equity,
      borrowed,
      basePnl,
      estimatedInterest,
      financingRate,
      expectedPnl,
      duration: Math.max(10, offer.duration + delivery.duration + incoterm.duration - office.durationBonus - vertical.durationBonus - shop.durationBonus - framework.durationBonus - hq.durationBonus + crisis.duration + regime.duration + route.delayDays - procurement.durationBonus + (_vc.durationMod || 0)),
      acceptance: negotiationAcceptance(opp, negotiation),
      crisisLabels: crisis.labels,
      marketRegime: regime,
      tenderPressure: tender?.pressure || 0,
      tenderLeader: rivalForTender(tender),
      competitionCost,
      routeCondition: route,
      procurementAgreement: procurement.agreement,
      procurementBonus: procurement.pnlBonus,
      procurementSavings: procurement.pnlBonus + Math.round(route.freightCost * .15),
      commercialFramework: framework.framework,
      deskSpecialization: specialization.specialization,
      marketReputationScore: franchise.score,
      hqTier: hq.tier,
      verticalSources: vertical.sources,
      shopSources: shop.sources,
      structure,
      initialMargin: initialMarginFor(opp, Number(selectedHedgeRatios[opp.id] ?? opp.recommendedHedge ?? 100), offer.quantity, offer.capital),
      pricingProfile: pricing,
      terms: { commercial: negotiation.commercial, payment: negotiation.payment, pricing: negotiation.pricing || 'fixed', delivery: negotiation.delivery, incoterm: negotiation.incoterm || 'fob' }
    };
  }
  function effectiveEquity(opp) { return opportunityEconomics(opp).equity; }
  function effectiveBorrowed(opp) { return opportunityEconomics(opp).borrowed; }
  function charterHireCost(vessel) {
    let factor = hasStaff('freight-charterer') ? .85 : 1;
    if (officeOwned('rotterdam')) factor *= .95;
    return Math.round(vessel.charterCost * factor);
  }
  function opportunityOfficeAdjustments(opp) {
    return officeNetworkAdjustments(opp);
  }
  function officeAvailabilitySnapshot() {
    const available=officeCatalog.filter(office=>office.id!=='geneva' && !officeOwned(office.id) && !activeOfficeProject(office.id) && officeUnlocked(office));
    const affordable=available.filter(office=>state.cash>=office.cost);
    const projects=state.officeProjects||[];
    return { available, affordable, projects };
  }
  function renderOfficeRailStatus() {
    const badge=$('#officeBadge');
    const button=$('#openOfficesButton');
    if(!badge||!button) return;
    if(!moduleUnlocked('expansion')){ badge.classList.add('hidden'); return; }
    const snapshot=officeAvailabilitySnapshot();
    const count=snapshot.projects.length || snapshot.affordable.length || snapshot.available.length;
    badge.textContent=String(count);
    badge.classList.toggle('hidden',count===0);
    badge.classList.toggle('building',snapshot.projects.length>0);
    button.title=snapshot.projects.length
      ? `${snapshot.projects.length} international office project${snapshot.projects.length===1?'':'s'} underway · O`
      : snapshot.affordable.length
        ? `${snapshot.affordable.length} office${snapshot.affordable.length===1?'':'s'} ready to open · O`
        : 'Global Office Network · O';
  }
  function openOfficeNetwork() {
    openLeftDrawer('expansion');
    setTimeout(()=>{
      const target=$('#globalOfficeSummary');
      target?.scrollIntoView({behavior:motionEnabled()?'smooth':'auto',block:'start'});
    },60);
  }
  function openOffice(id) {
    const office = getOffice(id);
    if (!office || officeOwned(id) || activeOfficeProject(id)) return;
    if (!officeUnlocked(office)) return showToast(`Office locked: ${officeLockReason(office)} required.`);
    if (activeProjectCount() >= builderSlots()) return showToast('All project teams are busy. Complete a construction project first.');
    if (state.cash < office.cost) return showToast(`Opening ${office.name} requires ${money(office.cost)} cash.`);
    state.cash -= office.cost;
    state.officeSpend = (state.officeSpend || 0) + office.cost;
    state.officeProjects = state.officeProjects || [];
    state.officeProjects.push({ id:`office-project-${state.sequence++}`, officeId:id, daysRemaining:office.buildDays, totalDays:office.buildDays, cost:office.cost, startedAt:state.date });
    recordJournal('Expansion', `${office.name} approved`, `${office.buildDays}-day international office project started in ${office.country}.`, -office.cost, id);
    activeLeftTab='expansion';
    saveState(); renderAll(); focusOnHub(office.hub);
    showToast(`${office.name} project started. Opening in ${office.buildDays} days.`);
  }
  function completeOfficeProject(project) {
    const office=getOffice(project.officeId); if(!office || officeOwned(office.id)) return;
    state.offices.push(office.id);
    state.offices=[...new Set(state.offices)];
    state.creditLimit += office.creditBonus || 0;
    state.reputation=clamp(state.reputation+2,0,100);
    state.officeOpenings=(state.officeOpenings||0)+1;
    state.worldEventFeed.unshift({type:'expansion',title:`${office.name} opened`,date:state.date,description:`The ${office.city} team is operational. Local market, execution and financing benefits are now active.`});
    state.worldEventFeed=state.worldEventFeed.slice(0,18);
    recordJournal('Expansion', `${office.name} opened`, `${office.country} joined the permanent World of Trade office network.`, 0, office.id);
    addXp(70,'global office');
    evaluateMissions();
  }
  function processOfficeProjectsDay() {
    (state.officeProjects||[]).forEach(project=>{ project.daysRemaining=Math.max(0,(project.daysRemaining||0)-1); });
    const completed=(state.officeProjects||[]).filter(project=>project.daysRemaining<=0);
    completed.forEach(completeOfficeProject);
    state.officeProjects=(state.officeProjects||[]).filter(project=>project.daysRemaining>0);
  }
  function hireStaff(id) {
    const member = getStaff(id);
    if (!member || hasStaff(id)) return;
    if (!staffUnlocked(member)) return showToast(`You need reputation ${member.minReputation} to hire this specialist.`);
    if (state.cash < member.hireCost) return showToast('Insufficient liquidity to hire this specialist.');
    state.cash -= member.hireCost;
    state.staff.push(id);
    if (id === 'trade-finance-manager') state.creditLimit += 1_000_000;
    state.reputation = clamp(state.reputation + 1, 0, 100);
    evaluateMissions();
    saveState(); renderAll();
    showToast(`${member.role} joined the WoT team.`);
  }
  function evaluateMissions() {
    const unlocked = [];
    missionCatalog.forEach(mission => {
      if (state.completedMissions.includes(mission.id) || !mission.achieved(state)) return;
      state.completedMissions.push(mission.id);
      state.cash += mission.cash || 0;
      state.creditLimit += mission.credit || 0;
      state.reputation = clamp(state.reputation + (mission.reputation || 0), 0, 100);
      unlocked.push(mission.title);
    });
    if (unlocked.length) { setTimeout(() => showToast(`Mission completed: ${unlocked.join(', ')}.`), 80); try { Sound.play('achievement'); } catch (e) {} addXp(50 * unlocked.length, 'mission'); }
  }

  let _lastBackupAt = 0;
  let _saveScheduled = false;

  // v45 — il salvataggio principale viene sempre tentato per primo; il backup
  // e' a rotazione (max 1 ogni 5 minuti) invece che a ogni tick di gioco.
  function saveState(force = false) {
    if (state.__loadFailed) { markSaveStatus('Save paused'); return; }
    if (state.autosave === false && !force) {
      markSaveStatus('Autosave off');
      return;
    }
    const key = currentStorageKey();
    try {
      markSaveStatus('Saving…', true);
      state.lastSavedAt = new Date().toISOString();
      const serialized = JSON.stringify(state);
      localStorage.setItem(key, serialized);
      const now = Date.now();
      if (now - _lastBackupAt > 300_000) {
        try { localStorage.setItem(`${key}-backup`, serialized); _lastBackupAt = now; } catch (e) {}
      }
      markSaveStatus('Saved');
    } catch (error) {
      handleSaveFailure(error, key);
    }
  }

  function handleSaveFailure(error, key) {
    const quotaExceeded = Boolean(error) && (error.name === 'QuotaExceededError'
      || error.name === 'NS_ERROR_DOM_QUOTA_REACHED' || error.code === 22);
    console.error('[WoT] salvataggio non riuscito', error);
    if (quotaExceeded) {
      // 1. libera lo spazio sacrificabile
      try { localStorage.removeItem(`${key}-backup`); } catch (e) {}
      try { [storageKey, ...legacyStorageKeys].forEach(legacyKey => localStorage.removeItem(legacyKey)); } catch (e) {}
      try { localStorage.setItem(key, JSON.stringify(state)); return markSaveStatus('Saved'); } catch (e) {}
      // 2. pota lo storico e riprova
      state.history = (state.history || []).slice(0, 20);
      state.tradeJournal = (state.tradeJournal || []).slice(0, 20);
      state.worldEventFeed = (state.worldEventFeed || []).slice(0, 8);
      state.priceHistory = {};
      try { localStorage.setItem(key, JSON.stringify(state)); return markSaveStatus('Saved (trimmed)'); } catch (e) {}
      showToast('Storage full — the save could not be written. Export your career from the profile panel.', 'error');
    }
    markSaveStatus('Save failed');
  }

  // v45 — a velocita' 5x advanceDay girava ogni 430 ms: il salvataggio ora e' con debounce
  function scheduleSave() {
    if (_saveScheduled) return;
    _saveScheduled = true;
    setTimeout(() => { _saveScheduled = false; saveState(); }, 1200);
  }

  // v45 — rispetta la scelta "autosave off" invece di forzare sempre la scrittura
  window.__WOT_NATIVE_SAVE__ = () => saveState(state.autosave !== false);

  // v45 — il carico distressed vive solo nello state e i deal chiusi possono riferirsi
  // a un catalogo cambiato: entrambi i casi vanno risolti, altrimenti ogni render crasha.
  function getOpportunity(id) {
    if (!id) return undefined;
    const catalogued = opportunities.find(o => o.id === id);
    if (catalogued) return catalogued;
    if (state?.distressedOpportunity?.id === id) return state.distressedOpportunity;
    const live = (state?.activeDeals || []).find(d => d.opportunityId === id && d.opportunitySnapshot);
    if (live) return live.opportunitySnapshot;
    const past = (state?.history || []).find(h => h.opportunityId === id && h.opportunitySnapshot);
    return past ? past.opportunitySnapshot : undefined;
  }
  // Risolutore usato in fase di caricamento, quando `state` non e' ancora assegnato
  function resolveOpportunityFor(deal) {
    if (!deal) return undefined;
    if (deal.opportunitySnapshot) return deal.opportunitySnapshot;
    return opportunities.find(o => o.id === deal.opportunityId);
  }
  function getHub(id) { return hubs.find(h => h.id === id); }
  function getActiveDeal(id) { return state.activeDeals.find(d => d.id === id); }
  function getHistoryDeal(id) { return state.history.find(d => d.id === id); }
  function getSelectedDeal() { return selected.type === 'deal' ? getActiveDeal(selected.id) : null; }
  function getVesselCatalog(id) { return vesselCatalog.find(v => v.id === id); }
  function getFleetAsset(id) { return state.fleetAssets.find(v => v.id === id); }
  function transportClassForOpportunity(opp) {
    const mode = String(opp.transportMode || '').toLowerCase();
    if (mode.includes('ocean') || mode.includes('coaster') || mode.includes('vessel') || mode.includes('ship') || mode.includes('tanker') || mode.includes('carrier') || mode.includes('container') || mode.includes('bulk')) return 'ocean';
    if (mode.includes('barge')) return 'barge';
    return 'land';
  }
  function fleetAssetAvailableFor(asset, opp) {
    const catalog = getVesselCatalog(asset.catalogId);
    return Boolean(catalog && asset.status === 'available' && asset.positionHub === opp.origin && catalog.transportClass === transportClassForOpportunity(opp));
  }
  function availableFleetForOpportunity(opp) { return state.fleetAssets.filter(asset => fleetAssetAvailableFor(asset, opp)); }
  function vesselUnlocked(vessel) { return state.reputation >= vessel.minReputation && state.completedDeals >= vessel.minDeals && (!vessel.requiresOffice || officeOwned(vessel.requiresOffice)); }


  function makeDealOperations(opp, dealId, fleetAsset = null) {
    const asset = logisticsAssets[opp.id] || {
      carrier: 'Northstar Contract Carrier', mode: opp.transportMode, booking: 'Confirmed',
      warehouse: `${getHub(opp.destination).name} Transit Depot`, warehouseHub: opp.destination, storageDays: 2,
      purchaseTerms: 'Indexed purchase contract', salesTerms: 'Indexed sales contract',
      documentSet: ['Commercial invoice', 'Packing list', 'Quality certificate', 'Transport document', 'Insurance certificate', 'Customs release']
    };
    const fleetVessel = fleetAsset ? getVesselCatalog(fleetAsset.catalogId) : null;
    const demurrageRate = transportClassForOpportunity(opp) === 'ocean' ? 9_500 : transportClassForOpportunity(opp) === 'barge' ? 3_800 : 1_800;
    return {
      contractId: `SHP-${String(dealId).slice(-6).toUpperCase()}`,
      purchaseContract: { status: 'Signed', terms: asset.purchaseTerms },
      salesContract: { status: 'Signed', terms: asset.salesTerms },
      transport: {
        carrier: fleetVessel?.name || asset.carrier,
        mode: fleetVessel ? `${fleetVessel.vesselClass} · internal charter` : asset.mode,
        booking: fleetVessel ? 'Fleet allocated' : asset.booking,
        status: 'Booked', upgraded: false,
        charterType: fleetVessel ? 'Time-charter allocation' : 'Spot / voyage booking',
        fleetAssetId: fleetAsset?.id || null,
        laycan: `D+3 / D+7`, laytimeAllowed: transportClassForOpportunity(opp) === 'land' ? 1 : 2,
        laytimeUsed: 0, demurrageRate: fleetVessel ? Math.round(demurrageRate * .8) : demurrageRate,
        demurrageAccrued: 0, freightIndexAtBooking: state.freightIndex
      },
      storage: { name: asset.warehouse, hubId: asset.warehouseHub, reserved: true, active: false, days: asset.storageDays, emergency: false },
      documents: asset.documentSet.map((name, index) => ({ name, status: index === 5 ? 'ready' : 'pending' })),
      expedited: false
    };
  }

  function hydrateDealOperations(deal) {
    const opp = getOpportunity(deal.opportunityId);
    if (!opp) return deal;
    const parties = partiesForOpportunity(opp);
    deal.quantity = deal.quantity || opp.quantity;
    deal.capital = deal.capital || opp.capital;
    deal.supplierId = deal.supplierId || parties.supplierId;
    deal.buyerId = deal.buyerId || parties.buyerId;
    deal.globalEventImpacts = deal.globalEventImpacts || [];
    deal.delivered = Boolean(deal.delivered);
    deal.paymentDaysRemaining = Number.isFinite(deal.paymentDaysRemaining) ? deal.paymentDaysRemaining : null;
    deal.collectionDelayDays = Number.isFinite(deal.collectionDelayDays) ? deal.collectionDelayDays : 0;
    deal.overdueRecorded = Boolean(deal.overdueRecorded);
    deal.invoiceStatus = deal.invoiceStatus || (deal.delivered ? 'Outstanding' : 'Not issued');
    deal.contractLifecycle = deal.contractLifecycle || { nominated: true, loaded: (deal.elapsed || 0) > Math.max(2, (deal.duration || 20) * .18), delivered: Boolean(deal.delivered), invoiced: Boolean(deal.delivered), paid: false };
    if (!deal.operations) return { ...deal, operations: makeDealOperations(opp, deal.id || `legacy-${Date.now()}`) };
    const transport = deal.operations.transport || {};
    deal.operations.transport = {
      charterType: 'Spot / voyage booking', fleetAssetId: deal.fleetAssetId || null,
      laycan: 'D+3 / D+7', laytimeAllowed: transportClassForOpportunity(opp) === 'land' ? 1 : 2,
      laytimeUsed: 0, demurrageRate: transportClassForOpportunity(opp) === 'ocean' ? 9_500 : 2_500,
      demurrageAccrued: 0, freightIndexAtBooking: 100,
      ...transport
    };
    return deal;
  }

  function updateDealOperations(deal) {
    deal = hydrateDealOperations(deal);
    const p = computeDealProgress(deal);
    const ops = deal.operations;
    if (deal.delivered) {
      ops.transport.status = 'Delivered';
      ops.storage.active = false;
      ops.purchaseContract.status = 'Completed';
      ops.salesContract.status = deal.invoiceStatus === 'Paid' ? 'Settled' : 'Invoiced';
      ops.documents.forEach(doc => { if (doc.status !== 'blocked') doc.status = 'ready'; });
      return deal;
    }
    ops.transport.status = p < .12 ? 'Booked' : p < .2 ? 'Loading' : p < .78 ? 'In transit' : p < .93 ? 'At terminal' : 'Final delivery';
    ops.storage.active = p >= .78 && p < .93;
    const readyThresholds = [.08, .1, .2, .24, .28, .04, .79, .22];
    ops.documents.forEach((doc, i) => {
      if (doc.status === 'blocked') return;
      if (p >= (readyThresholds[i] ?? .25)) doc.status = 'ready';
      else if (doc.status !== 'ready') doc.status = 'pending';
    });
    const opp = getOpportunity(deal.opportunityId);
    if (opp.id === 'baltic-copper' && deal.pendingDecision) {
      const quality = ops.documents.find(d => d.name === 'Quality certificate');
      if (quality) quality.status = 'blocked';
    }
    if ((opp.id === 'meridian-copper' || opp.id === 'asia-aluminium') && deal.pendingDecision) {
      const lc = ops.documents.find(d => d.name === 'LC compliance');
      if (lc) lc.status = 'blocked';
    }
    return deal;
  }

  function operationsReadiness(deal) {
    updateDealOperations(deal);
    const docs = deal.operations.documents;
    const ready = docs.filter(d => d.status === 'ready').length;
    const docScore = docs.length ? ready / docs.length : 1;
    const purchaseComplete = ['Signed', 'Completed'].includes(deal.operations.purchaseContract.status);
    const salesComplete = ['Signed', 'Invoiced', 'Settled'].includes(deal.operations.salesContract.status);
    const contractScore = purchaseComplete && salesComplete ? 1 : .5;
    const transportScore = deal.operations.transport.status === 'Booked' ? .7 : 1;
    const inspectionBonus = inspectionProfiles[deal.inspectionStrategy || 'standard']?.readiness || 0;
    return clamp((docScore * .58 + contractScore * .22 + transportScore * .2) * 100 + (hasStaff('operations-coordinator') ? 5 : 0) + inspectionBonus, 0, 100);
  }

  function expediteDocuments(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.operations?.expedited) return;
    const cost = hasStaff('operations-coordinator') ? 2_700 : 4_500;
    deal.pnlAdjustments -= cost;
    deal.operations.expedited = true;
    deal.operations.documents.forEach(doc => { if (doc.status !== 'blocked') doc.status = 'ready'; });
    saveState();
    renderAll();
    showToast(`Documents expedited. Operating cost ${money(cost)}.`);
  }

  function upgradeTransport(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.operations?.transport?.upgraded || computeDealProgress(deal) > .7) return;
    const cost = 14_000;
    deal.pnlAdjustments -= cost;
    deal.duration = Math.max(deal.elapsed + 2, deal.duration - 4);
    deal.operations.transport.upgraded = true;
    deal.operations.transport.booking = 'Priority confirmed';
    saveState();
    renderAll();
    showToast(`Priority transport confirmed. ETA reduced by 4 days.`);
  }

  function bookEmergencyStorage(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.operations?.storage?.emergency) return;
    const discount=storageDiscountForHub(deal.operations?.storage?.hubId);
    const cost = Math.round(8_000*(1-discount));
    deal.pnlAdjustments -= cost;
    deal.operations.storage.emergency = true;
    deal.operations.storage.reserved = true;
    deal.operations.storage.days += 5;
    saveState();
    renderAll();
    showToast(`Emergency storage booked for ${money(cost)}.`);
  }


  function charterVessel(catalogId) {
    const vessel = getVesselCatalog(catalogId);
    if (!vessel || !vesselUnlocked(vessel)) return showToast('This asset is not yet available to your desk.');
    if (state.fleetAssets.some(asset => asset.catalogId === catalogId)) return showToast('You already have this asset on charter.');
    const hireCost = charterHireCost(vessel);
    if (state.cash < hireCost) return showToast('Insufficient liquidity for the charter.');
    const asset = {
      id: `vessel-${catalogId}-${state.sequence++}`, catalogId, name: vessel.name,
      status: 'available', assignedDealId: null, positionHub: vessel.homeHub,
      daysRemaining: vessel.charterDays, charterDays: vessel.charterDays, charterCost: hireCost,
      acquired: state.date
    };
    state.cash -= hireCost;
    state.fleetAssets.push(asset);
    saveState();
    activeLeftTab = 'fleet';
    selectVessel(asset.id);
    renderAll();
    showToast(`${vessel.name} noleggiata per ${vessel.charterDays} days.`);
  }

  function releaseVessel(assetId) {
    const asset = getFleetAsset(assetId);
    if (!asset || asset.status === 'assigned') return showToast('You cannot release a vessel while it is assigned to a deal.');
    if (asset.ownership === 'owned') {
      const refund = Math.round((asset.purchaseCost || 0) * .45);
      state.cash += refund;
      state.fleetAssets = state.fleetAssets.filter(v => v.id !== assetId);
      const shopItem=shopCatalog.find(item=>item.vesselCatalogId===asset.catalogId && item.category==='fleet');
      if (shopItem) { const record=shopAssetRecord(shopItem.id); state.shopAssets[shopItem.id]={...record,quantity:Math.max(0,(record.quantity||0)-1),totalSpent:Math.max(0,(record.totalSpent||0)-(asset.purchaseCost||0))}; }
      selected={type:'hub',id:'geneva'}; saveState(); renderAll();
      return showToast(`Vessel sold. ${money(refund)} recovered.`);
    }
    const refund = Math.round(asset.charterCost * (asset.daysRemaining / asset.charterDays) * .2);
    state.cash += refund;
    state.fleetAssets = state.fleetAssets.filter(v => v.id !== assetId);
    selected = { type: 'hub', id: 'geneva' };
    saveState();
    renderAll();
    showToast(`Charter terminated. ${money(refund)} recovered.`);
  }

  function advanceFleetDay() {
    const expired = [];
    state.fleetAssets.forEach(asset => {
      if (asset.ownership === 'owned') return;
      asset.daysRemaining = Math.max(0, asset.daysRemaining - 1);
      if (asset.daysRemaining === 0 && asset.status === 'assigned') {
        const vessel = getVesselCatalog(asset.catalogId);
        const deal = getActiveDeal(asset.assignedDealId);
        const extensionCost = Math.round((vessel.charterCost / vessel.charterDays) * 1.35);
        if (deal) deal.pnlAdjustments -= extensionCost;
        asset.extensionCost = (asset.extensionCost || 0) + extensionCost;
      }
      if (asset.daysRemaining === 0 && asset.status !== 'assigned') expired.push(asset.id);
    });
    if (expired.length) state.fleetAssets = state.fleetAssets.filter(asset => !expired.includes(asset.id));
  }

  function accrueDailyShippingCosts(deal) {
    if (deal.delivered) return;
    updateDealOperations(deal);
    const shipping = deal.operations.transport;
    if (!deal.operations.storage.active) return;
    shipping.laytimeUsed += 1;
    if (shipping.laytimeUsed > shipping.laytimeAllowed) {
      shipping.demurrageAccrued += shipping.demurrageRate;
      deal.pnlAdjustments -= shipping.demurrageRate;
    }
  }

  function currentDate() { return new Date(state.date); }

  function deterministicRandom(seedText) {
    let hash = 2166136261;
    for (let i = 0; i < seedText.length; i++) {
      hash ^= seedText.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return ((hash >>> 0) % 10000) / 10000;
  }

  function refreshOpportunityMarket() {
    state.marketCycle = (state.marketCycle || 1) + 1;
    state.marketCycleDay = 0;
    state.negotiations = {};
    state.marketRegime = generateMarketRegime(state.marketCycle);
    opportunities.forEach(opp => { selectedNegotiationDrafts[opp.id] = null; });
    initializeCompetitiveMarket(true);
    refreshRouteConditions();
    state.worldEventFeed.unshift({
      type: 'market', title: 'Opportunity book refreshed', date: state.date,
      description: `New quantities, margins and delivery windows are available under a ${currentMarketRegime().label.toLowerCase()} regime.`
    });
    state.worldEventFeed = state.worldEventFeed.slice(0, 14);
    showToast('The opportunity market has been refreshed.');
  }

  function triggerGlobalEvent() {
    const activeIds = new Set((state.activeGlobalEvents || []).map(event => event.id));
    const accessibleOpps = opportunities.filter(isOpportunityUnlocked);
    const available = globalEventCatalog.filter(event => !activeIds.has(event.id)).filter(event => {
      if (typeof event.affects !== 'function') return true;
      return accessibleOpps.some(opp => { try { return event.affects(opp); } catch (e) { return false; } });
    });
    if (!available.length) return;
    const pick = Math.floor(deterministicRandom(`${state.date}-world-${state.marketCycle}`) * available.length);
    const definition = available[pick];
    const active = { id: definition.id, started: state.date, remaining: definition.duration, category: definition.category || 'Market / Logistics' };
    state.activeGlobalEvents.push(active);
    state.worldEventFeed.unshift({
      type: 'crisis', id: definition.id, title: definition.title, date: state.date,
      severity: definition.severity, description: definition.description
    });
    state.worldEventFeed = state.worldEventFeed.slice(0, 14);
    if (definition.freightShock) state.freightIndex = clamp(state.freightIndex + definition.freightShock, 76, 175);
    let eventImpact = 0;
    if (definition.firmPnl) {
      const sizeFactor = clamp(.35 + playerLevel() / 30, .4, 1.15);
      const directImpact = Math.round(definition.firmPnl * sizeFactor);
      state.cash += directImpact;
      state.realizedPnl += directImpact;
      eventImpact += directImpact;
    }
    refreshRouteConditions();
    let affectedCargoes = 0;
    state.activeDeals.forEach(deal => {
      const opp = getOpportunity(deal.opportunityId);
      if (!definition.affects?.(opp)) return;
      deal.globalEventImpacts = deal.globalEventImpacts || [];
      if (deal.globalEventImpacts.includes(definition.id)) return;
      deal.globalEventImpacts.push(definition.id);
      deal.duration += definition.dealDays || 0;
      const scaledImpact = scaleEventImpact(definition.dealPnl || 0, opp);
      deal.pnlAdjustments += scaledImpact;
      eventImpact += scaledImpact;
      affectedCargoes += 1;
      deal.eventResult = `${definition.title}: impact incorporated into route timing and P&L.`;
    });
    state.riskPnlImpact = (state.riskPnlImpact || 0) + eventImpact;
    state.riskLedger = state.riskLedger || [];
    state.riskLedger.unshift({ id:definition.id, date:state.date, category:definition.category || 'Market / Logistics', title:definition.title, severity:definition.severity || 'medium', impact:eventImpact, affectedCargoes, description:definition.description });
    state.riskLedger = state.riskLedger.slice(0,40);
    recordJournal('Risk', definition.title, `${definition.category || 'Market / Logistics'} · ${affectedCargoes} live cargo${affectedCargoes===1?'':'es'} affected.`, eventImpact, definition.id);
    showToast(`Global risk: ${definition.title} · ${eventImpact ? money(eventImpact) : 'market exposure'}`);
  }

  function advanceWorldState() {
    state.dayIndex = (state.dayIndex || 0) + 1;
    state.marketCycleDay = (state.marketCycleDay || 0) + 1;
    const expired = [];
    state.activeGlobalEvents.forEach(event => {
      event.remaining = Math.max(0, event.remaining - 1);
      if (event.remaining === 0) expired.push(event.id);
    });
    if (expired.length) {
      expired.forEach(id => {
        const definition = globalEventCatalog.find(event => event.id === id);
        if (definition?.freightShock) state.freightIndex = clamp(state.freightIndex - definition.freightShock * .75, 76, 175);
        state.worldEventFeed.unshift({ type: 'resolved', id, title: `${definition?.title || id} resolved`, date: state.date, description: 'Operating conditions are gradually returning to normal and temporary freight premia are unwinding.' });
      });
      state.activeGlobalEvents = state.activeGlobalEvents.filter(event => !expired.includes(event.id));
      expired.forEach(id => { if (state.crisisResponses?.[id]) state.crisisResponses[id].status = 'expired'; });
      refreshRouteConditions();
    }
    if (state.marketCycleDay >= 7) refreshOpportunityMarket();
    else advanceRivalMarketDay();
    // Rival deal activity — inject a competitor deal closing every 4-6 days
    if ((state.dayIndex||0) > 0 && (state.dayIndex||0) % 5 === 0) {
      const rivalList = [
        {name:'Helios Commodities',city:'Zurich',trades:[['copper','Tallinn','Brescia'],['aluminium','Rotterdam','Brescia'],['diesel','Houston','Rotterdam']]},
        {name:'NorthSea Trading',city:'Rotterdam',trades:[['aluminium','Rotterdam','Brescia'],['iron ore','Port Hedland','Shanghai'],['diesel','Houston','Rotterdam']]},
        {name:'Pacific Bulk Partners',city:'Singapore',trades:[['iron ore','Port Hedland','Shanghai'],['wheat','Rosario','Genoa'],['coffee','Santos','Genoa']]},
        {name:'Atlas Merchant Group',city:'London',trades:[['copper','Santiago','Brescia'],['urea','Casablanca','Genoa'],['wheat','Rosario','Genoa']]},
        {name:'Stratus Energy',city:'Houston',trades:[['diesel','Houston','Rotterdam'],['LNG','Doha','Rotterdam'],['crude','Houston','Rotterdam']]},
        {name:'Orion Agri Trade',city:'Geneva',trades:[['coffee','Santos','Brescia'],['wheat','Rosario','Genoa'],['palm oil','Port Klang','Genoa']]},
        {name:'Rhine Metals Desk',city:'Geneva',trades:[['copper','Tallinn','Brescia'],['aluminium','Rotterdam','Brescia'],['copper','Dubai','Singapore']]}
      ];
      const seed2 = deterministicRandom(state.date + '-rival-pick');
      const rival = rivalList[Math.floor(seed2 * rivalList.length)];
      const tradeSeed = deterministicRandom(state.date + '-rival-trade');
      const trade = rival.trades[Math.floor(tradeSeed * rival.trades.length)];
      const marginSeed = deterministicRandom(state.date + '-rival-margin');
      const marginPct = (2.8 + marginSeed * 4.2).toFixed(1);
      state.worldEventFeed.unshift({
        type: 'market',
        title: `${rival.name} closes ${trade[0]} cargo`,
        date: state.date,
        description: `${rival.city}-based desk settled a ${trade[0]} shipment from ${trade[1]} to ${trade[2]} with a ${marginPct}% margin. Competitive pressure in this corridor remains active.`
      });
      state.worldEventFeed = state.worldEventFeed.slice(0, 18);
    }

    if (state.dayIndex >= (state.nextGlobalEventDay || 6)) {
      triggerGlobalEvent();
      // v53 - da 8-14 a 14-24 giorni: un voyage da 35 giorni ne incontra uno o due
      // invece di due o tre, e il margine del cargo torna difendibile.
      state.nextGlobalEventDay = state.dayIndex + 14 + Math.floor(deterministicRandom(`${state.date}-next-world`) * 11);
    }
    // Counterparty relationship decay every 21 days without active deal
    if ((state.dayIndex || 0) % 21 === 0 && state.dayIndex > 0) {
      const activeCpIds = new Set();
      state.activeDeals.forEach(deal => {
        const opp = getOpportunity(deal.opportunityId);
        if (!opp) return;
        const parties = partiesForOpportunity(opp);
        if (parties.supplierId) activeCpIds.add(parties.supplierId);
        if (parties.buyerId) activeCpIds.add(parties.buyerId);
      });
      counterpartyCatalog.forEach(cp => {
        if (activeCpIds.has(cp.id)) return; // active deal — no decay
        const record = getCounterpartyState(cp.id);
        if ((record.relationship || 50) > 30) {
          record.relationship = (record.relationship || 50) - 1;
        }
      });
    }

    // ── Distressed cargo injection (every 7-11 days) ─────────────────────────
    if (!state.distressedCargoDay) state.distressedCargoDay = 7 + Math.floor(deterministicRandom(`${state.date}-dc-init`) * 5);
    if ((state.dayIndex || 0) >= state.distressedCargoDay) {
      state.distressedCargoDay = state.dayIndex + 7 + Math.floor(deterministicRandom(`${state.date}-dc-next`) * 5);
      const _dcPool = [
        { id:'dc-copper-scrap', origin:'antwerp',  destination:'shanghai', commodity:'Copper', priceKey:'copper', quantity:3000,  capital:2_800_000, equity:420_000, basePnl:210_000, duration:18, risk:'High', riskClass:'high', transportMode:'Handymax bulk', title:'Distressed copper parcel · ARA', description:'Seller facing liquidity squeeze. Vessel approaching laytime limits. Steep discount to clear cargo before demurrage escalates.', event:{id:'inspection-failure',title:'Disputed quality certificate',text:'Pre-shipment inspection flagged a moisture deviation. Resolve before discharge or renegotiate price adjustment.',choices:[{id:'accept',label:'Accept & adjust price',hint:'-$40k but deal closes cleanly'},{id:'dispute',label:'Dispute and hold',hint:'Risk 3-day delay and $25k demurrage'}]}, recommendedHedge:90 },
        { id:'dc-wheat-cargo', origin:'new-orleans', destination:'genova', commodity:'Wheat', priceKey:'wheat', quantity:25000, capital:5_200_000, equity:780_000, basePnl:290_000, duration:14, risk:'Medium', riskClass:'medium', transportMode:'Panamax bulk',  title:'Distressed wheat cargo · Gulf',  description:'US exporter offloading surplus position. Buyer in Egypt cancelled LC. Cargo available at significant discount to replacement cost.', recommendedHedge:80 },
        { id:'dc-crude-vlcc',  origin:'houston',   destination:'singapore', commodity:'Crude Oil', priceKey:'crude', quantity:280000, capital:22_000_000, equity:3_300_000, basePnl:480_000, duration:20, risk:'High', riskClass:'high', transportMode:'VLCC', title:'Distressed crude VLCC · Gulf',    description:'Trader unwinding long position. VLCC on demurrage at Galveston anchorage. Price reflects urgent disposal; cargo is clean WTI equivalent.', recommendedHedge:95 },
        { id:'dc-coffee-santos', origin:'santos',  destination:'antwerp', commodity:'Coffee', priceKey:'coffee', quantity:5000,  capital:19_000_000, equity:2_850_000, basePnl:520_000, duration:16, risk:'Medium', riskClass:'medium', transportMode:'Container ship', title:'Distressed coffee lot · Brazil', description:'Brazilian trader caught long after local currency move. Grade 2 arabica, discount to ICE benchmark. Deal must close this market cycle.', recommendedHedge:75 },
        { id:'dc-ironore-cape', origin:'port-hedland', destination:'shanghai', commodity:'Iron ore', priceKey:'ironore', quantity:80000, capital:8_000_000, equity:1_200_000, basePnl:350_000, duration:21, risk:'Medium', riskClass:'medium', transportMode:'Capesize bulk', title:'Distressed iron ore · Pilbara', description:'Mining co. needs to move spot cargo — port capacity allocation expires. 62% Fe fines at discount. Competitive bids expected.', recommendedHedge:85 },
      ];
      const eligibleDcPool = _dcPool.filter(dc => {
        const origin = getHub(dc.origin), destination = getHub(dc.destination);
        if (!origin || !destination) { console.warn('[WoT] distressed cargo scartato: hub inesistente', dc.id); return false; }
        const commodityName = dc.commodity === 'Crude Oil' ? 'Diesel' : dc.commodity;
        return commodityUnlocked(commodityName) && countryUnlocked(origin.country) && countryUnlocked(destination.country);
      });
      const dcSeed = deterministicRandom(`${state.date}-dc-pick`);
      const dc = eligibleDcPool.length ? eligibleDcPool[Math.floor(dcSeed * eligibleDcPool.length)] : null;
      if (dc) {
        // Mark as distressed and short-lived
        state.distressedOpportunity = { ...dc, distressed: true, distressedExpiry: state.dayIndex + 4 };
        state.worldEventFeed.unshift({
          type: 'distressed',
          title: `Distressed cargo available — ${dc.commodity}`,
          date: state.date,
          description: `${dc.title}: ${dc.description} Window: ~4 days. Margin: ${money(dc.basePnl)} (discounted).`
        });
        state.worldEventFeed = state.worldEventFeed.slice(0, 18);
      }
    }
    // Expire distressed opportunity
    if (state.distressedOpportunity && state.dayIndex > (state.distressedOpportunity.distressedExpiry || 0)) {
      state.worldEventFeed.unshift({ type: 'market', title: `Distressed ${state.distressedOpportunity.commodity} cargo window closed`, date: state.date, description: 'The distressed parcel was absorbed by another desk. Window expired.' });
      state.worldEventFeed = state.worldEventFeed.slice(0, 18);
      state.distressedOpportunity = null;
    }

    // ── Quarter-end evaluation (every 90 days) ─────────────────────────────
    if ((state.dayIndex || 0) > 0 && (state.dayIndex || 0) % 90 === 0) {
      const quarterPnl = state.realizedPnl - (state.quarterStartPnl || 0);
      const target     = state.quarterTarget || 500000;
      const hit        = quarterPnl >= target;
      const surplus    = quarterPnl - target;
      const bonus      = hit ? Math.round(Math.min(surplus * 0.12, target * 0.25)) : 0;
      const qNum       = state.quarterNumber || 1;
      const qLabel     = ['Q1','Q2','Q3','Q4'][(qNum - 1) % 4];
      const yearNum    = Math.ceil(qNum / 4);

      if (hit) {
        state.cash += bonus;
        state.quarterBonusPaid = (state.quarterBonusPaid || 0) + bonus;
        state.quarterMissed   = Math.max(0, (state.quarterMissed || 0) - 1);
        state.reputation      = clamp((state.reputation || 0) + 3, 0, 100);
        state.worldEventFeed.unshift({
          type: 'alert',
          title: `${qLabel} Year ${yearNum}: Target hit — bonus ${money(bonus)}`,
          date: state.date,
          description: `Management commends the desk. ${qLabel} P&L: ${money(quarterPnl)} vs target ${money(target)}. Performance bonus of ${money(bonus)} credited. Next quarter target raised.`
        });
        // Raise target by 15-25%
        const growthSeed = deterministicRandom(state.date + '-target-growth');
        state.quarterTarget = Math.round(target * (1.15 + growthSeed * 0.10));
      } else {
        state.quarterMissed  = (state.quarterMissed || 0) + 1;
        state.reputation     = clamp((state.reputation || 0) - 2, 0, 100);
        const shortfall      = money(target - quarterPnl);
        const pressure       = state.quarterMissed >= 2 ? 'Senior management is closely monitoring the desk.' : 'Management expects improved performance next quarter.';
        state.worldEventFeed.unshift({
          type: 'alert',
          title: `${qLabel} Year ${yearNum}: Target missed — short by ${shortfall}`,
          date: state.date,
          description: `${qLabel} P&L: ${money(quarterPnl)} vs target ${money(target)}. ${pressure} ${state.quarterMissed >= 2 ? 'Target reduced to rebuild momentum.' : 'No bonus this quarter.'}`
        });
        if (state.quarterMissed >= 2) {
          state.quarterTarget = Math.round(target * 0.80); // ease the target
        }
      }
      state.worldEventFeed = state.worldEventFeed.slice(0, 18);
      state.quarterStartPnl = state.realizedPnl;
      state.quarterNumber   = qNum + 1;
      saveState();
    }
  }

  function computeDealProgress(deal) {
    if (deal.delivered) return 1;
    return clamp(deal.elapsed / deal.duration, 0, 1);
  }

  function marketPriceForOpportunity(opp) {
    if (opp.priceKey === 'aluminium') return state.aluminiumPrice;
    if (opp.priceKey === 'urea') return state.ureaPrice;
    if (opp.priceKey === 'crude') return state.crudePrice;
    if (opp.priceKey === 'wheat') return state.wheatPrice;
    if (opp.priceKey === 'ironore') return state.ironorePrice;
    if (opp.priceKey === 'coffee') return state.coffeePrice;
    if (opp.priceKey === 'zinc') return state.zincPrice;
    if (opp.priceKey === 'nickel') return state.nickelPrice;
    if (opp.priceKey === 'lng') return state.lngPrice;
    return state.copperPrice;
  }

  function computeMarketImpact(deal) {
    if (deal.delivered && Number.isFinite(deal.deliveryMarketPnl)) return deal.deliveryMarketPnl;
    const opp = getOpportunity(deal.opportunityId);
    const current = marketPriceForOpportunity(opp);
    const entry = deal.entryMarketPrice || current;
    const hedgeShare = clamp((deal.hedgeRatio || 0) / 100, 0, 1.1);
    const basisRisk = negotiationProfiles.pricing[deal.commercialTerms?.pricing || deal.pricingStrategy || 'fixed']?.basisRisk || 0;
    const unhedgedShare = clamp(1 - hedgeShare + basisRisk * Math.min(1, hedgeShare), -0.1, 1);
    // Pricing windows and buyer options leave basis risk even when futures hedge coverage is high.
    return -(current - entry) * (deal.quantity || opp.quantity) * unitMultiplierForOpportunity(opp) * unhedgedShare;
  }

  function computeFxImpact(deal) {
    if (deal.delivered && Number.isFinite(deal.deliveryFxPnl)) return deal.deliveryFxPnl;
    const opp = getOpportunity(deal.opportunityId);
    const entry = deal.entryFx || state.eurusd;
    const unhedged = Math.max(0, 1 - (deal.fxHedgeRatio || 0) / 100);
    const exposure = physicalNotional(opp, deal.quantity || opp.quantity, deal.capital) * fxExposureShare(opp) * unhedged;
    return entry ? ((state.eurusd - entry) / entry) * exposure : 0;
  }

  function currentMarginRequirement(deal) {
    if (deal.delivered) return 0;
    const opp = getOpportunity(deal.opportunityId);
    const initial = initialMarginFor(opp, deal.hedgeRatio || 0, deal.quantity || opp.quantity, deal.capital);
    const adverseMove = Math.max(0, marketPriceForOpportunity(opp) - (deal.entryMarketPrice || marketPriceForOpportunity(opp)));
    const variation = adverseMove * (deal.quantity || opp.quantity) * unitMultiplierForOpportunity(opp) * clamp((deal.hedgeRatio || 0) / 100, 0, 1.1);
    return Math.round(initial + variation);
  }

  // v45 — il collaterale liberato rimborsa per prima cosa il ponte di liquidita';
  // prima il prestito spariva insieme al deal, creando denaro dal nulla.
  function releaseCollateral(deal, amount) {
    const release = Math.max(0, Math.min(deal.marginCollateral || 0, amount));
    if (release <= 0) return 0;
    deal.marginCollateral -= release;
    const repayment = Math.min(deal.bridgeFunding || 0, release);
    if (repayment > 0) {
      deal.bridgeFunding = (deal.bridgeFunding || 0) - repayment;
      deal.borrowed = Math.max(0, (deal.borrowed || 0) - repayment);
    }
    state.cash += release - repayment;
    return release;
  }

  function updateMarginLiquidity(deal) {
    const required = currentMarginRequirement(deal);
    const current = deal.marginCollateral || 0;
    const delta = required - current;
    if (Math.abs(delta) < 1) return;
    if (delta < 0) {
      releaseCollateral(deal, -delta);
      return;
    }
    const fromCash = Math.min(Math.max(0, state.cash), delta);
    state.cash -= fromCash;
    deal.marginCollateral += fromCash;
    const shortfall = delta - fromCash;
    if (shortfall <= 0) return;
    const availableCredit = Math.max(0, effectiveCreditLimit() - portfolioStats().creditUsed);
    const bridge = Math.min(shortfall, availableCredit);
    if (bridge > 0) {
      const fee = Math.max(2_500, Math.round(bridge * difficultySettings().emergencyRate));
      deal.borrowed += bridge;
      deal.bridgeFunding = (deal.bridgeFunding || 0) + bridge;
      deal.marginCollateral += bridge;
      deal.pnlAdjustments -= fee;
      deal.marginCalls = (deal.marginCalls || 0) + 1;
      state.marginCalls = (state.marginCalls || 0) + 1;
      state.emergencyFundingCost = (state.emergencyFundingCost || 0) + fee;
      state.worldEventFeed.unshift({ type: 'margin', title: 'Emergency margin funding', date: state.date, description: `${getOpportunity(deal.opportunityId).title}: ${money(bridge)} bridge liquidity, fee ${money(fee)}.` });
      state.worldEventFeed = state.worldEventFeed.slice(0,14);
    }
    const uncovered = shortfall - bridge;
    if (uncovered > 0) {
      const opp = getOpportunity(deal.opportunityId);
      const notional = physicalNotional(opp, deal.quantity || opp.quantity, deal.capital);
      const hedgeReduction = Math.ceil((uncovered / Math.max(1, notional * difficultySettings().marginRate)) * 100);
      deal.hedgeRatio = clamp((deal.hedgeRatio || 0) - hedgeReduction, 0, 100);
      deal.reputationAdjustments -= 2;
      deal.eventResult = `Margin shortfall: hedge reduced to ${deal.hedgeRatio}% to release collateral.`;
    }
  }

  function accrueDailyFinancing(deal) {
    const rate = deal.financingRate ?? financingProfiles[deal.financingStrategy || 'revolver']?.rate ?? .075;
    const interest = (deal.borrowed || 0) * rate / 360;
    deal.financingAccrued = (deal.financingAccrued || 0) + interest;
    state.totalInterestPaid = (state.totalInterestPaid || 0) + interest;
  }

  function dealPhase(deal) {
    if (deal.delivered && (deal.paymentDaysRemaining || 0) > 0) return { key:'receivable', label:deal.invoiceStatus === 'Overdue' ? 'Overdue receivable' : 'Awaiting payment', location:getHub(getOpportunity(deal.opportunityId).destination).name };
    const p = computeDealProgress(deal);
    if (p < .15) return { key: 'booked', label: 'Booked', location: getHub(getOpportunity(deal.opportunityId).origin).name };
    if (p < .78) return { key: 'transit', label: 'In transit', location: 'In transit' };
    if (p < .93) {
      const opp = getOpportunity(deal.opportunityId);
      const port = opp.via?.length ? getHub(opp.via.at(-1)).name : getHub(opp.destination).name;
      return { key: 'port', label: 'Port / Warehouse', location: port };
    }
    return { key: 'delivery', label: 'Final delivery', location: getHub(getOpportunity(deal.opportunityId).destination).name };
  }

  function computeUnrealizedPnl(deal) {
    const progress = computeDealProgress(deal);
    const completionFactor = deal.delivered ? 1 : Math.min(1, progress * .86);
    const operatingPnl = (deal.basePnl + deal.pnlAdjustments - (deal.financingAccrued || 0)) * completionFactor;
    return operatingPnl + computeMarketImpact(deal) + computeFxImpact(deal);
  }

  function riskStats() {
    const stats = portfolioStats();
    const grossByCommodity = {};
    let netFlatExposure = 0;
    let netFxExposure = 0;
    let totalCapital = 0;
    let largestCapital = 0;
    state.activeDeals.forEach(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const value = physicalNotional(opp, deal.quantity || opp.quantity, deal.capital);
      grossByCommodity[opp.commodity] = (grossByCommodity[opp.commodity] || 0) + value;
      netFlatExposure += value * Math.max(0, 1 - (deal.hedgeRatio || 0) / 100);
      netFxExposure += value * fxExposureShare(opp) * Math.max(0, 1 - (deal.fxHedgeRatio || 0) / 100);
      totalCapital += deal.capital || opp.capital;
      largestCapital = Math.max(largestCapital, deal.capital || opp.capital);
    });
    const creditUtilization = effectiveCreditLimit() ? stats.creditUsed / effectiveCreditLimit() : 0;
    const concentration = totalCapital ? largestCapital / totalCapital : 0;
    const marginRequirement = state.activeDeals.reduce((sum,deal)=>sum+currentMarginRequirement(deal),0);
    const liquidityReserve = Math.max(150_000, netFlatExposure * .08 + netFxExposure * .06 + stats.creditUsed * .035 + marginRequirement * .12);
    const liquidityCoverage = liquidityReserve ? state.cash / liquidityReserve : 10;
    const systemicRisk = activeCrisisDefinitions().reduce((sum,event) => sum + (event.severity === 'high' ? 9 : event.severity === 'medium' ? 5 : 2), 0);
    const riskScore = clamp(
      creditUtilization * 30 + concentration * 20 + Math.min(1, netFlatExposure / 1_500_000) * 26 + Math.min(1, netFxExposure / 800_000) * 12 + (liquidityCoverage < 1 ? 18 : liquidityCoverage < 1.5 ? 8 : 0) + Math.min(24, systemicRisk),
      0, 100
    ) - (hasStaff('risk-analyst') ? 8 : 0) - hqAdjustments().riskReduction - officeNetworkRiskReduction() + difficultySettings().riskPenalty + activeDoctrine().riskAdjustment + activeCapitalPolicy().riskAdjustment + deskSpecializationAdjustments(null).riskAdjustment;
    const stressLoss = netFlatExposure * .08 + netFxExposure * .05 + stats.creditUsed * .012 + Math.max(0, -(state.riskPnlImpact || 0)) * .15;
    return { ...stats, grossByCommodity, netFlatExposure, netFxExposure, marginRequirement, stressLoss, systemicRisk, creditUtilization, concentration, liquidityReserve, liquidityCoverage, riskScore: clamp(riskScore, 0, 100) };
  }

  function portfolioStats() {
    const invested = state.activeDeals.reduce((sum, d) => sum + d.equity, 0);
    const marginCollateral = state.activeDeals.reduce((sum, d) => sum + (d.marginCollateral || 0), 0);
    const activePnl = state.activeDeals.reduce((sum, d) => sum + computeUnrealizedPnl(d), 0);
    const creditUsed = state.activeDeals.reduce((sum, d) => sum + d.borrowed, 0);
    const assetValue = investmentBookValue() + shopBookValue() + hqBookValue() + officeBookValue();
    const bridgeFunding = state.activeDeals.reduce((sum, d) => sum + (d.bridgeFunding || 0), 0);
    const nav = state.cash + invested + marginCollateral + activePnl + assetValue - bridgeFunding;
    return { invested, marginCollateral, bridgeFunding, activePnl, creditUsed, creditAvailable: effectiveCreditLimit() - creditUsed, assetValue, nav };
  }

  function isOpportunityUnlocked(opp) {
    if (!opp) return false;
    const req = opportunityProgressionRequirements(opp);
    if (playerLevel() < req.requiredLevel) return false;
    if (!commodityUnlocked(opp.commodity)) return false;
    if (req.lockedCountries.length) return false;
    if (typeof opp.unlock === 'function') return Boolean(opp.unlock(state));
    return !opp.locked;
  }

  function tradingHouseValuation() {
    const stats = portfolioStats();
    const earnings = Math.max(0, state.realizedPnl || 0);
    const assetValue = investmentBookValue() + shopBookValue() + hqBookValue() + officeBookValue();
    const relationshipValue = Object.values(state.counterparties||{}).reduce((sum,cp)=>sum+Math.max(0,(cp.relationship||50)-45)*4_000,0);
    const executionValue = state.completedDeals * 35_000 + (state.reputation||0)*9_000;
    const value = Math.max(stats.nav, stats.nav + earnings*1.8 + assetValue*.35 + relationshipValue + executionValue);
    const tier = value >= 50_000_000 ? 'Integrated Major' : value >= 20_000_000 ? 'Global Trading House' : value >= 8_000_000 ? 'Regional Merchant' : value >= 3_000_000 ? 'Growth Trader' : 'Boutique Desk';
    return { value, tier, earnings, assetValue, relationshipValue, executionValue };
  }
  function boardMandateData() {
    const valuation = tradingHouseValuation();
    const chains = ['upstream','midstream','downstream'].filter(chain=>investmentCatalog.some(asset=>asset.chain===chain&&investmentLevel(asset.id)>0)).length;
    const origins = new Set((state.history||[]).map(item=>getOpportunity(item.opportunityId)?.origin).filter(Boolean)).size;
    return [
      { label:'Build a $10M merchant', progress:valuation.value, target:10_000_000, copy:'Scale equity, earnings and franchise value.' },
      { label:'Vertically integrate', progress:chains, target:3, copy:'Own upstream, midstream and downstream capacity.' },
      { label:'Global origination network', progress:origins, target:6, copy:'Complete cargoes from six distinct origins.' },
      { label:'Credit discipline', progress:(state.creditLosses||0)===0?Math.min(5,state.completedDeals||0):0, target:5, copy:'Build five clean settlement milestones without material credit loss.' }
    ];
  }

  function rankFromState() {
    if (officeOwned('singapore') && state.reputation >= 82 && state.completedDeals >= 8) return 'Global Desk Head';
    if (state.reputation >= 80 && state.completedDeals >= 8) return 'Desk Head';
    if (state.reputation >= 68 && state.completedDeals >= 4) return 'Senior Trader';
    if (state.reputation >= 58 && state.completedDeals >= 2) return 'Trader';
    return 'Junior Trader';
  }


  const leaderboardRivals = [
    ['helios','Helios Commodities','Zurich','CH',5750,980000,95,93],
    ['atlas','Atlas Merchant Group','London','GB',5240,860000,92,90],
    ['meridian-desk','Meridian Global Desk','Dubai','AE',4810,740000,87,82],
    ['northsea','NorthSea Trading','Rotterdam','NL',4460,690000,94,91],
    ['pacific','Pacific Bulk Partners','Singapore','SG',4120,610000,88,89],
    ['andean','Andean Resources','Santiago','CL',3860,540000,91,84],
    ['rhine','Rhine Metals Desk','Geneva','CH',3520,470000,89,94],
    ['stratus','Stratus Energy','Houston','US',3240,430000,83,78],
    ['baltic','Baltic Merchant','Tallinn','EE',3010,365000,93,92],
    ['orion','Orion Agri Trade','Geneva','CH',2760,320000,86,88],
    ['cobalt','Cobalt Bridge','Lugano','CH',2520,275000,90,86],
    ['saffron','Saffron Commodities','Dubai','AE',2310,230000,78,81],
    ['harbor','Harborline Trading','Genoa','IT',2120,205000,91,89],
    ['delta','Delta Physical Markets','Amsterdam','NL',1940,170000,84,87],
    ['forge','Forge Materials','Milan','IT',1780,145000,88,90],
    ['vertex','Vertex Commodity Desk','Paris','FR',1630,118000,82,85],
    ['mariner','Mariner Trade House','Hamburg','DE',1490,97000,87,83],
    ['alpine','Alpine Flow Trading','Geneva','CH',1360,78000,90,91],
    ['redwood','Redwood Merchant','Chicago','US',1240,61000,80,79],
    ['bluewater','Bluewater Commodities','Athens','GR',1120,43000,85,82],
    ['nova','Nova Materials Desk','Vienna','AT',1010,27000,86,88],
    ['frontier','Frontier Trade Co.','Madrid','ES',910,12000,79,84],
    ['oak','Oakline Physical','Dublin','IE',820,-4000,83,86],
    ['ember','Ember Trading Desk','Prague','CZ',730,-18000,76,80]
  ].map(([id,name,city,country,overall,pnl,operations,risk])=>({id,name,city,country,overall,pnl,operations,risk}));

  function averageOperationalScore() {
    if (!state.history.length) return 76;
    return state.history.reduce((sum,item)=>sum+(item.operationalReadiness ?? 75),0)/state.history.length;
  }

  function riskDisciplineScore() {
    const history = state.history || [];
    const avgHedge = history.length ? history.reduce((sum,item)=>sum+(item.hedgeRatio||0),0)/history.length : 72;
    const profitable = history.length ? history.filter(item=>item.pnl>=0).length/history.length : .5;
    const risk = riskStats();
    return clamp(42 + avgHedge*.34 + profitable*18 - (state.marginCalls||0)*4 - Math.max(0,risk.riskScore-55)*.35, 0, 100);
  }

  function leaderboardScore() {
    const stats = portfolioStats();
    const wealthGain = stats.nav - 1_000_000;
    const score = 500
      + wealthGain / 3000
      + state.reputation * 7
      + state.completedDeals * 55
      + averageOperationalScore() * 2
      + riskDisciplineScore() * 1.5
      + (state.academyScore||0) * .15
      + (state.completedMissions?.length||0) * 20
      + (state.achievements?.length||0) * 18
      + (state.tenderWins||0) * 12
      + Math.max(0,(state.offices?.length||1)-1) * 35
      - (state.marginCalls||0) * 45
      - (state.emergencyFundingCost||0) / 5000;
    return Math.max(0,Math.round(score));
  }

  function leaderboardLeague(score=leaderboardScore()) {
    if (score >= 6000) return {name:'Master Merchant',className:'master',next:null};
    if (score >= 4500) return {name:'Elite',className:'elite',next:6000};
    if (score >= 3400) return {name:'Platinum',className:'platinum',next:4500};
    if (score >= 2500) return {name:'Gold',className:'gold',next:3400};
    if (score >= 1800) return {name:'Silver',className:'silver',next:2500};
    if (score >= 1200) return {name:'Bronze',className:'bronze',next:1800};
    return {name:'Rookie',className:'rookie',next:1200};
  }

  function seasonNumber(dayIndex=state.dayIndex||0) { return Math.floor(dayIndex/90)+1; }
  function seasonDay(dayIndex=state.dayIndex||0) { return dayIndex%90+1; }

  function rivalRows(mode='overall') {
    const season = seasonNumber();
    return leaderboardRivals.map((rival,index)=>{
      const noise = deterministicRandom(`${rival.id}-${season}-${state.marketCycle}`)-.5;
      const progression = Math.min(1.35,1+(state.dayIndex||0)*.0014);
      return {
        ...rival,
        isPlayer:false,
        overall:Math.round((rival.overall*progression)+(noise*240)+(season-1)*90),
        pnl:Math.round((rival.pnl*progression)+(noise*90000)+(season-1)*35000),
        operations:clamp(rival.operations+noise*5,55,99.5),
        risk:clamp(rival.risk+noise*6,50,99.5)
      };
    });
  }

  function playerLeaderboardRow() {
    return {
      id:'player',
      name:state.companyName || 'World of Trade Co.',
      trader:state.profileName || 'Giorgio Bonetta',
      city:'Geneva',country:'YOU',isPlayer:true,
      overall:leaderboardScore(),
      pnl:Math.round(state.realizedPnl||0),
      operations:averageOperationalScore(),
      risk:riskDisciplineScore()
    };
  }

  function leaderboardRows(mode='overall') {
    return [...rivalRows(mode),playerLeaderboardRow()].sort((a,b)=>b[mode]-a[mode]).map((row,index)=>({...row,position:index+1}));
  }

  function leaderboardPosition(mode='overall') {
    return leaderboardRows(mode).find(row=>row.isPlayer)?.position || leaderboardRivals.length+1;
  }

  function formatLeaderboardMetric(row,mode) {
    if (mode==='pnl') return money(row.pnl,true);
    if (mode==='operations'||mode==='risk') return `${row[mode].toFixed(1)}%`;
    return Math.round(row.overall).toLocaleString('en-US');
  }

  function archiveSeasonIfNeeded(previousDayIndex) {
    const previousSeason=seasonNumber(previousDayIndex);
    const newSeason=seasonNumber(state.dayIndex||0);
    if (newSeason===previousSeason) return;
    state.leaderboardSnapshots=state.leaderboardSnapshots||[];
    state.leaderboardSnapshots.unshift({
      season:previousSeason,
      score:leaderboardScore(),
      position:leaderboardPosition('overall'),
      league:leaderboardLeague().name,
      pnl:state.realizedPnl||0,
      completedDeals:state.completedDeals||0,
      closedAt:state.date
    });
    state.leaderboardSnapshots=state.leaderboardSnapshots.slice(0,8);
  }

  function resizeCanvas() {
    canvasRect = canvas.getBoundingClientRect();
    dpr = targetPixelRatio();
    canvas.width = Math.max(1, Math.round(canvasRect.width * dpr));
    canvas.height = Math.max(1, Math.round(canvasRect.height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (earthRenderer) {
      earthRenderer.setPixelRatio(dpr);
      earthRenderer.setSize(Math.max(1, canvasRect.width), Math.max(1, canvasRect.height), false);
      syncEarthProjection();
    }
  }

  const toVector = (lon, lat) => {
    const phi = lat * deg;
    const lambda = lon * deg;
    return [Math.cos(phi) * Math.cos(lambda), Math.cos(phi) * Math.sin(lambda), Math.sin(phi)];
  };

  function vectorToLonLat(v) {
    const [x, y, z] = v;
    return { lon: Math.atan2(y, x) / deg, lat: Math.asin(clamp(z, -1, 1)) / deg };
  }

  function slerp(a, b, t) {
    const dot = clamp(a[0]*b[0] + a[1]*b[1] + a[2]*b[2], -1, 1);
    const omega = Math.acos(dot);
    if (omega < 1e-5) return a;
    const so = Math.sin(omega);
    const s1 = Math.sin((1-t)*omega) / so;
    const s2 = Math.sin(t*omega) / so;
    return [a[0]*s1+b[0]*s2, a[1]*s1+b[1]*s2, a[2]*s1+b[2]*s2];
  }

  function project(lon, lat, lift = 0) {
    if (!canvasRect) return null;
    const width = canvasRect.width;
    const height = canvasRect.height;
    const radius = desiredGlobeRadius();
    const cx = width * .5;
    const cy = height * .5;
    if (earthCamera) {
      const point = geoVector3(lon, lat, 1 + lift);
      const visible = point.clone().normalize().dot(earthCamera.position.clone().normalize());
      earthProjectionVector.copy(point).project(earthCamera);
      return {
        x: (earthProjectionVector.x * .5 + .5) * width,
        y: (-earthProjectionVector.y * .5 + .5) * height,
        z: visible,
        radius, cx, cy
      };
    }
    const phi = lat * deg;
    const lambda = lon * deg;
    const phi0 = view.lat * deg;
    const lambda0 = view.lon * deg;
    const dl = lambda - lambda0;
    const x = Math.cos(phi) * Math.sin(dl);
    const y = Math.cos(phi0) * Math.sin(phi) - Math.sin(phi0) * Math.cos(phi) * Math.cos(dl);
    const z = Math.sin(phi0) * Math.sin(phi) + Math.cos(phi0) * Math.cos(phi) * Math.cos(dl);
    return { x: cx + radius * x * (1 + lift), y: cy - radius * y * (1 + lift), z, radius, cx, cy };
  }

  function loadGeoBorders() {
    const loadGeoSource = async () => {
      for (const url of ['./assets/data/countries-lowres.geojson', './countries-lowres.geojson']) {
        try {
          const response = await fetch(url);
          if (response.ok) return response.json();
        } catch (error) { console.warn(`Geography source unavailable: ${url}`, error); }
      }
      throw new Error('Geography asset unavailable');
    };
    loadGeoSource()
      .then(world => {
        const borders = [];
        const coasts = [];
        const addPolygon = polygon => {
          if (!Array.isArray(polygon) || !polygon.length) return;
          polygon.forEach((ring,index) => {
            if (!Array.isArray(ring) || ring.length < 2) return;
            borders.push(ring);
            if (index === 0) coasts.push(ring);
          });
        };
        (world.features || []).forEach(feature => {
          const geometry = feature?.geometry;
          if (!geometry) return;
          if (geometry.type === 'Polygon') addPolygon(geometry.coordinates);
          if (geometry.type === 'MultiPolygon') geometry.coordinates.forEach(addPolygon);
        });
        geoBorderLines = borders;
        geoCoastlines = coasts;
      })
      .catch(() => {});
  }


  // ── v43 Terra fisica nel fallback 2D (continenti pieni, non solo contorni) ──
  function drawPhysicalLandmasses(cx, cy, radius) {
    if (!geoCoastlines?.length) return false;
    // Ricava le misure dal canvas se i parametri non sono validi
    if (!Number.isFinite(cx) || !Number.isFinite(cy)) {
      const w = canvasRect?.width || ctx?.canvas?.width || 0;
      const h = canvasRect?.height || ctx?.canvas?.height || 0;
      cx = w * .5; cy = h * .5;
    }
    if (!(radius > 0)) radius = desiredGlobeRadius();
    if (!Number.isFinite(cx) || !Number.isFinite(cy) || !(radius > 0)) return false;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.clip();

    // Terreno: verde vegetazione al centro, tinte aride verso i bordi
    const land = ctx.createRadialGradient(cx - radius * .3, cy - radius * .36, radius * .08, cx, cy, radius * 1.05);
    land.addColorStop(0,   '#7bbf63');
    land.addColorStop(.42, '#4f9a4a');
    land.addColorStop(.72, '#3d7a41');
    land.addColorStop(1,   '#2b5733');
    ctx.fillStyle = land;

    let drawn = 0;
    for (const ring of geoCoastlines) {
      if (!ring || ring.length < 3) continue;
      let open = false, visible = 0;
      ctx.beginPath();
      for (const [lon, lat] of ring) {
        const p = project(lon, lat);
        if (p.z > 0.02) {
          if (!open) { ctx.moveTo(p.x, p.y); open = true; } else ctx.lineTo(p.x, p.y);
          visible++;
        } else if (open) { open = false; }
      }
      if (visible >= 3) { ctx.closePath(); ctx.fill(); drawn++; }
    }

    // Rilievo morbido e ombreggiatura del terminatore
    const shade = ctx.createRadialGradient(cx - radius * .34, cy - radius * .4, radius * .1, cx, cy, radius);
    shade.addColorStop(0, 'rgba(255,244,214,0.18)');
    shade.addColorStop(.5, 'rgba(255,255,255,0)');
    shade.addColorStop(1, 'rgba(2,8,20,0.42)');
    ctx.fillStyle = shade;
    ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.fill();

    ctx.restore();

    // Alone atmosferico
    const halo = ctx.createRadialGradient(cx, cy, radius * .92, cx, cy, radius * 1.09);
    halo.addColorStop(0, 'rgba(120,200,255,0)');
    halo.addColorStop(.55, 'rgba(120,200,255,0.20)');
    halo.addColorStop(1, 'rgba(120,200,255,0)');
    ctx.fillStyle = halo;
    ctx.beginPath(); ctx.arc(cx, cy, radius * 1.09, 0, Math.PI * 2); ctx.fill();
    return drawn > 0;
  }

  function drawGeoBorders() {
    if (!canvasRect) return;
    const radius = desiredGlobeRadius();
    const cx = canvasRect.width * .5;
    const cy = canvasRect.height * .5;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.clip();
    function drawLines(lines, color, lw, dash) {
      if (!lines?.length) return;
      ctx.strokeStyle = color;
      ctx.lineWidth = lw;
      if (dash) ctx.setLineDash(dash); else ctx.setLineDash([]);
      for (const line of lines) {
        let open = false;
        ctx.beginPath();
        for (const [lon, lat] of line) {
          const p = project(lon, lat);
          if (p.z > 0.0) {
            if (!open) { ctx.moveTo(p.x, p.y); open = true; }
            else ctx.lineTo(p.x, p.y);
          } else { open = false; }
        }
        ctx.stroke();
      }
      ctx.setLineDash([]);
    }
    if (earthWebGLReady) {
      drawLines(geoCoastlines,  'rgba(225,238,245,0.16)', 0.46, null);
      drawLines(geoBorderLines, 'rgba(210,225,235,0.075)', 0.28, [1,4]);
    } else {
      drawLines(geoCoastlines,  'rgba(18,48,38,0.55)', 0.85, null);
      drawLines(geoBorderLines, 'rgba(245,252,255,0.20)', 0.45, [2,3]);
    }
    ctx.restore();
  }

  function drawGlobe() {
    if (!canvasRect) return;
    const width = canvasRect.width;
    const height = canvasRect.height;
    ctx.clearRect(0, 0, width, height);
    markerHitboxes = [];
    shipHitboxes = [];
    fleetHitboxes = [];
    investmentHitboxes = [];

    const radius = desiredGlobeRadius();
    const cx = width * .5;
    const cy = height * .5;

    if (!earthRenderer || !earthWebGLReady) {
      const ocean = ctx.createRadialGradient(cx - radius * .28, cy - radius * .34, radius * .05, cx, cy, radius);
      ocean.addColorStop(0, '#3d8fc4');
      ocean.addColorStop(.45, '#1f5f92');
      ocean.addColorStop(.78, '#123f6b');
      ocean.addColorStop(1, '#08203c');
      ctx.fillStyle = ocean;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.clip();
      drawGraticule();
      ctx.restore();
      // Terre emerse piene: Terra fisica anche senza WebGL
      const filled = drawPhysicalLandmasses(cx, cy, radius);
      if (!filled && !geoBorderLines) {
        ctx.save();
        ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.clip();
        drawContinents();
        ctx.restore();
      }
    }

    if (geoBorderLines || geoCoastlines) drawGeoBorders();

    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 1.045, 0, Math.PI * 2);
    ctx.clip();
    drawRoutes();
    drawHubs();
    drawInvestmentMarkers();
    drawShipments();
    drawFleetAssets();
    drawHubPings();
    ctx.restore();

    ctx.save();
    const edge = ctx.createRadialGradient(cx, cy, radius * .91, cx, cy, radius * 1.13);
    edge.addColorStop(0, 'rgba(71,177,255,0)');
    edge.addColorStop(.76, 'rgba(71,177,255,.06)');
    edge.addColorStop(1, 'rgba(71,177,255,0)');
    ctx.fillStyle = edge;
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 1.14, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(111, 191, 255, .15)';
    ctx.lineWidth = .8;
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 1.02, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawGraticule() {
    ctx.save();
    ctx.strokeStyle = 'rgba(145, 221, 240, .075)';
    ctx.lineWidth = .65;
    for (let lat = -60; lat <= 60; lat += 30) drawGeoLine(Array.from({length: 121}, (_,i) => [-180 + i*3, lat]));
    for (let lon = -180; lon < 180; lon += 30) drawGeoLine(Array.from({length: 61}, (_,i) => [lon, -90 + i*3]));
    ctx.restore();
  }

  function drawGeoLine(points) {
    let open = false;
    ctx.beginPath();
    for (const [lon, lat] of points) {
      const p = project(lon, lat);
      if (p.z > 0) {
        if (!open) { ctx.moveTo(p.x, p.y); open = true; }
        else ctx.lineTo(p.x, p.y);
      } else open = false;
    }
    ctx.stroke();
  }

  function densifyPolygon(poly, step = 2.5) {
    const points = [];
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i];
      const b = poly[(i+1) % poly.length];
      let dLon = b[0] - a[0];
      if (dLon > 180) dLon -= 360;
      if (dLon < -180) dLon += 360;
      const dLat = b[1] - a[1];
      const n = Math.max(2, Math.ceil(Math.max(Math.abs(dLon), Math.abs(dLat)) / step));
      for (let j = 0; j < n; j++) points.push([a[0] + dLon * j/n, a[1] + dLat * j/n]);
    }
    return points;
  }

  function drawContinents() {
    ctx.save();
    ctx.fillStyle = 'rgba(74, 148, 72, .92)';
    ctx.strokeStyle = 'rgba(24, 58, 40, .5)';
    ctx.lineWidth = .8;
    for (const dense of denseContinents) {
      const visible = dense.map(([lon, lat]) => ({...project(lon, lat), lon, lat})).filter(p => p.z > -.02);
      if (visible.length < 3) continue;
      ctx.beginPath();
      ctx.moveTo(visible[0].x, visible[0].y);
      for (let i = 1; i < visible.length; i++) ctx.lineTo(visible[i].x, visible[i].y);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }

  function routePoints(opp, segmentsPerLeg = 48) {
    const cacheKey = `${opp.id}-${segmentsPerLeg}`;
    if (routeCache.has(cacheKey)) return routeCache.get(cacheKey);
    const ids = [opp.origin, ...(opp.via || []), opp.destination];
    const output = [];
    for (let leg = 0; leg < ids.length - 1; leg++) {
      const aHub = getHub(ids[leg]);
      const bHub = getHub(ids[leg + 1]);
      const a = toVector(aHub.lon, aHub.lat);
      const b = toVector(bHub.lon, bHub.lat);
      for (let i = 0; i <= segmentsPerLeg; i++) {
        const t = i / segmentsPerLeg;
        const ll = vectorToLonLat(slerp(a, b, t));
        output.push({ ...ll, globalT: (leg + t) / (ids.length - 1) });
      }
    }
    routeCache.set(cacheKey, output);
    return output;
  }

  function drawProjectedRoute(points, style) {
    ctx.save();
    ctx.strokeStyle = style.color;
    ctx.lineWidth = style.width;
    ctx.globalAlpha = style.alpha ?? 1;
    if (style.dash) { ctx.setLineDash(style.dash); ctx.lineDashOffset = -(animationTime * 0.012); }
    ctx.beginPath();
    let open = false;
    for (const point of points) {
      const lift = style.lift ? Math.sin(point.globalT * Math.PI) * style.lift : 0;
      const p = project(point.lon, point.lat, lift);
      if (p.z > -.01) {
        if (!open) { ctx.moveTo(p.x, p.y); open = true; }
        else ctx.lineTo(p.x, p.y);
      } else open = false;
    }
    ctx.stroke();
    ctx.restore();
  }

  // ── v46 · disegna solo un tratto della rotta (da t0 a t1 in globalT) ─────────
  function drawProjectedRouteRange(points, t0, t1, style) {
    const slice = points.filter(point => point.globalT >= t0 - 1e-6 && point.globalT <= t1 + 1e-6);
    if (slice.length < 2) return;
    drawProjectedRoute(slice, style);
  }

  // v46 - impulso luminoso che scorre lungo la rotta, per far percepire la
  // direzione del flusso commerciale invece di una linea statica.
  function drawRouteFlow(points, color, speed = 0.00012, lift = 0.05, size = 0.06) {
    const head = (animationTime * speed) % 1;
    const tail = Math.max(0, head - size);
    drawProjectedRouteRange(points, tail, head, { color, width: 2.2, lift, alpha: .85 });
  }

  function drawRoutes() {
    if (layers.opportunities) {
      opportunities.forEach(opp => {
        if (!isOpportunityUnlocked(opp)) return;
        const isSelected = selected.type === 'opportunity' && selected.id === opp.id;
        const points = routePoints(opp, 36);
        drawProjectedRoute(points, {
          color: isSelected ? 'rgba(255,209,102,.88)' : 'rgba(255,209,102,.22)',
          width: isSelected ? 1.8 : .9,
          dash: isSelected ? [] : [3, 5], lift: .045, alpha: 1
        });
        // la rotta selezionata "respira": un impulso la percorre da origine a destino
        if (isSelected && motionEnabled()) drawRouteFlow(points, 'rgba(255,246,214,.95)', 0.00016, .045, .07);
      });
    }
    if (layers.portfolio) {
      state.activeDeals.forEach(deal => {
        const opp = getOpportunity(deal.opportunityId);
        if (!opp) return;
        const isSelected = selected.type === 'deal' && selected.id === deal.id;
        const hedge = deal.hedgeRatio || 0;
        const riskColor = hedge >= 90 ? 'rgba(97,242,166,.9)' : hedge >= 60 ? 'rgba(255,180,94,.9)' : 'rgba(255,100,121,.95)';
        const baseColor = layers.risk ? riskColor : (isSelected ? 'rgba(97,242,166,1)' : 'rgba(97,242,166,.58)');
        const points = routePoints(opp, 46);
        const progress = clamp(visualDealProgress(deal), 0, 1);

        // v46 - il tratto gia' percorso e' pieno e luminoso, quello che resta e'
        // tratteggiato e spento: a colpo d'occhio si legge quanto manca all'arrivo.
        drawProjectedRouteRange(points, progress, 1, {
          color: deal.pendingDecision ? 'rgba(255,100,121,.42)' : 'rgba(140,170,200,.30)',
          width: 1.1, dash: [3, 5], lift: .055, alpha: 1
        });
        drawProjectedRouteRange(points, 0, progress, {
          color: baseColor,
          width: isSelected ? 2.6 : (layers.risk ? 2 : 1.6), lift: .055
        });
        if (isSelected && motionEnabled()) drawRouteFlow(points, 'rgba(226,255,240,.9)', 0.00022, .055, .05);
      });
    }
  }

  function hubVisible(hub) {
    if (hub.type === 'hq') return true;
    if (layers.portfolio && state.activeDeals.some(d => {
      const o = getOpportunity(d.opportunityId);
      return [o.origin, o.destination, ...(o.via || [])].includes(hub.id);
    })) return true;
    if (layers.opportunities) {
      // Keep future markets and prospective office cities visible so expansion feels tangible.
      if (getOffice(hub.id)) return true;
      if (!countryUnlocked(hub.country)) return true;
      return opportunities.some(o => [o.origin,o.destination,...(o.via||[])].includes(hub.id));
    }
    return false;
  }

  function hubColor(hub) {
    // v55 - tavolozza del logo: crema, oro, blu reale. Il ciano fluo stonava.
    return { hq: '#fffaf0', supplier: '#ffd166', customer: '#8fc0ff', port: '#5a86d8' }[hub.type] || '#b79bff';
  }

  // ── v46 · porti toccati da una crisi in corso ───────────────────────────────
  // Ricavati dalle opportunita' colpite dagli eventi globali attivi. Il risultato
  // e' in cache per giornata: la valutazione non deve pesare su ogni frame.
  let _stressedHubsCache = { key: null, ids: new Set() };
  function stressedHubIds() {
    const key = `${state.dayIndex}-${(state.activeGlobalEvents || []).map(event => event.id).join('|')}`;
    if (_stressedHubsCache.key === key) return _stressedHubsCache.ids;
    const ids = new Set();
    try {
      activeCrisisDefinitions().forEach(definition => {
        if (typeof definition.affects !== 'function') return;
        opportunities.forEach(opp => {
          let hit = false;
          try { hit = definition.affects(opp); } catch (error) { hit = false; }
          if (!hit) return;
          [opp.origin, opp.destination, ...(opp.via || [])].forEach(id => ids.add(id));
        });
      });
    } catch (error) { /* mai bloccare il disegno */ }
    _stressedHubsCache = { key, ids };
    return ids;
  }

  // ping di arrivo: cerchi che si espandono quando un carico viene consegnato
  const _hubPings = [];
  function pingHub(hubId, tone = 'arrival') {
    if (!hubId) return;
    _hubPings.push({ hubId, tone, at: (typeof animationTime === 'number' ? animationTime : 0) });
    if (_hubPings.length > 12) _hubPings.shift();
  }
  function drawHubPings() {
    if (!_hubPings.length) return;
    const now = animationTime;
    const life = 1700;
    for (let i = _hubPings.length - 1; i >= 0; i--) {
      const ping = _hubPings[i];
      const age = now - ping.at;
      if (age < 0 || age > life) { _hubPings.splice(i, 1); continue; }
      const hub = getHub(ping.hubId);
      if (!hub) { _hubPings.splice(i, 1); continue; }
      const projected = project(hub.lon, hub.lat, .012);
      if (projected.z <= 0) continue;
      const t = age / life;
      const rgb = ping.tone === 'alert' ? '255,100,121' : '97,242,166';
      ctx.save();
      for (const delay of [0, .28]) {
        const local = t - delay;
        if (local <= 0 || local >= 1) continue;
        ctx.strokeStyle = `rgba(${rgb},${((1 - local) * .75).toFixed(3)})`;
        ctx.lineWidth = 2 - local * 1.4;
        ctx.beginPath();
        ctx.arc(projected.x, projected.y, 5 + local * 26, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  function drawHubs() {
    hubs.forEach(hub => {
      if (!hubVisible(hub)) return;
      const p = project(hub.lon, hub.lat, .012);
      if (p.z <= 0) return;
      const selectedHub = selected.type === 'hub' && selected.id === hub.id;
      const lockedMarket = !countryUnlocked(hub.country);
      const color = lockedMarket ? '#77829a' : hubColor(hub);
      const pulse = 1 + Math.sin(animationTime * .003 + hub.lon) * .12;
      ctx.save();
      ctx.globalAlpha = lockedMarket ? clamp(p.z * .75, .12, .42) : clamp(p.z * 1.7, .25, 1);
      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = selectedHub ? 18 : 9;
      ctx.beginPath();
      ctx.arc(p.x, p.y, (lockedMarket ? 2.4 : (selectedHub ? 5 : 3.4)) * pulse, 0, Math.PI*2);
      ctx.fill();
      ctx.shadowBlur = 0;
      // v46 - alone d'allerta sui porti toccati da una crisi attiva
      if (layers.risk && stressedHubIds().has(hub.id)) {
        const pulse = .5 + Math.sin(animationTime * .0042 + hub.lat) * .5;
        ctx.save();
        ctx.globalAlpha = clamp(p.z * (.35 + pulse * .45), .12, .8);
        ctx.strokeStyle = '#ff9a5e';
        ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.arc(p.x, p.y, 11 + pulse * 6, 0, Math.PI * 2); ctx.stroke();
        ctx.globalAlpha = clamp(p.z * .22, .05, .3);
        ctx.fillStyle = '#ff9a5e';
        ctx.beginPath(); ctx.arc(p.x, p.y, 11 + pulse * 6, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
      const prospectiveOffice=getOffice(hub.id);
      if (prospectiveOffice && hub.id!=='geneva' && !officeOwned(hub.id) && !activeOfficeProject(hub.id)) {
        const canOpen=officeUnlocked(prospectiveOffice);
        ctx.strokeStyle=canOpen?'#7fffa8':'#7f8ba3';
        ctx.globalAlpha=clamp(p.z*(canOpen?1.15:.7),.15,canOpen?.85:.42);
        ctx.lineWidth=canOpen?1.5:1;
        ctx.setLineDash(canOpen?[4,2]:[2,4]);
        ctx.beginPath();
        ctx.arc(p.x,p.y,canOpen?7.2:6.2,0,Math.PI*2);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      if (officeOwned(hub.id) && hub.id !== 'geneva') {
        ctx.strokeStyle = '#ffd166';
        ctx.globalAlpha = clamp(p.z * 1.5, .35, .95);
        ctx.lineWidth = selectedHub ? 2.4 : 1.6;
        ctx.beginPath();
        ctx.arc(p.x, p.y, selectedHub ? 9 : 6.8, 0, Math.PI*2);
        ctx.stroke();
      }
      if (activeOfficeProject(hub.id)) {
        ctx.strokeStyle = '#8fc0ff';
        ctx.setLineDash([3,3]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 8 + Math.sin(animationTime*.005)*1.5, 0, Math.PI*2);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      if (selectedHub) {
        ctx.strokeStyle = color;
        ctx.globalAlpha = .45;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 10 + Math.sin(animationTime*.004)*2, 0, Math.PI*2);
        ctx.stroke();
      }
      const hoveredHub = hoveredTarget?.type === 'hub' && hoveredTarget.id === hub.id;
      if (globeOptions.labels && (selectedHub || hoveredHub)) {
        ctx.globalAlpha = clamp(p.z * 1.5, .2, 1);
        ctx.font = `${selectedHub ? 700 : 600} ${selectedHub ? 10 : 8}px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = selectedHub ? '#f4fbff' : 'rgba(218,233,241,.78)';
        const officeLabel=getOffice(hub.id);
        const officePrefix=officeLabel&&hub.id!=='geneva'&&!officeOwned(hub.id)?`${officeUnlocked(officeLabel)?'OFFICE READY':'OFFICE L'+officeLabel.minLevel} · `:'';
        ctx.fillText(`${lockedMarket ? '🔒 ' : ''}${officePrefix}${hub.name.toUpperCase()}`, p.x, p.y - (selectedHub ? 14 : 10));
      }
      ctx.restore();
      markerHitboxes.push({ id: hub.id, x: p.x, y: p.y, r: selectedHub ? 15 : 11, z: p.z });
    });
  }

  function drawInvestmentMarkers() {
    investmentHitboxes=[];
    investmentCatalog.forEach(asset=>{
      const record=investmentRecord(asset.id);
      if (!record.level && !record.buildingTo) return;
      const hub=getHub(asset.hub); if(!hub) return;
      const p=project(hub.lon,hub.lat,.025); if(p.z<=0) return;
      const chainColor={upstream:'#ffb45e',midstream:'#8fc0ff',downstream:'#b79bff'}[asset.chain];
      const selectedAsset=selected.type==='investment'&&selected.id===asset.id;
      const pulse=1+Math.sin(animationTime*.004+hub.lon)*.08;
      ctx.save();ctx.globalAlpha=clamp(p.z*1.5,.3,1);ctx.translate(p.x+13,p.y-9);
      ctx.fillStyle='rgba(4,15,25,.9)';ctx.strokeStyle=chainColor;ctx.lineWidth=selectedAsset?2:1;
      ctx.beginPath();ctx.arc(0,0,(selectedAsset?8:6)*pulse,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.fillStyle=chainColor;ctx.font='700 8px Inter,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(record.buildingTo?'⌛':String(record.level),0,.5);
      ctx.restore();investmentHitboxes.push({id:asset.id,x:p.x+13,y:p.y-9,r:12,z:p.z});
    });
  }

  function pointOnRoute(opp, t) {
    const points = routePoints(opp, 70);
    const targetIndex = clamp(Math.floor(t * (points.length - 1)), 0, points.length - 1);
    return points[targetIndex];
  }

  function visualDealProgress(deal) {
    const interval = runningSpeed === 5 ? 430 : 1800;
    const fraction = runningSpeed > 0 ? clamp((animationTime - simulationDayAnchor) / interval, 0, .98) : 0;
    return clamp((deal.elapsed + fraction) / deal.duration, 0, 1);
  }

  function vehicleTypeForDeal(deal, progress) {
    const opp=getOpportunity(deal.opportunityId);
    const mode=(opp.transportMode||'').toLowerCase();
    if ((opp.via||[]).length && progress>.84) return mode.includes('rail') ? 'train' : 'truck';
    if (mode.includes('tanker')) return 'tanker';
    if (mode.includes('bulk') || mode.includes('panamax')) return 'bulk';
    if (mode.includes('ocean') || mode.includes('container')) return 'ship';
    if (mode.includes('barge')) return 'barge';
    if (mode.includes('rail')) return 'train';
    return 'truck';
  }

  function drawVehicleIcon(type,color,selected=false) {
    ctx.shadowColor=color; ctx.shadowBlur=selected?20:12; ctx.fillStyle=color; ctx.strokeStyle='rgba(225,247,255,.9)'; ctx.lineWidth=.8;
    if (['ship','tanker','bulk','barge'].includes(type)) {
      const length=type==='bulk'?18:type==='tanker'?17:type==='barge'?14:16;
      ctx.beginPath(); ctx.moveTo(length*.62,0); ctx.lineTo(length*.35,-4); ctx.lineTo(-length*.48,-4); ctx.lineTo(-length*.62,0); ctx.lineTo(-length*.45,4); ctx.lineTo(length*.35,4); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle='rgba(5,18,29,.88)'; ctx.fillRect(-4,-6,7,4);
      if(type==='tanker'){ctx.fillStyle='rgba(225,247,255,.45)';[-5,1,7].forEach(x=>{ctx.beginPath();ctx.arc(x,0,1.8,0,Math.PI*2);ctx.fill();});}
      if(type==='bulk'){ctx.fillStyle='rgba(225,247,255,.35)';[-6,0,6].forEach(x=>ctx.fillRect(x-2,-2,4,4));}
    } else if(type==='train') {
      ctx.fillRect(-9,-4,14,8); ctx.beginPath();ctx.moveTo(5,-4);ctx.lineTo(10,0);ctx.lineTo(5,4);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle='rgba(5,18,29,.9)';ctx.fillRect(-6,-2,4,3);ctx.fillRect(0,-2,3,3);
    } else {
      ctx.fillRect(-8,-4,10,8);ctx.beginPath();ctx.moveTo(2,-4);ctx.lineTo(8,-2);ctx.lineTo(8,4);ctx.lineTo(2,4);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle='rgba(5,18,29,.9)';ctx.fillRect(3,-2,3,3);
    }
  }

  // v46 - scia della nave: sfumatura sui singoli segmenti del percorso appena
  // compiuto. Lavora sugli indici dei punti, non su intervalli di globalT: con
  // intervalli troppo stretti una rotta a 2 tratte non aveva abbastanza punti.
  function drawShipTrail(opp, progress, color) {
    const points = routePoints(opp, 70);
    const last = points.length - 1;
    if (last < 2) return;
    const headIndex = clamp(Math.floor(progress * last), 0, last);
    const trailLength = Math.max(4, Math.round(last * 0.10));
    const startIndex = Math.max(0, headIndex - trailLength);
    if (headIndex - startIndex < 2) return;
    const rgb = color === '#ff6479' ? '255,100,121' : '97,242,166';
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = startIndex; i < headIndex; i++) {
      const fade = (i - startIndex) / (headIndex - startIndex); // 0 in coda, 1 alla nave
      const a = points[i], b = points[i + 1];
      const pa = project(a.lon, a.lat, Math.sin(a.globalT * Math.PI) * .058);
      const pb = project(b.lon, b.lat, Math.sin(b.globalT * Math.PI) * .058);
      if (pa.z <= -.01 || pb.z <= -.01) continue;
      ctx.strokeStyle = `rgba(${rgb},${(fade * fade * .6).toFixed(3)})`;
      ctx.lineWidth = .6 + fade * 2.6;
      ctx.beginPath();
      ctx.moveTo(pa.x, pa.y);
      ctx.lineTo(pb.x, pb.y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawShipments() {
    if (!layers.logistics || !layers.portfolio) return;
    state.activeDeals.forEach(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const progress = visualDealProgress(deal);
      const point = pointOnRoute(opp, progress);
      const nextPoint=pointOnRoute(opp,Math.min(.999,progress+.008));
      const p = project(point.lon, point.lat, .061 * Math.sin(progress * Math.PI));
      const pn=project(nextPoint.lon,nextPoint.lat,.061*Math.sin(Math.min(.999,progress+.008)*Math.PI));
      if (p.z <= -.02) return;
      const selectedShip = selected.type === 'deal' && selected.id === deal.id;
      const color = deal.pendingDecision ? '#ff6479' : '#61f2a6';
      const angle=Math.atan2(pn.y-p.y,pn.x-p.x);
      const type=vehicleTypeForDeal(deal,progress);
      // v46 - scia a cometa: il tratto appena percorso resta illuminato e
      // sfuma all'indietro, cosi' si capisce da dove arriva il carico.
      if (motionEnabled()) drawShipTrail(opp, progress, color);
      ctx.save();
      ctx.globalAlpha = clamp((p.z + .15) * 1.3, .25, 1);
      ctx.translate(p.x,p.y);ctx.rotate(angle);
      if(['ship','tanker','bulk','barge'].includes(type)){
        ctx.strokeStyle='rgba(200,232,255,.34)';ctx.lineWidth=1.2;ctx.setLineDash([2,3]);
        ctx.beginPath();ctx.moveTo(-12,-3);ctx.lineTo(-25,-6);ctx.moveTo(-12,3);ctx.lineTo(-25,6);ctx.stroke();ctx.setLineDash([]);
      } else {
        ctx.strokeStyle='rgba(97,242,166,.28)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-10,0);ctx.lineTo(-24,0);ctx.stroke();
      }
      // alone pulsante quando il carico richiede una decisione
      if (deal.pendingDecision) {
        const pulse = .5 + Math.sin(animationTime * .006) * .5;
        ctx.save(); ctx.rotate(-angle);
        ctx.strokeStyle = `rgba(255,100,121,${(.28 + pulse * .5).toFixed(3)})`;
        ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(0, 0, 12 + pulse * 5, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
      }
      drawVehicleIcon(type,color,selectedShip);
      ctx.restore();
      const hoveredShip = hoveredTarget?.type === 'deal' && hoveredTarget.id === deal.id;
      if(globeOptions.labels && (selectedShip || hoveredShip)){ctx.save();ctx.font='700 8px Inter,sans-serif';ctx.textAlign='center';ctx.fillStyle='rgba(235,249,255,.9)';ctx.fillText(`${type.toUpperCase()} · ${Math.round(progress*100)}%`,p.x,p.y-14);ctx.restore();}
      shipHitboxes.push({ id: deal.id, x: p.x, y: p.y, r: 16, z: p.z });
    });
  }


  function drawFleetAssets() {
    if (!layers.logistics) return;
    state.fleetAssets.filter(asset => asset.status === 'available').forEach(asset => {
      const hub = getHub(asset.positionHub);
      if (!hub) return;
      const p = project(hub.lon, hub.lat, .045);
      if (p.z <= 0) return;
      const isSelected = selected.type === 'vessel' && selected.id === asset.id;
      ctx.save();
      ctx.globalAlpha = clamp(p.z * 1.6, .3, 1);
      ctx.translate(p.x + 10, p.y + 8);
      ctx.fillStyle = '#ad8cff';
      ctx.shadowColor = '#ad8cff';
      ctx.shadowBlur = isSelected ? 18 : 9;
      ctx.beginPath();
      ctx.moveTo(0, -6); ctx.lineTo(6, 0); ctx.lineTo(0, 6); ctx.lineTo(-6, 0); ctx.closePath();
      ctx.fill();
      ctx.restore();
      fleetHitboxes.push({ id: asset.id, x: p.x + 10, y: p.y + 8, r: 13, z: p.z });
    });
  }

  function findGlobeTarget(x, y) {
    const groups = [
      { type: 'investment', items: investmentHitboxes },
      { type: 'vessel', items: fleetHitboxes },
      { type: 'deal', items: shipHitboxes },
      { type: 'hub', items: markerHitboxes }
    ];
    for (const group of groups) {
      const hit = [...group.items].sort((a,b) => b.z - a.z).find(item => Math.hypot(x - item.x, y - item.y) <= item.r);
      if (hit) return { type: group.type, id: hit.id };
    }
    return null;
  }

  function globeTargetCopy(target) {
    if (!target) return null;
    if (target.type === 'hub') {
      const hub = getHub(target.id);
      return hub ? { eyebrow: hub.type, title: hub.name, detail: `${hub.country} · ${hub.subtitle}` } : null;
    }
    if (target.type === 'deal') {
      const deal = getActiveDeal(target.id);
      if (!deal) return null;
      const opp = getOpportunity(deal.opportunityId);
      const progress = visualDealProgress(deal);
      return { eyebrow: 'Moving cargo', title: opp.title, detail: `${getHub(opp.origin).name} → ${getHub(opp.destination).name} · ${Math.round(progress * 100)}%` };
    }
    if (target.type === 'vessel') {
      const vessel = getFleetAsset(target.id);
      return vessel ? { eyebrow: 'Fleet asset', title: vessel.name, detail: `${vessel.className || vessel.vesselClass || 'Chartered vessel'} · ${getHub(vessel.positionHub)?.name || 'At sea'}` } : null;
    }
    if (target.type === 'investment') {
      const asset = investmentDefinition(target.id);
      const record = investmentRecord(target.id);
      return asset ? { eyebrow: `${asset.chain} asset`, title: asset.name, detail: `${getHub(asset.hub)?.name || ''} · Level ${record.level || 0}` } : null;
    }
    return null;
  }

  function updateGlobeTooltip(target, x, y) {
    hoveredTarget = target;
    const tooltip = $('#globeTooltip');
    if (!tooltip || !target) {
      tooltip?.classList.remove('visible');
      tooltip?.setAttribute('aria-hidden', 'true');
      canvas.style.cursor = dragging ? 'grabbing' : 'grab';
      return;
    }
    const copy = globeTargetCopy(target);
    if (!copy) return updateGlobeTooltip(null, x, y);
    tooltip.innerHTML = `<span>${copy.eyebrow}</span><strong>${copy.title}</strong><small>${copy.detail}</small>`;
    const maxX = Math.max(8, (canvasRect?.width || 0) - 245);
    const maxY = Math.max(8, (canvasRect?.height || 0) - 105);
    tooltip.style.left = `${clamp(x, 8, maxX)}px`;
    tooltip.style.top = `${clamp(y, 8, maxY)}px`;
    tooltip.classList.add('visible');
    tooltip.setAttribute('aria-hidden', 'false');
    canvas.style.cursor = 'pointer';
  }

  function renderLiveTracker() {
    const tracker = $('#liveTracker');
    const deal = trackingDealId ? getActiveDeal(trackingDealId) : null;
    if (!tracker || !deal) {
      tracker?.classList.remove('open');
      tracker?.setAttribute('aria-hidden', 'true');
      if (!deal) { trackingDealId = null; followCargo = false; }
      return;
    }
    const opp = getOpportunity(deal.opportunityId);
    const progress = visualDealProgress(deal);
    const remainingDays = Math.max(0, Math.ceil(deal.duration * (1 - progress)));
    const eta = new Date(currentDate());
    eta.setUTCDate(eta.getUTCDate() + remainingDays);
    const mode = vehicleTypeForDeal(deal, progress);
    $('#trackerTitle').textContent = opp.title;
    $('#trackerRoute').textContent = `${getHub(opp.origin).name} → ${getHub(opp.destination).name}`;
    $('#trackerProgress').textContent = `${Math.round(progress * 100)}%`;
    $('#trackerProgressBar').style.width = `${progress * 100}%`;
    $('#trackerEta').textContent = remainingDays ? formatDate(eta) : 'Arriving';
    $('#trackerMode').textContent = mode.charAt(0).toUpperCase() + mode.slice(1);
    $('#trackerPnl').textContent = money(computeUnrealizedPnl(deal));
    $('#trackerPnl').className = computeUnrealizedPnl(deal) >= 0 ? 'positive' : 'negative';
    $('#followCargoButton').textContent = followCargo ? 'Stop following' : 'Follow cargo';
    $('#followCargoButton').classList.toggle('active', followCargo);
    tracker.classList.add('open');
    tracker.setAttribute('aria-hidden', 'false');
  }

  function openLiveTracker(dealId, follow = false) {
    if (!getActiveDeal(dealId)) return;
    trackingDealId = dealId;
    followCargo = follow;
    renderLiveTracker();
  }

  function closeLiveTracker() {
    trackingDealId = null;
    followCargo = false;
    renderLiveTracker();
  }

  function animate(timestamp) {
    animationTime = timestamp;
    if (timestamp - lastDrawTime >= 32) {
      lastDrawTime = timestamp;
      const trackedDeal = followCargo && trackingDealId ? getActiveDeal(trackingDealId) : null;
      if (trackedDeal) {
        const opp = getOpportunity(trackedDeal.opportunityId);
        const point = pointOnRoute(opp, visualDealProgress(trackedDeal));
        view.targetLon = point.lon;
        view.targetLat = clamp(point.lat * .80, -58, 62);
        view.zoom = Math.max(view.zoom, 1.10);
      } else if (globeOptions.autoRotate && !dragging && view.targetLon === null && !leftDrawerOpen && !inspectorOpen && timestamp - lastInteractionTime > 2200) {
        view.lon = ((view.lon + 0.025 + 540) % 360) - 180;
      }
      if (view.targetLon !== null) {
        let diffLon = ((view.targetLon - view.lon + 540) % 360) - 180;
        const diffLat = view.targetLat - view.lat;
        view.lon += diffLon * (trackedDeal ? .20 : .12);
        view.lat += diffLat * (trackedDeal ? .20 : .12);
        if (!trackedDeal && Math.abs(diffLon) < .08 && Math.abs(diffLat) < .08) {
          view.lon = view.targetLon;
          view.lat = view.targetLat;
          view.targetLon = null;
          view.targetLat = null;
        }
      }
      renderEarth(timestamp);
      drawGlobe();
      renderLiveTracker();
    }
    _animationHandle = requestAnimationFrame(animate);
  }

  function focusOnHub(hubId) {
    const hub = getHub(hubId);
    if (!hub) return;
    view.targetLon = hub.lon;
    view.targetLat = clamp(hub.lat * .72, -52, 58);
  }

  function focusOnOpportunity(oppId) {
    const opp = getOpportunity(oppId);
    const a = getHub(opp.origin);
    const b = getHub(opp.destination);
    let lonA = a.lon;
    let lonB = b.lon;
    if (Math.abs(lonA-lonB) > 180) { if (lonA < lonB) lonA += 360; else lonB += 360; }
    let centerLon = (lonA + lonB) / 2;
    if (centerLon > 180) centerLon -= 360;
    view.targetLon = centerLon;
    view.targetLat = clamp((a.lat+b.lat)/2*.65, -42, 50);
    view.zoom = .88;
  }

  function focusOnDeal(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal) return;
    const opp = getOpportunity(deal.opportunityId);
    const point = pointOnRoute(opp, computeDealProgress(deal));
    view.targetLon = point.lon;
    view.targetLat = clamp(point.lat*.75, -50, 55);
    view.zoom = 1.05;
  }

  const drawerLabels = {
    portfolio: 'Trading desk', inventory: 'Physical inventory', operations: 'Operations center', supply: 'Supply chain control', contracts: 'Contracts & credit',
    fleet: 'Fleet desk', risk: 'Risk dashboard', opportunities: 'Opportunity market', rivals: 'Competitive intelligence', strategy: 'Board strategy', expansion: 'Strategic growth office',
    counterparties: 'Commercial network', compliance: 'Compliance desk', events: 'Global intelligence', finance: 'Treasury desk', performance: 'Performance office',
    academy: 'WoT Academy', empire: 'Trading empire', shop: 'Empire shop', hq: 'Headquarters',
    career: 'Career progression', leaderboard: 'Career League'
  };

  function drawerLabel(id) {
    if (state && state.language === 'it' && drawerLabelsIT[id]) return drawerLabelsIT[id];
    return drawerLabels[id];
  }

  // ── v52 · il mentore ────────────────────────────────────────────────────────
  // Ogni modulo che si sblocca viene presentato da Hélène Marchand, head trader
  // del desk di Ginevra: cos'è, come si usa, e la cosa che fa più danni se la
  // ignori. Le schede restano riapribili dal pulsante "?" di ogni sezione.
  const MENTOR = { name: 'Hélène Marchand', role: 'Head Trader · Geneva desk' };

  const moduleBriefings = {
    portfolio: {
      lead: 'This is your book. Everything you have money in, and what it is worth right now.',
      how: 'The equity curve tracks your net asset value against the capital you started with. Below it sit your open cargoes: each card shows unrealized P&L, days to arrival, hedge level and how ready the operation is.',
      watch: 'Unrealized P&L is not money. It becomes real only at settlement, after financing, operations and market moves have taken their cut.'
    },
    opportunities: {
      lead: 'The market. Buyers who need a cargo, sellers who have one, and a margin in between if you can execute.',
      how: 'Offers refresh every seven game days. Compare expected margin against the capital it locks up and the days it takes — a small fast cargo can beat a large slow one. Click a route to open it on the globe and negotiate.',
      watch: 'A high headline margin means nothing until you check what the deal needs upfront: your own equity, plus futures margin, plus the reserve your capital policy keeps untouched.'
    },
    inventory: {
      lead: 'Your physical position: tonnes you own, where they are, and what phase they are in.',
      how: 'Each cargo moves through sourcing, loading, transit and discharge. Value is marked against the current market price, so it drifts while the ship sails.',
      watch: 'Physical commodity is not a spreadsheet entry. It sits somewhere, it costs money to sit there, and quality disputes happen on arrival, not at signing.'
    },
    operations: {
      lead: 'Execution. Documents, carriers, terminals, and everything that can delay a cargo.',
      how: 'The readiness score aggregates paperwork, transport booking and terminal slots. You can pay to expedite documents or upgrade transport when a deadline is at risk.',
      watch: 'Readiness below 70% costs you reputation at settlement even if the trade makes money. Buyers remember late deliveries longer than good prices.'
    },
    supply: {
      lead: 'The network behind the trade: congestion, capacity and long-term supplier commitments.',
      how: 'Every corridor has a congestion score that adds days and freight cost at booking. Procurement agreements lock in supply at agreed terms, in exchange for volume commitments.',
      watch: 'A framework you cannot fill costs you a penalty. Commit to volumes you can actually move.'
    },
    contracts: {
      lead: 'What happens after the cargo lands: invoices, payment terms and getting paid.',
      how: 'Delivered cargoes become receivables. Payment terms you agreed in negotiation decide when cash comes back — and whether the buyer can default before it does.',
      watch: 'Selling on thirty days is a loan to your buyer. Cheap when they are good, expensive when they are not. Credit insurance and factoring exist for the second case.'
    },
    fleet: {
      lead: 'Ships. Chartering them, positioning them, and deciding whether to own or hire.',
      how: 'Charter from the market for a set number of days, then assign a vessel to a cargo. An owned or time-chartered ship at the right port improves your margin and your execution certainty.',
      watch: 'A chartered vessel costs money whether or not you use it. Position matters as much as capacity: a ship on the wrong ocean is a bill, not an asset.'
    },
    risk: {
      lead: 'What could hurt you, measured. Flat price, currency, concentration, liquidity, credit.',
      how: 'The risk score aggregates your exposures. Flat-price risk is the tonnes you have not hedged; concentration is having too much in one commodity or corridor; liquidity is whether you could survive a margin call.',
      watch: 'The exposure that kills a desk is rarely the one it was watching. Diversify before you have to.'
    },
    opportunitiesAlias: null,
    counterparties: {
      lead: 'The people you trade with. In physical, relationships are collateral.',
      how: 'Every supplier and buyer carries a credit rating, a reliability score and a relationship level with you. Relationship rises with punctual, clean execution and falls with claims and delays. It moves the terms you can get.',
      watch: 'Your buyer credit limit is a hard ceiling on deal size. Improve the relationship, secure the payment, or request a limit increase before you need it.'
    },
    finance: {
      lead: 'Treasury. Where the money to fund cargoes comes from, and what it costs.',
      how: 'Cargoes are funded by your equity plus bank facilities. Interest accrues daily on what you borrow. Futures collateral sits here too, and moves when prices move against your hedge.',
      watch: 'A margin call does not ask whether it is convenient. Keep liquidity headroom, or the desk finances itself at emergency rates.'
    },
    compliance: {
      lead: 'Know your counterparty, and know your cargo. The part nobody thanks you for until it goes wrong.',
      how: 'Higher-risk routes and counterparties need enhanced due diligence before you can trade them. Cleared reviews stay valid for the market cycle. The decision journal records what you chose and why.',
      watch: 'A blocked counterparty is not a negotiation. Clear the review first, or the deal simply cannot open.'
    },
    events: {
      lead: 'The world, interfering. Strikes, weather, sanctions, transit closures, supply shocks.',
      how: 'Active disruptions change prices, freight, financing rates, timing and buyer appetite. They affect cargoes that match their profile — a Suez closure only hurts if you are shipping through it.',
      watch: 'On a thirty-five day voyage you will meet two or three of these. Build the expectation into the margin you accept, not into your hopes.'
    },
    performance: {
      lead: 'Where the money actually came from, and whether the desk would survive a shock.',
      how: 'P&L attribution splits your result into commercial margin, market moves, currency, financing and operations. The scenario lab applies severe shocks to your current book and reports the damage.',
      watch: 'A profitable desk that only makes money on flat price is a lucky desk, not a good one. Read the attribution honestly.'
    },
    academy: {
      lead: 'The theory, short enough to read between cargoes.',
      how: 'Lessons cover pricing, hedging, incoterms, trade finance and logistics, with a glossary linked to the terms used across the interface.',
      watch: 'Nothing here is required to play. All of it makes the difference between guessing and deciding.'
    },
    career: {
      lead: 'Your track record: role, missions, achievements and how you got here.',
      how: 'Missions reward specific behaviours — a hedged profitable cargo, a second office, a full quarter above target. Analytics break your results down by commodity and corridor.',
      watch: 'Experience level opens the interface and the trading licences. Reputation opens the offices. They are not the same currency.'
    },
    rivals: {
      lead: 'Eight competing desks. They want the same cargoes you do.',
      how: 'Each has a specialisation, an aggression and a discipline. Competitive pressure on a tender lowers the margin you can hold and the odds you win it. The head-to-head record tracks the tenders you actually contested.',
      watch: 'Aggressive desks overpay and overextend. Disciplined desks walk away. Knowing which one you are bidding against is worth more than a lower price.'
    },
    strategy: {
      lead: 'How the desk operates, and what the board expects of it.',
      how: 'A doctrine sets your operating model — margin, risk appetite, overhead, capital intensity. Seasonal demand shows which commodities are in their window. Board mandates set long-term objectives.',
      watch: 'A doctrine is a commitment, not a bonus. It changes your economics in both directions, and you cannot switch it every week.'
    },
    expansion: {
      lead: 'Growing the house: headquarters, international offices, specialisation, market standing.',
      how: 'Offices unlock the corridors around them and improve the terms you get there. Each has a reputation and cargo threshold to open, and a daily cost once running.',
      watch: 'This is the module that opens the game. Most routes in the world need an office nearby, not a higher level. Genoa is the cheapest first step.'
    },
    hq: {
      lead: 'The organisation: office network, project teams and the specialists you hire.',
      how: 'HQ tiers add margin, acceptance, credit capacity and risk reduction, at a rising daily cost. Specialists each remove a specific friction — documents, hedging, chartering, trade finance.',
      watch: 'Every upgrade is permanent overhead. Grow the cost base after the revenue, not before it.'
    },
    shop: {
      lead: 'Permanent capacity: vessels, warehouses, terminals. Assets instead of rentals.',
      how: 'Purchases occupy a project team until delivery, then generate lasting operating advantages on matching cargoes — better freight, lower equity requirements, storage optionality.',
      watch: 'Owned capacity pays off with volume. Buy it when your flow justifies it, not because the balance looks healthy today.'
    },
    empire: {
      lead: 'Vertical integration: mines, refineries, terminals, distribution. Owning the chain.',
      how: 'Upstream secures supply, midstream captures processing, downstream reaches the end buyer. Each asset takes capital and construction time, then produces income and structural advantages.',
      watch: 'Integration ties you to a commodity. It is the strongest position in physical trading and the hardest to unwind.'
    },
    leaderboard: {
      lead: 'Where your house stands against the industry.',
      how: 'Rating combines realized P&L, execution quality, risk discipline and reach. Seasons are archived every ninety game days.',
      watch: 'The ranking rewards consistency, not a single lucky quarter.'
    },
  };
  delete moduleBriefings.opportunitiesAlias;

  function moduleBriefing(tab) { return moduleBriefings[tab] || null; }

  // Coda: quando un livello apre due moduli insieme si presentano uno dopo l'altro
  let _mentorQueue = [];
  let _mentorTimer = null;

  function queueMentorBriefing(tab, reason = 'unlock') {
    if (!moduleBriefing(tab)) return;
    if (_mentorQueue.some(item => item.tab === tab)) return;
    _mentorQueue.push({ tab, reason });
    if (!_mentorTimer) _mentorTimer = setTimeout(showNextMentorBriefing, 460);
  }

  function showMentorBriefing(tab, reason = 'reference') {
    const briefing = moduleBriefing(tab);
    const dialog = $('#mentorDialog');
    if (!briefing) return;
    if (!dialog) { showToast(briefing.lead, 'info'); return; }
    if (dialog.open) { queueMentorBriefing(tab, reason); return; }
    $('#mentorName').textContent = MENTOR.name;
    $('#mentorRole').textContent = MENTOR.role;
    $('#mentorTitle').textContent = drawerLabel(tab) || tab;
    $('#mentorLead').textContent = briefing.lead;
    $('#mentorHow').textContent = briefing.how;
    $('#mentorWatch').textContent = briefing.watch;
    const tag = $('#mentorTag');
    if (tag) {
      tag.textContent = reason === 'unlock' ? `Unlocked at level ${moduleUnlockLevel(tab)}` : 'Briefing';
      tag.classList.toggle('unlock', reason === 'unlock');
    }
    const close = $('#mentorCloseButton');
    if (close) close.textContent = reason === 'unlock' ? 'Got it' : 'Close';
    try { Sound.play('info'); } catch (error) {}
    dialog.showModal();
  }

  function showNextMentorBriefing() {
    _mentorTimer = null;
    const next = _mentorQueue.shift();
    if (!next) return;
    const dialog = $('#mentorDialog');
    if (dialog?.open) { _mentorQueue.unshift(next); _mentorTimer = setTimeout(showNextMentorBriefing, 700); return; }
    showMentorBriefing(next.tab, next.reason);
  }

  const searchModuleIcons = {
    portfolio:'◇', inventory:'▣', operations:'≋', supply:'⛓', contracts:'§', fleet:'⌁', risk:'!', opportunities:'◎', rivals:'⚔', strategy:'◈', expansion:'↗',
    counterparties:'○', compliance:'✓', events:'⚠', finance:'$', performance:'Σ', academy:'A', empire:'▲', shop:'▦', hq:'⌂', career:'↗', leaderboard:'#'
  };

  function buildGlobalSearchItems() {
    const modules = Object.keys(drawerLabels).filter(moduleUnlocked).map((id) => ({ type:'module', id, title:drawerLabel(id), subtitle:'Open command-center module', icon:searchModuleIcons[id] || '•', group:'Modules' }));
    const hubItems = hubs.filter(hub => hubVisible(hub) || hub.type === 'hq').map(hub => ({ type:'hub', id:hub.id, title:hub.name, subtitle:`${hub.country} · ${hub.subtitle}`, icon:hub.type === 'port' ? '⚓' : hub.type === 'supplier' ? '↑' : hub.type === 'customer' ? '↓' : '⌂', group:'World' }));
    const dealItems = state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      return { type:'deal', id:deal.id, title:opp.title, subtitle:`${getHub(opp.origin).name} → ${getHub(opp.destination).name} · ${Math.round(visualDealProgress(deal)*100)}%`, icon:'➤', group:'Live cargo' };
    });
    const opportunityItems = opportunities.filter(isOpportunityUnlocked).filter(opportunityAvailable).map(opp => ({ type:'opportunity', id:opp.id, title:opp.title, subtitle:`${opp.commodity} · ${getHub(opp.origin).name} → ${getHub(opp.destination).name}`, icon:'◆', group:'Opportunities' }));
    const investmentItems = investmentCatalog.filter(asset => { const record=investmentRecord(asset.id); return record.level || record.buildingTo; }).map(asset => ({ type:'investment', id:asset.id, title:asset.name, subtitle:`${asset.chain} · ${getHub(asset.hub)?.name || ''}`, icon:asset.icon || '▲', group:'Owned assets' }));
    return [...modules, ...dealItems, ...opportunityItems, ...hubItems, ...investmentItems];
  }

  function executeSearchItem(item) {
    const dialog = $('#searchDialog');
    dialog?.close();
    if (item.type === 'module') openLeftDrawer(item.id);
    else if (item.type === 'hub') selectHub(item.id);
    else if (item.type === 'deal') trackLiveDeal(item.id);
    else if (item.type === 'opportunity') selectOpportunity(item.id);
    else if (item.type === 'investment') selectInvestment(item.id);
  }

  function renderGlobalSearch(query = '') {
    const container = $('#globalSearchResults');
    if (!container) return;
    const term = query.trim().toLowerCase();
    searchItems = buildGlobalSearchItems().filter(item => !term || `${item.title} ${item.subtitle} ${item.group}`.toLowerCase().includes(term)).slice(0, 28);
    searchActiveIndex = clamp(searchActiveIndex, 0, Math.max(0, searchItems.length - 1));
    if (!searchItems.length) { container.innerHTML = '<div class="search-empty">No results. Try a city, commodity or function.</div>'; return; }
    const groups = [...new Set(searchItems.map(item => item.group))];
    container.innerHTML = groups.map(group => `<div class="search-group-title">${group}</div>${searchItems.map((item,index) => ({item,index})).filter(row => row.item.group === group).map(({item,index}) => `<button type="button" class="search-result ${index === searchActiveIndex ? 'active' : ''}" data-search-index="${index}"><span class="search-result-icon">${item.icon}</span><span><strong>${item.title}</strong><small>${item.subtitle}</small></span><kbd>↵</kbd></button>`).join('')}`).join('');
    $$('[data-search-index]', container).forEach(button => button.addEventListener('click', () => executeSearchItem(searchItems[Number(button.dataset.searchIndex)])));
    container.querySelector('.search-result.active')?.scrollIntoView({ block:'nearest' });
  }

  function openGlobalSearch() {
    const dialog = $('#searchDialog');
    if (!dialog || dialog.open) return;
    searchActiveIndex = 0;
    renderGlobalSearch('');
    dialog.showModal();
    setTimeout(() => { const input=$('#globalSearchInput'); if (input) { input.value=''; input.focus(); } }, 20);
  }


  function recommendedOpportunity() {
    const candidates = opportunities
      .filter(isOpportunityUnlocked)
      .filter(opportunityAvailable)
      .map(opp => {
        const economics = opportunityEconomics(opp);
        const capitalEfficiency = economics.expectedPnl / Math.max(1, economics.equity);
        const timeEfficiency = capitalEfficiency / Math.max(10, economics.duration);
        const riskPenalty = (opp.risk === 'High' ? .00045 : opp.risk === 'Medium' ? .00018 : 0);
        return { opp, economics, score: timeEfficiency - riskPenalty };
      })
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function briefingSignals() {
    const pending = state.activeDeals.filter(deal => deal.pendingDecision);
    const crises = activeCrisisDefinitions();
    const expiring = opportunities.filter(isOpportunityUnlocked).filter(opportunityAvailable).filter(opp => liveOffer(opp).expiresIn <= 2);
    const contested = opportunities.filter(isOpportunityUnlocked).filter(opportunityAvailable).filter(opp => {
      const tender = rivalTenderFor(opp.id);
      return tender?.status === 'open' && tender.awardDay - state.marketCycleDay <= 1;
    });
    const risk = riskStats();
    const recommended = recommendedOpportunity();
    const constructing = state.constructionQueue || [];
    const shopConstructing = state.shopOrders || [];
    const congestedDeals = state.activeDeals.filter(deal => !deal.delivered && !deal.routeMitigated && (deal.routeCondition?.score || 0) >= 70);
    const expiringAgreements = Object.values(state.procurementAgreements || {}).filter(item => item?.status === 'active' && item.daysRemaining <= 15 && item.liftings < item.commitment);
    const priorities = [];
    pending.forEach(deal => priorities.push({
      severity: 'critical',
      title: `Decision required · ${getOpportunity(deal.opportunityId)?.title || 'Active cargo'}`,
      copy: deal.eventResult || 'Operations cannot advance until this decision is resolved.',
      action: 'deal',
      id: deal.id
    }));
    if (risk.liquidityCoverage < 1.2 && state.activeDeals.length) priorities.push({
      severity: 'critical',
      title: 'Liquidity buffer under pressure',
      copy: `Coverage is ${risk.liquidityCoverage.toFixed(1)}× against the desk reserve. Review collateral and funding before advancing time.`,
      action: 'module',
      id: 'finance'
    });
    crises.slice(0, 2).forEach(event => priorities.push({
      severity: 'warning',
      title: event.title,
      copy: `${event.region || 'Global'} disruption · ${event.remaining} days remaining.`,
      action: 'module',
      id: 'events'
    }));
    contested.slice(0, 2).forEach(opp => {
      const tender = rivalTenderFor(opp.id);
      priorities.push({
        severity: 'critical',
        title: `Rival tender closing · ${opp.title}`,
        copy: `${rivalForTender(tender).name} leads at ${tender.pressure}% pressure. Submit terms before the next award decision.`,
        action: 'opportunity',
        id: opp.id
      });
    });
    expiring.slice(0, 2).forEach(opp => priorities.push({
      severity: 'warning',
      title: `${opp.title} expires soon`,
      copy: `${liveOffer(opp).expiresIn} days remaining in the current market cycle.`,
      action: 'opportunity',
      id: opp.id
    }));
    congestedDeals.slice(0, 2).forEach(deal => priorities.push({
      severity: 'warning',
      title: `Capacity risk · ${getOpportunity(deal.opportunityId).title}`,
      copy: `${deal.routeCondition.severity} congestion at ${deal.routeCondition.score}/100. Priority capacity can protect the ETA.`,
      action: 'deal',
      id: deal.id
    }));
    expiringAgreements.slice(0, 2).forEach(agreement => priorities.push({
      severity: 'critical',
      title: `Procurement commitment due · ${getCounterparty(agreement.supplierId)?.name || 'Supplier'}`,
      copy: `${agreement.daysRemaining} days left · ${Math.max(0,agreement.commitment-agreement.liftings)} cargo liftings still required.`,
      action: 'module',
      id: 'supply'
    }));
    if (recommended && !pending.length) priorities.push({
      severity: 'opportunity',
      title: `Best capital-adjusted opportunity · ${recommended.opp.title}`,
      copy: `${money(recommended.economics.expectedPnl)} expected P&L · ${money(recommended.economics.equity)} equity · ${recommended.economics.duration} days.`,
      action: 'opportunity',
      id: recommended.opp.id
    });
    if (constructing.length) priorities.push({
      severity: 'info',
      title: `${constructing.length} industrial project${constructing.length === 1 ? '' : 's'} under construction`,
      copy: 'Construction progress continues when the game clock advances.',
      action: 'module',
      id: 'empire'
    });
    if (shopConstructing.length) priorities.push({
      severity: 'info',
      title: `${shopConstructing.length} shop order${shopConstructing.length === 1 ? '' : 's'} under construction`,
      copy: 'Your permanent fleet and logistics assets progress whenever the game clock advances.',
      action: 'module',
      id: 'shop'
    });
    if (!priorities.length) priorities.push({
      severity: 'info',
      title: 'Desk is clear',
      copy: 'No urgent decisions. Review the market or invest in the physical value chain.',
      action: 'module',
      id: 'opportunities'
    });
    return { pending, crises, expiring, contested, congestedDeals, expiringAgreements, risk, recommended, priorities };
  }

  function briefingUnreadCount() {
    const signals = briefingSignals();
    let count = signals.pending.length + signals.crises.length + signals.expiring.length + signals.contested.length + signals.congestedDeals.length + signals.expiringAgreements.length;
    if (signals.risk.liquidityCoverage < 1.2 && state.activeDeals.length) count += 1;
    if (state.briefingViewedDay !== state.dayIndex) count = Math.max(1, count);
    return count;
  }

  // ── v47 · stati vuoti con un'azione ─────────────────────────────────────────
  // Una sezione vuota diceva soltanto che era vuota. Ora spiega qual e' il passo
  // successivo e ci porta con un click. Un solo handler delegato li serve tutti.
  function emptyState(message, action) {
    // v52 - con la scoperta progressiva dei moduli un pulsante poteva puntare a
    // una sezione non ancora sbloccata: in quel caso si mostra solo il messaggio.
    if (action && action.type === 'module' && !moduleUnlocked(action.id)) action = null;
    if (!action) return `<div class="empty-card">${message}</div>`;
    return `<div class="empty-card empty-card-action">
      <span>${message}</span>
      <button type="button" class="empty-action" data-empty-action="${action.type}:${action.id}">${action.label}</button>
    </div>`;
  }
  document.addEventListener('click', event => {
    const button = event.target.closest?.('[data-empty-action]');
    if (!button) return;
    const [type, ...rest] = button.dataset.emptyAction.split(':');
    executeBriefingAction(type, rest.join(':'));
    try { Sound.play('click'); } catch (error) {}
  });

  function executeBriefingAction(type, id) {
    closeBriefing();
    if (type === 'deal') selectDeal(id);
    else if (type === 'opportunity') selectOpportunity(id);
    else if (type === 'module') openLeftDrawer(id);
  }

  function renderBriefing() {
    const panel = $('#briefingPanel');
    if (!panel) return;
    const signals = briefingSignals();
    $('#briefingDate').textContent = `${formatDate(currentDate())} · Day ${state.dayIndex + 1} · ${rankFromState()}`;
    const stats = portfolioStats();
    $('#briefingScorecard').innerHTML = `
      <div><span>NAV</span><strong>${money(stats.nav, true)}</strong><small>${state.realizedPnl >= 0 ? '+' : ''}${money(state.realizedPnl)} realized</small></div>
      <div><span>Liquidity</span><strong>${money(state.cash, true)}</strong><small>${signals.risk.liquidityCoverage.toFixed(1)}× coverage</small></div>
      <div><span>Open cargoes</span><strong>${state.activeDeals.length}</strong><small>${money(stats.activePnl)} live P&L</small></div>
      <div><span>Desk risk</span><strong>${Math.round(signals.risk.riskScore)}</strong><small>${signals.risk.riskScore < 35 ? 'Controlled' : signals.risk.riskScore < 65 ? 'Elevated' : 'High'}</small></div>`;
    $('#briefingPriorities').innerHTML = signals.priorities.slice(0, 6).map((item, index) => `
      <button class="briefing-priority ${item.severity}" data-briefing-index="${index}">
        <i></i><span><strong>${item.title}</strong><small>${item.copy}</small></span><b>Open</b>
      </button>`).join('');
    $$('[data-briefing-index]', $('#briefingPriorities')).forEach(button => button.addEventListener('click', () => {
      const item = signals.priorities[Number(button.dataset.briefingIndex)];
      executeBriefingAction(item.action, item.id);
    }));
    const quick = [];
    if (signals.pending[0]) quick.push({ label: 'Resolve decision', type: 'deal', id: signals.pending[0].id });
    if (signals.recommended) quick.push({ label: 'Review best trade', type: 'opportunity', id: signals.recommended.opp.id });
    if (moduleUnlocked('risk')) quick.push({ label: 'Open risk desk', type: 'module', id: 'risk' });
    $('#briefingActions').innerHTML = quick.map((item, index) => `<button data-briefing-quick="${index}">${item.label}</button>`).join('');
    $$('[data-briefing-quick]', $('#briefingActions')).forEach(button => button.addEventListener('click', () => {
      const item = quick[Number(button.dataset.briefingQuick)];
      executeBriefingAction(item.type, item.id);
    }));
    const unread = briefingUnreadCount();
    const badge = $('#briefingBadge');
    badge.textContent = unread;
    badge.classList.toggle('hidden', unread <= 0 || briefingOpen);
  }

  function openBriefing() {
    briefingOpen = true;
    state.briefingViewedDay = state.dayIndex;
    saveState();
    leftDrawerOpen = false;
    inspectorOpen = false;
    overviewOpen = false;
    marketsOpen = false;
    layersOpen = false;
    renderBriefing();
    syncOverlayUI();
  }

  function closeBriefing() {
    briefingOpen = false;
    syncOverlayUI();
    renderBriefing();
  }

  // v47 - ogni passo indica un bersaglio reale nell'interfaccia. Il riflettore lo
  // ritaglia dallo sfondo scurito, cosi' si guarda l'elemento invece di cercarlo.
  const tutorialSteps = [
    {
      title: 'Read the opportunity market',
      copy: 'Physical trading starts with a buyer need and a viable source. Compare expected margin, equity, duration and route risk.',
      action: 'Open Market',
      target: () => $('#openDeskButton'),
      hint: 'Open the command centre from here.'
    },
    {
      title: 'Inspect a trade route',
      copy: 'Open the recommended opportunity and review origin, destination, commodity, freight path and counterparties.',
      action: 'Inspect opportunity',
      target: () => $('#opportunityList .opportunity-card') || $('#opportunityList') || $('[data-left-tab="opportunities"]'),
      hint: 'Each card is a cargo you can source and sell.'
    },
    {
      title: 'Negotiate commercial terms',
      copy: 'Balance buyer acceptance against margin. Price, payment and delivery terms change both economics and working capital.',
      action: 'Open negotiation',
      target: () => $('.negotiation-box', $('#inspectorContent')) || $('#inspectorContent'),
      hint: 'Terms are agreed here before any capital moves.'
    },
    {
      title: 'Structure and fund the deal',
      copy: 'Choose the hedge, FX coverage, financing, insurance, inspection and carrier before committing capital.',
      action: 'Open deal structure',
      target: () => $('#hedgeRatioInput')?.closest('.inspector-section') || $('#inspectorContent'),
      hint: 'The hedge decides how much price risk you keep.'
    },
    {
      title: 'Run the physical operation',
      copy: 'Advance time and monitor cargo, documents, collateral, interest and global disruptions.',
      action: 'Advance to next event',
      target: () => $('#nextEventButton'),
      hint: 'Time only moves when you let it.'
    },
    {
      title: 'Resolve the operational event',
      copy: 'Your response affects P&L, delivery time, reputation and counterparty relationships.',
      action: 'Open decision',
      target: () => ($('#eventBanner')?.classList.contains('hidden') ? null : $('#eventBanner')) || $('#inspectorContent'),
      hint: 'A decision is waiting: it will not resolve itself.'
    },
    {
      title: 'Reach settlement',
      copy: 'Advance to the next milestone. The final review attributes commercial, market, FX, finance and operational P&L.',
      action: 'Advance to settlement',
      target: () => $('#nextEventButton'),
      hint: 'Keep advancing until the cargo is paid.'
    },
    {
      title: 'First cargo completed',
      copy: 'You now control the full physical-trading cycle. Continue freely, build the company and climb the Career League.',
      action: 'Finish tour',
      target: () => $('.pnl-rail') || $('#realizedPnlMetric'),
      hint: 'Your realized P&L lives here.'
    }
  ];

  function inferredTutorialStep() {
    if (state.history.length) return 7;
    const pending = state.activeDeals.find(deal => deal.pendingDecision);
    if (pending) return 5;
    if (state.activeDeals.length) return state.activeDeals.some(deal => deal.eventResolved) ? 6 : 4;
    const accepted = opportunities.find(opp => state.negotiations?.[opp.id]?.cycle === state.marketCycle && state.negotiations[opp.id].status === 'accepted');
    if (accepted) return 3;
    if (selected.type === 'opportunity') return 2;
    if (activeLeftTab === 'opportunities' && leftDrawerOpen) return 1;
    return 0;
  }

  function currentTutorialStep() {
    state.tutorialStep = Math.max(state.tutorialStep || 0, inferredTutorialStep());
    return clamp(state.tutorialStep, 0, tutorialSteps.length - 1);
  }

  function runTutorialAction() {
    const step = currentTutorialStep();
    const recommended = recommendedOpportunity()?.opp;
    if (step === 0) {
      state.tutorialStep = 1;
      openLeftDrawer('opportunities');
    } else if (step === 1) {
      state.tutorialStep = 2;
      if (recommended) selectOpportunity(recommended.id);
      else openLeftDrawer('opportunities');
    } else if (step === 2) {
      if (selected.type === 'opportunity') selectOpportunity(selected.id);
      else if (recommended) selectOpportunity(recommended.id);
    } else if (step === 3) {
      const accepted = opportunities.find(opp => state.negotiations?.[opp.id]?.cycle === state.marketCycle && state.negotiations[opp.id].status === 'accepted');
      if (accepted) selectOpportunity(accepted.id);
    } else if (step === 4 || step === 6) {
      advanceToNextEvent();
    } else if (step === 5) {
      const pending = state.activeDeals.find(deal => deal.pendingDecision);
      if (pending) selectDeal(pending.id);
    } else {
      state.tutorialDismissed = true;
      state.tutorialEnabled = false;
      saveState();
      showToast('Guided first deal completed.');
    }
    renderTutorialCoach();
  }

  // ── v47 · riflettore del tutorial ───────────────────────────────────────────
  // Il coach descriveva i passi a parole da un angolo dello schermo. Ora ritaglia
  // l'elemento di cui sta parlando: lo sfondo si scurisce tranne quel rettangolo.
  let _spotlightTarget = null;
  let _spotlightRaf = null;

  function updateSpotlight() {
    const ring = $('#tutorialSpotlight');
    const hint = $('#tutorialSpotlightHint');
    if (!ring) return;
    const element = _spotlightTarget;
    if (!element || !element.isConnected) { hideSpotlight(); return; }
    const rect = element.getBoundingClientRect();
    if (!rect.width || !rect.height || rect.bottom < 0 || rect.top > window.innerHeight) { hideSpotlight(); return; }
    const pad = 7;
    ring.style.top = `${rect.top - pad}px`;
    ring.style.left = `${rect.left - pad}px`;
    ring.style.width = `${rect.width + pad * 2}px`;
    ring.style.height = `${rect.height + pad * 2}px`;
    if (hint) {
      // il fumetto va sopra o sotto a seconda dello spazio disponibile
      const below = rect.bottom + 14;
      const fitsBelow = below + 64 < window.innerHeight;
      hint.style.top = fitsBelow ? `${below}px` : `${Math.max(8, rect.top - 62)}px`;
      hint.style.left = `${clamp(rect.left + rect.width / 2 - 130, 8, Math.max(8, window.innerWidth - 268))}px`;
    }
    _spotlightRaf = requestAnimationFrame(updateSpotlight);
  }

  function showSpotlight(element, hintText) {
    const ring = $('#tutorialSpotlight');
    const hint = $('#tutorialSpotlightHint');
    if (!ring || !element) return hideSpotlight();
    _spotlightTarget = element;
    document.body.classList.add('spotlight-active');
    ring.hidden = false;
    if (hint) { hint.hidden = !hintText; hint.textContent = hintText || ''; }
    if (_spotlightRaf) cancelAnimationFrame(_spotlightRaf);
    updateSpotlight();
  }

  function hideSpotlight() {
    _spotlightTarget = null;
    if (_spotlightRaf) { cancelAnimationFrame(_spotlightRaf); _spotlightRaf = null; }
    document.body.classList.remove('spotlight-active');
    const ring = $('#tutorialSpotlight'); if (ring) ring.hidden = true;
    const hint = $('#tutorialSpotlightHint'); if (hint) hint.hidden = true;
  }

  function renderTutorialCoach() {
    const coach = $('#tutorialCoach');
    if (!coach) return;
    const visible = state.onboardingComplete && state.tutorialEnabled && !state.tutorialDismissed;
    coach.classList.toggle('open', visible);
    coach.setAttribute('aria-hidden', String(!visible));
    if (!visible) { hideSpotlight(); return; }
    const step = currentTutorialStep();
    const data = tutorialSteps[step];
    $('#tutorialStepLabel').textContent = `Guided career · ${step + 1}/${tutorialSteps.length}`;
    $('#tutorialTitle').textContent = data.title;
    $('#tutorialCopy').textContent = data.copy;
    $('#tutorialActionButton').textContent = data.action;
    $('#tutorialProgressBar').style.width = `${((step + 1) / tutorialSteps.length) * 100}%`;
    const back = $('#tutorialBackButton');
    back.disabled = step === 0;

    // il bersaglio puo' comparire subito dopo un render: si riprova a breve
    const aim = () => {
      let element = null;
      try { element = data.target?.(); } catch (error) { element = null; }
      if (element) showSpotlight(element, data.hint);
      else hideSpotlight();
    };
    aim();
    clearTimeout(coach._aimTimer);
    coach._aimTimer = setTimeout(aim, 260);
  }

  function syncOverlayUI() {
    const left = $('#leftDrawer');
    const right = $('#rightInspector');
    const backdrop = $('#drawerBackdrop');
    left?.classList.toggle('open', leftDrawerOpen);
    right?.classList.toggle('open', inspectorOpen);
    left?.setAttribute('aria-hidden', String(!leftDrawerOpen));
    right?.setAttribute('aria-hidden', String(!inspectorOpen));
    $('#briefingPanel')?.classList.toggle('open', briefingOpen);
    $('#briefingPanel')?.setAttribute('aria-hidden', String(!briefingOpen));
    backdrop?.classList.toggle('open', leftDrawerOpen || inspectorOpen || briefingOpen);
    backdrop?.setAttribute('aria-hidden', String(!(leftDrawerOpen || inspectorOpen || briefingOpen)));
    $('#overviewPanel')?.classList.add('open');
    $('#overviewPanel')?.setAttribute('aria-hidden', 'false');
    $('#marketStrip')?.classList.toggle('open', marketsOpen);
    $('#marketStrip')?.setAttribute('aria-hidden', String(!marketsOpen));
    $('#layerControls')?.classList.toggle('open', layersOpen);
    $('#layerControls')?.setAttribute('aria-hidden', String(!layersOpen));
    $('#globeLegend')?.classList.toggle('open', layersOpen);
    $('#globeLegend')?.setAttribute('aria-hidden', String(!layersOpen));
    $('#openDeskButton')?.classList.toggle('active', leftDrawerOpen);
    $('#openShopButton')?.classList.toggle('active', leftDrawerOpen && activeLeftTab === 'shop');
    $('#openOfficesButton')?.classList.toggle('active', leftDrawerOpen && activeLeftTab === 'expansion');
    $('#toggleOverviewButton')?.classList.toggle('active', overviewOpen);
    $('#toggleMarketsButton')?.classList.toggle('active', marketsOpen);
    $('#toggleLayersButton')?.classList.toggle('active', layersOpen);
    $('#openBriefingButton')?.classList.toggle('active', briefingOpen);
    document.body.classList.toggle('overlay-active', leftDrawerOpen || inspectorOpen || marketsOpen || layersOpen || briefingOpen);
  }

  function openLeftDrawer(tab = activeLeftTab) {
    activeLeftTab = tab;
    leftDrawerOpen = true;
    inspectorOpen = false;
    overviewOpen = false;
    marketsOpen = false;
    briefingOpen = false;
    renderTabs();
    syncOverlayUI();
  }

  function closeLeftDrawer() { leftDrawerOpen = false; syncOverlayUI(); }
  function openInspector() { inspectorOpen = true; leftDrawerOpen = false; overviewOpen = false; marketsOpen = false; briefingOpen = false; syncOverlayUI(); }
  function closeInspectorPanel() { inspectorOpen = false; syncOverlayUI(); }
  function cleanGlobeView() {
    leftDrawerOpen = false; inspectorOpen = false; briefingOpen = false; overviewOpen = false; marketsOpen = false; layersOpen = false; briefingOpen = false;
    if (globeOptions.cinematic) globeOptions.cinematic = false;
    renderLayers();
    syncOverlayUI();
  }

  function openShortcutsOverlay() {
    const ov = $('#shortcutsOverlay');
    if (!ov) return;
    ov.classList.add('open');
    ov.setAttribute('aria-hidden', 'false');
  }
  function closeShortcutsOverlay() {
    const ov = $('#shortcutsOverlay');
    if (!ov) return;
    ov.classList.remove('open');
    ov.setAttribute('aria-hidden', 'true');
  }
  function toggleShortcutsOverlay() {
    const ov = $('#shortcutsOverlay');
    if (!ov) return;
    ov.classList.contains('open') ? closeShortcutsOverlay() : openShortcutsOverlay();
  }

  const toastIcons = { success: '✓', error: '✕', warning: '!', info: 'ℹ', money: '$', deal: '◎' };
  function inferToastType(message) {
    const m = String(message).toLowerCase();
    if (/(fail|reject|error|blocked|cannot|insufficient|not enough|not a valid|denied|invalid|declined|lost|missed|too busy|all project teams are busy)/.test(m)) return 'error';
    if (/(warn|risk|delay|caution|overdue|breach|dispute|penalt|shortfall|exceed|locked:|requires )/.test(m)) return 'warning';
    if (/(complete|approved|won|success|secured|delivered|profit|accepted|started|purchased|built|unlocked|saved|imported|exported|paid|settled|ordered|joined|opened|confirmed|is now active|activated|expedited|booked|hired|granted)/.test(m)) return 'success';
    return 'info';
  }
  function showToast(message, type) {
    const stack = $('#toastStack');
    if (!stack) { // fallback to legacy element
      const toast = $('#toast');
      if (!toast) return;
      clearTimeout(toastTimer);
      toast.textContent = message;
      toast.classList.remove('hidden');
      requestAnimationFrame(() => toast.classList.add('visible'));
      toastTimer = setTimeout(() => { toast.classList.remove('visible'); setTimeout(() => toast.classList.add('hidden'), 260); }, 2600);
      return;
    }
    const kind = type || inferToastType(message);
    try {
      notificationHistory.unshift({ message: String(message), kind, at: Date.now(), gameDate: (typeof state !== 'undefined' && state) ? state.date : null });
      if (notificationHistory.length > 60) notificationHistory.length = 60;
      notificationsUnread = Math.min(99, notificationsUnread + 1);
      updateNotificationsBadge();
    } catch (e) {}
    try { Sound.play(kind); } catch (e) {}
    const el = document.createElement('div');
    el.className = `toast-item toast-${kind}`;
    el.setAttribute('role', kind === 'error' ? 'alert' : 'status');
    el.innerHTML = `<span class="toast-icon">${toastIcons[kind] || 'ℹ'}</span><span class="toast-msg"></span><button class="toast-close" aria-label="Dismiss">×</button>`;
    el.querySelector('.toast-msg').textContent = message;
    // Cap stack at 4 — remove oldest
    while (stack.children.length >= 4) stack.firstElementChild?.remove();
    stack.appendChild(el);
    requestAnimationFrame(() => el.classList.add('visible'));
    const dismiss = () => {
      el.classList.remove('visible');
      el.classList.add('leaving');
      setTimeout(() => el.remove(), 300);
    };
    const timer = setTimeout(dismiss, kind === 'error' ? 4200 : 3000);
    el.querySelector('.toast-close').addEventListener('click', () => { clearTimeout(timer); dismiss(); });
  }

  function selectHub(id, focus = true) {
    selected = { type: 'hub', id };
    if (focus) focusOnHub(id);
    renderInspector();
    renderAllLists();
    openInspector();
  }

  function selectOpportunity(id, focus = true) {
    const opp = getOpportunity(id);
    if (!isOpportunityUnlocked(opp)) return showToast('This opportunity is not yet unlocked.');
    if (!opportunityAvailable(opp)) return showToast('This opportunity has already been allocated in the current cycle.');
    selected = { type: 'opportunity', id };
    if (focus) focusOnOpportunity(id);
    renderInspector();
    renderOpportunityList();
    openInspector();
  }

  function trackLiveDeal(id, focus = true) {
    if (!getActiveDeal(id)) return;
    selected = { type: 'deal', id };
    leftDrawerOpen = false; inspectorOpen = false; briefingOpen = false; overviewOpen = false; marketsOpen = false; layersOpen = false;
    if (focus) focusOnDeal(id);
    syncOverlayUI();
    renderActiveDeals();
    openLiveTracker(id);
  }

  function selectDeal(id, focus = true) {
    selected = { type: 'deal', id };
    closeLiveTracker();
    if (focus) focusOnDeal(id);
    renderInspector();
    renderActiveDeals();
    openInspector();
  }

  function selectHistory(id) {
    const item = getHistoryDeal(id);
    if (!item) return;
    selected = { type: 'history', id };
    activeLeftTab = 'portfolio';
    renderTabs();
    renderInspector();
    renderHistory();
    openInspector();
  }

  function selectVessel(id, focus = true) {
    const asset = getFleetAsset(id);
    if (!asset) return;
    selected = { type: 'vessel', id };
    activeLeftTab = 'fleet';
    if (focus) focusOnHub(asset.positionHub);
    renderTabs();
    renderInspector();
    renderFleet();
    openInspector();
  }

  function opportunityAvailable(opp) {
    if (opp?.distressed) {
      return !!(state.distressedOpportunity?.id === opp.id && state.dayIndex <= (opp.distressedExpiry || 0));
    }
    const negotiation = state.negotiations?.[opp.id];
    const tender = rivalTenderFor(opp.id);
    const consumed = negotiation && negotiation.cycle === state.marketCycle && negotiation.status === 'consumed';
    const rivalAwarded = tender?.cycle === state.marketCycle && tender.status === 'awarded';
    return !consumed && !rivalAwarded;
  }

  function submitNegotiation(oppId) {
    const opp = getOpportunity(oppId);
    if (!opp || !isOpportunityUnlocked(opp) || !opportunityAvailable(opp)) return;
    const draft = { ...negotiationFor(oppId) };
    // v45 — senza un tetto ai tentativi bastava premere "Submit" una ventina di
    // volte per ottenere sempre l'accettazione: il rifiuto non costava nulla.
    const previous = state.negotiations?.[oppId];
    if (previous && previous.cycle === state.marketCycle && previous.status === 'rejected' && (previous.attempts || 0) >= 3) {
      return showToast('The buyer has closed the discussion for this market cycle. Try again next week.');
    }
    const attempts = (previous && previous.cycle === state.marketCycle ? (previous.attempts || 0) : 0) + 1;
    const probability = negotiationAcceptance(opp, draft);
    const roll = deterministicRandom(`${opp.id}-${state.marketCycle}-${attempts}-${draft.commercial}-${draft.payment}-${draft.pricing||'fixed'}-${draft.delivery}-${draft.incoterm||'fob'}`) * 100;
    const accepted = roll <= probability;
    const parties = partiesForOpportunity(opp);
    const buyerState = getCounterpartyState(parties.buyerId);
    const result = { ...draft, attempts, probability, status: accepted ? 'accepted' : 'rejected', submittedAt: state.date };
    state.negotiations[oppId] = result;
    selectedNegotiationDrafts[oppId] = result;
    recordJournal('Negotiation', `${opp.title}: ${accepted ? 'offer accepted' : 'offer rejected'}`, `${negotiationProfiles.commercial[draft.commercial]?.label || 'Quote'} · ${negotiationProfiles.payment[draft.payment]?.label || 'Payment terms'} · probability ${Math.round(probability)}%`, 0, opp.id);
    const tender = rivalTenderFor(opp.id);
    if (accepted) {
      buyerState.relationship = clamp(buyerState.relationship + 1, 0, 100);
      if (tender && tender.status !== 'player_reserved') {
        tender.status = 'player_reserved';
        tender.awardedTo = 'player';
        state.tenderWins = (state.tenderWins || 0) + 1; addXp(25, 'tender');
        recordRivalOutcome(tender.leaderId, true, opp.title);
        state.rivalFeed.unshift({ date:state.date, cycle:state.marketCycle, opportunityId:opp.id, rivalId:'player', title:`${state.companyName} secures ${opp.title}`, description:`Player bid accepted against ${tender.pressure}% competitive pressure.` });
        state.rivalFeed = state.rivalFeed.slice(0,18);
      }
      evaluateAchievements();
      showToast(`Tender won. The deal can be opened within ${liveOffer(opp).expiresIn} days.`);
    } else {
      buyerState.relationship = clamp(buyerState.relationship - 1, 0, 100);
      if (tender) tender.pressure = clamp(tender.pressure + 5, 0, 99);
      showToast('Offer rejected. Rival pressure has increased; revise price, payment or delivery terms.');
    }
    saveState();
    renderAll();
  }

  function submitTenderBid(oppId, marginAdjust) {
    const opp = getOpportunity(oppId);
    if (!opp || !opp.tender) return;
    const tender = rivalTenderFor(oppId);
    if (!tender || tender.status === 'awarded') {
      showToast('This tender has already been awarded.');
      return;
    }
    // v45 — prima ogni click era un tiro indipendente (il seed dipendeva dallo sconto
    // offerto) e perdere non costava nulla: si rilanciava finche' non si vinceva.
    if (tender.bidCycle === state.marketCycle) {
      return showToast('You have already bid in this tender round. Wait for the next market cycle.');
    }
    const adj = Math.max(Math.round(-opp.basePnl * 0.7), Math.min(0, marginAdjust));
    const concessionRatio = Math.abs(adj) / Math.max(1, opp.basePnl);
    const pressurePenalty = Math.max(0, (tender.pressure || 0) - 35) * 0.5;
    const winPct = Math.min(95, Math.max(5, 30 + concessionRatio * 120 - pressurePenalty));
    tender.bidCycle = state.marketCycle;
    tender.bidAttempts = (tender.bidAttempts || 0) + 1;
    const seed = `${oppId}-tender-${state.marketCycle}-${tender.bidAttempts}`;
    const roll = deterministicRandom(seed) * 100;
    const won = roll <= winPct;
    if (won) {
      tender.status = 'player_reserved';
      tender.awardedTo = 'player';
      state.tenderWins = (state.tenderWins || 0) + 1; addXp(25, 'tender');
      recordRivalOutcome(tender.leaderId, true, opp.title);
      state.rivalFeed.unshift({ date: state.date, cycle: state.marketCycle, opportunityId: oppId, rivalId: 'player', title: `${state.companyName || 'Player'} secures tender`, description: `Competitive bid accepted for ${opp.title} with ${Math.round(winPct)}% win probability.` });
      state.rivalFeed = state.rivalFeed.slice(0, 18);
      // Temporarily apply margin adjustment for this deal
      // v45 — try/finally: se startOpportunity solleva un errore il margine del
      // catalogo globale non resta permanentemente ridotto.
      if (adj !== 0) {
        const orig = opp.basePnl;
        opp.basePnl = orig + adj;
        try { startOpportunity(oppId); } finally { opp.basePnl = orig; }
      } else {
        startOpportunity(oppId);
      }
      evaluateAchievements();
      showToast(`Tender won! Margin offered: ${money(opp.basePnl + adj)}. Deal started.`);
    } else {
      state.tenderLosses = (state.tenderLosses || 0) + 1;
      recordRivalOutcome(tender.leaderId, false, opp.title);
      if (tender) tender.pressure = clamp((tender.pressure || 0) + 8, 0, 99);
      showToast(`Bid not accepted. Rival interest has risen to ${tender.pressure}%. Improve your offer or try the next cycle.`);
    }
    saveState();
    renderAll();
  }

  // ── v49 · diagnosi dell'apribilita' ─────────────────────────────────────────
  // Misurando la curva e' emerso che al livello di copertura raccomandato il primo
  // deal della carriera costa piu' della liquidita' iniziale: 520.656 $ fra capitale
  // proprio e margine contro 500.000 $ di cassa, piu' 100.000 $ di riserva di policy.
  // La partita resta possibile abbassando la copertura, ma il gioco lo comunicava
  // con un generico "Insufficient capital". Qui si dice esattamente cosa manca.
  function startBlockers(opp) {
    const blockers = [];
    if (!opp) return [{ code: 'missing', message: 'Opportunity unavailable.' }];
    const negotiation = state.negotiations?.[opp.id];
    const economics = opportunityEconomics(opp, negotiation || negotiationFor(opp.id));
    const stats = portfolioStats();
    const reserve = minimumCashReserve();
    const upfront = economics.equity + economics.initialMargin;

    if (!opportunityAvailable(opp)) blockers.push({ code: 'window', message: 'The offer window for this cargo has closed.' });
    if (!(opp.distressed || (negotiation?.cycle === state.marketCycle && negotiation.status === 'accepted'))) {
      blockers.push({ code: 'terms', message: 'The buyer has not accepted your terms yet.' });
    }
    const compliance = complianceProfileForOpportunity(opp);
    if (!compliance.canTrade) blockers.push({ code: 'compliance', message: 'Compliance clearance is required before the cargo can be opened.' });
    const buyerId = partiesForOpportunity(opp).buyerId;
    if (buyerId && counterpartyCreditHeadroom(buyerId) < prospectiveCreditExposure(opp, economics)) {
      const gap = prospectiveCreditExposure(opp, economics) - counterpartyCreditHeadroom(buyerId);
      blockers.push({ code: 'buyer-credit', message: `Buyer credit limit short by ${money(gap)}. Use a safer payment term or request an increase.` });
    }
    const structure = economics.structure;
    if (!financingAvailable(structure.financingId)) blockers.push({ code: 'financing', message: 'The selected financing structure needs a specialist you have not hired.' });
    if (stats.creditAvailable < economics.borrowed) {
      blockers.push({ code: 'facility', message: `Bank facility short by ${money(economics.borrowed - stats.creditAvailable)}.` });
    }
    if (state.cash < upfront) {
      blockers.push({ code: 'cash', message: `Needs ${money(upfront)} upfront (${money(economics.equity)} equity + ${money(economics.initialMargin)} margin) against ${money(state.cash)} of cash.`, shortfall: upfront - state.cash });
    } else if (state.cash - upfront < reserve) {
      blockers.push({ code: 'reserve', message: `${activeCapitalPolicy().label} keeps ${money(reserve)} in reserve; this cargo would leave ${money(state.cash - upfront)}.`, shortfall: reserve - (state.cash - upfront) });
    }
    return blockers;
  }

  // Copertura piu' alta che la liquidita' consente, a passi del 10%.
  function affordableHedgeRatio(opp) {
    const negotiation = state.negotiations?.[opp.id] || negotiationFor(opp.id);
    const reserve = minimumCashReserve();
    const previous = selectedHedgeRatios[opp.id];
    let best = null;
    try {
      for (let ratio = 100; ratio >= 0; ratio -= 10) {
        selectedHedgeRatios[opp.id] = ratio;
        const economics = opportunityEconomics(opp, negotiation);
        if (state.cash - economics.equity - economics.initialMargin >= reserve) { best = ratio; break; }
      }
    } finally {
      if (previous === undefined) delete selectedHedgeRatios[opp.id]; else selectedHedgeRatios[opp.id] = previous;
    }
    return best;
  }

  function canStartOpportunity(opp) {
    const stats = portfolioStats();
    const negotiation = state.negotiations?.[opp.id];
    const effectiveNegotiation = negotiation || negotiationFor(opp.id);
    const economics = opportunityEconomics(opp, effectiveNegotiation);
    const structure = economics.structure;
    const compliance = complianceProfileForOpportunity(opp);
    const commercialClearance = Boolean(opp.distressed || (negotiation?.cycle === state.marketCycle && negotiation.status === 'accepted'));
    const buyerId = partiesForOpportunity(opp).buyerId;
    const creditClearance = !buyerId || counterpartyCreditHeadroom(buyerId) >= prospectiveCreditExposure(opp, economics);
    return opportunityAvailable(opp) && commercialClearance && compliance.canTrade && creditClearance && financingAvailable(structure.financingId) && state.cash >= economics.equity + economics.initialMargin && state.cash - economics.equity - economics.initialMargin >= minimumCashReserve() && stats.creditAvailable >= economics.borrowed;
  }

  function startOpportunity(oppId) {
    const opp = getOpportunity(oppId);
    if (!opp || !isOpportunityUnlocked(opp) || !opportunityAvailable(opp)) return;
    const negotiation = state.negotiations?.[opp.id] || negotiationFor(opp.id);
    // Distressed cargo: seller is desperate — deal is pre-accepted, skip negotiation
    if (!opp.distressed) {
      if (!negotiation || negotiation.cycle !== state.marketCycle || negotiation.status !== 'accepted') {
        showToast('Negotiate and obtain buyer acceptance before opening the deal.');
        return;
      }
    }
    if (!canStartOpportunity(opp)) {
      // v49 - messaggio specifico invece del generico "Insufficient capital",
      // con il suggerimento della copertura sostenibile quando il problema e' la cassa.
      const blockers = startBlockers(opp);
      const first = blockers[0];
      let message = first ? first.message : 'This cargo cannot be opened yet.';
      if (first && (first.code === 'cash' || first.code === 'reserve')) {
        const affordable = affordableHedgeRatio(opp);
        const currentHedge = Number(selectedHedgeRatios[opp.id] ?? opp.recommendedHedge ?? 100);
        if (affordable !== null && affordable < currentHedge) {
          message += ` A ${affordable}% hedge fits your liquidity.`;
        }
      }
      showToast(message, 'warning');
      return;
    }
    const strategy = selectedCarrierStrategies[opp.id] || 'spot';
    const fleetAsset = strategy.startsWith('fleet:') ? getFleetAsset(strategy.slice(6)) : null;
    if (fleetAsset && !fleetAssetAvailableFor(fleetAsset, opp)) {
      selectedCarrierStrategies[opp.id] = 'spot';
      return showToast('The selected vessel is no longer available or is not at the origin port.');
    }
    const fleetVessel = fleetAsset ? getVesselCatalog(fleetAsset.catalogId) : null;
    const economics = opportunityEconomics(opp, negotiation);
    const dealEquity = economics.equity;
    const dealBorrowed = economics.borrowed;
    const parties = partiesForOpportunity(opp);
    const deal = {
      id: `deal-${Date.now()}-${state.sequence++}`,
      opportunityId: opp.id,
      started: state.date,
      elapsed: 0,
      duration: Math.max(10, economics.duration - (fleetVessel?.durationBonus || 0)),
      equity: dealEquity,
      borrowed: dealBorrowed,
      capital: economics.capital,
      quantity: economics.quantity,
      supplierId: parties.supplierId,
      buyerId: parties.buyerId,
      commercialTerms: { ...economics.terms },
      pricingStrategy: economics.terms.pricing || 'fixed',
      receivableProtection: null,
      storageOptionUsed: false,
      storageOptionalityEntry: null,
      financingStrategy: economics.structure.financingId,
      financingRate: economics.financingRate,
      insuranceStrategy: economics.structure.insuranceId,
      inspectionStrategy: economics.structure.inspectionId,
      fxHedgeRatio: economics.structure.fxHedgeRatio,
      entryFx: state.eurusd,
      initialMargin: economics.initialMargin,
      marginCollateral: economics.initialMargin,
      bridgeFunding: 0,
      marginCalls: 0,
      financingAccrued: 0,
      // v45 — copia leggera dell'opportunita': se il catalogo cambia (o il carico
      // distressed scade) il deal resta comunque renderizzabile.
      opportunitySnapshot: { ...opp, unlock: undefined, events: undefined },
      marketCycle: state.marketCycle,
      vesselClass: selectedVesselClasses[opp.id] || 'supramax',
      globalEventsAtBooking: economics.crisisLabels,
      verticalSources: economics.verticalSources || [],
      basePnl: economics.basePnl + (fleetVessel?.bonusPnl || 0) + (fleetAsset && hasStaff('freight-charterer') ? 5_000 : 0),
      fleetAssetId: fleetAsset?.id || null,
      shippingStrategy: fleetAsset ? 'internal-fleet' : 'spot-carrier',
      pnlAdjustments: 0,
      hedgeRatio: Number(selectedHedgeRatios[opp.id] ?? opp.recommendedHedge ?? 100),
      entryMarketPrice: marketPriceForOpportunity(opp),
      hedgeTransactions: 1,
      reputationAdjustments: 0,
      eventTriggered: false,
      eventResolved: false,
      pendingDecision: false,
      forcedCompletion: false,
      eventResult: null,
      complianceStatus: complianceProfileForOpportunity(opp).status,
      complianceReviewed: complianceProfileForOpportunity(opp).reviewed,
      complianceScore: complianceProfileForOpportunity(opp).score,
      delivered: false,
      deliveredAt: null,
      paymentDaysRemaining: null,
      collectionDelayDays: 0,
      overdueRecorded: false,
      invoiceStatus: 'Not issued',
      invoiceAmount: Math.round(physicalNotional(opp, economics.quantity, economics.capital) + Math.max(0, economics.basePnl || 0)),
      contractLifecycle: { nominated: true, loaded: false, delivered: false, invoiced: false, paid: false },
      procurementAgreementId: economics.procurementAgreement?.supplierId || null,
      routeCondition: { ...economics.routeCondition },
      routeMitigated: false,
      deskSpecialization: economics.deskSpecialization?.id || state.deskSpecialization,
      marketReputationAtBooking: economics.marketReputationScore || 0,
      hqTierAtBooking: economics.hqTier || state.hqTier,
      commercialFrameworkId: economics.commercialFramework?.opportunityId || null
    };
    deal.operations = makeDealOperations(opp, deal.id, fleetAsset);
    if (opp.distressed) { state.distressedOpportunity = null; }
    const commercialLabel = negotiationProfiles.commercial[negotiation.commercial]?.label || 'Market quote';
    const paymentLabel = negotiationProfiles.payment[negotiation.payment]?.label || 'Payment at delivery';
    const pricingLabel = negotiationProfiles.pricing[negotiation.pricing || 'fixed']?.label || 'Fixed price';
    const deliveryLabel = negotiationProfiles.delivery[negotiation.delivery]?.label || 'Standard window';
    deal.operations.salesContract.terms = `${deal.operations.salesContract.terms} · ${commercialLabel} · ${paymentLabel} · ${pricingLabel} · ${deliveryLabel}`;
    deal.operations.purchaseContract.terms = `${deal.operations.purchaseContract.terms} · ${economics.structure.inspection.label}`;
    deal.operations.finance = { facility: economics.structure.financing.label, rate: economics.financingRate, insurance: economics.structure.insurance.label, fxHedgeRatio: economics.structure.fxHedgeRatio };
    if (economics.structure.inspectionId === 'independent') {
      const qualityDoc = deal.operations.documents.find(doc => /quality|assay|protein|moisture/i.test(doc.name));
      if (qualityDoc) qualityDoc.status = 'ready';
    }
    if (fleetAsset) { fleetAsset.status = 'assigned'; fleetAsset.assignedDealId = deal.id; }
    selectedCarrierStrategies[opp.id] = 'spot';
    state.cash -= deal.equity + deal.marginCollateral;
    state.activeDeals.push(deal);
    registerProcurementLift(opp, deal, economics);
    registerCommercialFrameworkLift(opp, deal);
    state.negotiations[opp.id] = { ...negotiation, status: 'consumed' };
    recordJournal('Deal opened', opp.title, `${getHub(opp.origin).name} → ${getHub(opp.destination).name} · ${economics.quantity.toLocaleString('en-US')} t · hedge ${deal.hedgeRatio}% · ${deal.complianceStatus}`, -(deal.equity + deal.marginCollateral), deal.id);
    saveState();
    selectDeal(deal.id);
    activeLeftTab = 'portfolio';
    renderTabs();
    renderAll();
    showToast(`${opp.title} started: capital allocated and shipment opened.`);
  }

  function protectReceivable(dealId, type) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.receivableProtection || deal.commercialTerms?.payment !== 'thirty') return;
    const notional = physicalNotional(getOpportunity(deal.opportunityId), deal.quantity, deal.capital);
    const profile = type === 'factor'
      ? { label:'Receivable factored', cost:Math.round(notional*.012), lossFactor:0 }
      : { label:'Trade credit insurance', cost:Math.round(notional*.0065), lossFactor:.12 };
    deal.receivableProtection = { type, label:profile.label, lossFactor:profile.lossFactor, cost:profile.cost };
    deal.pnlAdjustments -= profile.cost;
    state.receivableProtectionCost = (state.receivableProtectionCost||0) + profile.cost;
    saveState(); renderAll(); showToast(`${profile.label} secured for ${money(profile.cost)}.`);
  }

  function exerciseStorageOption(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.storageOptionUsed || !deal.operations?.storage?.active || deal.commercialTerms?.delivery !== 'flexible') return;
    const warehouseDiscount=storageDiscountForHub(deal.operations?.storage?.hubId);
    const dailyCost = Math.max(900, Math.round((deal.capital||0)*.00022*(1-warehouseDiscount)));
    const days = 7;
    deal.storageOptionUsed = true;
    deal.storageOptionalityEntry = marketPriceForOpportunity(getOpportunity(deal.opportunityId));
    deal.storageOptionalityShare = .20;
    deal.duration += days;
    deal.pnlAdjustments -= dailyCost*days;
    deal.operations.storage.days += days;
    deal.eventResult = `Warehouse optionality exercised: 20% of the flexible parcel held for ${days} days.`;
    saveState(); renderAll(); showToast(`Warehouse option exercised. Cost ${money(dailyCost*days)}.`);
  }

  function storageOptionalityPnl(deal) {
    if (!deal.storageOptionUsed || !deal.storageOptionalityEntry) return 0;
    const opp = getOpportunity(deal.opportunityId);
    const move = marketPriceForOpportunity(opp) - deal.storageOptionalityEntry;
    return Math.max(0, move) * (deal.quantity||opp.quantity) * unitMultiplierForOpportunity(opp) * (deal.storageOptionalityShare||.2);
  }

  function settlementCreditPnl(deal) {
    if (deal.commercialTerms?.payment !== 'thirty') return { pnl:0, label:'Payment secured at delivery' };
    const buyer = getCounterparty(deal.buyerId);
    const relationship = getCounterpartyState(deal.buyerId);
    const protection = deal.receivableProtection;
    const financeShield = deal.financingStrategy === 'lc' ? .32 : 1;
    const probability = clamp((100-(buyer?.credit||70))*.38 + Math.max(0,55-(relationship.relationship||50))*.22 + (state.difficulty==='expert'?5:0), 1, 24) * financeShield;
    const roll = deterministicRandom(`${deal.id}-credit-${state.marketCycle}`)*100;
    if (roll > probability) return { pnl:0, label:protection ? `${protection.label}; buyer paid on time` : 'Buyer paid on time' };
    const grossLoss = Math.min(120_000, Math.round((deal.capital||0)*(.018 + deterministicRandom(`${deal.id}-credit-loss`)*.022)));
    const loss = Math.round(grossLoss * (protection?.lossFactor ?? 1));
    state.creditLosses = (state.creditLosses||0) + loss;
    relationship.disputes = (relationship.disputes||0) + 1;
    relationship.relationship = clamp((relationship.relationship||50)-4,0,100);
    return { pnl:-loss, label: protection ? `Buyer delay/default mitigated by ${protection.label}` : 'Uninsured buyer delay/default' };
  }

  function triggerDealEvent(deal) {
    const opp = getOpportunity(deal.opportunityId);
    if (!opp.event || deal.eventTriggered) return false;
    if (computeDealProgress(deal) >= opp.event.dayRatio) {
      deal.eventTriggered = true;
      deal.pendingDecision = true;
      updateDealOperations(deal);
      runningSpeed = 0;
      updateClock();
      selected = { type: 'deal', id: deal.id };
      focusOnDeal(deal.id);
      openInspector();
      showToast(`Decision required: ${opp.event.title}`);
      return true;
    }
    return false;
  }

  function resolveEvent(dealId, choiceId) {
    const deal = getActiveDeal(dealId);
    if (!deal) return;
    const opp = getOpportunity(deal.opportunityId);
    const choice = opp.event.choices.find(c => c.id === choiceId);
    if (!choice) return;
    let outcome = choice;
    if (choice.random) {
      const roll = deterministicRandom(`${deal.id}-${choice.id}-${state.date}`);
      outcome = roll < .55 ? choice.good : choice.bad;
    }
    const insuranceFactor = insuranceProfiles[deal.insuranceStrategy || 'basic']?.lossFactor || 1;
    const inspectionFactor = inspectionProfiles[deal.inspectionStrategy || 'standard']?.lossFactor || 1;
    const rawPnl = outcome.pnl || 0;
    const mitigatedPnl = rawPnl < 0 ? Math.round(rawPnl * insuranceFactor * inspectionFactor * difficultySettings().eventLoss) : rawPnl;
    deal.pnlAdjustments += mitigatedPnl;
    deal.duration += outcome.days || 0;
    deal.reputationAdjustments += outcome.reputation || 0;
    deal.eventResult = outcome.result;
    recordJournal('Operations', `${opp.event.title}: ${choice.label}`, outcome.result, mitigatedPnl, deal.id);
    deal.eventResolved = true;
    deal.pendingDecision = false;
    updateDealOperations(deal);
    if (choiceId === 'inspect') {
      const quality = deal.operations.documents.find(d => d.name === 'Quality certificate');
      if (quality) quality.status = 'ready';
    }
    if (['kyc', 'amend-lc', 'waiver'].includes(choiceId)) {
      const lc = deal.operations.documents.find(d => d.name === 'LC compliance');
      if (lc) lc.status = 'ready';
    }
    if (choice.forceComplete) {
      deal.forcedCompletion = true;
      deal.elapsed = deal.duration;
      completeDeal(deal);
    }
    saveState();
    renderAll();
    showToast(outcome.result);
  }

  function increaseHedge(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.hedgeRatio >= 100) return;
    const opp = getOpportunity(deal.opportunityId);
    const realizedMarketImpact = computeMarketImpact(deal);
    const transactionCost = Math.round((2_000 + (deal.quantity || opp.quantity) * 2) * (hasStaff('risk-analyst') ? .65 : 1));
    deal.pnlAdjustments += realizedMarketImpact - transactionCost;
    deal.entryMarketPrice = marketPriceForOpportunity(opp);
    deal.hedgeRatio = 100;
    recordJournal('Risk', `${opp.title}: hedge raised to 100%`, `Residual market exposure crystallized and hedge reset at the current market price.`, realizedMarketImpact - transactionCost, deal.id);
    deal.hedgeTransactions = (deal.hedgeTransactions || 1) + 1;
    updateMarginLiquidity(deal);
    saveState();
    renderAll();
    showToast(`Hedge increased to 100%. Operating cost ${money(transactionCost)}.`);
  }

  function collectionDelayForDeal(deal) {
    if (deal.commercialTerms?.payment !== 'thirty') return 0;
    if (deal.receivableProtection?.type === 'factor' || deal.financingStrategy === 'lc') return 0;
    const buyer = getCounterparty(deal.buyerId);
    const relationship = getCounterpartyState(deal.buyerId);
    const risk = clamp((100 - (buyer?.credit || 70)) * .42 + Math.max(0, 58 - (relationship.relationship || 50)) * .18 + (state.difficulty === 'expert' ? 5 : 0), 1, 30);
    const roll = deterministicRandom(`${deal.id}-collection-delay-${state.marketCycle}`) * 100;
    if (roll >= risk) return 0;
    const severity = deterministicRandom(`${deal.id}-collection-severity`);
    const rawDays = severity < .55 ? 5 : severity < .86 ? 10 : 20;
    return deal.receivableProtection?.type === 'insurance' ? Math.max(2, Math.round(rawDays * .6)) : rawDays;
  }

  function deliverDeal(deal) {
    if (!deal || deal.delivered) return;
    const opp = getOpportunity(deal.opportunityId);
    deal.deliveryMarketPnl = computeMarketImpact(deal);
    deal.deliveryFxPnl = computeFxImpact(deal);
    deal.delivered = true;
    deal.deliveredAt = state.date;
    deal.elapsed = Math.max(deal.elapsed, deal.duration);
    deal.paymentDaysRemaining = paymentDaysForDeal(deal);
    deal.collectionDelayDays = collectionDelayForDeal(deal);
    deal.overdueRecorded = false;
    deal.invoiceStatus = deal.paymentDaysRemaining > 0 ? 'Outstanding' : 'Due';
    deal.contractLifecycle = { ...(deal.contractLifecycle || {}), nominated:true, loaded:true, delivered:true, invoiced:true, paid:false };
    if (deal.marginCollateral > 0) releaseCollateral(deal, deal.marginCollateral);
    pingHub(opp.destination, 'arrival');   // v46 - il porto di arrivo lampeggia
    updateDealOperations(deal);
    if (deal.fleetAssetId) {
      const fleetAsset = getFleetAsset(deal.fleetAssetId);
      if (fleetAsset) { fleetAsset.status = 'available'; fleetAsset.assignedDealId = null; fleetAsset.positionHub = opp.destination; }
    }
    recordJournal('Delivery', `${opp.title} delivered`, `${deal.invoiceStatus} invoice ${deal.operations?.contractId || deal.id} · ${deal.paymentDaysRemaining} payment days`, 0, deal.id);
    state.worldEventFeed.unshift({ type:'contract', title:`Cargo delivered · ${opp.title}`, date:state.date, description:deal.paymentDaysRemaining ? `Invoice issued for ${money(deal.invoiceAmount)}. Payment due in ${deal.paymentDaysRemaining} days.` : 'Payment is due at delivery; settlement is processing.' });
    state.worldEventFeed = state.worldEventFeed.slice(0,18);
    if (deal.paymentDaysRemaining <= 0) completeDeal(deal);
    else showToast(`${opp.title} delivered. Invoice due in ${deal.paymentDaysRemaining} days.`);
  }

  function completeDeal(deal) {
    const opp = getOpportunity(deal.opportunityId);
    const marketPnl = computeMarketImpact(deal);
    const fxPnl = computeFxImpact(deal);
    const financingCost = deal.financingAccrued || 0;
    const storagePnl = storageOptionalityPnl(deal);
    const creditResult = settlementCreditPnl(deal);
    const creditPnl = creditResult.pnl || 0;
    const pnl = deal.basePnl + deal.pnlAdjustments - financingCost + marketPnl + fxPnl + storagePnl + creditPnl;
    deal.invoiceStatus = 'Paid';
    deal.paymentDaysRemaining = 0;
    deal.collectionDelayDays = 0;
    deal.contractLifecycle = { ...(deal.contractLifecycle || {}), delivered:true, invoiced:true, paid:true };
    state.receivablesCollected = (state.receivablesCollected || 0) + (deal.invoiceAmount || 0);
    state.storageOptionIncome = (state.storageOptionIncome||0) + storagePnl;
    if (deal.marginCollateral > 0) releaseCollateral(deal, deal.marginCollateral);
    // qualunque residuo del ponte non coperto dal collaterale esce dai proventi
    const outstandingBridge = deal.bridgeFunding || 0;
    if (outstandingBridge > 0) { deal.borrowed = Math.max(0, (deal.borrowed || 0) - outstandingBridge); deal.bridgeFunding = 0; }
    state.cash += deal.equity + pnl - outstandingBridge;
    state.realizedPnl += pnl;
    state.completedDeals += 1;
    const readiness = operationsReadiness(deal);
    const opsRep = readiness >= 92 ? 2 : readiness < 70 ? -2 : 0;
    // v53 - la penalita' per un cargo in perdita era piu' pesante del premio per
    // uno in utile: la reputazione non cresceva mai abbastanza per il primo ufficio
    const baseRep = pnl >= 0 ? 3 : -2;
    state.reputation = clamp(state.reputation + baseRep + opsRep + deal.reputationAdjustments, 0, 100);
    updateMarketReputationAfterDeal(opp, pnl, readiness);
    [deal.supplierId, deal.buyerId].filter(Boolean).forEach(counterpartyId => {
      const relationship = getCounterpartyState(counterpartyId);
      relationship.deals = (relationship.deals || 0) + 1;
      const relationshipMove = readiness >= 90 && pnl >= 0 ? 3 : readiness < 70 || pnl < 0 ? -2 : 1;
      relationship.relationship = clamp(relationship.relationship + relationshipMove, 0, 100);
      if (readiness < 70 || (deal.eventResult || '').toLowerCase().includes('claim')) relationship.disputes = (relationship.disputes || 0) + 1;
    });
    if (deal.fleetAssetId) {
      const fleetAsset = getFleetAsset(deal.fleetAssetId);
      if (fleetAsset) {
        fleetAsset.status = 'available';
        fleetAsset.assignedDealId = null;
        fleetAsset.positionHub = opp.destination;
      }
    }
    // v46 - schermata di chiusura: il conto economico del carico, voce per voce
    queueSettlementSummary(opp, deal, {
      pnl, marketPnl, fxPnl, financingCost, storagePnl, creditPnl,
      basePnl: deal.basePnl, adjustments: deal.pnlAdjustments, readiness,
    });
    state.history.unshift({
      id: deal.id,
      opportunityId: opp.id,
      completed: state.date,
      pnl,
      days: deal.elapsed,
      eventResult: [deal.eventResult, creditResult.label].filter(Boolean).join(' · '),
      operationalReadiness: readiness,
      carrier: deal.operations?.transport?.carrier || 'N/A',
      charterType: deal.operations?.transport?.charterType || 'N/A',
      demurrage: deal.operations?.transport?.demurrageAccrued || 0,
      hedgeRatio: deal.hedgeRatio || 0,
      shippingStrategy: deal.shippingStrategy || 'spot-carrier',
      commodity: opp.commodity,
      priceKey: opp.priceKey,
      quantity: deal.quantity || opp.quantity,
      supplierId: deal.supplierId,
      buyerId: deal.buyerId,
      commercialTerms: deal.commercialTerms,
      financingStrategy: deal.financingStrategy,
      insuranceStrategy: deal.insuranceStrategy,
      inspectionStrategy: deal.inspectionStrategy,
      fxHedgeRatio: deal.fxHedgeRatio || 0,
      marginCalls: deal.marginCalls || 0,
      pricingStrategy: deal.pricingStrategy || 'fixed',
      receivableProtection: deal.receivableProtection?.label || null,
      storageOptionality: storagePnl,
      creditPnl,
      pnlBreakdown: { commercial: deal.basePnl, operations: deal.pnlAdjustments, financing: -financingCost, market: marketPnl, fx: fxPnl, storage: storagePnl, credit: creditPnl, demurrage: -(deal.operations?.transport?.demurrageAccrued || 0) },
      globalEventImpacts: deal.globalEventImpacts || [],
      verticalSources: deal.verticalSources || [],
      complianceStatus: deal.complianceStatus || 'Clear',
      complianceScore: deal.complianceScore || 0,
      deliveredAt: deal.deliveredAt || state.date,
      invoiceAmount: deal.invoiceAmount || 0,
      invoiceStatus: deal.invoiceStatus || 'Paid',
      paymentTerms: negotiationProfiles.payment[deal.commercialTerms?.payment || 'delivery']?.label || 'Payment at delivery'
    });
    recordJournal('Settlement', `${opp.title} settled`, `Realized P&L ${money(pnl)} · operational readiness ${Math.round(readiness)}% · compliance ${deal.complianceStatus || 'Clear'}`, pnl, deal.id);
    state.history = state.history.slice(0, 60);
    state.activeDeals = state.activeDeals.filter(d => d.id !== deal.id);
    state.valuationHigh = Math.max(state.valuationHigh||0, tradingHouseValuation().value);
    evaluateMissions();
    evaluateAchievements();
    selected = { type: 'hub', id: 'geneva' };
    focusOnHub('geneva');
    { const _ps = _soundSuppressed; _soundSuppressed = true; showToast(`${opp.title} closed with ${money(pnl)} P&L.`, pnl >= 0 ? 'success' : 'warning'); _soundSuppressed = _ps; }
    try { Sound.play(pnl >= 0 ? 'deal' : 'error'); } catch (e) {}
    addXp(20 + Math.max(0, Math.min(80, Math.round(pnl / 5000))), 'deal');
  }

  // ─── Commodity price news headline catalog ─────────────────────────────────
  const _priceNews = {
    copper: {
      up:   ['BHP mine disruption tightens copper supply','Chinese EV demand lifts copper premiums','LME copper backwardation widens on low stocks','Codelco force majeure boosts copper spread','Supply disruption at major Zambia mine','Copper scrap availability tightens in Europe'],
      down: ['Chinese industrial data disappoints base metals','LME copper stocks rise at Rotterdam warehouses','Risk-off macro environment weighs on metals','Scrap substitution rises on elevated copper price','Demand softness in Chinese construction sector','Chilean exports accelerate on weaker peso']
    },
    aluminium: {
      up:   ['Power curtailments reduce Chinese aluminium output','Bauxite export restrictions tighten supply chain','EU energy crisis lifts aluminium smelting costs','Atlantic arbitrage widens on low European stocks'],
      down: ['Chinese aluminium production data beats expectations','Hydropower capacity returns in Yunnan province','Demand softness in automotive and packaging sector','LME aluminium warrant cancellations fall']
    },
    crude: {
      up:   ['OPEC+ announces unexpected production cut','US crude inventory draw exceeds expectations','Middle East tension premium re-enters the market','Refinery outages tighten refined product supply'],
      down: ['OPEC spare capacity signals ease market concerns','Demand outlook weakened by macro headwinds','US shale output beats monthly estimates','IEA raises global demand growth forecast lower']
    },
    wheat: {
      up:   ['Black Sea export corridor disruption lifts grain','Adverse weather forecast hits European crop outlook','Argentine peso weakness may cut export competitiveness','Wheat tender from Egypt lifts benchmark prices'],
      down: ['Australia harvest estimates revised higher','Russian export quota raised for current season','Global wheat carry-out projections improve','Rain improves US winter wheat condition ratings']
    },
    ironore: {
      up:   ['China steel mills restock on improved demand signals','Pilbara port scheduling disruption tightens supply','Brazilian iron ore shipments delayed by weather','Steel margin recovery lifts iron ore demand'],
      down: ['China construction activity softens demand outlook','Steel mill margins compress on rising coke costs','Indian ore exports accelerate into Asian markets','Chinese steel inventories build above seasonal norms']
    },
    coffee: {
      up:   ['Brazilian frost risk premium enters arabica market','Vietnam robusta crop forecast cut on dry weather','ICO export data shows tighter-than-expected supply','Colombian production hampered by La Niña rains'],
      down: ['Brazil harvest weather improves crop estimates','Certified arabica warehouse stocks rise in New York','Vietnamese output recovery weighs on robusta','Global coffee demand softens in key European markets']
    },
    urea: {
      up:   ['Gas curtailments reduce European urea output','India tender demand lifts benchmark urea price','Spring planting season drives fertilizer buying','Egypt export restrictions tighten Mediterranean supply'],
      down: ['Chinese urea export window may reopen on inventory','Gas prices ease, restoring production economics','Seasonal demand lull weighs on nitrogen markets','Brazilian import demand finishes for the season']
    },
    zinc: { up:['Smelter maintenance tightens refined zinc supply','LME zinc stocks fall on stronger galvanizing demand'], down:['Chinese zinc output recovers after maintenance','Galvanized steel demand softens in Europe'] },
    nickel: { up:['Indonesia policy tightens Class I nickel availability','Battery-grade nickel premiums strengthen in Europe'], down:['Indonesian nickel output exceeds market expectations','Stainless demand slowdown weighs on nickel'] },
    lng: { up:['European utilities accelerate spot LNG buying','Asian LNG demand tightens Atlantic basin supply'], down:['Mild weather reduces European gas demand','High storage levels weigh on spot LNG prices'] }
  };

  function generatePriceNews(key, prevPrice, newPrice, date) {
    const pct = (newPrice - prevPrice) / prevPrice;
    if (Math.abs(pct) < 0.007) return null; // threshold: 0.7% move
    const dir = pct > 0 ? 'up' : 'down';
    const templates = _priceNews[key]?.[dir];
    if (!templates?.length) return null;
    const idx = Math.floor(deterministicRandom(date.toISOString() + '-news-' + key) * templates.length);
    const sign = pct > 0 ? '+' : '';
    const labels = { copper: 'Copper', aluminium: 'Aluminium', crude: 'Crude', wheat: 'Wheat', ironore: 'Iron ore', coffee: 'Coffee', urea: 'Urea', zinc:'Zinc', nickel:'Nickel', lng:'LNG' };
    return {
      type: 'market',
      title: templates[idx],
      date: date.toISOString(),
      description: `${labels[key] || key}: ${sign}${(pct * 100).toFixed(1)}% — price moves to ${key === 'crude' ? `$${newPrice.toFixed(2)}/bbl` : key === 'urea' || key === 'wheat' ? `$${Math.round(newPrice)}/t` : key === 'coffee' ? `$${Math.round(newPrice)}/t` : money(Math.round(newPrice)) + '/t'}.`
    };
  }

  // ─── Seasonal volatility per commodity (month 0-11 index) ──────────────────
  const _seasonalVol = {
    copper:    [1.00,1.00,1.05,1.10,1.05,1.00,0.95,0.90,1.00,1.05,1.00,0.95],
    aluminium: [0.95,0.95,1.00,1.05,1.05,1.00,0.95,0.90,1.00,1.05,1.00,0.95],
    urea:      [1.10,1.00,1.10,1.20,0.95,0.85,0.80,0.85,1.00,1.15,1.10,1.05],
    crude:     [1.10,1.05,1.00,0.95,1.00,1.10,1.15,1.10,0.95,0.90,1.00,1.15],
    wheat:     [0.90,0.85,0.95,1.10,1.20,1.35,1.40,1.20,0.90,0.80,0.85,0.90],
    ironore:   [0.95,1.00,1.10,1.15,1.05,0.95,0.90,0.85,1.00,1.10,1.05,0.95],
    coffee:    [0.90,0.90,1.00,1.10,1.30,1.40,1.35,1.10,1.00,1.20,1.10,0.95],
    zinc:      [0.95,0.95,1.00,1.05,1.05,1.00,0.95,0.95,1.00,1.05,1.05,1.00],
    nickel:    [1.05,1.00,1.10,1.15,1.05,1.00,0.95,0.95,1.05,1.10,1.05,1.00],
    lng:       [1.30,1.20,1.05,0.90,0.80,0.75,0.80,0.85,0.95,1.10,1.20,1.35]
  };
  function seasonalPriceVolatility(key, date) {
    return (_seasonalVol[key] || [])[date.getUTCMonth()] || 1;
  }

  // ─── Market Intelligence report ──────────────────────────────────────────
  function buyMarketIntel() {
    const cost = 18_000;
    const cooldownDays = 5;
    if (state.completedDeals < 1) return showToast('Complete at least one deal to access market intelligence.');
    if ((state.dayIndex||0) - (state.intelCooldownDay||0) < cooldownDays) {
      const wait = cooldownDays - ((state.dayIndex||0) - (state.intelCooldownDay||0));
      return showToast(`Research desk is still compiling. Available in ${wait} day${wait > 1 ? 's' : ''}.`);
    }
    if (state.cash < cost) return showToast(`Insufficient liquidity. Research report costs ${money(cost)}.`);
    state.cash -= cost;
    state.intelCooldownDay = state.dayIndex || 0;
    // Compute a forward-looking directional bias for top commodities
    const date = currentDate();
    const nextDate1 = new Date(date); nextDate1.setUTCDate(date.getUTCDate() + 1);
    const nextDate2 = new Date(date); nextDate2.setUTCDate(date.getUTCDate() + 2);
    const nextDate3 = new Date(date); nextDate3.setUTCDate(date.getUTCDate() + 3);
    function priceDirection(key, priceNow, dateSeeds) {
      // Reproduce noise formula to find direction (same deterministic seed logic)
      const equilibria = { copper: 9500, aluminium: 2450, urea: 360, crude: 78.5, wheat: 245, ironore: 108, coffee: 4200 };
      const noiseAmp = { copper: [18,34], aluminium: [7,15], urea: [1.6,4.5], crude: [0.45,1.45], wheat: [1.3,4.2], ironore: [0.55,1.8], coffee: [18,46] };
      let price = priceNow;
      let delta = 0;
      const regime = currentMarketRegime();
      const vol = regime.volatility || 1;
      for (const d of dateSeeds) {
        const s = deterministicRandom(d.toISOString());
        const s2 = deterministicRandom(d.toISOString() + '-' + key.slice(0,2));
        const amp = noiseAmp[key] || [1, 2];
        const mr = (equilibria[key] - price) * 0.018;
        const noise = (Math.sin(d.getUTCDate() * 0.43) * amp[0] + (s2 - 0.5) * amp[1] + mr) * vol * seasonalPriceVolatility(key, d);
        delta += noise;
        price += noise;
      }
      return delta;
    }
    const commodityMap = [
      { key: 'copper', label: 'Copper', price: state.copperPrice },
      { key: 'crude', label: 'Crude', price: state.crudePrice },
      { key: 'wheat', label: 'Wheat', price: state.wheatPrice },
      { key: 'coffee', label: 'Coffee', price: state.coffeePrice },
      { key: 'ironore', label: 'Iron ore', price: state.ironorePrice }
    ];
    const dateSeeds = [nextDate1, nextDate2, nextDate3];
    const directions = commodityMap.map(c => {
      const delta = priceDirection(c.key, c.price, dateSeeds);
      return { ...c, delta, arrow: delta > 0 ? '↑' : '↓', bias: Math.abs(delta) > (c.price * 0.006) ? 'strong' : 'mild' };
    });
    // Event risk
    const daysToEvent = Math.max(0, (state.nextGlobalEventDay||0) - (state.dayIndex||0));
    const eventRisk = daysToEvent <= 2 ? 'HIGH' : daysToEvent <= 5 ? 'MEDIUM' : 'LOW';
    // Freight outlook
    const freightDir = currentMarketRegime().freightBias > 0 ? 'tightening' : currentMarketRegime().freightBias < 0 ? 'softening' : 'stable';
    state.intelReport = { day: state.dayIndex, directions, eventRisk, daysToEvent, freightDir, regime: currentMarketRegime().label };
    state.worldEventFeed.unshift({ type: 'market', title: 'Market intelligence report issued', date: state.date, description: `Analysis desk delivered a 3-day directional outlook. Cost: ${money(cost)}.` });
    state.worldEventFeed = state.worldEventFeed.slice(0, 14);
    saveState(); renderAll();
    showToast('Market intelligence report ready — see World Events.');
  }

  // ─── Mid-deal hedge adjustment ──────────────────────────────────────────────
  function rehedgeDeal(dealId, newRatio) {
    const deal = getActiveDeal(dealId);
    if (!deal) return;
    const opp = getOpportunity(deal.opportunityId);
    const progress = computeDealProgress(deal);
    if (progress < 0.12 || progress > 0.88) return showToast('Rehedging is only possible while the cargo is in transit.');
    const oldRatio = deal.hedgeRatio || 0;
    const deltaRatio = Math.abs(newRatio - oldRatio);
    if (deltaRatio < 1) return showToast('Minimum hedge adjustment is 1%.');
    if (newRatio < 0 || newRatio > 110) return showToast('Hedge ratio must be between 0% and 110%.');
    const cost = Math.round(8_000 + deltaRatio * 200); // base + execution cost per %
    if (state.cash < cost) return showToast(`Insufficient liquidity. Rehedge execution costs ${money(cost)}.`);
    // v45 — cristallizza il risultato maturato col vecchio rapporto e riparte dal
    // prezzo corrente: altrimenti alzare l'hedge cancellava a posteriori le perdite
    // gia' subite (e abbassarlo regalava profitti). Il costo, come per tutte le altre
    // azioni operative, incide solo su pnlAdjustments: prima era addebitato due volte.
    const realizedMarketImpact = computeMarketImpact(deal);
    deal.pnlAdjustments += realizedMarketImpact - cost;
    deal.entryMarketPrice = marketPriceForOpportunity(opp);
    deal.hedgeRatio = newRatio;
    deal.hedgeTransactions = (deal.hedgeTransactions || 1) + 1;
    updateMarginLiquidity(deal);
    recordJournal('Risk', `${opp.title}: hedge ${oldRatio}% \u2192 ${newRatio}%`, 'Market exposure crystallized and hedge reset at the current market price.', realizedMarketImpact - cost, deal.id);
    state.worldEventFeed.unshift({ type: 'market', title: `Hedge adjusted: ${opp.title}`, date: state.date, description: `Hedge ratio moved from ${oldRatio}% to ${newRatio}%. Execution cost ${money(cost)}.` });
    state.worldEventFeed = state.worldEventFeed.slice(0, 18);
    saveState(); renderAll();
    showToast(`Hedge adjusted to ${newRatio}%. Cost: ${money(cost)}.`);
  }

  // ─── Warm outreach to counterparty ──────────────────────────────────────
  function warmOutreach(cpId) {
    const cost = 5_000;
    const cooldown = 14;
    const lastDay = (state.cpOutreachDays || {})[cpId] || -99;
    if ((state.dayIndex||0) - lastDay < cooldown) {
      const wait = cooldown - ((state.dayIndex||0) - lastDay);
      return showToast(`Outreach cooldown: available in ${wait} day${wait > 1 ? 's' : ''}.`);
    }
    if (state.cash < cost) return showToast(`Insufficient liquidity. Outreach costs ${money(cost)}.`);
    const cp = counterpartyCatalog.find(p => p.id === cpId);
    if (!cp) return;
    state.cash -= cost;
    state.cpOutreachDays = state.cpOutreachDays || {};
    state.cpOutreachDays[cpId] = state.dayIndex || 0;
    const record = getCounterpartyState(cpId);
    record.relationship = clamp((record.relationship || 50) + 3, 0, 100);
    saveState(); renderAll();
    showToast(`Outreach to ${cp.name} complete. Relationship +3.`);
  }

  function advanceDay({ silent = false, deferRender = false } = {}) {
    if (state.activeDeals.some(d => d.pendingDecision)) {
      const pending = state.activeDeals.find(d => d.pendingDecision);
      selectDeal(pending.id);
      if (!silent) showToast('Resolve the open operational decision first.');
      return false;
    }
    simulationDayAnchor = performance.now();
    const previousDayIndex=state.dayIndex||0;
    const date = currentDate();
    date.setUTCDate(date.getUTCDate() + 1);
    state.date = date.toISOString();
    advanceWorldState();
    archiveSeasonIfNeeded(previousDayIndex);

    state.copperPrev = state.copperPrice;
    state.aluminiumPrev = state.aluminiumPrice;
    state.ureaPrev = state.ureaPrice;
    state.eurusdPrev = state.eurusd;
    state.freightPrev = state.freightIndex;
    state.crudePrev = state.crudePrice;
    state.wheatPrev = state.wheatPrice;
    state.ironorePrev = state.ironorePrice;
    state.coffeePrev = state.coffeePrice;
    state.zincPrev = state.zincPrice;
    state.nickelPrev = state.nickelPrice;
    state.lngPrev = state.lngPrice;
    const seed = deterministicRandom(state.date);
    const regime = currentMarketRegime();
    const volatility = regime.volatility || 1;
    const crisisDrift = key => activeCrisisDefinitions().filter(event => event.commodity === key).reduce((sum,event)=>sum+(event.dailyDrift||0),0);
    // Mean reversion toward equilibrium prices (prevents runaway drift)
    const _eq = { copper: 9500, aluminium: 2450, urea: 360, crude: 78.5, wheat: 245, ironore: 108, coffee: 4200, zinc: 2800, nickel: 16000, lng: 12.5 };
    const _mrStrength = 0.018;
    const copperMR    = (state.copperPrice    - _eq.copper)    * _mrStrength;
    const aluminiumMR = (state.aluminiumPrice - _eq.aluminium) * _mrStrength;
    const ureaMR      = (state.ureaPrice      - _eq.urea)      * _mrStrength;
    const crudeMR     = (state.crudePrice     - _eq.crude)     * _mrStrength;
    const wheatMR     = (state.wheatPrice     - _eq.wheat)     * _mrStrength;
    const ironMR      = (state.ironorePrice   - _eq.ironore)   * _mrStrength;
    const coffeeMR    = (state.coffeePrice    - _eq.coffee)    * _mrStrength;
    const zincMR      = (state.zincPrice      - _eq.zinc)      * _mrStrength;
    const nickelMR    = (state.nickelPrice    - _eq.nickel)    * _mrStrength;
    const lngMR       = (state.lngPrice       - _eq.lng)       * _mrStrength;
    // Seasonal multipliers (month-specific volatility per commodity)
    const svCopper    = seasonalPriceVolatility('copper',    date);
    const svAluminium = seasonalPriceVolatility('aluminium', date);
    const svUrea      = seasonalPriceVolatility('urea',      date);
    const svCrude     = seasonalPriceVolatility('crude',     date);
    const svWheat     = seasonalPriceVolatility('wheat',     date);
    const svIronore   = seasonalPriceVolatility('ironore',   date);
    const svCoffee    = seasonalPriceVolatility('coffee',    date);
    const svZinc      = seasonalPriceVolatility('zinc',      date);
    const svNickel    = seasonalPriceVolatility('nickel',    date);
    const svLng       = seasonalPriceVolatility('lng',       date);
    // Base noise (same deterministic seeds as before) + seasonal vol + mean reversion
    const copperNoise    = ((Math.sin(date.getUTCDate() * .71 + date.getUTCMonth()) * 18 + (seed - .5) * 34 + crisisDrift('copper')) * volatility * svCopper) - copperMR;
    const aluminiumNoise = ((Math.cos(date.getUTCDate() * .53 + date.getUTCMonth() * .7) * 7 + (deterministicRandom(state.date + '-al') - .5) * 15 + crisisDrift('aluminium')) * volatility * svAluminium) - aluminiumMR;
    const ureaNoise      = ((Math.sin(date.getUTCDate() * .27 + date.getUTCMonth() * .9) * 1.6 + (deterministicRandom(state.date + '-ur') - .5) * 4.5 + crisisDrift('urea')) * volatility * svUrea) - ureaMR;
    const crudeNoise     = ((Math.sin(date.getUTCDate() * .43) * .45 + (deterministicRandom(state.date + '-cr') - .5) * 1.45 + crisisDrift('crude')) * volatility * svCrude) - crudeMR;
    const wheatNoise     = ((Math.cos(date.getUTCDate() * .37) * 1.3 + (deterministicRandom(state.date + '-wh') - .5) * 4.2 + crisisDrift('wheat')) * volatility * svWheat) - wheatMR + crudeNoise * 0.08;
    const ironNoise      = ((Math.sin(date.getUTCDate() * .32) * .55 + (deterministicRandom(state.date + '-io') - .5) * 1.8 + crisisDrift('ironore')) * volatility * svIronore) - ironMR;
    const coffeeNoise    = ((Math.cos(date.getUTCDate() * .25) * 18 + (deterministicRandom(state.date + '-co') - .5) * 46 + crisisDrift('coffee')) * volatility * svCoffee) - coffeeMR;
    const zincNoise      = ((Math.sin(date.getUTCDate() * .36) * 8 + (deterministicRandom(state.date + '-zn') - .5) * 22 + crisisDrift('zinc')) * volatility * svZinc) - zincMR;
    const nickelNoise    = ((Math.cos(date.getUTCDate() * .29) * 48 + (deterministicRandom(state.date + '-ni') - .5) * 145 + crisisDrift('nickel')) * volatility * svNickel) - nickelMR;
    const lngNoise       = ((Math.sin(date.getUTCDate() * .41) * .12 + (deterministicRandom(state.date + '-lng') - .5) * .38 + crisisDrift('lng')) * volatility * svLng) - lngMR;
    const fxNoise        = (Math.sin(date.getUTCDate() * .39) * .0011 + (deterministicRandom(state.date + '-fx') - .5) * .0025) * volatility + (regime.id === 'riskon' ? .0006 : regime.id === 'soft' ? -.0004 : 0);
    const freightNoise   = (Math.cos(date.getUTCDate() * .31) * .65 + (deterministicRandom(state.date + '-fr') - .5) * 1.4 + activeCrisisDefinitions().length * .08) * volatility + regime.freightBias + crudeNoise * 0.18;
    state.copperPrice    = clamp(state.copperPrice    + copperNoise,    8200,  11600);
    state.aluminiumPrice = clamp(state.aluminiumPrice + aluminiumNoise, 1950,   3100);
    state.ureaPrice      = clamp(state.ureaPrice      + ureaNoise,       250,    580);
    state.crudePrice     = clamp(state.crudePrice     + crudeNoise,       52,    116);
    state.wheatPrice     = clamp(state.wheatPrice     + wheatNoise,      175,    365);
    state.ironorePrice   = clamp(state.ironorePrice   + ironNoise,        72,    168);
    state.coffeePrice    = clamp(state.coffeePrice    + coffeeNoise,     2900,   6100);
    state.zincPrice      = clamp(state.zincPrice      + zincNoise,       2100,   3900);
    state.nickelPrice    = clamp(state.nickelPrice    + nickelNoise,    10500,  28000);
    state.lngPrice       = clamp(state.lngPrice       + lngNoise,         5.5,   28.0);
    state.eurusd         = clamp(state.eurusd         + fxNoise,          .94,   1.24);
    state.freightIndex   = clamp(state.freightIndex   + freightNoise,     68,    165);
    // Generate price news headlines for significant moves
    const _newsChecks = [
      ['copper',    state.copperPrev,    state.copperPrice],
      ['aluminium', state.aluminiumPrev, state.aluminiumPrice],
      ['crude',     state.crudePrev,     state.crudePrice],
      ['wheat',     state.wheatPrev,     state.wheatPrice],
      ['ironore',   state.ironorePrev,   state.ironorePrice],
      ['coffee',    state.coffeePrev,    state.coffeePrice],
      ['urea',      state.ureaPrev,      state.ureaPrice],
      ['zinc',      state.zincPrev,      state.zincPrice],
      ['nickel',    state.nickelPrev,    state.nickelPrice],
      ['lng',       state.lngPrev,       state.lngPrice]
    ];
    let newsAdded = 0;
    for (const [key, prev, curr] of _newsChecks) {
      if (newsAdded >= 2) break; // max 2 headlines per day
      const item = generatePriceNews(key, prev, curr, date);
      if (item) { state.worldEventFeed.unshift(item); newsAdded++; }
    }
    if (newsAdded) state.worldEventFeed = state.worldEventFeed.slice(0, 18);
    advanceFleetDay();
    // Update hub basis differentials (premium/discount vs global benchmark, in price units)
    const _hubBasisConfig = {
      'geneva':       { copper: { s:+18, r:.05 }, aluminium: { s:+12, r:.05 } },
      'rotterdam':    { copper: { s:+22, r:.04 }, aluminium: { s:+15, r:.04 } },
      'singapore':    { crude:  { s:-1.2, r:.04 }, wheat: { s:-8, r:.05 } },
      'shanghai':     { copper: { s:-30, r:.06 }, ironore: { s:-15, r:.06 } },
      'dubai':        { crude:  { s:-0.8, r:.04 }, urea: { s:-12, r:.05 } },
      'houston':      { crude:  { s:+0.6, r:.04 }, wheat: { s:+6, r:.05 } },
      'new-orleans':  { wheat:  { s:+10, r:.05 }, coffee: { s:-18, r:.04 } },
      'antwerp':      { copper: { s:+8, r:.04 }, aluminium: { s:+10, r:.04 }, ironore: { s:+5, r:.05 } },
      'santos':       { coffee: { s:-40, r:.06 }, wheat: { s:+5, r:.05 } },
      'abidjan':      { coffee: { s:-50, r:.07 } },
      'durban':       { crude:  { s:-3.0, r:.05 } },
      'klang':        { crude:  { s:-1.5, r:.04 } },
      'doha':         { urea:   { s:-18, r:.05 }, crude: { s:-2.5, r:.04 } },
      'rosario':      { wheat:  { s:+8, r:.05 } },
    };
    state.hubBasis = state.hubBasis || {};
    Object.entries(_hubBasisConfig).forEach(([hubId, comms]) => {
      state.hubBasis[hubId] = state.hubBasis[hubId] || {};
      Object.entries(comms).forEach(([key, cfg]) => {
        const prev = state.hubBasis[hubId][key] ?? cfg.s;
        // v45 — deterministico come tutto il resto della simulazione: con Math.random()
        // il basis divergeva fra una sessione e l'altra a parita' di salvataggio.
        const noise = (deterministicRandom(`basis-${hubId}-${key}-${state.date}`) - 0.5) * Math.abs(cfg.s) * 0.08;
        state.hubBasis[hubId][key] = prev + (cfg.s - prev) * cfg.r + noise;
      });
    });

    // Update term structure (contango = positive → near price < forward; backwardation = negative)
    // Driven by inventory tightness proxy: price deviation from equilibrium and regime
    const _updateTermStructure = (key, price, eq, regimeId) => {
      const deviation = (price - eq) / eq; // positive = above eq → backwardation signal
      const regimeBias = regimeId === 'squeeze' ? -0.12 : regimeId === 'soft' ? 0.08 : regimeId === 'freight' ? 0.05 : 0;
      const prev = state.termStructure[key] || 0;
      const target = clamp(-deviation * 1.8 + regimeBias, -0.5, 0.5);
      state.termStructure[key] = prev * 0.85 + target * 0.15; // smooth
    };
    const _reg = currentMarketRegime().id;
    _updateTermStructure('copper',    state.copperPrice,    _eq.copper,    _reg);
    _updateTermStructure('aluminium', state.aluminiumPrice, _eq.aluminium, _reg);
    _updateTermStructure('crude',     state.crudePrice,     _eq.crude,     _reg);
    _updateTermStructure('wheat',     state.wheatPrice,     _eq.wheat,     _reg);
    _updateTermStructure('ironore',   state.ironorePrice,   _eq.ironore,   _reg);
    _updateTermStructure('coffee',    state.coffeePrice,    _eq.coffee,    _reg);
    _updateTermStructure('urea',      state.ureaPrice,      _eq.urea,      _reg);
    _updateTermStructure('zinc',      state.zincPrice,      _eq.zinc,      _reg);
    _updateTermStructure('nickel',    state.nickelPrice,    _eq.nickel,    _reg);
    _updateTermStructure('lng',       state.lngPrice,       _eq.lng,       _reg);
    // Compute synthetic forward curve M1-M6 for each major commodity
    const _fwdComms = [
      ['copper', state.copperPrice], ['aluminium', state.aluminiumPrice],
      ['urea', state.ureaPrice],     ['crude', state.crudePrice],
      ['wheat', state.wheatPrice],   ['ironore', state.ironorePrice],
      ['coffee', state.coffeePrice], ['zinc', state.zincPrice],
      ['nickel', state.nickelPrice], ['lng', state.lngPrice],
    ];
    state.forwardCurve = {};
    _fwdComms.forEach(([key, spot]) => {
      const ts = state.termStructure[key] || 0;
      state.forwardCurve[key] = [1,2,3,4,5,6].map(m => {
        const carry = Math.pow(1 + ts * 0.12, m);
        const noise = 1 + (deterministicRandom(`fwd-${key}-${state.date}-${m}`) - 0.5) * 0.004;
        return Math.round(spot * carry * noise * 100) / 100;
      });
    });
    // Record rolling price history (last 90 days) per commodity
    state.priceHistory = state.priceHistory || {};
    _fwdComms.forEach(([key, spot]) => {
      const arr = state.priceHistory[key] || [];
      arr.push(Math.round(spot * 100) / 100);
      if (arr.length > 90) arr.shift();
      state.priceHistory[key] = arr;
    });
    const overhead = dailyOverhead();
    state.cash -= overhead;
    state.overheadPaid = (state.overheadPaid || 0) + overhead;
    // v45 — prima la cassa poteva restare negativa all'infinito senza alcuna
    // conseguenza. Ora scatta un finanziamento d'emergenza a tasso punitivo e,
    // se anche il credito e' esaurito, un avviso di insolvenza al board.
    handleCashShortfall();
    processInvestmentDay();
    processShopDay();
    processCreditLimitRequests();
    processProcurementAgreements();
    processCommercialFrameworks();
    processOfficeProjectsDay();
    processHQUpgradeDay();

    let eventTriggered = false;
    for (const deal of [...state.activeDeals]) {
      accrueDailyFinancing(deal);
      if (deal.delivered) {
        if ((deal.paymentDaysRemaining || 0) > 0) {
          deal.paymentDaysRemaining = Math.max(0, deal.paymentDaysRemaining - 1);
          if (deal.paymentDaysRemaining <= 0 && (deal.collectionDelayDays || 0) > 0) {
            deal.invoiceStatus = 'Overdue';
            if (!deal.overdueRecorded) {
              deal.overdueRecorded = true;
              state.overdueReceivables = (state.overdueReceivables || 0) + 1;
              recordJournal('Credit', `${getOpportunity(deal.opportunityId).title}: invoice overdue`, `${deal.collectionDelayDays} additional collection days expected.`, 0, deal.id);
            }
          } else if (deal.paymentDaysRemaining <= 0) completeDeal(deal);
        } else if ((deal.collectionDelayDays || 0) > 0) {
          deal.invoiceStatus = 'Overdue';
          deal.collectionDelayDays = Math.max(0, deal.collectionDelayDays - 1);
          if (deal.collectionDelayDays <= 0) completeDeal(deal);
        } else completeDeal(deal);
        continue;
      }
      deal.elapsed += 1;
      deal.contractLifecycle = { ...(deal.contractLifecycle || {}), loaded:(deal.elapsed / Math.max(1, deal.duration)) >= .18 };
      updateDealOperations(deal);
      updateMarginLiquidity(deal);
      accrueDailyShippingCosts(deal);
      if (!deal.eventTriggered && triggerDealEvent(deal)) {
        // v45 — 'continue', non 'break': gli altri cargo devono comunque
        // maturare giorni di transito, interessi e consegna.
        eventTriggered = true;
        continue;
      }
      if (deal.elapsed >= deal.duration) deliverDeal(deal);
    }

    evaluateAchievements();
    const stats = portfolioStats();
    state.valuationHigh = Math.max(state.valuationHigh||0, tradingHouseValuation().value);
    checkVictory();
    state.navHistory.push(stats.nav);
    if (state.navHistory.length > 50) state.navHistory.shift();
    scheduleSave();
    if (!deferRender) renderAll();
    if (!silent) { pulseNewDay(); try { Sound.play('day'); } catch (e) {} addXp(2, 'day'); }
    return !eventTriggered;
  }

  function pulseNewDay() {
    if (!motionEnabled()) return;
    const dateEl = $('#gameDate');
    if (dateEl) {
      dateEl.classList.remove('date-pulse');
      void dateEl.offsetWidth;
      dateEl.classList.add('date-pulse');
      setTimeout(() => dateEl.classList.remove('date-pulse'), 700);
    }
    const stage = $('#globeStage');
    if (stage && motionEnabled()) {
      const sweep = document.createElement('div');
      sweep.className = 'day-sweep';
      stage.appendChild(sweep);
      setTimeout(() => sweep.remove(), 900);
    }
  }

  function advanceToNextEvent() {
    if (state.activeDeals.some(d => d.pendingDecision)) return selectDeal(state.activeDeals.find(d => d.pendingDecision).id);
    let safe = 0;
    const feedBefore = state.worldEventFeed.length;
    const cycleBefore = state.marketCycle;
    const _prevSuppress = _soundSuppressed;
    _soundSuppressed = true;
    while (safe < 120) {
      safe++;
      const before = state.activeDeals.length;
      const continued = advanceDay({ silent: true, deferRender: true });
      if (!continued || state.activeDeals.length < before || state.worldEventFeed.length > feedBefore || state.marketCycle !== cycleBefore) break;
    }
    _soundSuppressed = _prevSuppress;
    renderAll();
    try { Sound.play('info'); } catch (e) {}
  }

  function updateClock() {
    $$('.time-button').forEach(b => b.classList.remove('active'));
    const dot = $('#clockDot');
    if (runningSpeed === 0) {
      $('#pauseButton').classList.add('active');
      $('#clockStatus').textContent = 'Paused';
      dot.classList.remove('running');
    } else {
      const speedButton = $(`.time-button[data-speed="${runningSpeed}"]`);
      speedButton?.classList.add('active');
      $('#clockStatus').textContent = `${runningSpeed}× active`;
      dot.classList.add('running');
    }
    _soundSuppressed = runningSpeed > 0;
    clearInterval(clockTimer);
    simulationDayAnchor = performance.now();
    if (runningSpeed > 0) {
      clockTimer = setInterval(() => advanceDay(), runningSpeed === 1 ? 1800 : 430);
    }
  }

  function forwardCurvePopupHtml(key, label, unit) {
    const curve = state.forwardCurve?.[key] || [];
    if (!curve.length) return '';
    const spot = curve[0];
    const ts = state.termStructure?.[key] || 0;
    const tsLabel = ts < -0.06 ? 'Backwardation' : ts > 0.06 ? 'Contango' : 'Flat';
    const tsColor = ts < -0.06 ? 'var(--orange)' : ts > 0.06 ? '#60a5fa' : 'var(--muted)';
    const months = ['M1','M2','M3','M4','M5','M6'];
    const mn = Math.min(...curve), mx = Math.max(...curve);
    const rng = mx - mn || 1;
    const bW=30, bG=5, pX=6, pY=10, cH=52, svgW = pX*2+(bW+bG)*6-bG;
    const fmt = p => unit==='bbl' ? '$'+p.toFixed(1) : Math.round(p).toLocaleString();
    const bars = curve.map((p,i)=>{
      const bH = Math.max(4, Math.round((p-mn)/rng*cH));
      const x = pX+i*(bW+bG), y = pY+cH-bH;
      const col = i===0 ? '#f59e0b' : p>spot ? '#60a5fa' : '#f97316';
      return `<rect x="${x}" y="${y}" width="${bW}" height="${bH}" rx="3" fill="${col}" opacity="${i===0?1:0.75}"/>`
           + `<text x="${x+bW/2}" y="${pY+cH+13}" text-anchor="middle" fill="rgba(255,255,255,.45)" font-size="9">${months[i]}</text>`
           + `<text x="${x+bW/2}" y="${y-3}" text-anchor="middle" fill="rgba(255,255,255,.85)" font-size="8">${fmt(p)}</text>`;
    }).join('');
    // Historical price line chart (last up to 60 days)
    const hist = (state.priceHistory?.[key] || []).slice(-60);
    let histSvg = '';
    if (hist.length >= 2) {
      const hMn = Math.min(...hist), hMx = Math.max(...hist);
      const hRng = hMx - hMn || 1;
      const hW = svgW, hH = 46, hPad = 4;
      const stepX = (hW - hPad*2) / (hist.length - 1);
      const pts = hist.map((p,i) => {
        const x = hPad + i*stepX;
        const y = hPad + (hH - hPad*2) * (1 - (p - hMn) / hRng);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      }).join(' ');
      const first = hist[0], last = hist[hist.length-1];
      const lineCol = last >= first ? '#6ce3a6' : '#f0717f';
      const areaPts = `${hPad},${hH-hPad} ${pts} ${(hPad+(hist.length-1)*stepX).toFixed(1)},${hH-hPad}`;
      const pctChg = ((last/first - 1) * 100);
      histSvg = `<div class="fwd-hist-head"><span>${hist.length}-day trend</span><strong style="color:${lineCol}">${pctChg>=0?'+':''}${pctChg.toFixed(1)}%</strong></div>
        <svg viewBox="0 0 ${hW} ${hH}" width="100%" style="display:block;margin-bottom:8px">
          <polyline points="${areaPts}" fill="${lineCol}" opacity="0.08" stroke="none"/>
          <polyline points="${pts}" fill="none" stroke="${lineCol}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>
        </svg>`;
    }
    return `<div class="fwd-curve-popup" id="fwdCurvePopup">
      <div class="fwd-curve-head"><strong>${label}</strong><em style="color:${tsColor}">${tsLabel}</em></div>
      ${histSvg}
      <div class="fwd-curve-sub">Forward curve</div>
      <svg viewBox="0 0 ${svgW} ${pY*2+cH+18}" width="100%" style="overflow:visible;display:block">${bars}</svg>
      <div class="fwd-curve-meta">
        <div><span>Spot</span><strong>${fmt(spot)}</strong></div>
        <div><span>6M forward</span><strong>${fmt(curve[5])}</strong></div>
        <div><span>Carry</span><strong style="color:${tsColor}">${ts>=0?'+':''}${(ts*100).toFixed(1)}%</strong></div>
      </div>
    </div>`;
  }

  function motionEnabled() {
    if (state && state.reduceMotion) return false;
    try { if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false; } catch (e) {}
    return true;
  }

  const _counterAnims = new WeakMap();
  // ── v46 · lampeggio del valore ──────────────────────────────────────────────
  // Un breve alone verde o rosso quando una metrica cambia: rende leggibile
  // "cosa e' appena successo" senza dover confrontare i numeri a memoria.
  function flashOnChange(el, value, threshold = 1) {
    if (!el || !Number.isFinite(value)) return;
    const previous = el._flashValue;
    el._flashValue = value;
    if (!Number.isFinite(previous) || !motionEnabled()) return;
    const delta = value - previous;
    if (Math.abs(delta) < threshold) return;
    const cls = delta > 0 ? 'value-flash-up' : 'value-flash-down';
    el.classList.remove('value-flash-up', 'value-flash-down');
    void el.offsetWidth;               // forza il riavvio dell'animazione
    el.classList.add(cls);
    clearTimeout(el._flashTimer);
    el._flashTimer = setTimeout(() => el.classList.remove(cls), 900);
  }

  function animateCounter(el, target, fmt) {
    if (!el) return;
    const prev = _counterAnims.get(el);
    if (prev) cancelAnimationFrame(prev.raf);
    const from = prev ? prev.current : (Number.isFinite(el._counterVal) ? el._counterVal : target);
    if (!motionEnabled() || from === target || from === null || from === undefined) {
      el.textContent = fmt(target);
      el._counterVal = target;
      _counterAnims.delete(el);
      return;
    }
    const duration = 520;
    const startT = performance.now();
    const step = (now) => {
      const t = Math.min(1, (now - startT) / duration);
      const eased = 1 - Math.pow(1 - t, 3); // easeOutCubic
      const value = from + (target - from) * eased;
      el.textContent = fmt(value);
      if (t < 1) {
        const raf = requestAnimationFrame(step);
        _counterAnims.set(el, { raf, current: value });
      } else {
        el.textContent = fmt(target);
        el._counterVal = target;
        _counterAnims.delete(el);
      }
    };
    const raf = requestAnimationFrame(step);
    _counterAnims.set(el, { raf, current: from });
    el._counterVal = target;
  }

  let _prevMetricValues = { nav: null, cash: null, rep: null };
  function flashMetric(elId, newVal, prevVal, opts = {}) {
    const el = $('#' + elId);
    if (!el) return;
    if (prevVal === null || prevVal === undefined || newVal === prevVal) return;
    if (!motionEnabled()) return;
    const up = newVal > prevVal;
    el.classList.remove('metric-flash-up', 'metric-flash-down');
    void el.offsetWidth; // reflow to restart animation
    el.classList.add(up ? 'metric-flash-up' : 'metric-flash-down');
    setTimeout(() => el.classList.remove('metric-flash-up', 'metric-flash-down'), 900);
    // Floating delta chip
    if (opts.showDelta && Math.abs(newVal - prevVal) >= (opts.threshold || 1)) {
      const chip = document.createElement('span');
      chip.className = 'metric-delta-chip ' + (up ? 'up' : 'down');
      const diff = newVal - prevVal;
      chip.textContent = (up ? '+' : '−') + (opts.fmt ? opts.fmt(Math.abs(diff)) : Math.abs(Math.round(diff)));
      const host = el.parentElement;
      if (host) {
        host.style.position = host.style.position || 'relative';
        host.appendChild(chip);
        requestAnimationFrame(() => chip.classList.add('rise'));
        setTimeout(() => chip.remove(), 1400);
      }
    }
  }

  function renderMetrics() {
    const stats = portfolioStats();
    const start = state.startingCapital || 500_000;
    const ret = (stats.nav / start - 1) * 100;
    animateCounter($('#navMetric'), stats.nav, v => money(v, true));
    $('#navDelta').textContent = `${ret >= 0 ? '+' : ''}${ret.toFixed(1)}% all time`;
    flashOnChange($('#cashMetric'), state.cash);
    animateCounter($('#cashMetric'), state.cash, v => money(v, true));
    $('#cashDelta').textContent = (dailyInvestmentIncome()+shopDailyIncome()) ? `${money(dailyInvestmentIncome()+shopDailyIncome())}/day assets` : (state.cash < 250_000 ? 'Low liquidity' : 'Available');
    animateCounter($('#creditMetric'), stats.creditUsed, v => money(v, true));
    $('#creditSub').textContent = `of ${money(effectiveCreditLimit(), true)}`;
    $('#repMetric').textContent = Math.round(state.reputation);
    $('#rankMetric').textContent = `${rankFromState()} · L${playerLevel()}`;
    const realizedMetric = $('#realizedPnlMetric');
    if (realizedMetric) {
      // v46 - anche il P&L scorre invece di saltare, e lampeggia quando cambia
      flashOnChange(realizedMetric, state.realizedPnl || 0);
      animateCounter(realizedMetric, state.realizedPnl || 0, v => money(v, true));
      realizedMetric.style.color = (state.realizedPnl||0) >= 0 ? 'var(--green)' : 'var(--red)';
    }
    const activeRail = $('#activePnlRail');
    if (activeRail) {
      flashOnChange(activeRail, stats.activePnl);
      animateCounter(activeRail, stats.activePnl, v => `${v >= 0 ? '+' : ''}${money(v, true)} live`);
      activeRail.style.color = stats.activePnl >= 0 ? 'var(--green)' : 'var(--red)';
    }
    const risk = riskStats();
    const riskMetric = $('#riskMetric');
    if (riskMetric) { riskMetric.textContent = `${Math.round(risk.riskScore)}/100`; riskMetric.style.color = risk.riskScore >= 70 ? 'var(--red)' : risk.riskScore >= 45 ? 'var(--orange)' : 'var(--green)'; }
    const riskImpactMetric = $('#riskImpactMetric');
    if (riskImpactMetric) { riskImpactMetric.textContent = `${money(state.riskPnlImpact || 0, true)} event impact`; riskImpactMetric.style.color = (state.riskPnlImpact||0) >= 0 ? 'var(--green)' : 'var(--red)'; }
    const stageMetric = $('#stageMetric'); if (stageMetric) stageMetric.textContent = expansionStage().title;
    animateCounter($('#portfolioValue'), stats.nav, v => money(v));
    $('#portfolioReturn').textContent = `${ret >= 0 ? '+' : ''}${ret.toFixed(1)}% since inception`;
    $('#portfolioReturn').style.color = ret >= 0 ? 'var(--green)' : 'var(--red)';
    animateCounter($('#investedMetric'), stats.invested, v => money(v, true));
    animateCounter($('#activePnlMetric'), stats.activePnl, v => money(v, true));
    $('#activePnlMetric').style.color = stats.activePnl >= 0 ? 'var(--green)' : 'var(--red)';
    $('#completedMetric').textContent = state.completedDeals;
    $('#creditAvailableMetric').textContent = money(stats.creditAvailable, true);
    $('#activeCount').textContent = state.activeDeals.length;
    $('#gameDate').textContent = formatDate(currentDate());
    const profileInitials=(state.profileName||'GB').split(/\s+/).map(value=>value[0]).slice(0,2).join('').toUpperCase();
    if ($('.profile-button')) $('.profile-button').textContent=profileInitials;
    const prestigeBadge = $('#prestigeBadge');
    if (prestigeBadge) {
      const lvl = state.prestigeLevel || 0;
      if (lvl > 0) { prestigeBadge.textContent = '★ ' + lvl; prestigeBadge.classList.remove('hidden'); prestigeBadge.title = `Prestige level ${lvl} · +${12*lvl}% starting capital`; }
      else prestigeBadge.classList.add('hidden');
    }
    // v31 XP HUD
    const xpLabel = $('#xpLevelLabel');
    if (xpLabel) xpLabel.textContent = state.xpLevel || 1;
    const xpFill = $('#xpFill');
    if (xpFill) { const p = xpLevelProgress(); xpFill.style.width = p.pct + '%'; const chip = $('#xpChip'); if (chip) chip.title = `Level ${state.xpLevel} · ${p.have}/${p.need} XP`; }
    const goldLabel = $('#goldBarsLabel'); if (goldLabel) goldLabel.textContent = (state.goldBars || 0).toLocaleString('en-US');

    // v24 animated metric feedback
    flashMetric('navMetric', stats.nav, _prevMetricValues.nav, { showDelta: true, threshold: 500, fmt: v => money(v, true).replace('$','$') });
    flashMetric('cashMetric', state.cash, _prevMetricValues.cash, { showDelta: true, threshold: 500, fmt: v => money(v, true) });
    flashMetric('repMetric', Math.round(state.reputation), _prevMetricValues.rep, { showDelta: true, threshold: 1 });
    _prevMetricValues = { nav: stats.nav, cash: state.cash, rep: Math.round(state.reputation) };

    const marketDisplays = [
      ['copper', state.copperPrice, state.copperPrev, `${money(state.copperPrice)}/t`, 2],
      ['aluminium', state.aluminiumPrice, state.aluminiumPrev, `${money(state.aluminiumPrice)}/t`, 2],
      ['urea', state.ureaPrice, state.ureaPrev, `${money(state.ureaPrice)}/t`, 2],
      ['crude', state.crudePrice, state.crudePrev, `$${state.crudePrice.toFixed(2)}/bbl`, 2],
      ['wheat', state.wheatPrice, state.wheatPrev, `${money(state.wheatPrice)}/t`, 2],
      ['ironore', state.ironorePrice, state.ironorePrev, `${money(state.ironorePrice)}/t`, 2],
      // v45 — il caffe' era l'unico ticker presente nell'HTML ma assente da questa
      // lista: restava fermo sul valore statico "$4,200/t · +0.0%" per tutta la partita.
      ['coffee', state.coffeePrice, state.coffeePrev, `${money(state.coffeePrice)}/t`, 2],
      ['eurusd', state.eurusd, state.eurusdPrev, state.eurusd.toFixed(4), 2],
      ['freight', state.freightIndex, state.freightPrev, state.freightIndex.toFixed(1), 2],
      ['zinc',    state.zincPrice   || 2800,  state.zincPrev   || 2800,  `${money(state.zincPrice||2800)}/t`,   2],
      ['nickel',  state.nickelPrice || 16000, state.nickelPrev || 16000, `${money(state.nickelPrice||16000)}/t`, 2],
      ['lng',     state.lngPrice    || 12.5,  state.lngPrev    || 12.5,  `$${(state.lngPrice||12.5).toFixed(2)}/MMBtu`, 2]
    ];
    const _tsKeys = { copper:'copper', aluminium:'aluminium', urea:'urea', crude:'crude', wheat:'wheat', ironore:'ironore', coffee:'coffee', zinc:'zinc', nickel:'nickel', lng:'lng' };
    marketDisplays.forEach(([id, value, previous, label, decimals]) => {
      const move = (previous && Number.isFinite(previous) && previous !== 0) ? (value / previous - 1) * 100 : 0;
      const priceEl = $(`#${id}Price`);
      if (priceEl) priceEl.textContent = label;
      const moveEl = $(`#${id}Move`);
      if (moveEl) {
        moveEl.textContent = `${move >= 0 ? '+' : ''}${move.toFixed(decimals)}%`;
        moveEl.style.color = move >= 0 ? 'var(--green)' : 'var(--red)';
      }
      // v46 - sparkline sugli ultimi 30 giorni di prezzo
      const sparkEl = $(`#${id}Spark`);
      if (sparkEl) {
        const series = (state.priceHistory?.[id] || []).slice(-30);
        const svg = sparklineSvg(series, { width: 42, height: 15 });
        if (sparkEl._sparkKey !== svg) { sparkEl.innerHTML = svg; sparkEl._sparkKey = svg; }
      }
      // Show term structure indicator
      const tsKey = _tsKeys[id];
      if (tsKey) {
        const ts = state.termStructure?.[tsKey] || 0;
        const tsEl = $(`#${id}TermStructure`);
        if (tsEl) {
          const tsLabel = ts < -0.06 ? 'Backw.' : ts > 0.06 ? 'Contango' : 'Flat';
          tsEl.textContent = tsLabel;
          tsEl.setAttribute('data-term', ts < -0.06 ? 'backwardation' : ts > 0.06 ? 'contango' : 'termstructure');
          tsEl.style.color = ts < -0.06 ? 'var(--orange)' : ts > 0.06 ? 'var(--blue)' : 'var(--muted)';
        }
      }
    });
    // Wire forward curve popup on clickable commodity tickers
    const _fwdMeta = {copper:['Copper','t'],aluminium:['Aluminium','t'],urea:['Urea','t'],crude:['Crude Oil','bbl'],wheat:['Wheat','t'],ironore:['Iron Ore','t'],coffee:['Coffee','t']};
    document.querySelectorAll('.market-ticker').forEach(ticker => {
      const priceEl = ticker.querySelector('[id$="Price"]');
      if (!priceEl) return;
      const comKey = priceEl.id.replace('Price','');
      if (!_fwdMeta[comKey]) return;
      ticker.style.cursor = 'pointer';
      ticker.onclick = (e) => {
        e.stopPropagation();
        const existing = document.getElementById('fwdCurvePopup');
        if (existing && existing._key === comKey) { existing.remove(); return; }
        if (existing) existing.remove();
        const [label, unit] = _fwdMeta[comKey];
        const wrapper = document.createElement('div');
        wrapper.innerHTML = forwardCurvePopupHtml(comKey, label, unit);
        const popup = wrapper.firstElementChild;
        if (!popup) return;
        popup._key = comKey;
        const rect = ticker.getBoundingClientRect();
        popup.style.top = (rect.bottom + 8) + 'px';
        popup.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - 230)) + 'px';
        document.body.appendChild(popup);
      };
    });
  }

  // ── v46 · curva del patrimonio ──────────────────────────────────────────────
  // Prima era una spezzata piatta con un riempimento fisso. Ora: colore che segue
  // il segno del rendimento, riempimento sfumato, linea del capitale iniziale,
  // marcatori su massimo e minimo e punto luminoso sul valore corrente.
  function renderEquityChart() {
    const line = $('#equityLine'), area = $('#equityArea');
    if (!line || !area) return;
    const chart = line.ownerSVGElement;
    const values = state.navHistory.length >= 2 ? state.navHistory : [state.cash || 1_000_000, state.cash || 1_000_000];
    const W = 260, H = 72, TOP = 5, BOT = 67;
    const rawMin = Math.min(...values), rawMax = Math.max(...values);
    const start = state.startingCapital || values[0] || 1;
    const min = Math.min(rawMin, start) * .995;
    const max = Math.max(rawMax, start) * 1.005;
    const range = max - min || 1;
    const xAt = i => (i / Math.max(1, values.length - 1)) * W;
    const yAt = v => BOT - ((v - min) / range) * (BOT - TOP);
    const points = values.map((v, i) => [xAt(i), yAt(v)]);

    const up = values.at(-1) >= start;
    const stroke = up ? 'var(--green)' : 'var(--red)';
    line.setAttribute('points', points.map(p => p.join(',')).join(' '));
    line.setAttribute('stroke', stroke);
    area.setAttribute('d', `M ${points[0][0]} ${H} L ${points.map(p => p.join(' ')).join(' L ')} L ${points.at(-1)[0]} ${H} Z`);
    area.setAttribute('fill', up ? 'url(#equityFillUp)' : 'url(#equityFillDown)');
    area.setAttribute('opacity', '1');

    // decorazioni ridisegnate a ogni aggiornamento
    chart.querySelectorAll('.equity-deco').forEach(node => node.remove());
    const svgNS = 'http://www.w3.org/2000/svg';
    const make = (tag, attrs) => { const el = document.createElementNS(svgNS, tag); el.setAttribute('class', 'equity-deco'); Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v)); chart.appendChild(el); return el; };

    // linea del capitale iniziale
    const baseY = yAt(start);
    make('line', { x1: 0, y1: baseY, x2: W, y2: baseY, stroke: 'rgba(255,255,255,.22)', 'stroke-width': 1, 'stroke-dasharray': '3 4', 'vector-effect': 'non-scaling-stroke' });

    if (values.length > 3 && rawMax !== rawMin) {
      const iMax = values.indexOf(rawMax), iMin = values.indexOf(rawMin);
      make('circle', { cx: xAt(iMax), cy: yAt(rawMax), r: 2.2, fill: 'var(--green)', opacity: .85 });
      make('circle', { cx: xAt(iMin), cy: yAt(rawMin), r: 2.2, fill: 'var(--red)', opacity: .85 });
    }
    // valore corrente
    const last = points.at(-1);
    make('circle', { cx: last[0], cy: last[1], r: 4.5, fill: stroke, opacity: .18 });
    make('circle', { cx: last[0], cy: last[1], r: 2.4, fill: stroke });
  }

  // ── v46 · sparkline SVG riutilizzabile ──────────────────────────────────────
  // `state.priceHistory` conserva 90 giorni per 10 commodity ma non veniva
  // praticamente mai mostrata: adesso alimenta i ticker di mercato.
  function sparklineSvg(series, options = {}) {
    const values = (series || []).filter(Number.isFinite);
    if (values.length < 2) return '';
    const w = options.width || 46, h = options.height || 16, pad = 1.5;
    const min = Math.min(...values), max = Math.max(...values), range = max - min || 1;
    const stepX = (w - pad * 2) / (values.length - 1);
    const pts = values.map((v, i) => `${(pad + i * stepX).toFixed(1)},${(pad + (h - pad * 2) * (1 - (v - min) / range)).toFixed(1)}`);
    const rising = values.at(-1) >= values[0];
    const color = options.color || (rising ? 'var(--green)' : 'var(--red)');
    const lastX = pad + (values.length - 1) * stepX;
    const lastY = pad + (h - pad * 2) * (1 - (values.at(-1) - min) / range);
    return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true" focusable="false">`
      + `<polyline points="${pts.join(' ')}" fill="none" stroke="${color}" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round" opacity=".92"/>`
      + `<circle cx="${lastX.toFixed(1)}" cy="${lastY.toFixed(1)}" r="1.7" fill="${color}"/>`
      + `</svg>`;
  }

  // ── v46 · navigazione a due livelli ─────────────────────────────────────────
  // 22 schede affiancate erano un muro di pulsanti. Ora si sceglie prima l'area,
  // poi la scheda; ogni area segnala quante cose richiedono attenzione.
  const tabGroups = [
    { id:'desk',    label:'Desk',       icon:'\u25C8', tabs:['portfolio','opportunities','rivals','counterparties'] },
    { id:'ops',     label:'Operations', icon:'\u25A4', tabs:['inventory','operations','supply','contracts','fleet'] },
    { id:'riskfin', label:'Risk',       icon:'\u26A0', tabs:['risk','finance','compliance','performance','events'] },
    { id:'growth',  label:'Growth',     icon:'\u2197', tabs:['strategy','expansion','empire','shop','hq'] },
    { id:'career',  label:'Career',     icon:'\u2605', tabs:['career','leaderboard','academy'] },
  ];

  // ── v51 · scoperta progressiva dei moduli ───────────────────────────────────
  // Prima il giocatore vedeva 22 schede al primo avvio: tutto lo strumentario di
  // una casa di trading matura, senza avere ancora un cargo. Ora si parte con due
  // schede e le altre compaiono quando il livello di esperienza le rende utili —
  // il che dà anche un senso concreto al salire di livello.
  const moduleUnlockLevel = tab => moduleUnlockLevels[tab] || 1;
  const moduleUnlocked = tab => playerLevel() >= moduleUnlockLevel(tab);

  // Moduli che si aprono esattamente a un dato livello, per l'annuncio di level-up
  function modulesUnlockedAtLevel(level) {
    return Object.entries(moduleUnlockLevels)
      .filter(([, required]) => required === level)
      .map(([tab]) => drawerLabel(tab) || tab);
  }

  // I moduli mai aperti restano marcati come nuovi
  function moduleIsNew(tab) {
    if (!moduleUnlocked(tab)) return false;
    if (moduleUnlockLevel(tab) <= 1) return false;
    return !(Array.isArray(state.seenModules) ? state.seenModules : []).includes(tab);
  }
  function markModuleSeen(tab) {
    if (!tab || !moduleIsNew(tab)) return;
    state.seenModules = [...(Array.isArray(state.seenModules) ? state.seenModules : []), tab];
    // v52 - alla prima apertura il mentore spiega di cosa si tratta
    queueMentorBriefing(tab, 'unlock');
  }
  const tabGroupsIT = { desk:'Scrivania', ops:'Operazioni', riskfin:'Rischio', growth:'Crescita', career:'Carriera' };
  const groupOfTab = tab => (tabGroups.find(group => group.tabs.includes(tab)) || tabGroups[0]).id;
  let activeTabGroup = 'desk';

  // Quante voci richiedono un'azione, per scheda. Solo lettura: non tocca lo stato.
  function tabAttention() {
    const counts = {};
    const add = (tab, value) => { if (value > 0) counts[tab] = (counts[tab] || 0) + value; };
    try {
      const deals = state.activeDeals || [];
      add('portfolio', deals.filter(d => d.pendingDecision).length);
      add('opportunities', opportunities.filter(opp => {
        if (!isOpportunityUnlocked(opp) || !opportunityAvailable(opp)) return false;
        const negotiation = state.negotiations?.[opp.id];
        return negotiation && negotiation.cycle === state.marketCycle && negotiation.status === 'accepted';
      }).length);
      add('contracts', deals.filter(d => d.invoiceStatus === 'Overdue').length
        + Object.values(state.creditLimitRequests || {}).filter(r => r && r.status === 'pending').length);
      add('compliance', Object.values(state.complianceReviews || {}).filter(r => r && r.status === 'pending').length);
      add('finance', deals.filter(d => (d.marginCalls || 0) > 0 && !d.delivered).length + ((state.cash < 0) ? 1 : 0));
      add('events', (state.activeGlobalEvents || []).length);
      add('shop', (state.shopOrders || []).length);
      add('empire', (state.constructionQueue || []).length);
      const officeSnapshot = officeAvailabilitySnapshot();
      add('expansion', officeSnapshot.projects.length || officeSnapshot.affordable.length);

    } catch (error) { /* i badge non devono mai impedire il render */ }
    return counts;
  }

  // ── v47 · frecce, Home e End dentro una barra di schede ─────────────────────
  function wireArrowNavigation(container, selector) {
    if (!container || container._arrowsWired) return;
    container._arrowsWired = true;
    container.addEventListener('keydown', event => {
      const keys = ['ArrowRight', 'ArrowLeft', 'ArrowDown', 'ArrowUp', 'Home', 'End'];
      if (!keys.includes(event.key)) return;
      const items = [...container.querySelectorAll(selector)].filter(item => !item.hidden && !item.disabled);
      if (items.length < 2) return;
      const current = items.indexOf(document.activeElement);
      if (current < 0) return;
      event.preventDefault();
      let next = current;
      if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = items.length - 1;
      else if (event.key === 'ArrowRight' || event.key === 'ArrowDown') next = (current + 1) % items.length;
      else next = (current - 1 + items.length) % items.length;
      items[next].focus();
      items[next].click();
    });
  }

  function renderTabs() {
    const attention = tabAttention();
    // v51 - se il modulo attivo non e' (piu') disponibile si torna alla scrivania
    if (!moduleUnlocked(activeLeftTab)) activeLeftTab = 'portfolio';
    markModuleSeen(activeLeftTab);
    activeTabGroup = groupOfTab(activeLeftTab);

    const groupRail = $('#panelGroups');
    // v47 - la barra delle aree viene ricostruita: se il fuoco era li' dentro va
    // riportato sul nuovo pulsante attivo, altrimenti le frecce smettono di funzionare.
    const focusWasOnGroup = Boolean(document.activeElement?.closest?.('#panelGroups'));
    if (groupRail) {
      const useIT = state.language === 'it';
      groupRail.innerHTML = tabGroups.filter(group => group.tabs.some(moduleUnlocked)).map(group => {
        const visible = group.tabs.filter(moduleUnlocked);
        const count = visible.reduce((sum, tab) => sum + (attention[tab] || 0), 0);
        const fresh = visible.some(moduleIsNew);
        const label = useIT ? (tabGroupsIT[group.id] || group.label) : group.label;
        const isActive = group.id === activeTabGroup;
        return `<button class="panel-group ${isActive ? 'active' : ''} ${fresh ? 'fresh' : ''}" data-tab-group="${group.id}" role="tab" aria-selected="${isActive}" tabindex="${isActive ? 0 : -1}" aria-label="${label}${count ? `, ${count} item${count === 1 ? '' : 's'} need attention` : ''}${fresh ? ', contains a new module' : ''}">
          <i aria-hidden="true">${group.icon}</i><span>${label}</span>${count ? `<em class="group-count">${count > 9 ? '9+' : count}</em>` : ''}
        </button>`;
      }).join('');
      if (focusWasOnGroup) groupRail.querySelector('.panel-group.active')?.focus();
      $$('[data-tab-group]', groupRail).forEach(button => button.addEventListener('click', () => {
        const group = tabGroups.find(item => item.id === button.dataset.tabGroup);
        if (!group) return;
        // apre il modulo nuovo, poi quello che richiede attenzione, altrimenti il primo
        const available = group.tabs.filter(moduleUnlocked);
        const target = available.find(moduleIsNew) || available.find(tab => attention[tab]) || available[0];
        if (!target) return;
        activeLeftTab = target;
        try { Sound.play('click'); } catch (e) {}
        renderTabs();
        renderSection(activeLeftTab, { animate: true });
      }));
    }

    $$('.panel-tab').forEach(button => {
      const tab = button.dataset.leftTab;
      const isActive = tab === activeLeftTab;
      const unlocked = moduleUnlocked(tab);
      button.classList.toggle('active', isActive);
      button.classList.toggle('fresh', moduleIsNew(tab));
      button.hidden = !unlocked || button.dataset.group !== activeTabGroup;
      // v47 - roving tabindex: Tab entra nella barra, poi ci si muove con le frecce
      button.setAttribute('role', 'tab');
      button.setAttribute('aria-selected', String(isActive));
      button.setAttribute('aria-controls', `left-${tab}`);
      button.tabIndex = isActive ? 0 : -1;
      const count = attention[tab] || 0;
      let badge = button.querySelector('.tab-count');
      if (count) {
        if (!badge) { badge = document.createElement('em'); badge.className = 'tab-count'; button.appendChild(badge); }
        badge.textContent = count > 9 ? '9+' : String(count);
        badge.setAttribute('aria-label', `${count} item${count === 1 ? '' : 's'} need attention`);
      } else if (badge) badge.remove();
    });

    wireArrowNavigation($('#panelGroups'), '[data-tab-group]');
    wireArrowNavigation($('#panelTabs'), '.panel-tab');

    // v51 - anche i comandi sul globo seguono la scoperta progressiva dei moduli
    const shopButton = $('#openShopButton');
    if (shopButton) shopButton.hidden = !moduleUnlocked('shop');
    const officesButton = $('#openOfficesButton');
    if (officesButton) officesButton.hidden = !moduleUnlocked('expansion');

    $$('.left-section').forEach(section => {
      const isActive = section.id === `left-${activeLeftTab}`;
      section.classList.toggle('active', isActive);
      section.setAttribute('role', 'tabpanel');
      section.setAttribute('aria-hidden', String(!isActive));
    });
    if (_renderedLeftTab !== activeLeftTab) renderSection(activeLeftTab, { animate: true });
    if ($('#drawerTitle')) $('#drawerTitle').textContent = drawerLabel(activeLeftTab) || 'Command center';
    const askButton = $('#askMentorButton');
    if (askButton) askButton.hidden = !moduleBriefing(activeLeftTab);
  }

  function renderActiveDeals() {
    const container = $('#activeDealsList');
    if (!state.activeDeals.length) {
      container.innerHTML = emptyState('No open operations yet.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
      return;
    }
    container.innerHTML = state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      if (!opp || !getHub(opp.origin) || !getHub(opp.destination)) return '';
      const progress = computeDealProgress(deal);
      const pnl = computeUnrealizedPnl(deal);
      return `<button class="deal-card ${selected.type === 'deal' && selected.id === deal.id ? 'selected' : ''}" data-deal-id="${deal.id}">
        <div class="deal-card-head"><span class="route-name">${getHub(opp.origin).name} <span class="route-arrow">→</span> ${getHub(opp.destination).name}</span><span class="status-pill ${deal.pendingDecision ? 'high' : ''}">${deal.pendingDecision ? 'Decision' : Math.round(progress*100)+'%'}</span></div>
        <div class="deal-card-meta"><div><span>Unrealized P&amp;L</span><strong style="color:${pnl >= 0 ? 'var(--green)' : 'var(--red)'}">${money(pnl)}</strong></div><div><span>${deal.delivered?(deal.invoiceStatus==='Overdue'?'Overdue':'Cash due'):'ETA'}</span><strong>${deal.delivered?(deal.invoiceStatus==='Overdue'?Math.max(0,deal.collectionDelayDays||0):Math.max(0,deal.paymentDaysRemaining||0)):Math.max(0, deal.duration-deal.elapsed)} days</strong></div><div><span>Hedge</span><strong>${deal.hedgeRatio || 0}%</strong></div><div><span>Ops ready</span><strong>${Math.round(operationsReadiness(deal))}%</strong></div></div>
        <div class="progress-track"><span style="width:${progress*100}%"></span></div>
      </button>`;
    }).join('');
    $$('[data-deal-id]', container).forEach(button => button.addEventListener('click', () => selectDeal(button.dataset.dealId)));
  }

  function renderHistory() {
    const container = $('#historyList');
    if (!state.history.length) {
      container.innerHTML = emptyState('Your track record will appear after the first closed deal.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
      return;
    }
    container.innerHTML = state.history.slice(0,8).map(item => {
      const opp = getOpportunity(item.opportunityId);
      return `<button class="history-card ${selected.type==='history'&&selected.id===item.id?'selected':''}" data-history-id="${item.id}"><div class="history-card-head"><span class="route-name">${opp.title}</span><strong class="history-pnl ${item.pnl >= 0 ? 'positive' : 'negative'}">${money(item.pnl)}</strong></div><div class="deal-card-meta"><div><span>Duration</span><strong>${item.days} days</strong></div><div><span>Ops score</span><strong>${Math.round(item.operationalReadiness ?? 100)}%</strong></div><div><span>Margin calls</span><strong>${item.marginCalls||0}</strong></div><div><span>FX hedge</span><strong>${item.fxHedgeRatio||0}%</strong></div></div></button>`;
    }).join('');
    $$('[data-history-id]',container).forEach(button=>button.addEventListener('click',()=>selectHistory(button.dataset.historyId)));
  }

  function renderInventory() {
    const summary = $('#inventorySummary');
    const container = $('#inventoryList');
    const tonnes = state.activeDeals.reduce((sum, deal) => sum + (deal.quantity || getOpportunity(deal.opportunityId).quantity), 0);
    const value = state.activeDeals.reduce((sum, deal) => {
      const opp = getOpportunity(deal.opportunityId);
      return sum + physicalNotional(opp, deal.quantity || opp.quantity, deal.capital);
    }, 0);
    const inTransit = state.activeDeals.filter(d => dealPhase(d).key === 'transit').length;
    const atPort = state.activeDeals.filter(d => dealPhase(d).key === 'port').length;
    summary.innerHTML = `
      <div><span>Physical tonnes</span><strong>${tonnes.toLocaleString('en-US')} t</strong></div>
      <div><span>Marked value</span><strong>${money(value, true)}</strong></div>
      <div><span>In transit</span><strong>${inTransit} cargo</strong></div>
      <div><span>At port</span><strong>${atPort} cargo</strong></div>`;
    if (!state.activeDeals.length) {
      container.innerHTML = emptyState('No physical inventory yet.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
      return;
    }
    container.innerHTML = state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const phase = dealPhase(deal);
      const quantity = deal.quantity || opp.quantity;
      const value = physicalNotional(opp, quantity, deal.capital);
      const progress = computeDealProgress(deal);
      return `<button class="inventory-card" data-inventory-deal="${deal.id}">
        <div class="inventory-head"><strong>${quantity} t ${opp.commodity}</strong><span class="phase-chip ${phase.key}">${phase.label}</span></div>
        <div class="inventory-grid">
          <div><span>Location</span><strong>${phase.location}</strong></div>
          <div><span>Market value</span><strong>${money(value, true)}</strong></div>
          <div><span>Transport</span><strong>${opp.transportMode}</strong></div>
          <div><span>Insured</span><strong>110% cargo value</strong></div>
        </div>
        <div class="progress-track"><span style="width:${progress*100}%"></span></div>
      </button>`;
    }).join('');
    $$('[data-inventory-deal]', container).forEach(button => button.addEventListener('click', () => selectDeal(button.dataset.inventoryDeal)));
  }


  function renderOperations() {
    const summary = $('#operationsSummary');
    const container = $('#operationsList');
    if (!summary || !container) return;
    const allDeals = state.activeDeals.map(updateDealOperations);
    const docs = allDeals.flatMap(d => d.operations.documents);
    const readyDocs = docs.filter(d => d.status === 'ready').length;
    const blockedDocs = docs.filter(d => d.status === 'blocked').length;
    const activeStorage = allDeals.filter(d => d.operations.storage.active).length;
    const avgReadiness = allDeals.length ? allDeals.reduce((s,d)=>s+operationsReadiness(d),0)/allDeals.length : 0;
    summary.innerHTML = `
      <div><span>Open contracts</span><strong>${allDeals.length * 2}</strong></div>
      <div><span>Document readiness</span><strong>${docs.length ? Math.round(readyDocs/docs.length*100) : 0}%</strong></div>
      <div><span>Blocked documents</span><strong style="color:${blockedDocs?'var(--red)':'var(--green)'}">${blockedDocs}</strong></div>
      <div><span>Active storage</span><strong>${activeStorage}</strong></div>`;
    if (!allDeals.length) {
      container.innerHTML = emptyState('No operations chain running.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
      return;
    }
    container.innerHTML = allDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const ops = deal.operations;
      const readiness = operationsReadiness(deal);
      const blocked = ops.documents.filter(d => d.status === 'blocked').length;
      return `<button class="operations-card" data-operations-deal="${deal.id}">
        <div class="operations-head"><div><span>${ops.contractId}</span><strong>${opp.title}</strong></div><div class="readiness-ring" style="--value:${readiness}"><strong>${Math.round(readiness)}%</strong></div></div>
        <div class="operations-grid">
          <div><span>Carrier</span><strong>${ops.transport.carrier}</strong></div>
          <div><span>Transport status</span><strong>${ops.transport.status}</strong></div>
          <div><span>Storage</span><strong>${ops.storage.active ? 'Active' : ops.storage.reserved ? 'Reserved' : 'Not booked'}</strong></div>
          <div><span>Exceptions</span><strong style="color:${blocked?'var(--red)':'var(--green)'}">${blocked ? blocked+' blocked' : 'None'}</strong></div>
        </div>
        <div class="document-strip">${ops.documents.map(d=>`<i class="document-dot ${d.status}"></i>`).join('')}</div>
      </button>`;
    }).join('');
    $$('[data-operations-deal]', container).forEach(button => button.addEventListener('click', () => selectDeal(button.dataset.operationsDeal)));
  }


  function routeConditionFor(opp) {
    state.routeConditions = state.routeConditions || {};
    const current = state.routeConditions[opp.id];
    if (current && current.cycle === state.marketCycle) return current;
    const ocean = /Ocean|bulk|carrier|VLCC|Panamax|Capesize|Handymax|LNG/i.test(opp.transportMode || '');
    const crisisPressure = activeCrisisDefinitions().filter(event => event.affects?.(opp)).reduce((sum, event) => sum + (event.severity === 'Critical' ? 22 : event.severity === 'High' ? 16 : 9), 0);
    const freightPressure = Math.max(0, (state.freightIndex || 100) - 100) * .55;
    const regimePressure = currentMarketRegime().id === 'freight' ? 18 : currentMarketRegime().id === 'squeeze' ? 10 : 0;
    const seed = deterministicRandom(`${opp.id}-${state.marketCycle}-network`);
    const score = clamp(Math.round(12 + seed * 58 + crisisPressure + freightPressure + regimePressure + (ocean ? 8 : 0)), 5, 96);
    const severity = score >= 78 ? 'Severe' : score >= 55 ? 'Elevated' : score >= 32 ? 'Moderate' : 'Fluid';
    const delayDays = severity === 'Severe' ? 4 + Math.floor(seed * 3) : severity === 'Elevated' ? 2 + Math.floor(seed * 2) : severity === 'Moderate' ? 1 : 0;
    const notionalScale = Math.max(.7, Math.min(2.8, (opp.capital || 1_000_000) / 3_000_000));
    const freightCost = Math.round((score ** 1.25) * 95 * notionalScale / 1000) * 1000;
    const bottleneck = ocean
      ? (score >= 70 ? 'Berth and vessel capacity' : score >= 45 ? 'Port rotation' : 'Open capacity')
      : (score >= 70 ? 'Border and rail slots' : score >= 45 ? 'Terminal handling' : 'Open capacity');
    const condition = {
      cycle: state.marketCycle,
      score,
      severity,
      delayDays,
      freightCost,
      acceptancePenalty: severity === 'Severe' ? 7 : severity === 'Elevated' ? 4 : severity === 'Moderate' ? 1 : 0,
      bottleneck,
      generatedAt: state.date
    };
    state.routeConditions[opp.id] = condition;
    return condition;
  }

  function refreshRouteConditions() {
    state.routeConditions = {};
    opportunities.forEach(opp => routeConditionFor(opp));
  }

  function procurementAgreementForOpportunity(opp) {
    const supplierId = partiesForOpportunity(opp).supplierId;
    const agreement = supplierId ? state.procurementAgreements?.[supplierId] : null;
    if (!agreement || agreement.status !== 'active' || agreement.daysRemaining <= 0) return null;
    return agreement.commodities?.includes(opp.commodity) ? agreement : null;
  }

  function procurementAgreementAdjustments(opp) {
    const agreement = procurementAgreementForOpportunity(opp);
    if (!agreement) return { agreement: null, pnlBonus: 0, acceptance: 0, equityFactor: 1, durationBonus: 0, competitionFactor: 1 };
    const remainingCommitment = Math.max(0, agreement.commitment - agreement.liftings);
    return {
      agreement,
      pnlBonus: Math.round(Math.max(6_000, opp.basePnl * .075)),
      acceptance: 6,
      equityFactor: .96,
      durationBonus: 1,
      competitionFactor: remainingCommitment > 0 ? .72 : .84
    };
  }

  function supplierAgreementCandidates() {
    const map = new Map();
    opportunities.filter(isOpportunityUnlocked).forEach(opp => {
      const supplierId = partiesForOpportunity(opp).supplierId;
      const supplier = getCounterparty(supplierId);
      if (!supplier || !supplierId) return;
      if (!map.has(supplierId)) map.set(supplierId, { supplierId, supplier, commodities: new Set(), routes: [] });
      const row = map.get(supplierId);
      row.commodities.add(opp.commodity);
      row.routes.push(opp);
    });
    return [...map.values()].map(item => ({ ...item, commodities: [...item.commodities] }));
  }

  function signProcurementAgreement(supplierId) {
    state.procurementAgreements = state.procurementAgreements || {};
    const existing = state.procurementAgreements[supplierId];
    if (existing?.status === 'active' && existing.daysRemaining > 0) return showToast('An active procurement agreement already covers this supplier.');
    const candidate = supplierAgreementCandidates().find(item => item.supplierId === supplierId);
    if (!candidate) return showToast('No eligible supply program is available.');
    const relationship = getCounterpartyState(supplierId).relationship || 50;
    if (relationship < 42) return showToast('Improve the supplier relationship before proposing a strategic agreement.');
    const averageCapital = candidate.routes.reduce((sum, opp) => sum + (opp.capital || 0), 0) / Math.max(1, candidate.routes.length);
    const fee = Math.round(clamp(averageCapital * .012, 32_000, 95_000) / 1000) * 1000;
    if (state.cash < fee) return showToast(`Insufficient liquidity. The reservation fee is ${money(fee)}.`);
    state.cash -= fee;
    state.supplyChainSpend = (state.supplyChainSpend || 0) + fee;
    state.procurementAgreements[supplierId] = {
      supplierId,
      commodities: candidate.commodities,
      signedAt: state.date,
      daysRemaining: 90,
      commitment: 3,
      liftings: 0,
      fee,
      status: 'active',
      fulfilledRewardPaid: false
    };
    recordJournal('Procurement', `${candidate.supplier.name}: strategic supply agreement`, `90-day framework · 3 cargo commitment · reservation fee ${money(fee)}.`, -fee, supplierId);
    state.worldEventFeed.unshift({ type:'contract', title:`Supply framework signed · ${candidate.supplier.name}`, date:state.date, description:`Priority access secured for ${candidate.commodities.join(', ')}. Three cargo liftings are due within 90 days.` });
    state.worldEventFeed = state.worldEventFeed.slice(0, 18);
    saveState();
    renderAll();
    showToast(`Strategic supply agreement signed with ${candidate.supplier.name}.`);
  }

  function registerProcurementLift(opp, deal, economics) {
    const agreement = procurementAgreementForOpportunity(opp);
    if (!agreement) return;
    agreement.liftings += 1;
    agreement.lastLiftDay = state.dayIndex || 0;
    state.supplyChainSavings = (state.supplyChainSavings || 0) + (economics.procurementSavings || economics.procurementBonus || 0);
    deal.procurementAgreementId = agreement.supplierId;
    if (agreement.liftings >= agreement.commitment && !agreement.fulfilledRewardPaid) {
      agreement.fulfilledRewardPaid = true;
      state.commitmentsFulfilled = (state.commitmentsFulfilled || 0) + 1;
      state.reputation = clamp((state.reputation || 0) + 2, 0, 100);
      recordJournal('Procurement', `${getCounterparty(agreement.supplierId)?.name || 'Supplier'} commitment fulfilled`, `${agreement.liftings}/${agreement.commitment} cargoes lifted. Reputation +2.`, 0, agreement.supplierId);
    }
  }

  function processProcurementAgreements() {
    Object.values(state.procurementAgreements || {}).forEach(agreement => {
      if (!agreement || agreement.status !== 'active') return;
      agreement.daysRemaining = Math.max(0, (agreement.daysRemaining || 0) - 1);
      if (agreement.daysRemaining > 0) return;
      const shortfall = Math.max(0, (agreement.commitment || 0) - (agreement.liftings || 0));
      const penalty = shortfall * 18_000;
      if (penalty > 0) {
        state.cash -= penalty;
        state.supplyChainSpend = (state.supplyChainSpend || 0) + penalty;
        agreement.status = 'expired-shortfall';
        agreement.shortfallPenalty = penalty;
        state.reputation = clamp((state.reputation || 0) - Math.min(4, shortfall), 0, 100);
        recordJournal('Procurement', `${getCounterparty(agreement.supplierId)?.name || 'Supplier'} commitment shortfall`, `${shortfall} cargo commitment missed · penalty ${money(penalty)}.`, -penalty, agreement.supplierId);
        state.worldEventFeed.unshift({ type:'alert', title:'Take-or-pay commitment missed', date:state.date, description:`${getCounterparty(agreement.supplierId)?.name || 'Supplier'} charged ${money(penalty)} for ${shortfall} unlifted cargo commitment${shortfall === 1 ? '' : 's'}.` });
      } else {
        agreement.status = 'fulfilled';
        recordJournal('Procurement', `${getCounterparty(agreement.supplierId)?.name || 'Supplier'} framework completed`, `${agreement.liftings} cargoes lifted with no shortfall.`, 0, agreement.supplierId);
      }
    });
    state.worldEventFeed = state.worldEventFeed.slice(0, 18);
  }

  function mitigateRouteCongestion(dealId) {
    const deal = getActiveDeal(dealId);
    if (!deal || deal.delivered || deal.routeMitigated) return;
    const route = deal.routeCondition || routeConditionFor(getOpportunity(deal.opportunityId));
    if (!route || route.delayDays <= 0) return showToast('This route is currently fluid; no mitigation is required.');
    const daysSaved = Math.min(3, Math.max(1, Math.ceil(route.delayDays * .6)));
    const cost = Math.round((9_000 + route.score * 180) / 1000) * 1000;
    deal.duration = Math.max(deal.elapsed + 1, deal.duration - daysSaved);
    deal.pnlAdjustments -= cost;
    deal.routeMitigated = true;
    deal.routeMitigationCost = cost;
    deal.routeMitigationDays = daysSaved;
    state.congestionMitigations = (state.congestionMitigations || 0) + 1;
    state.supplyChainSpend = (state.supplyChainSpend || 0) + cost;
    recordJournal('Supply chain', `${getOpportunity(deal.opportunityId).title}: congestion mitigation`, `${daysSaved} transit days protected through priority slots and alternate handling · cost ${money(cost)}.`, -cost, deal.id);
    saveState(); renderAll(); showToast(`Priority capacity secured. ETA improved by ${daysSaved} day${daysSaved === 1 ? '' : 's'}.`);
  }

  function renderSupplyChain() {
    const summary = $('#supplyChainSummary');
    const routes = $('#routeConditionList');
    const agreements = $('#procurementAgreementList');
    const cargoes = $('#supplyChainCargoList');
    if (!summary || !routes || !agreements || !cargoes) return;
    const visibleOpps = opportunities.filter(isOpportunityUnlocked);
    const conditions = visibleOpps.map(opp => ({ opp, condition: routeConditionFor(opp) }));
    const averageCongestion = conditions.length ? Math.round(conditions.reduce((sum, row) => sum + row.condition.score, 0) / conditions.length) : 0;
    const severe = conditions.filter(row => row.condition.score >= 78).length;
    const activeAgreements = Object.values(state.procurementAgreements || {}).filter(item => item?.status === 'active' && item.daysRemaining > 0);
    const inventoryAtRisk = state.activeDeals.filter(deal => !deal.delivered && (deal.routeCondition?.score || 0) >= 55).reduce((sum, deal) => sum + (deal.capital || 0), 0);
    summary.innerHTML = `
      <div><span>Network congestion</span><strong>${averageCongestion}/100</strong></div>
      <div><span>Severe corridors</span><strong style="color:${severe ? 'var(--red)' : 'var(--green)'}">${severe}</strong></div>
      <div><span>Strategic suppliers</span><strong>${activeAgreements.length}</strong></div>
      <div><span>Inventory at risk</span><strong>${money(inventoryAtRisk,true)}</strong></div>`;
    routes.innerHTML = conditions.sort((a,b) => b.condition.score - a.condition.score).map(({opp, condition}) => `
      <button class="route-condition-card severity-${condition.severity.toLowerCase()}" data-supply-route="${opp.id}">
        <div class="route-condition-head"><div><span>${opp.commodity} · ${condition.bottleneck}</span><strong>${getHub(opp.origin).name} → ${getHub(opp.destination).name}</strong></div><b>${condition.score}</b></div>
        <div class="route-condition-meter"><i style="width:${condition.score}%"></i></div>
        <div class="route-condition-meta"><span>${condition.severity}</span><span>+${condition.delayDays}d</span><span>${money(condition.freightCost)} capacity cost</span></div>
      </button>`).join('') || '<div class="empty-card">No unlocked trade corridors.</div>';
    const candidates = supplierAgreementCandidates();
    agreements.innerHTML = candidates.map(candidate => {
      const agreement = state.procurementAgreements?.[candidate.supplierId];
      const active = agreement?.status === 'active' && agreement.daysRemaining > 0;
      const completed = agreement && !active;
      return `<div class="procurement-card ${active ? 'active' : completed ? 'completed' : ''}">
        <div class="procurement-head"><div><span>${candidate.supplier.country} · ${candidate.commodities.join(', ')}</span><strong>${candidate.supplier.name}</strong></div><b>${active ? `${agreement.daysRemaining}d` : completed ? agreement.status.replace('-', ' ') : 'Open'}</b></div>
        ${active ? `<div class="commitment-progress"><span style="width:${Math.min(100,agreement.liftings/agreement.commitment*100)}%"></span></div><div class="procurement-meta"><span>${agreement.liftings}/${agreement.commitment} cargoes lifted</span><span>Priority access · lower capital · margin edge</span></div>` : `<p>Secure priority allocation, reduced tender pressure and better working-capital terms for a 90-day, three-cargo commitment.</p><button class="button secondary" data-sign-procurement="${candidate.supplierId}">${completed ? 'Renew framework' : 'Propose framework'}</button>`}
      </div>`;
    }).join('') || '<div class="empty-card">No supplier programs are currently accessible.</div>';
    cargoes.innerHTML = state.activeDeals.length ? state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const route = deal.routeCondition || routeConditionFor(opp);
      const mtm = computeUnrealizedPnl(deal);
      return `<button class="supply-cargo-card" data-supply-deal="${deal.id}"><div><span>${deal.delivered ? deal.invoiceStatus : `${Math.max(0,deal.duration-deal.elapsed)}d to destination`}</span><strong>${opp.title}</strong><small>${deal.quantity.toLocaleString('en-US')} t · ${route.severity} route · ${deal.procurementAgreementId ? 'contracted supply' : 'spot supply'}</small></div><b style="color:${mtm>=0?'var(--green)':'var(--red)'}">${money(mtm,true)}</b></button>`;
    }).join('') : '<div class="empty-card">No inventory is currently moving through the network.</div>';
    $$('[data-supply-route]', routes).forEach(button => button.addEventListener('click', () => selectOpportunity(button.dataset.supplyRoute)));
    $$('[data-sign-procurement]', agreements).forEach(button => button.addEventListener('click', () => signProcurementAgreement(button.dataset.signProcurement)));
    $$('[data-supply-deal]', cargoes).forEach(button => button.addEventListener('click', () => selectDeal(button.dataset.supplyDeal)));
  }


  function renderContracts() {
    const summary = $('#contractSummary');
    const contracts = $('#contractList');
    const receivables = $('#receivableList');
    const requests = $('#creditRequestList');
    if (!summary || !contracts || !receivables || !requests) return;
    const outstanding = state.activeDeals.filter(deal => deal.delivered && ((deal.paymentDaysRemaining || 0) > 0 || (deal.collectionDelayDays || 0) > 0));
    const outstandingValue = outstanding.reduce((sum, deal) => sum + (deal.invoiceAmount || 0), 0);
    const creditUsed = counterpartyCatalog.reduce((sum, party) => sum + counterpartyExposure(party.id), 0);
    const totalLimits = counterpartyCatalog.reduce((sum, party) => sum + counterpartyCreditLimit(party.id), 0);
    summary.innerHTML = `
      <div><span>Live contracts</span><strong>${state.activeDeals.length}</strong></div>
      <div><span>Receivables</span><strong>${money(outstandingValue,true)}</strong></div>
      <div><span>Buyer limits used</span><strong>${totalLimits ? Math.round(creditUsed/totalLimits*100) : 0}%</strong></div>
      <div><span>Cash collected</span><strong>${money(state.receivablesCollected||0,true)}</strong></div>`;
    contracts.innerHTML = state.activeDeals.length ? state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const phase = dealPhase(deal);
      const stages = [
        ['Contract', true], ['Nominated', deal.contractLifecycle?.nominated], ['Loaded', deal.contractLifecycle?.loaded],
        ['Delivered', deal.contractLifecycle?.delivered], ['Invoiced', deal.contractLifecycle?.invoiced], ['Paid', deal.contractLifecycle?.paid]
      ];
      return `<button class="contract-card" data-contract-deal="${deal.id}">
        <div class="contract-card-head"><div><span>${deal.operations?.contractId || deal.id}</span><strong>${opp.title}</strong></div><b class="status-pill ${deal.delivered?'medium':'low'}">${phase.label}</b></div>
        <div class="contract-route">${getHub(opp.origin).name} → ${getHub(opp.destination).name} · ${negotiationProfiles.payment[deal.commercialTerms?.payment || 'delivery']?.label}</div>
        <div class="contract-stages">${stages.map(([label,done])=>`<span class="${done?'done':''}"><i></i>${label}</span>`).join('')}</div>
        <div class="contract-meta"><span>Buyer: ${getCounterparty(deal.buyerId)?.name || '—'}</span><strong>${deal.delivered ? (deal.invoiceStatus === 'Overdue' ? `${Math.max(0,deal.collectionDelayDays||0)} overdue days remaining` : `${Math.max(0,deal.paymentDaysRemaining||0)} days to cash`) : `${Math.max(0,deal.duration-deal.elapsed)} days to delivery`}</strong></div>
      </button>`;
    }).join('') : emptyState('No live contracts. Accepted physical deals appear here.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
    receivables.innerHTML = outstanding.length ? outstanding.map(deal => {
      const buyer = getCounterparty(deal.buyerId);
      const limit = counterpartyCreditLimit(deal.buyerId);
      const exposure = counterpartyExposure(deal.buyerId);
      return `<div class="receivable-card">
        <div class="receivable-head"><div><span>${deal.operations?.contractId || deal.id} · ${deal.invoiceStatus}</span><strong>${buyer?.name || 'Buyer receivable'}</strong></div><b>${money(deal.invoiceAmount||0,true)}</b></div>
        <div class="receivable-grid"><div><span>${deal.invoiceStatus === 'Overdue' ? 'Collection delay' : 'Due in'}</span><strong>${deal.invoiceStatus === 'Overdue' ? deal.collectionDelayDays : deal.paymentDaysRemaining} days</strong></div><div><span>Protection</span><strong>${deal.receivableProtection?.label || 'Unprotected'}</strong></div><div><span>Buyer limit</span><strong>${money(limit,true)}</strong></div><div><span>Limit use</span><strong>${limit ? Math.round(exposure/limit*100) : 0}%</strong></div></div>
        <button class="button secondary" data-open-receivable="${deal.id}">Open invoice</button>
      </div>`;
    }).join('') : '<div class="empty-card">No outstanding receivables. Deferred-payment invoices appear after delivery.</div>';
    const activeRequests = Object.values(state.creditLimitRequests || {}).filter(Boolean).sort((a,b)=>(a.status==='pending'?-1:1)-(b.status==='pending'?-1:1));
    requests.innerHTML = activeRequests.length ? activeRequests.map(request => {
      const party = getCounterparty(request.counterpartyId);
      return `<div class="credit-request-row ${request.status}"><div><span>${party?.country || ''} · ${request.status}</span><strong>${party?.name || request.counterpartyId}</strong><small>${request.status==='pending' ? `${request.daysRemaining} committee days remaining` : `${money(request.increment)} requested`}</small></div><b>${request.status==='approved'?'+':''}${request.status==='approved'?money(request.increment,true):request.status==='declined'?'Declined':'Review'}</b></div>`;
    }).join('') : '<div class="empty-card">No credit committee requests are active.</div>';
    $$('[data-contract-deal]', contracts).forEach(button => button.addEventListener('click',()=>selectDeal(button.dataset.contractDeal)));
    $$('[data-open-receivable]', receivables).forEach(button => button.addEventListener('click',()=>selectDeal(button.dataset.openReceivable)));
  }


  // ── v42 illustrazioni navi ───────────────────────────────────────────────
  const vesselArt = {
    bulker: `<svg viewBox="0 0 52 40" fill="none"><defs><linearGradient id="bkH" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fa8d8"/><stop offset="1" stop-color="#2f5b8f"/></linearGradient></defs><path d="M3 26h46l-5 9H8z" fill="#2f5b8f" stroke="#16304f" stroke-width="1.7" stroke-linejoin="round"/><path d="M6 26V18h30v8z" fill="#4a7fbd" stroke="#16304f" stroke-width="1.6"/><rect x="10" y="19" width="6" height="6" rx="1" fill="#22405f"/><rect x="19" y="19" width="6" height="6" rx="1" fill="#22405f"/><rect x="28" y="19" width="6" height="6" rx="1" fill="#22405f"/><rect x="38" y="13" width="9" height="13" rx="1.6" fill="#e8f1fb" stroke="#41607f" stroke-width="1.5"/><path d="M40 17h5M40 21h5" stroke="#41607f" stroke-width="1.3" stroke-linecap="round"/><path d="M8 30h32" stroke="#fff" stroke-opacity=".4" stroke-width="1.8" stroke-linecap="round"/><path d="M2 38c4-1.8 6-1.8 10 0s6 1.8 10 0 6-1.8 10 0 6 1.8 10 0" stroke="#7fd2ff" stroke-width="2" stroke-linecap="round" fill="none"/></svg>`,
    tanker: `<svg viewBox="0 0 52 40" fill="none"><path d="M3 26h46l-5 9H8z" fill="#3a5f4a" stroke="#1c3227" stroke-width="1.7" stroke-linejoin="round"/><path d="M6 26v-7h34v7z" fill="#57876a" stroke="#1c3227" stroke-width="1.6"/><circle cx="14" cy="22" r="2.4" fill="#cfe6d8" stroke="#1c3227" stroke-width="1.2"/><circle cx="23" cy="22" r="2.4" fill="#cfe6d8" stroke="#1c3227" stroke-width="1.2"/><circle cx="32" cy="22" r="2.4" fill="#cfe6d8" stroke="#1c3227" stroke-width="1.2"/><path d="M14 19v-4h18v4" stroke="#9fc9ad" stroke-width="1.6" fill="none"/><rect x="41" y="13" width="8" height="13" rx="1.6" fill="#e8f1fb" stroke="#41607f" stroke-width="1.5"/><path d="M8 30h32" stroke="#fff" stroke-opacity=".35" stroke-width="1.8" stroke-linecap="round"/><path d="M2 38c4-1.8 6-1.8 10 0s6 1.8 10 0 6-1.8 10 0 6 1.8 10 0" stroke="#7fd2ff" stroke-width="2" stroke-linecap="round" fill="none"/></svg>`,
    barge: `<svg viewBox="0 0 52 40" fill="none"><path d="M6 27h40l-4 8H10z" fill="#8a6a3c" stroke="#4d3a1d" stroke-width="1.7" stroke-linejoin="round"/><rect x="11" y="20" width="24" height="7" rx="1.4" fill="#a98551" stroke="#4d3a1d" stroke-width="1.5"/><rect x="14" y="22" width="5" height="4" rx=".8" fill="#6b5029"/><rect x="21" y="22" width="5" height="4" rx=".8" fill="#6b5029"/><rect x="28" y="22" width="5" height="4" rx=".8" fill="#6b5029"/><rect x="37" y="18" width="8" height="9" rx="1.4" fill="#e8f1fb" stroke="#41607f" stroke-width="1.4"/><path d="M2 38c4-1.8 6-1.8 10 0s6 1.8 10 0 6-1.8 10 0 6 1.8 10 0" stroke="#7fd2ff" stroke-width="2" stroke-linecap="round" fill="none"/></svg>`,
    general: `<svg viewBox="0 0 52 40" fill="none"><path d="M3 26h46l-5 9H8z" fill="#8a4634" stroke="#4d2317" stroke-width="1.7" stroke-linejoin="round"/><rect x="8" y="19" width="9" height="7" rx="1.2" fill="#e2603f" stroke="#4d2317" stroke-width="1.4"/><rect x="19" y="17" width="8" height="9" rx="1.2" fill="#f2865f" stroke="#4d2317" stroke-width="1.4"/><path d="M30 26V12l9 6" stroke="#ffce3d" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/><rect x="40" y="15" width="8" height="11" rx="1.5" fill="#e8f1fb" stroke="#41607f" stroke-width="1.5"/><path d="M8 30h32" stroke="#fff" stroke-opacity=".4" stroke-width="1.8" stroke-linecap="round"/><path d="M2 38c4-1.8 6-1.8 10 0s6 1.8 10 0 6-1.8 10 0 6 1.8 10 0" stroke="#7fd2ff" stroke-width="2" stroke-linecap="round" fill="none"/></svg>`
  };
  function vesselArtFor(vessel) {
    const c = String(vessel?.vesselClass || '').toLowerCase();
    if (c.includes('tanker')) return { svg: vesselArt.tanker, cls: 'va-tanker' };
    if (c.includes('barge')) return { svg: vesselArt.barge, cls: 'va-barge' };
    if (c.includes('bulk') || c.includes('panamax') || c.includes('handysize')) return { svg: vesselArt.bulker, cls: 'va-bulker' };
    return { svg: vesselArt.general, cls: 'va-general' };
  }

  function renderFleet() {
    const summary = $('#fleetSummary');
    const container = $('#fleetList');
    const market = $('#charterMarketList');
    if (!summary || !container || !market) return;
    const assigned = state.fleetAssets.filter(v => v.status === 'assigned').length;
    const available = state.fleetAssets.filter(v => v.status === 'available').length;
    const capacity = state.fleetAssets.reduce((sum, asset) => sum + (getVesselCatalog(asset.catalogId)?.capacity || 0), 0);
    summary.innerHTML = `
      <div><span>Controlled assets</span><strong>${state.fleetAssets.length}</strong></div>
      <div><span>Available</span><strong>${available}</strong></div>
      <div><span>Assigned</span><strong>${assigned}</strong></div>
      <div><span>Total capacity</span><strong>${capacity.toLocaleString('en-US')} t</strong></div>`;
    if (!state.fleetAssets.length) {
      container.innerHTML = emptyState('No vessels under control. The charter market is just below.', { label: 'Open the empire store', type: 'module', id: 'shop' });
    } else {
      container.innerHTML = state.fleetAssets.map(asset => {
        const vessel = getVesselCatalog(asset.catalogId);
        const deal = asset.assignedDealId ? getActiveDeal(asset.assignedDealId) : null;
        const fart = vesselArtFor(vessel);
        return `<button class="fleet-card v42 ${selected.type === 'vessel' && selected.id === asset.id ? 'selected' : ''}" data-fleet-asset="${asset.id}">
          <div class="fleet-hero">
            <span class="fleet-art ${fart.cls}">${fart.svg}${asset.ownership==='owned'?'<b class="fleet-own">★</b>':''}</span>
            <span class="fleet-id"><span class="fleet-class">${vessel.vesselClass}</span><strong class="fleet-name">${vessel.name}</strong></span>
            <span class="status-pill ${asset.status === 'assigned' ? 'medium' : 'low'}">${asset.status}</span>
          </div>
          <div class="fleet-grid">
            <div><span>Position</span><strong>${getHub(asset.positionHub)?.name || 'At sea'}</strong></div>
            <div><span>Capacity</span><strong>${vessel.capacity.toLocaleString('en-US')} t</strong></div>
            <div><span>${asset.ownership==='owned'?'Ownership':'Charter remaining'}</span><strong>${asset.ownership==='owned'?'Owned outright':`${asset.daysRemaining} days`}</strong></div>
            <div><span>Allocation</span><strong>${deal ? getOpportunity(deal.opportunityId).title : 'Open'}</strong></div>
          </div>
          ${asset.ownership==='owned'?`<div class="owned-vessel-strip"><span>Permanent fleet</span><strong>${money(asset.maintenance||0)}/day upkeep</strong></div>`:`<div class="charter-life"><span style="width:${asset.daysRemaining/asset.charterDays*100}%"></span></div>`}
        </button>`;
      }).join('');
      $$('[data-fleet-asset]', container).forEach(button => button.addEventListener('click', () => selectVessel(button.dataset.fleetAsset)));
    }
    market.innerHTML = vesselCatalog.map(vessel => {
      const unlocked = vesselUnlocked(vessel);
      const owned = state.fleetAssets.some(asset => asset.catalogId === vessel.id);
      const displayedHire = charterHireCost(vessel);
      const canAfford = state.cash >= displayedHire;
      const cart = vesselArtFor(vessel);
      return `<div class="charter-card v42 ${unlocked ? '' : 'locked'}">
        <div class="fleet-hero">
          <span class="fleet-art ${cart.cls}">${cart.svg}</span>
          <span class="fleet-id"><span class="fleet-class">${vessel.vesselClass}</span><strong class="fleet-name">${vessel.name}</strong></span>
          <span class="status-pill ${unlocked ? 'low' : 'high'}">${unlocked ? 'Available' : 'Locked'}</span>
        </div>
        <p>${vessel.description}</p>
        <div class="fleet-grid">
          <div><span>Capacity</span><strong>${vessel.capacity.toLocaleString('en-US')} t</strong></div>
          <div><span>Position</span><strong>${getHub(vessel.homeHub).name}</strong></div>
          <div><span>Charter block</span><strong>${vessel.charterDays} days</strong></div>
          <div><span>Upfront hire</span><strong>${money(displayedHire)}</strong></div>
        </div>
        <button class="button secondary charter-button" data-charter-vessel="${vessel.id}" ${!unlocked || owned || !canAfford ? 'disabled' : ''}>${owned ? 'Already controlled' : unlocked ? 'Start time charter' : vessel.requiresOffice && !officeOwned(vessel.requiresOffice) ? `Requires ${getOffice(vessel.requiresOffice).name}` : `Requires rep ${vessel.minReputation}`}</button>
      </div>`;
    }).join('');
    $$('[data-charter-vessel]', market).forEach(button => button.addEventListener('click', () => charterVessel(button.dataset.charterVessel)));
  }

  function renderRiskDashboard() {
    const container = $('#riskDashboard');
    const risk = riskStats();
    const riskClass = risk.riskScore < 35 ? 'low' : risk.riskScore < 68 ? 'medium' : 'high';
    const largestCommodity = Object.entries(risk.grossByCommodity).sort((a,b) => b[1]-a[1])[0];
    const warnings = [];
    if (risk.creditUtilization > .75) warnings.push('Credit-line utilization is above 75%.');
    if (risk.concentration > .65 && state.activeDeals.length > 1) warnings.push('The portfolio is concentrated in a single deal.');
    if (risk.liquidityCoverage < 1.25) warnings.push('Liquidity may not cover margin calls and unexpected costs.');
    if (risk.netFlatExposure > 1_000_000) warnings.push('Unhedged flat-price exposure exceeds $1 million.');
    if (risk.netFxExposure > 500_000) warnings.push('Residual FX exposure is significant.');
    if (risk.marginRequirement > state.cash * 1.5) warnings.push('Futures collateral is high relative to available liquidity.');
    container.innerHTML = `
      <div class="risk-card">
        <div class="risk-headline"><span>Desk risk score</span><strong>${riskClass.toUpperCase()}</strong></div>
        <div class="risk-score">${Math.round(risk.riskScore)}<small style="font-size:11px;color:var(--muted)"> / 100</small></div>
        <div class="risk-meter"><span style="width:${risk.riskScore}%"></span></div>
      </div>
      <div class="risk-card">
        <div class="risk-headline"><strong>Core metrics</strong><span>Live</span></div>
        <div class="risk-row"><span>Net flat-price exposure</span><strong>${money(risk.netFlatExposure, true)}</strong></div>
        <div class="risk-row"><span>Net FX exposure</span><strong>${money(risk.netFxExposure, true)}</strong></div>
        <div class="risk-row"><span>Futures margin requirement</span><strong>${money(risk.marginRequirement, true)}</strong></div>
        <div class="risk-row"><span>Stress loss estimate</span><strong>${money(risk.stressLoss, true)}</strong></div>
        <div class="risk-row"><span>Credit utilization</span><strong>${(risk.creditUtilization*100).toFixed(1)}%</strong></div>
        <div class="risk-row"><span>Largest deal concentration</span><strong>${(risk.concentration*100).toFixed(1)}%</strong></div>
        <div class="risk-row"><span>Liquidity coverage</span><strong>${risk.liquidityCoverage.toFixed(1)}×</strong></div>
        <div class="risk-row"><span>Margin reserve estimate</span><strong>${money(risk.liquidityReserve, true)}</strong></div>
      </div>
      <div class="risk-card">
        <div class="risk-headline"><strong>Risk allocation</strong><span>${largestCommodity ? largestCommodity[0] : 'No positions'}</span></div>
        <div class="risk-bars">
          <div class="risk-bar-row"><div><span>Credit</span><strong>${(risk.creditUtilization*100).toFixed(0)}%</strong></div><div class="capital-bar"><span class="${risk.creditUtilization<.5?'low':risk.creditUtilization<.8?'medium':'high'}" style="width:${clamp(risk.creditUtilization*100,0,100)}%"></span></div></div>
          <div class="risk-bar-row"><div><span>Concentration</span><strong>${(risk.concentration*100).toFixed(0)}%</strong></div><div class="capital-bar"><span class="${risk.concentration<.5?'low':risk.concentration<.75?'medium':'high'}" style="width:${clamp(risk.concentration*100,0,100)}%"></span></div></div>
          <div class="risk-bar-row"><div><span>Liquidity stress</span><strong>${risk.liquidityCoverage.toFixed(1)}×</strong></div><div class="capital-bar"><span class="${risk.liquidityCoverage>2?'low':risk.liquidityCoverage>1?'medium':'high'}" style="width:${clamp(100/risk.liquidityCoverage,8,100)}%"></span></div></div>
        </div>
      </div>
      ${warnings.length ? warnings.map(w => `<div class="risk-alert">${w}</div>`).join('') : '<div class="success-box">The portfolio is within the desk’s operating limits.</div>'}
      ${(()=>{
        if (!state.activeDeals.length) return '';
        const _book = {};
        state.activeDeals.forEach(deal => {
          const opp = getOpportunity(deal.opportunityId);
          if (!opp) return;
          const key = opp.priceKey || 'other';
          const label = opp.commodity || key;
          const qty = deal.quantity || opp.quantity || 0;
          const unhedgedShare = Math.max(0, 1 - (deal.hedgeRatio || 0) / 100);
          const mtmPnl = computeMarketImpact(deal);
          const notional = physicalNotional(opp, qty, deal.capital);
          if (!_book[key]) _book[key] = { label, qty: 0, notional: 0, mtmPnl: 0, deals: 0 };
          _book[key].qty += qty;
          _book[key].notional += notional * unhedgedShare;
          _book[key].mtmPnl += mtmPnl;
          _book[key].deals++;
        });
        const rows = Object.values(_book).map(pos => {
          const pnlColor = pos.mtmPnl >= 0 ? 'var(--green)' : 'var(--red)';
          return `<div class="position-row"><div class="pos-commodity">${pos.label}</div><div class="pos-stats"><div><span>Qty</span><strong>${(pos.qty/1000).toFixed(0)}kt</strong></div><div><span>Unhedged</span><strong>${money(pos.notional, true)}</strong></div><div><span>MTM P&L</span><strong style="color:${pnlColor}">${money(pos.mtmPnl)}</strong></div><div><span>Deals</span><strong>${pos.deals}</strong></div></div></div>`;
        }).join('');
        const totalMtm = Object.values(_book).reduce((s,p) => s + p.mtmPnl, 0);
        const totalNotional = Object.values(_book).reduce((s,p) => s + p.notional, 0);
        return `<div class="risk-card position-book"><div class="risk-headline"><strong>Open position book</strong><span style="color:${totalMtm>=0?'var(--green)':'var(--red)'}">MTM ${money(totalMtm)}</span></div><div class="pos-summary"><div><span>Unhedged notional</span><strong>${money(totalNotional, true)}</strong></div><div><span>Commodities</span><strong>${Object.keys(_book).length}</strong></div></div>${rows}</div>`;
      })()}`;
  }


  // ── v39 icone commodity illustrate (SVG) ─────────────────────────────────
  const commodityArt = {
    metal: { cls:'i-metal', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="cuA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd9b0"/><stop offset="1" stop-color="#c2661f"/></linearGradient><linearGradient id="cuB" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffcb95"/><stop offset="1" stop-color="#a9540f"/></linearGradient></defs><path d="M6 30h20l6-5H12z" fill="url(#cuB)" stroke="#7a3b08" stroke-width="1.6" stroke-linejoin="round"/><path d="M6 30v6h20v-6z" fill="url(#cuA)" stroke="#7a3b08" stroke-width="1.6" stroke-linejoin="round"/><path d="M26 30l6-5v6l-6 5z" fill="#8e4610" stroke="#7a3b08" stroke-width="1.6" stroke-linejoin="round"/><path d="M16 19h20l6-5H22z" fill="url(#cuB)" stroke="#7a3b08" stroke-width="1.6" stroke-linejoin="round"/><path d="M16 19v6h20v-6z" fill="url(#cuA)" stroke="#7a3b08" stroke-width="1.6" stroke-linejoin="round"/><path d="M36 19l6-5v6l-6 5z" fill="#8e4610" stroke="#7a3b08" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 32h6M19 21h6" stroke="#fff" stroke-opacity=".55" stroke-width="2" stroke-linecap="round"/></svg>` },
    silver:{ cls:'i-silver', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="agA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef4fb"/><stop offset="1" stop-color="#8d9aab"/></linearGradient><linearGradient id="agB" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#dfe8f3"/><stop offset="1" stop-color="#78869a"/></linearGradient></defs><path d="M6 30h20l6-5H12z" fill="url(#agB)" stroke="#4e5a6b" stroke-width="1.6" stroke-linejoin="round"/><path d="M6 30v6h20v-6z" fill="url(#agA)" stroke="#4e5a6b" stroke-width="1.6" stroke-linejoin="round"/><path d="M26 30l6-5v6l-6 5z" fill="#68758a" stroke="#4e5a6b" stroke-width="1.6" stroke-linejoin="round"/><path d="M16 19h20l6-5H22z" fill="url(#agB)" stroke="#4e5a6b" stroke-width="1.6" stroke-linejoin="round"/><path d="M16 19v6h20v-6z" fill="url(#agA)" stroke="#4e5a6b" stroke-width="1.6" stroke-linejoin="round"/><path d="M36 19l6-5v6l-6 5z" fill="#68758a" stroke="#4e5a6b" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 32h6M19 21h6" stroke="#fff" stroke-opacity=".7" stroke-width="2" stroke-linecap="round"/></svg>` },
    oil:   { cls:'i-oil', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="oiA" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8c99ad"/><stop offset=".45" stop-color="#4a586e"/><stop offset="1" stop-color="#28323f"/></linearGradient></defs><rect x="12" y="8" width="24" height="32" rx="4" fill="url(#oiA)" stroke="#1b2430" stroke-width="1.8"/><ellipse cx="24" cy="9.5" rx="12" ry="3.6" fill="#9aa8bc" stroke="#1b2430" stroke-width="1.6"/><path d="M12 18h24M12 30h24" stroke="#1b2430" stroke-width="1.8"/><path d="M16 12v24" stroke="#fff" stroke-opacity=".28" stroke-width="2.4" stroke-linecap="round"/><path d="M24 20c3 3.4 5 6 5 8.2a5 5 0 0 1-10 0c0-2.2 2-4.8 5-8.2z" fill="#12181f"/><path d="M22 26.5c.2-1.2 1-2.3 1.8-3" stroke="#7fd2ff" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/></svg>` },
    gas:   { cls:'i-gas', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="gsA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bfe9ff"/><stop offset="1" stop-color="#3d90c9"/></linearGradient></defs><ellipse cx="24" cy="26" rx="15" ry="13" fill="url(#gsA)" stroke="#1d5c85" stroke-width="1.8"/><path d="M9 26a15 13 0 0 1 30 0" fill="#e6f6ff" fill-opacity=".35"/><path d="M24 13V7M18 9l-2-3M30 9l2-3" stroke="#1d5c85" stroke-width="2" stroke-linecap="round"/><path d="M15 22c2.5-2 5-2 7 0" stroke="#fff" stroke-opacity=".8" stroke-width="2" stroke-linecap="round"/></svg>` },
    grain: { cls:'i-grain', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="wgA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a8"/><stop offset="1" stop-color="#c98a12"/></linearGradient></defs><path d="M24 42V16" stroke="#8a5f0c" stroke-width="2.6" stroke-linecap="round"/><g fill="url(#wgA)" stroke="#8a5f0c" stroke-width="1.4" stroke-linejoin="round"><path d="M24 6c3 2.6 4 5.4 0 9-4-3.6-3-6.4 0-9z"/><path d="M24 14c3 2.6 4 5.4 0 9-4-3.6-3-6.4 0-9z"/><path d="M24 22c3 2.6 4 5.4 0 9-4-3.6-3-6.4 0-9z"/><path d="M23 15c-1.4 3.6-3.6 5.2-7.6 4 1.6-3.8 4-5 7.6-4z"/><path d="M25 15c1.4 3.6 3.6 5.2 7.6 4-1.6-3.8-4-5-7.6-4z"/><path d="M23 23c-1.4 3.6-3.6 5.2-7.6 4 1.6-3.8 4-5 7.6-4z"/><path d="M25 23c1.4 3.6 3.6 5.2 7.6 4-1.6-3.8-4-5-7.6-4z"/></g></svg>` },
    ore:   { cls:'i-ore', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="irA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfd7e2"/><stop offset="1" stop-color="#5d6674"/></linearGradient></defs><path d="M8 36l7-13 8 5 6-9 11 17z" fill="url(#irA)" stroke="#3a4250" stroke-width="1.8" stroke-linejoin="round"/><circle cx="17" cy="20" r="4" fill="#98a2b1" stroke="#3a4250" stroke-width="1.6"/><circle cx="30" cy="16" r="3" fill="#b6c0cd" stroke="#3a4250" stroke-width="1.6"/><path d="M12 33l4-6" stroke="#fff" stroke-opacity=".4" stroke-width="2" stroke-linecap="round"/></svg>` },
    bean:  { cls:'i-bean', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="cfA" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a96a3d"/><stop offset="1" stop-color="#4e2a13"/></linearGradient></defs><ellipse cx="18" cy="20" rx="9" ry="11" transform="rotate(-25 18 20)" fill="url(#cfA)" stroke="#3a1d0c" stroke-width="1.7"/><path d="M14 13c3 4 3 10 0 14" stroke="#2a1409" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="30" cy="30" rx="9" ry="11" transform="rotate(-25 30 30)" fill="url(#cfA)" stroke="#3a1d0c" stroke-width="1.7"/><path d="M26 23c3 4 3 10 0 14" stroke="#2a1409" stroke-width="1.8" stroke-linecap="round"/></svg>` },
    fert:  { cls:'i-fert', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="feA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3f7ff"/><stop offset="1" stop-color="#b9c6da"/></linearGradient></defs><path d="M14 14h20l4 26H10z" fill="url(#feA)" stroke="#5b6879" stroke-width="1.8" stroke-linejoin="round"/><path d="M14 14c0-3 2-5 10-5s10 2 10 5" fill="#dde6f2" stroke="#5b6879" stroke-width="1.8"/><circle cx="20" cy="26" r="2.4" fill="#7fc98a"/><circle cx="28" cy="30" r="2.4" fill="#7fc98a"/><circle cx="24" cy="21" r="2.4" fill="#7fc98a"/></svg>` },
    steel: { cls:'i-steel', svg:`<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="stA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#dbe4f0"/><stop offset="1" stop-color="#6f7c8e"/></linearGradient></defs><rect x="7" y="26" width="34" height="7" rx="2" fill="url(#stA)" stroke="#3f4a59" stroke-width="1.7"/><rect x="11" y="18" width="26" height="7" rx="2" fill="url(#stA)" stroke="#3f4a59" stroke-width="1.7"/><rect x="15" y="10" width="18" height="7" rx="2" fill="url(#stA)" stroke="#3f4a59" stroke-width="1.7"/><path d="M10 29h7M14 21h6M18 13h5" stroke="#fff" stroke-opacity=".6" stroke-width="2" stroke-linecap="round"/></svg>` }
  };
  const commodityArtMap = {
    copper:'metal', aluminium:'silver', zinc:'silver', nickel:'silver',
    crude:'oil', lng:'gas', wheat:'grain', coffee:'bean', urea:'fert', ironore:'ore'
  };
  function commodityArtFor(opp) {
    const label = String(opp.commodity || '').toLowerCase();
    if (label.includes('steel')) return commodityArt.steel;
    if (label.includes('cocoa') || label.includes('coffee')) return commodityArt.bean;
    if (label.includes('soy') || label.includes('palm') || label.includes('wheat')) return commodityArt.grain;
    if (label.includes('diesel')) return commodityArt.oil;
    const key = commodityArtMap[opp.priceKey] || 'metal';
    return commodityArt[key] || commodityArt.metal;
  }

  function renderOpportunityList() {
    const container = $('#opportunityList');
    const summary = $('#marketCycleSummary');
    if (summary) {
      const accepted = Object.values(state.negotiations || {}).filter(n => n.cycle === state.marketCycle && n.status === 'accepted').length;
      const regime = currentMarketRegime();
      const openTenders = Object.values(state.rivalMarket || {}).filter(t=>t.cycle===state.marketCycle && t.status==='open').length;
      summary.innerHTML = `
        <div><span>Market cycle</span><strong>#${state.marketCycle}</strong></div>
        <div><span>Regime</span><strong>${regime.label}</strong></div>
        <div><span>Season</span><strong>${currentSeason().label}</strong></div>
        <div><span>Refresh in</span><strong>${Math.max(0, 7-state.marketCycleDay)} days</strong></div>
        <div><span>Open tenders</span><strong>${openTenders}</strong></div>
        <div><span>Accepted bids</span><strong>${accepted}</strong></div>
        <div><span>Active crises</span><strong>${state.activeGlobalEvents.length}</strong></div>
        <div><span>Expansion level</span><strong>L${playerLevel()}</strong></div>
        <div><span>Next unlock</span><strong>${nextExpansionUnlock() ? `L${nextExpansionUnlock().level}` : 'Global'}</strong></div>`;
    }
    container.innerHTML = opportunities.map(opp => {
      const unlocked = isOpportunityUnlocked(opp);
      const available = opportunityAvailable(opp);
      const origin = getHub(opp.origin);
      const destination = getHub(opp.destination);
      const selectedClass = selected.type === 'opportunity' && selected.id === opp.id ? 'selected' : '';
      const economics = opportunityEconomics(opp);
      const negotiation = state.negotiations?.[opp.id];
      const tender = rivalTenderFor(opp.id);
      const rival = rivalForTender(tender);
      const rivalWon = tender?.status === 'awarded';
      const status = !unlocked ? `L${opportunityProgressionRequirements(opp).requiredLevel}` : rivalWon ? `${rival.name} won` : !available ? 'Taken' : negotiation?.status === 'accepted' ? 'Tender secured' : negotiation?.status === 'rejected' ? 'Revise bid' : `${economics.expiresIn}d left`;
      const statusClass = !unlocked || rivalWon || !available ? 'high' : negotiation?.status === 'accepted' ? 'low' : negotiation?.status === 'rejected' ? 'medium' : opp.riskClass;
      const art = commodityArtFor(opp);
      const acc = Math.round(economics.acceptance);
      const accClass = acc >= 70 ? 'green' : acc >= 45 ? '' : 'red';
      const pressure = tender?.pressure || 0;
      const season = seasonalDemand(opp);
      const isHot = unlocked && available && economics.expectedPnl > 0 && (acc >= 70 || pressure >= 60);
      const ctaLabel = !unlocked ? `🔒 Level ${opportunityProgressionRequirements(opp).requiredLevel} required`
        : rivalWon ? 'Lost to rival'
        : !available ? 'No longer available'
        : negotiation?.status === 'accepted' ? 'Open the deal'
        : 'Negotiate the deal';
      return `<button class="opportunity-card v39 ${selectedClass} ${unlocked && available ? '' : 'locked'} ${isHot ? 'hot' : ''}" data-opportunity-id="${opp.id}" ${unlocked && available ? '' : 'disabled'}>
        ${isHot ? '<span class="opp-ribbon">HOT</span>' : ''}
        <div class="opp-top">
          <span class="opp-icon ${art.cls}">${art.svg}</span>
          <span class="opp-route">
            <span class="opp-r">${origin.name} <span class="route-arrow">→</span> ${destination.name}</span>
            <span class="opp-q">${economics.quantity.toLocaleString('en-US')} t · ${opp.commodity}</span>
          </span>
          <span class="status-pill ${statusClass}">${status}</span>
        </div>
        <div class="opp-stats">
          <div class="opp-stat"><span class="k">Expected P&amp;L</span><strong class="v gold">${money(economics.expectedPnl)}</strong></div>
          <div class="opp-stat"><span class="k">Equity</span><strong class="v">${money(economics.equity, true)}</strong></div>
          <div class="opp-stat"><span class="k">Duration</span><strong class="v">${economics.duration} d</strong></div>
          <div class="opp-stat"><span class="k">Acceptance</span><strong class="v ${accClass}">${acc}%</strong></div>
        </div>
        <div class="opp-meter-row"><span>Rival interest · ${rival.name}</span><b>${pressure}%</b></div>
        <div class="opp-meter rival"><span style="width:${pressure}%"></span></div>
        <div class="opp-meter-row"><span>Seasonal flow · ${season.label}</span><b>${Math.round(season.factor*100)}</b></div>
        <div class="opp-meter season"><span style="width:${Math.round(clamp(season.factor*70, 4, 100))}%"></span></div>
        ${economics.crisisLabels.length ? `<div class="crisis-tag">Impacted · ${economics.crisisLabels.join(', ')}</div>` : ''}
        ${!unlocked ? `<div class="unlock-requirement"><strong>Locked expansion</strong><span>${unlockReason(opp)}</span></div>` : ''}
        <span class="opp-cta ${unlocked && available ? '' : 'lock'}">${ctaLabel}</span>
      </button>`;
    }).join('');
    $$('[data-opportunity-id]', container).forEach(button => button.addEventListener('click', () => selectOpportunity(button.dataset.opportunityId)));
  }

  function renderRivals() {
    const summary = $('#rivalSummary');
    const list = $('#rivalOpportunityList');
    const feed = $('#rivalFeed');
    if (!summary || !list || !feed) return;
    initializeCompetitiveMarket();
    const regime = currentMarketRegime();
    const current = Object.entries(state.rivalMarket || {}).filter(([,t])=>t.cycle===state.marketCycle);
    const open = current.filter(([,t])=>t.status==='open').length;
    const won = current.filter(([,t])=>t.status==='player_reserved').length;
    const lost = current.filter(([,t])=>t.status==='awarded').length;
    const avgPressure = current.length ? current.reduce((sum,[,t])=>sum+(t.pressure||0),0)/current.length : 0;
    summary.innerHTML = `
      <div class="regime-card ${regime.tone}"><span>Market regime</span><strong>${regime.label}</strong><small>${regime.description}</small></div>
      <div><span>Open tenders</span><strong>${open}</strong></div>
      <div><span>Secured by you</span><strong>${won}</strong></div>
      <div><span>Lost this cycle</span><strong>${lost}</strong></div>
      <div><span>Average pressure</span><strong>${avgPressure.toFixed(0)}%</strong></div>`;
    list.innerHTML = opportunities.filter(isOpportunityUnlocked).map(opp => {
      const tender = rivalTenderFor(opp.id);
      const rival = rivalForTender(tender);
      const statusLabel = tender.status==='player_reserved' ? 'Secured' : tender.status==='awarded' ? 'Awarded to rival' : `Closes day ${tender.awardDay}`;
      return `<button class="rival-tender-card ${tender.status}" data-rival-opportunity="${opp.id}" ${tender.status==='awarded'?'disabled':''}>
        <div class="rival-tender-head"><div><span>${opp.commodity} tender</span><strong>${opp.title}</strong></div><span class="status-pill ${tender.status==='player_reserved'?'low':tender.status==='awarded'?'high':'medium'}">${statusLabel}</span></div>
        <div class="rival-desk-line"><span>Leading rival</span><strong>${rival.name} · ${rival.city}</strong></div>
        <div class="tender-pressure-row"><span>Competitive pressure</span><strong>${tender.pressure}%</strong></div>
        <div class="tender-pressure-track"><span style="width:${tender.pressure}%"></span></div>
      </button>`;
    }).join('');
    // ── v48 · scouting dei desk rivali ────────────────────────────────────────
    const roster = $('#rivalRoster');
    if (roster) {
      const cycleTenders = Object.entries(state.rivalMarket || {}).filter(([, tender]) => tender.cycle === state.marketCycle);
      roster.innerHTML = aiRivalDesks.map(rival => {
        const record = rivalRecord(rival.id);
        const played = record.won + record.lost;
        const winRate = played ? Math.round(record.won / played * 100) : null;
        // corridoi che il desk sta presidiando in questo ciclo
        const leading = cycleTenders
          .filter(([, tender]) => tender.leaderId === rival.id && tender.status === 'open')
          .map(([oppId]) => getOpportunity(oppId))
          .filter(Boolean);
        const heat = leading.length ? Math.round(cycleTenders
          .filter(([, tender]) => tender.leaderId === rival.id && tender.status === 'open')
          .reduce((sum, [, tender]) => sum + (tender.pressure || 0), 0) / leading.length) : 0;
        const form = record.lastResult
          ? `<em class="rival-form ${record.lastResult}">${record.lastResult === 'won' ? 'You won the last one' : 'They took the last one'}${record.lastTitle ? ` \u00b7 ${esc(record.lastTitle)}` : ''}</em>`
          : '<em class="rival-form neutral">No head-to-head yet</em>';
        return `<article class="rival-desk-card ${leading.length ? 'engaged' : ''}">
          <div class="rival-desk-top">
            <span class="rival-flag">${rival.flag}</span>
            <div><strong>${rival.name}</strong><small>${rival.city} \u00b7 ${rival.style}</small></div>
            <span class="rival-h2h ${winRate === null ? '' : winRate >= 50 ? 'ahead' : 'behind'}">${played ? `${record.won}\u2013${record.lost}` : '\u2013'}</span>
          </div>
          <p class="rival-desk-profile">${rival.profile}</p>
          <div class="rival-traits">
            <div><span>Aggression</span><i><b style="width:${rival.aggression}%"></b></i><small>${rival.aggression}</small></div>
            <div><span>Discipline</span><i><b class="calm" style="width:${rival.discipline}%"></b></i><small>${rival.discipline}</small></div>
          </div>
          <div class="rival-specialties">${rival.specialties.map(item => `<span class="tag">${item}</span>`).join('')}</div>
          <div class="rival-desk-foot">
            <span>${leading.length ? `Leading ${leading.length} open tender${leading.length === 1 ? '' : 's'} \u00b7 avg pressure ${heat}%` : 'Not leading any open tender this cycle'}</span>
            ${form}
          </div>
        </article>`;
      }).join('');
    }

    const entries = state.rivalFeed || [];
    feed.innerHTML = entries.length ? entries.slice(0,10).map(item => `<div class="rival-feed-card"><div><span>${formatDate(new Date(item.date))} · cycle ${item.cycle}</span><strong>${item.title}</strong></div><p>${item.description}</p></div>`).join('') : '<div class="empty-card">No tender awards yet. Rival desks will begin bidding as game days advance.</div>';
    $$('[data-rival-opportunity]', list).forEach(button=>button.addEventListener('click',()=>selectOpportunity(button.dataset.rivalOpportunity)));
  }

  function renderStrategy() {
    const summary=$('#strategySummary'), demand=$('#seasonDemandGrid'), doctrines=$('#doctrineList'), mandates=$('#boardMandates');
    if (!summary||!demand||!doctrines||!mandates) return;
    const season=currentSeason(), valuation=tradingHouseValuation(), doctrine=activeDoctrine();
    summary.innerHTML=`<div><span>Enterprise value</span><strong>${money(valuation.value,true)}</strong><small>${valuation.tier}</small></div><div><span>Current season</span><strong>${season.icon} ${season.label}</strong><small>${currentMarketRegime().label}</small></div><div><span>Desk doctrine</span><strong>${doctrine.label}</strong><small>${canChangeDoctrine()?'Board change available':`${14-((state.dayIndex||0)-(state.strategyChangedDay??-30))}d lock`}</small></div><div><span>Valuation high</span><strong>${money(state.valuationHigh||valuation.value,true)}</strong><small>Career record</small></div>`;
    const commodityDefs=[['Copper','copper'],['Aluminium','aluminium'],['Urea','urea'],['Diesel','crude'],['Wheat','wheat'],['Iron ore','ironore'],['Coffee','coffee']];
    demand.innerHTML=commodityDefs.map(([label,key])=>{const sample={priceKey:key},s=seasonalDemand(sample);return `<div class="season-card ${s.factor>=1.08?'hot':s.factor<=.94?'cold':''}"><span>${label}</span><strong>${s.label}</strong><div class="season-meter"><i style="width:${clamp((s.factor-.82)/.38*100,5,100)}%"></i></div><small>Demand index ${(s.factor*100).toFixed(0)}</small></div>`}).join('');
    doctrines.innerHTML=Object.values(strategyDoctrineCatalog).map(item=>`<button class="doctrine-card ${item.id===state.strategyDoctrine?'active':''}" data-doctrine="${item.id}" ${item.id!==state.strategyDoctrine&&!canChangeDoctrine()?'disabled':''}><div><i>${item.icon}</i><span><strong>${item.label}</strong><small>${item.description}</small></span></div><em>${item.id===state.strategyDoctrine?'Active':canChangeDoctrine()?'Adopt · '+money(18_000+state.activeDeals.length*4_000):'Board locked'}</em></button>`).join('');
    $$('[data-doctrine]',doctrines).forEach(button=>button.addEventListener('click',()=>changeDoctrine(button.dataset.doctrine)));
    mandates.innerHTML=boardMandateData().map(item=>{const pct=clamp(item.progress/item.target*100,0,100);return `<div class="mandate-card"><div><span>${item.label}</span><strong>${pct>=100?'Complete':`${Math.round(pct)}%`}</strong></div><p>${item.copy}</p><div class="mandate-track"><i style="width:${pct}%"></i></div><small>${typeof item.target==='number'&&item.target>=1_000_000?`${money(item.progress,true)} / ${money(item.target,true)}`:`${Math.min(item.progress,item.target)} / ${item.target}`}</small></div>`}).join('');
  }


  function renderGlobalOfficeNetwork() {
    const summary=$('#globalOfficeSummary');
    const roadmap=$('#officeUnlockRoadmap');
    const pipeline=$('#globalOfficePipeline');
    const network=$('#globalOfficeNetwork');
    if(!summary||!roadmap||!pipeline||!network) return;
    const active=officeCatalog.filter(o=>officeOwned(o.id));
    const projects=state.officeProjects||[];
    const countries=new Set(active.map(o=>o.country));
    const next=officeCatalog.find(o=>o.id!=='geneva'&&!officeOwned(o.id)&&!activeOfficeProject(o.id));
    const availableNow=officeCatalog.filter(o=>o.id!=='geneva'&&!officeOwned(o.id)&&!activeOfficeProject(o.id)&&officeUnlocked(o));
    const nextLevelOffice=officeCatalog.filter(o=>o.id!=='geneva'&&!officeOwned(o.id)&&!activeOfficeProject(o.id)&&o.minLevel>playerLevel()).sort((a,b)=>a.minLevel-b.minLevel)[0];
    summary.innerHTML=`<div><span>Countries covered</span><strong>${countries.size}</strong></div><div><span>International offices</span><strong>${Math.max(0,active.length-1)}/${officeCatalog.length-1}</strong></div><div><span>Ready to open</span><strong>${availableNow.length}</strong></div><div><span>Network book value</span><strong>${money(officeBookValue(),true)}</strong></div>`;
    const roadmapItems=officeCatalog.filter(o=>o.id!=='geneva'&&!officeOwned(o.id)).sort((a,b)=>a.minLevel-b.minLevel).slice(0,8);
    roadmap.innerHTML=`<div class="office-roadmap-heading"><div><span>Level expansion roadmap</span><strong>${nextLevelOffice?`Next level unlock: ${nextLevelOffice.city} at L${nextLevelOffice.minLevel}`:'All international locations unlocked'}</strong></div><small>Reach the company level, satisfy commercial requirements, then fund the local opening project.</small></div><div class="office-roadmap-track">${roadmapItems.map(office=>{const project=activeOfficeProject(office.id), unlocked=officeUnlocked(office); const cls=project?'building':unlocked?'ready':'locked'; return `<button class="office-roadmap-node ${cls}" data-office-roadmap="${office.id}"><span>${office.flag}</span><b>L${office.minLevel}</b><strong>${office.city}</strong><small>${project?`${project.daysRemaining}d left`:unlocked?'Ready':officeLockReason(office)}</small></button>`;}).join('')}</div>`;
    $$('[data-office-roadmap]',roadmap).forEach(button=>button.addEventListener('click',()=>{const id=button.dataset.officeRoadmap; focusOnHub(getOffice(id)?.hub); document.getElementById(`office-card-${id}`)?.scrollIntoView({behavior:motionEnabled()?'smooth':'auto',block:'center'});}));
    pipeline.innerHTML=projects.length?projects.map(project=>{const office=getOffice(project.officeId);const pct=Math.max(4,100*(1-project.daysRemaining/project.totalDays));return `<article class="office-project-card"><div><span>${office.flag} ${office.country}</span><strong>${office.name}</strong><small>${project.daysRemaining} days remaining</small></div><div class="progress-track"><span style="width:${pct}%"></span></div></article>`;}).join(''):`<div class="empty-card">No office is under construction. ${next?`The next available location is ${next.city} at level ${next.minLevel}.`:''}</div>`;
    network.innerHTML=officeCatalog.map(office=>{
      const owned=officeOwned(office.id), project=activeOfficeProject(office.id), unlocked=officeUnlocked(office), lock=officeLockReason(office);
      const status=owned?'ACTIVE':project?'BUILDING':unlocked?'AVAILABLE':'LOCKED';
      const progress=project?Math.max(4,100*(1-project.daysRemaining/project.totalDays)):0;
      return `<article id="office-card-${office.id}" class="global-office-card ${owned?'owned':project?'building':unlocked?'available':'locked'}">
        <div class="office-card-banner"><span class="office-flag">${office.flag}</span><div><small>${office.region}</small><h3>${office.city}</h3><b>${office.country}</b></div><em>${status}</em></div>
        <p>${office.description}</p>
        <div class="office-benefit">${office.benefit}</div>
        <div class="office-stat-grid"><div><span>Unlock</span><strong>Level ${office.minLevel}</strong></div><div><span>Opening cost</span><strong>${office.cost?money(office.cost):'Included'}</strong></div><div><span>Build time</span><strong>${office.buildDays||0}d</strong></div><div><span>Daily overhead</span><strong>${money(office.dailyCost)}</strong></div></div>
        <div class="office-specialties">${(office.focusCommodities||[]).map(c=>`<span>${c}</span>`).join('')||'<span>Group management</span>'}</div>
        ${project?`<div class="office-build-progress"><div><span>International expansion project</span><strong>${project.daysRemaining}d</strong></div><div class="progress-track"><span style="width:${progress}%"></span></div></div>`:''}
        ${office.id==='geneva'?'':`<button class="button ${owned?'secondary':'primary'} office-open-button" data-open-global-office="${office.id}" ${owned||project||!unlocked||state.cash<office.cost||activeProjectCount()>=builderSlots()?'disabled':''}>${owned?'Office active':project?`Opening · ${project.daysRemaining}d`:!unlocked?`Requires ${lock}`:state.cash<office.cost?'Insufficient cash':'Open office'}</button>`}
      </article>`;
    }).join('');
    $$('[data-open-global-office]',network).forEach(button=>button.addEventListener('click',()=>openOffice(button.dataset.openGlobalOffice)));
    renderOfficeRailStatus();
  }

  function renderExpansion() {
    const summary = $('#expansionSummary');
    const hqPanel = $('#hqGrowthPanel');
    const specializationList = $('#deskSpecialisationList');
    const reputationGrid = $('#marketReputationGrid');
    const frameworkList = $('#commercialFrameworkList');
    const responseList = $('#crisisResponseList');
    const officeNetwork = $('#globalOfficeNetwork');
    if (!summary || !hqPanel || !specializationList || !reputationGrid || !frameworkList || !responseList || !officeNetwork) return;
    ensureMarketReputation();
    const hq = hqCurrentTier();
    const nextHq = hqNextTier();
    const specialization = activeDeskSpecialization();
    const frameworks = Object.values(state.commercialFrameworks || {}).filter(item => item && item.status === 'active');
    const avgMarketRepEntries = [...Object.values(state.marketReputation.countries || {}), ...Object.values(state.marketReputation.commodities || {})];
    const avgMarketRep = avgMarketRepEntries.length ? Math.round(avgMarketRepEntries.reduce((a,b)=>a+b,0)/avgMarketRepEntries.length) : 0;
    summary.innerHTML = `
      <div><span>Geneva HQ</span><strong>Tier ${hq.tier} · ${hq.name}</strong></div>
      <div><span>Core desk</span><strong>${specialization.name}</strong></div>
      <div><span>Market credibility</span><strong>${avgMarketRep}/100</strong></div>
      <div><span>International offices</span><strong>${Math.max(0,state.offices.length-1)}</strong></div>`;

    const project = state.hqUpgrade;
    hqPanel.innerHTML = `<article class="hq-growth-card current">
      <div class="growth-card-head"><div><span>Current headquarters</span><strong>${hq.name}</strong></div><span class="status-pill low">Tier ${hq.tier}</span></div>
      <p>${hq.description}</p>
      <div class="growth-benefit-grid"><div><span>Deal edge</span><strong>+${money(hq.pnlBonus)}</strong></div><div><span>Credit capacity</span><strong>+${money(hq.creditBonus,true)}</strong></div><div><span>Risk reduction</span><strong>-${hq.riskReduction}</strong></div><div><span>Overhead</span><strong>${money(hq.dailyCost)}/day</strong></div></div>
    </article>${nextHq ? `<article class="hq-growth-card next ${project ? 'building' : ''}">
      <div class="growth-card-head"><div><span>${project ? 'Construction in progress' : 'Next headquarters tier'}</span><strong>${nextHq.name}</strong></div><span class="status-pill ${playerLevel()>=nextHq.minLevel?'medium':'high'}">Level ${nextHq.minLevel}</span></div>
      <p>${nextHq.description}</p>
      <div class="growth-benefit-grid"><div><span>Project cost</span><strong>${money(nextHq.cost)}</strong></div><div><span>Build time</span><strong>${nextHq.buildDays} days</strong></div><div><span>Deal edge</span><strong>+${money(nextHq.pnlBonus)}</strong></div><div><span>Credit</span><strong>+${money(nextHq.creditBonus,true)}</strong></div></div>
      ${project ? `<div class="build-progress-card"><strong>${project.daysRemaining} days remaining</strong><div class="progress-track"><span style="width:${Math.max(4,100*(1-project.daysRemaining/nextHq.buildDays))}%"></span></div></div>` : `<button class="button primary" id="startHqUpgradeButton" ${playerLevel()<nextHq.minLevel||state.cash<nextHq.cost?'disabled':''}>Build ${nextHq.name}</button>`}
    </article>` : '<div class="success-box">Maximum Geneva headquarters tier reached.</div>'}`;
    $('#startHqUpgradeButton')?.addEventListener('click', startHQUpgrade);
    renderGlobalOfficeNetwork();

    const cooldown = Math.max(0, 30 - ((state.dayIndex || 0) - (state.specializationChangedDay || -99)));
    specializationList.innerHTML = Object.values(deskSpecializationCatalog).map(item => {
      const active = item.id === specialization.id;
      const locked = playerLevel() < 3;
      const canChange = !active && !locked && (!state.specializationChosen || cooldown === 0);
      const core = item.commodities.length ? item.commodities.join(' · ') : 'All commodity groups';
      return `<article class="specialisation-card ${active?'active':''} ${locked?'locked':''}"><div class="specialisation-icon">${item.icon}</div><div class="specialisation-copy"><span>${active?'Active board mandate':'Desk mandate'}</span><strong>${item.name}</strong><p>${item.description}</p><small>${core}</small></div><div class="specialisation-stats"><b>${item.pnlFactor>1?`+${Math.round((item.pnlFactor-1)*100)}% core margin`:'Balanced margin'}</b><b>${item.acceptance?`+${item.acceptance} acceptance`:'No concentration penalty'}</b></div><button class="button ${active?'secondary':'primary'}" data-select-specialization="${item.id}" ${active||!canChange?'disabled':''}>${active?'Selected':locked?'Unlocks at level 3':cooldown?`Board lock ${cooldown}d`:state.specializationChosen?'Switch mandate · $90K':'Choose free'}</button></article>`;
    }).join('');
    $$('[data-select-specialization]', specializationList).forEach(button => button.addEventListener('click', () => chooseDeskSpecialization(button.dataset.selectSpecialization)));

    const countryRows = Object.entries(state.marketReputation.countries || {}).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([name,score]) => ({ name, score, type:'Country' }));
    const commodityRows = Object.entries(state.marketReputation.commodities || {}).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,score]) => ({ name, score, type:'Commodity' }));
    reputationGrid.innerHTML = [...countryRows,...commodityRows].map(item => `<div class="market-reputation-card"><div><span>${item.type}</span><strong>${item.name}</strong></div><b>${Math.round(item.score)}</b><div class="progress-track"><span style="width:${clamp(item.score,0,100)}%"></span></div><small>${item.score>=70?'Preferred merchant':item.score>=45?'Established':item.score>=25?'Developing':'New entrant'}</small></div>`).join('') || '<div class="empty-card">Complete cargoes to build a commercial franchise.</div>';

    const activeFrameworkIds = new Set(frameworks.map(item => item.opportunityId));
    const candidates = opportunities.filter(isOpportunityUnlocked).filter(opp => !activeFrameworkIds.has(opp.id)).slice(0,6);
    const cards = [...frameworks.map(framework => ({ framework, opp:getOpportunity(framework.opportunityId) })), ...candidates.map(opp => ({ framework:null, opp }))];
    frameworkList.innerHTML = cards.map(({framework,opp}) => {
      if (!opp) return '';
      const cost = clamp(Math.round(opp.capital * .025),45_000,180_000);
      return `<article class="framework-card ${framework?'active':''}"><div class="framework-head"><div><span>${framework?'Active commercial agreement':'Available corridor'}</span><strong>${opp.title}</strong></div><span class="status-pill ${framework?'low':'medium'}">${framework?`${framework.daysRemaining}d`:'120 days'}</span></div><p>${getHub(opp.origin).name} → ${getHub(opp.destination).name} · ${opp.commodity}</p>${framework?`<div class="framework-progress"><strong>${framework.lifts}/${framework.commitments} committed cargoes</strong><div class="progress-track"><span style="width:${Math.min(100,framework.lifts/framework.commitments*100)}%"></span></div></div><div class="management-benefit">+${money(framework.pnlBonus)} per cargo · +${framework.acceptance} acceptance · -${framework.durationBonus} days</div>`:`<div class="management-benefit">Priority supply and buyer offtake · 3 committed cargoes · take-or-pay applies</div><button class="button secondary" data-sign-framework="${opp.id}" ${playerLevel()<3||state.completedDeals<1||state.cash<cost?'disabled':''}>Sign framework · ${money(cost)}</button>`}</article>`;
    }).join('') || '<div class="empty-card">No corridors are currently eligible for a framework agreement.</div>';
    $$('[data-sign-framework]', frameworkList).forEach(button => button.addEventListener('click', () => signCommercialFramework(button.dataset.signFramework)));

    const activeEvents = activeCrisisDefinitions();
    responseList.innerHTML = activeEvents.length ? activeEvents.map(event => {
      const response = crisisResponseFor(event.id);
      return `<article class="crisis-playbook-card ${response?'protected':''}"><div class="crisis-playbook-head"><div><span>${event.category || 'Global risk'} · ${event.remaining}d</span><strong>${event.title}</strong></div><span class="status-pill ${event.severity || 'medium'}">${response?'Response active':'Unmitigated'}</span></div><p>${event.description}</p>${response?`<div class="success-box">${crisisPlaybookCatalog[response.playbookId]?.name} · ${money(response.cost)} spent · ${money(response.recovered || 0)} cargo recovery.</div>`:`<div class="playbook-actions">${Object.values(crisisPlaybookCatalog).map(playbook => `<button data-crisis-response="${event.id}" data-playbook="${playbook.id}"><span>${playbook.icon}</span><strong>${playbook.name}</strong><small>${money(playbook.cost)} · loss protection ${Math.round((1-playbook.lossFactor)*100)}%</small></button>`).join('')}</div>`}</article>`;
    }).join('') : '<div class="empty-card">No active global shock requires a response. Maintain liquidity for the next crisis.</div>';
    $$('[data-crisis-response]', responseList).forEach(button => button.addEventListener('click', () => activateCrisisResponse(button.dataset.crisisResponse, button.dataset.playbook)));
  }

  function renderCounterparties() {
    const summary = $('#counterpartySummary');
    const container = $('#counterpartyList');
    if (!summary || !container) return;
    const accessiblePartyIds = new Set();
    opportunities.filter(isOpportunityUnlocked).forEach(opp => {
      const parties = partiesForOpportunity(opp);
      if (parties.supplierId) accessiblePartyIds.add(parties.supplierId);
      if (parties.buyerId) accessiblePartyIds.add(parties.buyerId);
    });
    const accessibleParties = counterpartyCatalog.filter(party => accessiblePartyIds.has(party.id));
    const exposures = {};
    accessibleParties.forEach(party => { exposures[party.id] = counterpartyExposure(party.id); });
    const avgRelationship = accessibleParties.length ? accessibleParties.reduce((sum, p) => sum + getCounterpartyState(p.id).relationship, 0) / accessibleParties.length : 0;
    const suppliers = accessibleParties.filter(p=>p.type==='Supplier').length;
    const buyers = accessibleParties.filter(p=>p.type==='Buyer').length;
    summary.innerHTML = `
      <div><span>Active suppliers</span><strong>${suppliers}</strong></div>
      <div><span>Active customers</span><strong>${buyers}</strong></div>
      <div><span>Avg relationship</span><strong>${Math.round(avgRelationship)}/100</strong></div>
      <div><span>Next network unlock</span><strong>${nextExpansionUnlock()?`L${nextExpansionUnlock().level}`:'Global'}</strong></div>`;
    container.innerHTML = accessibleParties.map(party => {
      const record = getCounterpartyState(party.id);
      const exposure = exposures[party.id] || 0;
      const limit = counterpartyCreditLimit(party.id);
      const pendingRequest = state.creditLimitRequests?.[party.id]?.status === 'pending';
      const relClass = record.relationship >= 65 ? 'low' : record.relationship >= 45 ? 'medium' : 'high';
      return `<div class="counterparty-card">
        <div class="counterparty-head"><div><span>${party.type} · ${party.country}</span><strong>${party.name}</strong></div><span class="status-pill ${party.kyc === 'Approved' ? 'low' : 'medium'}">${party.kyc}</span></div>
        <p>${party.description}</p>
        <div class="counterparty-grid">
          <div><span>Credit score</span><strong>${party.credit}/100</strong></div>
          <div><span>Rating</span><strong class="credit-rating-badge rating-${(party.creditRating||'BBB').replace('+','p').replace('-','m')}">${party.creditRating||'BBB'}</strong></div>
          <div><span>Reliability</span><strong>${party.reliability}/100</strong></div>
          <div><span>Relationship</span><strong>${record.relationship}/100</strong></div>
          <div><span>Exposure</span><strong>${money(exposure,true)}</strong></div>
          <div><span>Buyer limit</span><strong>${money(limit,true)}</strong></div>
        </div>
        <div class="credit-usage-bar"><span style="width:${clamp(limit?exposure/limit*100:0,0,100)}%"></span></div>
        <div class="relationship-bar"><span class="${relClass}" style="width:${record.relationship}%"></span></div>
        <div class="counterparty-foot"><span>${record.deals || 0} completed deals</span><span>${record.disputes || 0} disputes</span>
          <button class="outreach-btn" data-outreach="${party.id}">Warm outreach — $5,000</button>
          ${party.type === 'Buyer' ? `<button class="outreach-btn" data-limit-request="${party.id}" ${pendingRequest?'disabled':''}>${pendingRequest?'Limit review pending':'Request limit increase'}</button>` : ''}
        </div>
      </div>`;
    }).join('');
    $$('[data-outreach]', container).forEach(btn => btn.addEventListener('click', e => { e.stopPropagation(); warmOutreach(btn.dataset.outreach); }));
    $$('[data-limit-request]', container).forEach(btn => btn.addEventListener('click', e => { e.stopPropagation(); requestCreditLimit(btn.dataset.limitRequest); }));
  }

  function renderCompliance() {
    const summary = $('#complianceSummary');
    const queue = $('#complianceQueue');
    const active = $('#complianceActiveDeals');
    const journal = $('#tradeJournalList');
    if (!summary || !queue || !active || !journal) return;
    const profiles = opportunities.filter(isOpportunityUnlocked).filter(opportunityAvailable).map(opp => ({ opp, profile: complianceProfileForOpportunity(opp) }));
    const clearCount = profiles.filter(item => item.profile.canTrade).length;
    const reviewCount = profiles.filter(item => item.profile.requiresReview && !item.profile.reviewed && item.profile.status !== 'Blocked').length;
    const blockedCount = profiles.filter(item => item.profile.status === 'Blocked').length;
    summary.innerHTML = `
      <div><span>Tradable routes</span><strong>${clearCount}</strong></div>
      <div><span>Reviews required</span><strong>${reviewCount}</strong></div>
      <div><span>Blocked</span><strong>${blockedCount}</strong></div>
      <div><span>Compliance spend</span><strong>${money(state.complianceSpend || 0, true)}</strong></div>`;
    const reviewItems = profiles.filter(item => item.profile.requiresReview || item.profile.status === 'Blocked');
    queue.innerHTML = reviewItems.length ? reviewItems.map(({opp,profile}) => `
      <article class="compliance-card ${profile.status === 'Blocked' ? 'blocked' : profile.reviewed ? 'approved' : 'review'}">
        <div class="compliance-card-head"><div><span>${opp.commodity} · ${getHub(opp.origin).country}</span><strong>${opp.title}</strong></div><b>${profile.status}</b></div>
        <div class="compliance-score"><span>Risk score</span><strong>${profile.score}/100</strong></div>
        <p>${profile.flags.length ? profile.flags.join(' · ') : 'Standard KYC and jurisdiction profile.'}</p>
        ${profile.requiresReview && !profile.reviewed && profile.status !== 'Blocked' ? `<button class="button secondary" data-compliance-review="${opp.id}">Run enhanced review · ${money(profile.cost)}</button>` : ''}
      </article>`).join('') : '<div class="empty-card">No enhanced reviews are required in the current market cycle.</div>';
    active.innerHTML = state.activeDeals.length ? state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      return `<div class="compliance-active-row"><div><span>${opp.commodity} · ${deal.operations?.salesContract?.status || 'Signed'}</span><strong>${opp.title}</strong></div><b>${deal.complianceStatus || 'Clear'} · ${deal.complianceScore || 0}/100</b></div>`;
    }).join('') : '<div class="empty-card">No live cargoes require compliance monitoring.</div>';
    const entries = state.tradeJournal || [];
    journal.innerHTML = entries.length ? entries.slice(0,24).map(item => `
      <div class="journal-row"><i class="journal-${(item.category || 'general').toLowerCase().replace(/[^a-z]+/g,'-')}"></i><div><span>${formatDate(new Date(item.date))} · ${item.category}</span><strong>${item.title}</strong><small>${item.detail}</small></div><b style="color:${item.impact >= 0 ? 'var(--green)' : 'var(--red)'}">${item.impact ? money(item.impact) : '—'}</b></div>`).join('') : '<div class="empty-card">Major commercial, risk and operational decisions will be recorded here.</div>';
    $$('[data-compliance-review]', queue).forEach(button => button.addEventListener('click', () => runComplianceReview(button.dataset.complianceReview)));
  }

  function renderWorldEvents() {
    const summary = $('#worldSummary');
    const container = $('#worldEventList');
    if (!summary || !container) return;
    const active = activeCrisisDefinitions();
    summary.innerHTML = `
      <div><span>Active disruptions</span><strong>${active.length}</strong></div>
      <div><span>Freight index</span><strong>${state.freightIndex.toFixed(1)}</strong></div>
      <div><span>Effective credit</span><strong>${money(effectiveCreditLimit(),true)}</strong></div>
      <div><span>Next risk window</span><strong>${Math.max(0,(state.nextGlobalEventDay||0)-state.dayIndex)}d</strong></div>
      <div><span>Risk P&amp;L impact</span><strong style="color:${(state.riskPnlImpact||0)>=0?'var(--green)':'var(--red)'}">${money(state.riskPnlImpact||0,true)}</strong></div>`;
    const activeHtml = active.length ? active.map(event => `<div class="world-event-card active ${event.severity}">
      <div class="world-event-head"><div><span>${event.category || 'Market / Logistics'} · ${event.region || 'Global'}</span><strong>${event.title}</strong></div><span class="status-pill ${event.severity}">${event.remaining}d</span></div>
      <p>${event.description}</p>
      <div class="world-impact">${event.creditPenalty ? `${money(event.creditPenalty,true)} temporary credit reduction` : event.freightShock ? `Freight shock +${event.freightShock} points` : event.commodity ? `${event.commodity} price pressure` : 'Operational disruption'}</div>
    </div>`).join('') : '<div class="success-box">No active global crisis. Routes are operating under normal conditions.</div>';
    const categoryOrder=['Geopolitical','Macroeconomic','Weather','Operational','Credit','Regulatory','Compliance','Political / FX','Market / Logistics'];
    const categoryRows=categoryOrder.map(category=>{
      const events=active.filter(event=>(event.category||'Market / Logistics')===category);
      const impact=(state.riskLedger||[]).filter(item=>item.category===category).slice(0,8).reduce((sum,item)=>sum+(item.impact||0),0);
      return `<div class="risk-radar-cell ${events.length?'alert':''}"><span>${category}</span><strong>${events.length}</strong><small>${money(impact,true)} P&amp;L</small></div>`;
    }).join('');
    const ledgerHtml=(state.riskLedger||[]).length ? (state.riskLedger||[]).slice(0,12).map(item=>`<div class="risk-ledger-row"><div><span>${formatDate(new Date(item.date))} · ${item.category}</span><strong>${item.title}</strong><small>${item.affectedCargoes||0} cargoes affected</small></div><b style="color:${(item.impact||0)>=0?'var(--green)':'var(--red)'}">${item.impact?money(item.impact):'Market'}</b></div>`).join('') : '<div class="empty-card">Risk events and their P&amp;L impact will be recorded here.</div>';
    const nextUnlock=nextExpansionUnlock();
    const expansionHtml=`<div class="expansion-roadmap-card"><div><span>Current company stage · Level ${playerLevel()}</span><strong>${expansionStage().title}</strong><small>${expansionStage().text}</small></div>${nextUnlock?`<div class="next-unlock"><span>Next expansion</span><strong>Level ${nextUnlock.level}</strong><small>${nextUnlock.text}</small></div>`:'<div class="next-unlock"><strong>All global markets unlocked</strong></div>'}</div>`;

    // Market Intelligence panel
    const intelCooldown = (state.dayIndex||0) - (state.intelCooldownDay||-99);
    const intelReady = intelCooldown >= 5 && state.completedDeals >= 1;
    const intelWait = Math.max(0, 5 - intelCooldown);
    const report = state.intelReport;
    const intelReportHtml = report ? (() => {
      const dirRows = report.directions.map(d => `<div class="intel-dir ${d.delta > 0 ? 'up' : 'down'}"><span>${d.label}</span><strong>${d.arrow} ${d.bias}</strong></div>`).join('');
      return `<div class="intel-report-card">
        <div class="intel-report-head"><span class="eyebrow">3-day outlook · issued day ${report.day}</span><strong>Market Intelligence Report</strong></div>
        <div class="intel-dir-grid">${dirRows}</div>
        <div class="intel-meta"><div><span>Event risk</span><strong class="risk-${report.eventRisk.toLowerCase()}">${report.eventRisk}</strong></div><div><span>Freight</span><strong>${report.freightDir}</strong></div><div><span>Regime</span><strong>${report.regime}</strong></div></div>
      </div>`;
    })() : '';
    const intelBtnLabel = !intelReady && state.completedDeals < 1 ? 'Complete a deal to unlock intel' : !intelReady ? `Available in ${intelWait}d` : 'Buy research report — $18,000';
    const intelSection = `<div class="section-head history-head"><div><span class="eyebrow">Market intelligence</span><h2>Research desk</h2></div></div>
      ${intelReportHtml}
      <button class="action-btn intel-btn" id="buyIntelBtn" ${!intelReady ? 'disabled' : ''}>${intelBtnLabel}</button>`;
    const distressedOpp = state.distressedOpportunity;
    const distressedCard = distressedOpp ? `<div class="distressed-cargo-card">
      <div class="distressed-head"><span class="status-pill high">⚡ Distressed · ${Math.max(0, (distressedOpp.distressedExpiry||0) - (state.dayIndex||0))}d left</span><strong>${distressedOpp.title}</strong></div>
      <p>${distressedOpp.description}</p>
      <div class="distressed-stats">
        <div><span>Commodity</span><strong>${distressedOpp.commodity}</strong></div>
        <div><span>Route</span><strong>${getHub(distressedOpp.origin)?.name || distressedOpp.origin} → ${getHub(distressedOpp.destination)?.name || distressedOpp.destination}</strong></div>
        <div><span>Margin (discounted)</span><strong style="color:var(--green)">${money(distressedOpp.basePnl)}</strong></div>
        <div><span>Duration</span><strong>${distressedOpp.duration} days</strong></div>
      </div>
      <button class="button primary" id="viewDistressedBtn">Open distressed opportunity →</button>
    </div>` : '';
    const feedHtml = (state.worldEventFeed || []).map(item => `<div class="intelligence-item ${item.type}"><span>${formatDate(new Date(item.date))}</span><strong>${item.title}</strong><p>${item.description}</p></div>`).join('');
    container.innerHTML = `<div class="section-head history-head"><div><span class="eyebrow">Enterprise risk radar</span><h2>Risk categories and P&amp;L</h2></div></div><div class="risk-radar-grid">${categoryRows}</div>${expansionHtml}<div class="section-head history-head"><div><span class="eyebrow">Active shocks</span><h2>Global tension monitor</h2></div></div>${activeHtml}<div class="section-head history-head"><div><span class="eyebrow">Risk attribution</span><h2>Event P&amp;L ledger</h2></div></div><div class="risk-ledger-list">${ledgerHtml}</div>${intelSection}${distressedCard ? `<div class="section-head history-head"><div><span class="eyebrow">Distressed cargo</span><h2>Urgent deal window</h2></div></div>${distressedCard}` : ''}<div class="section-head history-head"><div><span class="eyebrow">Intelligence feed</span><h2>Latest developments</h2></div></div>${feedHtml || '<div class="empty-card">The global intelligence feed will update over time.</div>'}`;
    $('#buyIntelBtn')?.addEventListener('click', () => buyMarketIntel());
    $('#viewDistressedBtn')?.addEventListener('click', () => {
      if (state.distressedOpportunity) {
        selected = { type: 'opportunity', id: state.distressedOpportunity.id };
        openInspector();
        // Switch to market tab so opportunity inspector is visible
        renderInspector();
      }
    });
  }

  function renderFinance() {
    const summary = $('#financeSummary');
    const dealList = $('#financeDealList');
    const banking = $('#bankingList');
    if (!summary || !dealList || !banking) return;
    const stats = portfolioStats();
    const collateral = stats.marginCollateral || 0;
    const interest = state.activeDeals.reduce((sum,deal)=>sum+(deal.financingAccrued||0),0);
    summary.innerHTML = `
      <div><span>Credit used</span><strong>${money(stats.creditUsed,true)}</strong></div>
      <div><span>Credit available</span><strong>${money(stats.creditAvailable,true)}</strong></div>
      <div><span>Futures collateral</span><strong>${money(collateral,true)}</strong></div>
      <div><span>Interest accrued</span><strong>${money(interest)}</strong></div>
      <div><span>Margin calls</span><strong>${state.marginCalls||0}</strong></div>
      <div><span>Emergency fees</span><strong>${money(state.emergencyFundingCost||0)}</strong></div>
      <div><span>Credit losses</span><strong>${money(state.creditLosses||0)}</strong></div>
      <div><span>Receivable protection</span><strong>${money(state.receivableProtectionCost||0)}</strong></div>`;
    dealList.innerHTML = state.activeDeals.length ? state.activeDeals.map(deal => {
      const opp = getOpportunity(deal.opportunityId);
      const required = currentMarginRequirement(deal);
      const coverage = required ? (deal.marginCollateral||0)/required : 1;
      return `<button class="finance-card" data-finance-deal="${deal.id}">
        <div class="finance-card-head"><div><span>${opp.commodity} · ${opp.title}</span><strong>${financingProfiles[deal.financingStrategy||'revolver']?.label}</strong></div><span class="status-pill ${coverage>=1?'low':'high'}">${Math.round(coverage*100)}% margin</span></div>
        <div class="finance-grid"><div><span>Debt</span><strong>${money(deal.borrowed,true)}</strong></div><div><span>Rate</span><strong>${((deal.financingRate||0)*100).toFixed(1)}%</strong></div><div><span>Collateral</span><strong>${money(deal.marginCollateral||0,true)}</strong></div><div><span>Interest</span><strong>${money(deal.financingAccrued||0)}</strong></div></div>
        <div class="capital-bar margin"><span style="width:${clamp(coverage*100,0,100)}%"></span></div>
      </button>`;
    }).join('') : emptyState('No active funding. Facilities, LCs and futures collateral appear once a cargo is open.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
    banking.innerHTML = bankCatalog.map(bank => {
      const unlocked = bank.id !== 'oceanic' || officeOwned('singapore');
      const capacity = effectiveCreditLimit()*bank.limitShare;
      const used = stats.creditUsed*bank.limitShare;
      return `<div class="bank-card ${unlocked?'':'locked'}"><div class="finance-card-head"><div><span>${bank.type}</span><strong>${bank.name}</strong></div><span class="status-pill ${unlocked?'low':'high'}">${unlocked?'Active':'Locked'}</span></div><p>${bank.description}</p><div class="finance-grid"><div><span>Capacity</span><strong>${money(capacity,true)}</strong></div><div><span>Indicative rate</span><strong>${(bank.rate*100).toFixed(1)}%</strong></div><div><span>Relationship</span><strong>${bank.relationship}/100</strong></div><div><span>Allocated</span><strong>${money(used,true)}</strong></div></div></div>`;
    }).join('');
    $$('[data-finance-deal]',dealList).forEach(button=>button.addEventListener('click',()=>selectDeal(button.dataset.financeDeal)));
  }

  function completeAcademyLesson(id, answer) {
    const lesson = academyCatalog.find(item=>item.id===id);
    if (!lesson) return;
    state.academyProgress = state.academyProgress || {};
    const current = state.academyProgress[id] || { attempts: 0, completed: false };
    current.attempts += 1;
    if (Number(answer) === lesson.correct) {
      if (!current.completed) {
        current.completed = true;
        current.completedAt = state.date;
        state.academyScore = (state.academyScore||0)+100;
        state.cash += 12_000;
        state.reputation = clamp(state.reputation+1,0,100);
        showToast(`Lesson completed: ${lesson.title}. Reward ${money(12_000)}.`);
      }
    } else {
      current.lastWrong = Number(answer);
      showToast('Incorrect answer. Review the concept and try again.');
    }
    state.academyProgress[id]=current;
    evaluateMissions();
    saveState();
    renderAll();
  }

  function renderAcademy() {
    const summary = $('#academySummary');
    const lessons = $('#academyLessonList');
    const glossary = $('#glossaryList');
    if (!summary || !lessons || !glossary) return;
    const completed = academyCatalog.filter(item=>state.academyProgress?.[item.id]?.completed).length;
    const dealExperience = state.completedDeals + state.activeDeals.length;
    summary.innerHTML = `<div><span>Lessons complete</span><strong>${completed}/${academyCatalog.length}</strong></div><div><span>Academy score</span><strong>${state.academyScore||0}</strong></div><div><span>Field experience</span><strong>${dealExperience} cargo</strong></div><div><span>Difficulty</span><strong>${state.difficulty}</strong></div>`;
    lessons.innerHTML = academyCatalog.map((lesson,index)=>{
      const progress=state.academyProgress?.[lesson.id]||{};
      const unlocked=index===0 || academyCatalog.slice(0,index).every(previous=>state.academyProgress?.[previous.id]?.completed) || state.difficulty==='guided';
      return `<div class="academy-card ${progress.completed?'completed':unlocked?'':'locked'}"><div class="academy-head"><div><span>Module ${index+1}</span><strong>${lesson.title}</strong></div><span class="status-pill ${progress.completed?'low':unlocked?'medium':'high'}">${progress.completed?'Complete':unlocked?'Open':'Locked'}</span></div><p>${lesson.concept}</p>${unlocked&&!progress.completed?`<div class="academy-question"><strong>${lesson.question}</strong>${lesson.options.map((option,i)=>`<button data-academy-answer="${lesson.id}" data-answer-index="${i}">${option}</button>`).join('')}</div>`:progress.completed?'<div class="success-box">Knowledge verified and ready to apply in deals.</div>':'<div class="warning-box">Complete the previous module to unlock this lesson.</div>'}</div>`;
    }).join('');
    glossary.innerHTML = glossaryCatalog.map(([term,definition])=>`<details class="glossary-item"><summary>${term}</summary><p>${definition}</p></details>`).join('');
    $$('[data-academy-answer]',lessons).forEach(button=>button.addEventListener('click',()=>completeAcademyLesson(button.dataset.academyAnswer,button.dataset.answerIndex)));
  }


  // ── v40 illustrazioni per filiera industriale ────────────────────────────
  const chainArt = {
    upstream: `<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="upA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd79a"/><stop offset="1" stop-color="#c07a20"/></linearGradient><linearGradient id="upR" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a9b4c4"/><stop offset="1" stop-color="#5d6675"/></linearGradient></defs><path d="M6 40h36" stroke="#3a4250" stroke-width="2.6" stroke-linecap="round"/><path d="M14 40V18l10-8 10 8v22" fill="url(#upA)" stroke="#7d4c0c" stroke-width="1.8" stroke-linejoin="round"/><path d="M24 10l10 8H14z" fill="#ffe6bb" stroke="#7d4c0c" stroke-width="1.7" stroke-linejoin="round"/><rect x="20" y="26" width="8" height="14" rx="1.5" fill="#6b4310" stroke="#3f2708" stroke-width="1.5"/><path d="M17 22h14" stroke="#7d4c0c" stroke-width="1.8" stroke-linecap="round"/><path d="M7 36l4-6 4 3 3-4" stroke="url(#upR)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" fill="none"/><circle cx="34" cy="31" r="3" fill="#cfd7e2" stroke="#3a4250" stroke-width="1.5"/></svg>`,
    midstream: `<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="mdA" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#dfe9f6"/><stop offset=".5" stop-color="#9fb0c6"/><stop offset="1" stop-color="#6a7789"/></linearGradient></defs><path d="M5 41h38" stroke="#3a4250" stroke-width="2.6" stroke-linecap="round"/><rect x="8" y="18" width="14" height="23" rx="2" fill="url(#mdA)" stroke="#41506a" stroke-width="1.8"/><ellipse cx="15" cy="18" rx="7" ry="2.6" fill="#eaf2fb" stroke="#41506a" stroke-width="1.6"/><rect x="27" y="24" width="13" height="17" rx="2" fill="url(#mdA)" stroke="#41506a" stroke-width="1.8"/><ellipse cx="33.5" cy="24" rx="6.5" ry="2.4" fill="#eaf2fb" stroke="#41506a" stroke-width="1.6"/><path d="M22 30h5M22 35h5" stroke="#41506a" stroke-width="2" stroke-linecap="round"/><path d="M11 24v12M31 29v9" stroke="#fff" stroke-opacity=".55" stroke-width="2.2" stroke-linecap="round"/><path d="M5 30h3" stroke="#7fd2ff" stroke-width="2.4" stroke-linecap="round"/></svg>`,
    downstream: `<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="dwA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfe0f5"/><stop offset="1" stop-color="#69809c"/></linearGradient></defs><path d="M5 41h38" stroke="#3a4250" stroke-width="2.6" stroke-linecap="round"/><path d="M8 41V24l9 5v-5l9 5V17h14v24z" fill="url(#dwA)" stroke="#3c4b60" stroke-width="1.8" stroke-linejoin="round"/><rect x="30" y="9" width="5" height="9" rx="1" fill="#8fa3bb" stroke="#3c4b60" stroke-width="1.5"/><path d="M32.5 8c1.6-2 .4-3.4 0-4.6" stroke="#bcd3ea" stroke-width="1.8" stroke-linecap="round"/><rect x="12" y="32" width="5" height="9" rx="1" fill="#41536b" stroke="#2c3a4c" stroke-width="1.3"/><rect x="21" y="32" width="5" height="9" rx="1" fill="#41536b" stroke="#2c3a4c" stroke-width="1.3"/><rect x="32" y="24" width="8" height="6" rx="1" fill="#dceaf9" stroke="#3c4b60" stroke-width="1.4"/></svg>`
  };

  function renderEmpire() {
    const summary=$('#investmentSummary'), queue=$('#builderQueue'), container=$('#investmentList');
    if(!summary||!queue||!container) return;
    const levels=totalInvestmentLevels(), income=dailyInvestmentIncome(), book=investmentBookValue(), active=activeProjectCount();
    summary.innerHTML=`<div><span>Industrial levels</span><strong>${levels}</strong></div><div><span>Asset book value</span><strong>${money(book,true)}</strong></div><div><span>Daily asset income</span><strong>${money(income)}</strong></div><div><span>Project teams</span><strong>${active}/${builderSlots()}</strong></div>`;
    const builds=investmentCatalog.filter(asset=>investmentRecord(asset.id).buildingTo);
    queue.innerHTML=builds.length?builds.map(asset=>{const r=investmentRecord(asset.id);const total=investmentBuildDays(asset,r.buildingTo);const pct=(1-r.daysRemaining/total)*100;return `<div class="builder-card"><div><span>${asset.chain} construction</span><strong>${asset.name} · L${r.buildingTo}</strong><small>${r.daysRemaining} days remaining</small></div><div class="progress-track"><span style="width:${pct}%"></span></div></div>`}).join(''):emptyState(`No projects under construction \u00b7 ${builderSlots()} project teams free.`, { label: 'Open the empire store', type: 'module', id: 'shop' });
    // v32 buy extra project team with gold bars
    const gCost = builderGoldCost();
    queue.innerHTML += `<div class="buy-builder-card"><div class="bb-info"><span>Extra project team</span><small>+1 permanent builder · ${state.bonusBuilders||0} purchased</small></div><button class="button gold buy-builder-btn" id="buyBuilderBtn" ${(state.goldBars||0)<gCost?'disabled':''}>${gCost} gold bars</button></div>`;
    const bbBtn = $('#buyBuilderBtn'); if (bbBtn) bbBtn.addEventListener('click', buyExtraBuilder);
    const visible=investmentCatalog.filter(asset=>selectedEmpireChain==='all'||asset.chain===selectedEmpireChain);
    container.innerHTML=visible.map(asset=>{
      const r=investmentRecord(asset.id), level=r.level||0, target=level+1, max=level>=asset.maxLevel, unlocked=investmentUnlocked(asset), building=Boolean(r.buildingTo), cost=max?0:investmentCost(asset,target), days=max?0:investmentBuildDays(asset,target);
      const benefits=[asset.dailyIncome?`${money(asset.dailyIncome*level)}/day`:null,asset.pnlBonus?`+${money(asset.pnlBonus*level)} deal edge`:null,asset.durationBonus&&level?`-${asset.durationBonus*level} days`:null].filter(Boolean).join(' · ');
      const buildPct = building ? Math.round((1 - r.daysRemaining / Math.max(1, investmentBuildDays(asset, r.buildingTo))) * 100) : 0;
      const noCash = !max && state.cash < cost;
      const noTeam = activeProjectCount() >= builderSlots();
      const btnLabel = building ? `Building L${r.buildingTo} · ${r.daysRemaining}d`
        : max ? 'MAX LEVEL'
        : !unlocked ? `🔒 Rep ${asset.minReputation} · ${asset.minDeals} deals`
        : noTeam ? 'All teams busy'
        : noCash ? `Need ${money(cost)}`
        : `UPGRADE · ${money(cost)}`;
      return `<article class="investment-card v40 chain-${asset.chain} ${building?'building':''} ${!unlocked?'locked':''} ${max?'maxed':''}" data-investment-card="${asset.id}">
        <div class="inv-top">
          <span class="inv-art art-${asset.chain}">${chainArt[asset.chain] || chainArt.upstream}
            <b class="inv-lvl">${level}</b>
          </span>
          <span class="inv-id">
            <span class="inv-chain">${asset.chain}</span>
            <strong class="inv-name">${asset.name}</strong>
            <span class="inv-hub">${getHub(asset.hub)?.name||''} · ${asset.commodity||''}</span>
          </span>
        </div>
        <div class="inv-pips">${Array.from({length:asset.maxLevel},(_,i)=>`<i class="${i<level?'filled':''} ${r.buildingTo===i+1?'building':''}"></i>`).join('')}<em>L${level}/${asset.maxLevel}</em></div>
        <p class="inv-desc">${asset.description}</p>
        <div class="inv-benefit">${level?benefits:'No active benefit — build level 1'}</div>
        ${building ? `<div class="inv-progress"><div class="inv-progress-row"><span>Building L${r.buildingTo}</span><b>${r.daysRemaining} d</b></div><div class="inv-progress-track"><span style="width:${buildPct}%"></span></div></div>`
        : `<div class="inv-econ">
            <div class="inv-cell"><span class="k">Cost</span><strong class="v ${noCash?'red':'gold'}">${max?'—':money(cost)}</strong></div>
            <div class="inv-cell"><span class="k">Time</span><strong class="v">${max?'—':days+' d'}</strong></div>
          </div>`}
        <button class="inv-btn ${building?'busy':''} ${max?'maxed':''} ${(!unlocked||noCash||noTeam)?'blocked':''}" data-build-investment="${asset.id}" ${max||building||!unlocked||noCash||noTeam?'disabled':''}>${btnLabel}</button>
      </article>`;
    }).join('');
    $$('[data-empire-chain]').forEach(button=>button.classList.toggle('active',button.dataset.empireChain===selectedEmpireChain));
    $$('[data-empire-chain]').forEach(button=>button.onclick=()=>{selectedEmpireChain=button.dataset.empireChain;renderEmpire();});
    $$('[data-build-investment]',container).forEach(button=>button.onclick=()=>startInvestment(button.dataset.buildInvestment));
    $$('[data-investment-card]',container).forEach(card=>card.addEventListener('click',event=>{if(event.target.closest('button'))return;selectInvestment(card.dataset.investmentCard);}));
  }


  // ── v41 illustrazioni categorie negozio ──────────────────────────────────
  const shopArt = {
    fleet: `<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="shH" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff9a6b"/><stop offset="1" stop-color="#c1442a"/></linearGradient><linearGradient id="shS" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eaf3ff"/><stop offset="1" stop-color="#9fb2c9"/></linearGradient></defs><path d="M4 34h40l-4 7H8z" fill="url(#shH)" stroke="#7e2a17" stroke-width="1.8" stroke-linejoin="round"/><rect x="12" y="24" width="9" height="10" rx="1.5" fill="#d84b2f" stroke="#7e2a17" stroke-width="1.5"/><rect x="23" y="26" width="8" height="8" rx="1.5" fill="#f2694a" stroke="#7e2a17" stroke-width="1.5"/><rect x="30" y="20" width="10" height="14" rx="2" fill="url(#shS)" stroke="#54637a" stroke-width="1.6"/><path d="M32 24h6M32 28h6" stroke="#54637a" stroke-width="1.5" stroke-linecap="round"/><path d="M8 37h30" stroke="#fff" stroke-opacity=".45" stroke-width="2" stroke-linecap="round"/><path d="M4 44c4-2 6-2 10 0s6 2 10 0 6-2 10 0 6 2 10 0" stroke="#7fd2ff" stroke-width="2.2" stroke-linecap="round" fill="none"/></svg>`,
    storage: `<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="stW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd98f"/><stop offset="1" stop-color="#c4881c"/></linearGradient></defs><path d="M5 41h38" stroke="#3a4250" stroke-width="2.6" stroke-linecap="round"/><path d="M9 41V21l15-9 15 9v20z" fill="url(#stW)" stroke="#7d4c0c" stroke-width="1.8" stroke-linejoin="round"/><path d="M24 12l15 9H9z" fill="#ffe9bb" stroke="#7d4c0c" stroke-width="1.7" stroke-linejoin="round"/><rect x="19" y="28" width="10" height="13" rx="1.5" fill="#8a5a12" stroke="#4d3208" stroke-width="1.5"/><path d="M19 33h10" stroke="#4d3208" stroke-width="1.4"/><rect x="12" y="26" width="5" height="5" rx="1" fill="#fff3d6" stroke="#7d4c0c" stroke-width="1.3"/><rect x="31" y="26" width="5" height="5" rx="1" fill="#fff3d6" stroke="#7d4c0c" stroke-width="1.3"/></svg>`,
    infrastructure: `<svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="crA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe07a"/><stop offset="1" stop-color="#e0951a"/></linearGradient></defs><path d="M4 41h40" stroke="#3a4250" stroke-width="2.6" stroke-linecap="round"/><path d="M14 41V9" stroke="url(#crA)" stroke-width="4.5" stroke-linecap="round"/><path d="M14 11h22" stroke="url(#crA)" stroke-width="4" stroke-linecap="round"/><path d="M36 11v9" stroke="#c9d4e3" stroke-width="2.2" stroke-linecap="round"/><rect x="31" y="20" width="10" height="8" rx="1.6" fill="#8fb7e8" stroke="#3f5a80" stroke-width="1.6"/><path d="M9 41c0-6 2-9 5-9s5 3 5 9" fill="#c9d4e3" stroke="#4b5769" stroke-width="1.6"/><path d="M18 11l-4 6 4 6" stroke="#e0951a" stroke-width="2" stroke-linejoin="round" fill="none"/></svg>`
  };

  function renderShop() {
    const summary=$('#shopSummary'), queue=$('#shopBuildQueue'), catalog=$('#shopCatalogList');
    if(!summary||!queue||!catalog) return;
    const orders=state.shopOrders||[];
    const delivered=shopCatalog.reduce((sum,item)=>sum+shopOwnedQuantity(item.id),0);
    const permanentShips=(state.fleetAssets||[]).filter(asset=>asset.ownership==='owned').length;
    summary.innerHTML=`
      <div><span>Permanent assets</span><strong>${delivered}</strong></div>
      <div><span>Owned vessels</span><strong>${permanentShips}</strong></div>
      <div><span>Asset book value</span><strong>${money(shopBookValue(),true)}</strong></div>
      <div><span>Project teams</span><strong>${activeProjectCount()}/${builderSlots()}</strong></div>`;
    renderShopRailBadge();
    queue.innerHTML=orders.length?orders.map(order=>{
      const item=shopDefinition(order.itemId); const pct=Math.round((1-order.daysRemaining/Math.max(1,order.totalDays))*100);
      return `<article class="shop-order-card"><div class="shop-order-icon">${item?.icon||'▦'}</div><div><span>${item?.category||'asset'} project</span><strong>${item?.name||'Capital asset'}</strong><small>${order.daysRemaining} days remaining · ${pct}% complete</small><div class="shop-order-progress"><i style="width:${pct}%"></i></div></div></article>`;
    }).join(''):`<div class="empty-card compact">No store orders under construction. ${Math.max(0,builderSlots()-activeProjectCount())} project team${builderSlots()-activeProjectCount()===1?'':'s'} available.</div>`;
    const visible=shopCatalog.filter(item=>selectedShopCategory==='all'||item.category===selectedShopCategory);
    catalog.innerHTML=visible.map(item=>{
      const owned=shopOwnedQuantity(item.id), pending=shopPendingQuantity(item.id), unlocked=shopUnlocked(item), maxed=owned+pending>=item.maxOwned;
      const officeMissing=item.requiresOffice&&!officeOwned(item.requiresOffice);
      const lockText=officeMissing?`Requires ${getOffice(item.requiresOffice)?.name}`:`Requires rep ${item.minReputation} · ${item.minDeals} deals`;
      const busy=activeProjectCount()>=builderSlots();
      const status=pending?`${pending} building`:owned?`${owned}/${item.maxOwned} owned`:'Available';
      const noCash = state.cash < item.cost;
      return `<article class="shop-item-card v41 category-${item.category} ${!unlocked?'locked':''} ${pending?'building':''} ${maxed?'maxed':''}">
        <div class="shop-ribbon">${item.category==='fleet'?'SHIPYARD':item.category==='storage'?'STORAGE':'LOGISTICS'}</div>
        <div class="shop-hero">
          <span class="shop-art sa-${item.category}">${shopArt[item.category] || shopArt.infrastructure}
            ${owned?`<b class="shop-own">×${owned}</b>`:''}
          </span>
          <span class="shop-head">
            <span class="shop-cat">${item.category}</span>
            <strong class="shop-name">${item.name}</strong>
            <span class="shop-status ${pending?'is-building':owned?'is-owned':''}">${status}</span>
          </span>
        </div>
        <p class="shop-desc">${item.description}</p>
        <div class="shop-benefit v41"><b>Permanent benefit</b><span>${item.benefit}</span></div>
        <div class="shop-grid">
          <div class="shop-cell"><span class="k">Price</span><strong class="v ${noCash?'red':'gold'}">${money(item.cost)}</strong></div>
          <div class="shop-cell"><span class="k">Build time</span><strong class="v">${item.buildDays} d</strong></div>
          <div class="shop-cell"><span class="k">Owned</span><strong class="v">${owned}/${item.maxOwned}</strong></div>
          <div class="shop-cell"><span class="k">Upkeep</span><strong class="v">${money(item.maintenance||item.dailyCost||0)}</strong></div>
        </div>
        <div class="shop-level-pips">${Array.from({length:item.maxOwned},(_,i)=>`<i class="${i<owned?'owned':i<owned+pending?'building':''}"></i>`).join('')}</div>
        <button class="shop-buy-button" data-buy-shop-item="${item.id}" ${!unlocked||maxed||busy||state.cash<item.cost?'disabled':''}>
          <span>${maxed?'MAX':pending?'ORDER MORE':unlocked?'BUY & BUILD':'LOCKED'}</span><b>${maxed?'Capacity reached':!unlocked?lockText:busy?'All teams busy':state.cash<item.cost?'Insufficient cash':`${money(item.cost)} · ${item.buildDays}d`}</b>
        </button>
      </article>`;
    }).join('');
    $$('[data-shop-category]').forEach(button=>button.classList.toggle('active',button.dataset.shopCategory===selectedShopCategory));
    $$('[data-shop-category]').forEach(button=>button.onclick=()=>{selectedShopCategory=button.dataset.shopCategory;renderShop();});
    $$('[data-buy-shop-item]',catalog).forEach(button=>button.onclick=()=>buyShopItem(button.dataset.buyShopItem));
  }

  function renderHQ() {
    const summary = $('#hqSummary');
    const officesContainer = $('#officeList');
    const staffContainer = $('#staffList');
    if (!summary || !officesContainer || !staffContainer) return;
    const _qPnl      = state.realizedPnl - (state.quarterStartPnl || 0);
    const _qTarget   = state.quarterTarget || 500000;
    const _qPct      = Math.min(100, Math.round((_qPnl / _qTarget) * 100));
    const _qNum      = state.quarterNumber || 1;
    const _qLabel    = ['Q1','Q2','Q3','Q4'][(_qNum - 1) % 4] + ' Year ' + Math.ceil(_qNum / 4);
    const _qColor    = _qPct >= 100 ? 'var(--green)' : _qPct >= 60 ? 'var(--orange)' : 'var(--red)';
    summary.innerHTML = `
      <div><span>Global offices</span><strong>${state.offices.length}/${officeCatalog.length}</strong></div>
      <div><span>Team members</span><strong>${state.staff.length}/${staffCatalog.length}</strong></div>
      <div><span>Daily overhead</span><strong>${money(dailyOverhead())}</strong></div>
      <div><span>Total overhead paid</span><strong>${money(state.overheadPaid || 0, true)}</strong></div>
      <div class="quarter-target-block">
        <div class="quarter-target-head"><span>${_qLabel} desk target</span><strong>${money(_qPnl, true)} / ${money(_qTarget, true)}</strong></div>
        <div class="quarter-target-bar"><span style="width:${_qPct}%;background:${_qColor}"></span></div>
        <div class="quarter-target-meta"><span>${_qPct}% of target${state.quarterBonusPaid ? ' · Bonuses paid: ' + money(state.quarterBonusPaid, true) : ''}</span><span>${state.quarterMissed ? state.quarterMissed + ' missed' : '✓ on track'}</span></div>
      </div>`;
    officesContainer.innerHTML = officeCatalog.map(office => {
      const owned = officeOwned(office.id);
      const project = activeOfficeProject(office.id);
      const unlocked = officeUnlocked(office);
      return `<div class="management-card ${owned ? 'owned' : project ? 'building' : unlocked ? '' : 'locked'}">
        <div class="management-head"><div><span>${office.flag} ${office.region}</span><strong>${office.name}</strong></div><span class="status-pill ${owned ? 'low' : project ? 'medium' : unlocked ? 'medium' : 'high'}">${owned ? 'Active' : project ? `${project.daysRemaining}d` : unlocked ? 'Available' : `Level ${office.minLevel}`}</span></div>
        <p>${office.description}</p><div class="management-benefit">${office.benefit}</div>
        <div class="management-grid"><div><span>Opening cost</span><strong>${office.cost ? money(office.cost) : 'Included'}</strong></div><div><span>Build / daily cost</span><strong>${office.buildDays || 0}d · ${money(office.dailyCost)}</strong></div></div>
        ${project?`<div class="progress-track"><span style="width:${Math.max(4,100*(1-project.daysRemaining/project.totalDays))}%"></span></div>`:''}
        ${office.id === 'geneva' ? '' : `<button class="button secondary management-action" data-open-office="${office.id}" ${owned || project || !unlocked || state.cash < office.cost || activeProjectCount()>=builderSlots() ? 'disabled' : ''}>${owned ? 'Office active' : project ? 'Under construction' : unlocked ? 'Open international office' : `Requires ${officeLockReason(office)}`}</button>`}
      </div>`;
    }).join('');
    staffContainer.innerHTML = staffCatalog.map(member => {
      const hired = hasStaff(member.id);
      const unlocked = staffUnlocked(member);
      return `<div class="management-card ${hired ? 'owned' : unlocked ? '' : 'locked'}">
        <div class="management-head"><div><span>Specialist</span><strong>${member.role}</strong></div><span class="status-pill ${hired ? 'low' : unlocked ? 'medium' : 'high'}">${hired ? 'Hired' : unlocked ? 'Available' : 'Locked'}</span></div>
        <p>${member.description}</p><div class="management-benefit">${member.benefit}</div>
        <div class="management-grid"><div><span>Hiring cost</span><strong>${money(member.hireCost)}</strong></div><div><span>Daily salary</span><strong>${money(member.dailySalary)}</strong></div></div>
        <button class="button secondary management-action" data-hire-staff="${member.id}" ${hired || !unlocked || state.cash < member.hireCost ? 'disabled' : ''}>${hired ? 'In team' : unlocked ? 'Hire specialist' : `Requires rep ${member.minReputation}`}</button>
      </div>`;
    }).join('');
    $$('[data-open-office]', officesContainer).forEach(button => button.addEventListener('click', () => openOffice(button.dataset.openOffice)));
    $$('[data-hire-staff]', staffContainer).forEach(button => button.addEventListener('click', () => hireStaff(button.dataset.hireStaff)));
  }

  function renderCareer() {
    const summary = $('#careerSummary');
    const container = $('#missionList');
    if (!summary || !container) return;
    const completed = state.completedMissions.length;
    summary.innerHTML = `
      <div><span>Rank</span><strong>${rankFromState()}</strong></div>
      <div><span>Missions</span><strong>${completed}/${missionCatalog.length}</strong></div>
      <div><span>Completed deals</span><strong>${state.completedDeals}</strong></div>
      <div><span>Reputation</span><strong>${Math.round(state.reputation)}/100</strong></div>`;
    container.innerHTML = missionCatalog.map(mission => {
      const done = state.completedMissions.includes(mission.id);
      const progress = Math.min(mission.target, mission.progress(state));
      const pct = mission.target ? progress / mission.target * 100 : 100;
      const rewards = [mission.cash ? money(mission.cash) : null, mission.credit ? `${money(mission.credit)} credit` : null, mission.reputation ? `+${mission.reputation} rep` : null].filter(Boolean).join(' · ');
      return `<div class="mission-card ${done ? 'completed' : ''}">
        <div class="mission-head"><div><span>Career mission</span><strong>${mission.title}</strong></div><span class="status-pill ${done ? 'low' : 'medium'}">${done ? 'Complete' : `${progress}/${mission.target}`}</span></div>
        <p>${mission.description}</p><div class="mission-reward">Reward · ${rewards}</div>
        <div class="progress-track"><span style="width:${pct}%"></span></div>
      </div>`;
    }).join('');
    const achievementGrid = $('#achievementGrid');
    if (achievementGrid) achievementGrid.innerHTML = achievementCatalog.map(item => {
      const unlocked = (state.achievements || []).includes(item.id);
      return `<div class="achievement-card ${unlocked?'unlocked':'locked'}"><span class="achievement-icon">${item.icon}</span><div><strong>${item.title}</strong><p>${item.description}</p></div><em>${unlocked?'Unlocked':'Locked'}</em></div>`;
    }).join('');
    // Analytics panel
    const analyticsPanel = $('#analyticsPanel');
    if (analyticsPanel) {
      const pnlMap = state.pnlByCommodity || {};
      const entries = Object.entries(pnlMap).sort((a,b) => b[1].pnl - a[1].pnl);
      if (!entries.length) {
        analyticsPanel.innerHTML = '<p style="color:var(--muted);font-size:13px;padding:12px 0">No closed trades yet. Complete your first deal to see analytics.</p>';
      } else {
        const totalPnl = entries.reduce((s,[,v]) => s+v.pnl, 0);
        const totalWins = entries.reduce((s,[,v]) => s+v.wins, 0);
        const totalTrades = entries.reduce((s,[,v]) => s+v.wins+v.losses, 0);
        const bestTrade = entries.reduce((best,[k,v]) => v.bestPnl > (best?.pnl||0) ? {commodity:k,pnl:v.bestPnl} : best, null);
        const worstTrade = entries.reduce((worst,[k,v]) => v.worstPnl < (worst?.pnl||Infinity) ? {commodity:k,pnl:v.worstPnl} : worst, null);
        const overallBar = `<div class="analytics-overview">
          <div><span>Total realised P&L</span><strong style="color:${totalPnl>=0?'var(--green)':'var(--red)'}">${money(totalPnl)}</strong></div>
          <div><span>Win rate</span><strong>${totalTrades?Math.round(totalWins/totalTrades*100):0}%</strong></div>
          <div><span>Best trade</span><strong style="color:var(--green)">${bestTrade?money(bestTrade.pnl)+' ('+bestTrade.commodity+')':'—'}</strong></div>
          <div><span>Worst trade</span><strong style="color:var(--red)">${worstTrade&&worstTrade.pnl<0?money(worstTrade.pnl)+' ('+worstTrade.commodity+')':'—'}</strong></div>
        </div>`;
        const maxAbsPnl = Math.max(...entries.map(([,v])=>Math.abs(v.pnl)),1);
        const rows = entries.map(([key,v]) => {
          const wr = (v.wins+v.losses) ? Math.round(v.wins/(v.wins+v.losses)*100) : 0;
          const barW = Math.round(Math.abs(v.pnl)/maxAbsPnl*100);
          const col = v.pnl >= 0 ? 'var(--green)' : 'var(--red)';
          return `<div class="analytics-row">
            <div class="analytics-label"><strong>${key}</strong><span>${v.wins+v.losses} trades · ${wr}% win</span></div>
            <div class="analytics-bar-wrap"><div class="analytics-bar" style="width:${barW}%;background:${col}"></div></div>
            <div class="analytics-value" style="color:${col}">${money(v.pnl)}</div>
          </div>`;
        }).join('');
        analyticsPanel.innerHTML = overallBar + '<div class="analytics-table">' + rows + '</div>';
      }
    }
  }

  function renderLeaderboard() {
    const summary=$('#leaderboardSummary');
    const table=$('#leaderboardTable');
    const profile=$('#leaderboardProfile');
    const history=$('#seasonHistory');
    if (!summary||!table||!profile||!history) return;
    const rows=leaderboardRows(selectedLeaderboardMode);
    const player=rows.find(row=>row.isPlayer);
    const league=leaderboardLeague();
    const nextProgress=league.next ? clamp(leaderboardScore()/league.next*100,0,100) : 100;
    summary.innerHTML=`
      <div><span>Career League</span><strong>#${player.position} / ${rows.length}</strong></div>
      <div><span>League</span><strong class="league-name ${league.className}">${league.name}</strong></div>
      <div><span>Rating</span><strong>${leaderboardScore().toLocaleString('en-US')}</strong></div>
      <div><span>Season</span><strong>S${seasonNumber()} · day ${seasonDay()}/90</strong></div>`;
    profile.innerHTML=`
      <div class="leaderboard-profile-card">
        <div class="leaderboard-avatar">${esc((state.profileName||'GB').split(/\s+/).map(v=>v[0]).slice(0,2).join('').toUpperCase())}</div>
        <div class="leaderboard-profile-copy"><span>Player identity</span><strong>${esc(state.profileName)}</strong><small>${esc(state.companyName)} · ${rankFromState()}</small></div>
      </div>
      <div class="leaderboard-edit-grid"><label>Trader name<input id="leaderboardTraderName" maxlength="40" value="${esc(state.profileName)}"></label><label>Trading house<input id="leaderboardCompanyName" maxlength="40" value="${esc(state.companyName)}"></label></div>
      <button class="button secondary leaderboard-save" id="saveLeaderboardProfile">Save identity</button>
      <div class="league-progress"><div><span>${league.name}</span><strong>${league.next?`${Math.max(0,league.next-leaderboardScore()).toLocaleString('en-US')} points to next league`:'Highest league reached'}</strong></div><div class="progress-track"><span style="width:${nextProgress}%"></span></div></div>`;
    table.innerHTML=`
      <div class="leaderboard-mode-tabs">${[['overall','Overall'],['pnl','P&L'],['operations','Operations'],['risk','Risk discipline']].map(([id,label])=>`<button data-leaderboard-mode="${id}" class="${selectedLeaderboardMode===id?'active':''}">${label}</button>`).join('')}</div>
      <div class="leaderboard-head"><span>Rank</span><span>Trading house</span><span>${selectedLeaderboardMode==='overall'?'Rating':selectedLeaderboardMode==='pnl'?'Realized P&L':selectedLeaderboardMode==='operations'?'Ops score':'Risk score'}</span></div>
      <div class="leaderboard-rows">${rows.slice(0,10).map(row=>`<div class="leaderboard-row ${row.isPlayer?'player':''}"><span class="leaderboard-position ${row.position<=3?'podium':''}">${row.position<=3?['Ⅰ','Ⅱ','Ⅲ'][row.position-1]:`#${row.position}`}</span><div><strong>${esc(row.name)}</strong><small>${row.isPlayer?esc(row.trader):`${esc(row.city)} · ${esc(row.country)}`}</small></div><b>${formatLeaderboardMetric(row,selectedLeaderboardMode)}</b></div>`).join('')}${player.position>10?`<div class="leaderboard-divider">Your position</div><div class="leaderboard-row player"><span class="leaderboard-position">#${player.position}</span><div><strong>${esc(player.name)}</strong><small>${esc(player.trader)}</small></div><b>${formatLeaderboardMetric(player,selectedLeaderboardMode)}</b></div>`:''}</div>
      <div class="leaderboard-disclosure">World of Trade Career League uses transparent simulated rivals in this offline prototype. Your score is based only on your real World of Trade career results.</div>
      <button class="button secondary leaderboard-share" id="copyLeaderboardResult">Copy ranking result</button>`;
    history.innerHTML=(state.leaderboardSnapshots||[]).length ? state.leaderboardSnapshots.map(item=>`<div class="season-card"><div><span>Season ${item.season}</span><strong>#${item.position} · ${item.league}</strong></div><div><span>Rating</span><strong>${item.score.toLocaleString('en-US')}</strong></div><div><span>P&L</span><strong>${money(item.pnl,true)}</strong></div></div>`).join('') : '<div class="empty-card">The first season will be archived after 90 game days.</div>';
    $$('[data-leaderboard-mode]',table).forEach(button=>button.addEventListener('click',()=>{selectedLeaderboardMode=button.dataset.leaderboardMode;renderLeaderboard();}));
    $('#saveLeaderboardProfile')?.addEventListener('click',()=>{
      const trader=cleanUserName($('#leaderboardTraderName')?.value, '');
      const company=cleanUserName($('#leaderboardCompanyName')?.value, '');
      if (trader) state.profileName=trader;
      if (company) state.companyName=company;
      saveState();renderAll();showToast('Career League identity updated.');
    });
    $('#copyLeaderboardResult')?.addEventListener('click',async()=>{
      const text=`World of Trade Career League · ${state.companyName} · #${player.position}/${rows.length} · ${league.name} · rating ${leaderboardScore()} · P&L ${money(state.realizedPnl||0)}`;
      try { await navigator.clipboard.writeText(text); showToast('Ranking result copied.'); }
      catch { showToast(text); }
    });
  }

  function performanceAttribution() {
    const labels = {
      commercial:'Commercial margin', operations:'Operations & claims', financing:'Financing', market:'Market & basis',
      fx:'FX', storage:'Storage optionality', credit:'Credit', demurrage:'Demurrage'
    };
    const totals = Object.fromEntries(Object.keys(labels).map(key => [key, 0]));
    (state.history || []).forEach(deal => {
      const breakdown = deal.pnlBreakdown || {};
      Object.keys(totals).forEach(key => { totals[key] += Number(breakdown[key] || 0); });
    });
    return Object.entries(totals).map(([key,value]) => ({ key, label:labels[key], value })).sort((a,b)=>Math.abs(b.value)-Math.abs(a.value));
  }

  function outstandingReceivablesValue() {
    return state.activeDeals.reduce((sum, deal) => {
      if (!deal.delivered || deal.invoiceStatus === 'Paid') return sum;
      return sum + Number(deal.invoiceAmount || deal.capital || 0);
    }, 0);
  }

  function performanceScore() {
    const risk = riskStats();
    const closed = state.history || [];
    const profitable = closed.length ? closed.filter(item => (item.pnl || 0) > 0).length / closed.length : .5;
    const avgReadiness = closed.length ? closed.reduce((sum,item)=>sum+(item.operationalReadiness||75),0)/closed.length : 75;
    const cashConversion = Math.min(100, 55 + (state.receivablesCollected||0)/100_000*4 - (state.overdueReceivables||0)*6);
    const compliance = Math.max(0, 100 - (state.complianceIncidents||[]).length*12);
    const profitability = clamp(45 + profitable*35 + Math.min(20, Math.max(-20,(state.realizedPnl||0)/100_000*3)),0,100);
    const resilience = clamp(100-risk.riskScore,0,100);
    const score = Math.round(profitability*.28 + resilience*.27 + avgReadiness*.20 + cashConversion*.15 + compliance*.10);
    return { score, profitability, resilience, execution:avgReadiness, cashConversion, compliance };
  }

  function calculateStressScenario(id) {
    const scenario = stressScenarioCatalog[id];
    if (!scenario) return null;
    const risk = riskStats();
    const stats = portfolioStats();
    const receivables = outstandingReceivablesValue();
    const oceanCapital = state.activeDeals.reduce((sum,deal)=>{
      const opp=getOpportunity(deal.opportunityId);
      return sum + (transportClassForOpportunity(opp)==='ocean' ? (deal.capital||0) : 0);
    },0);
    let components = [];
    let loss = 0;
    let collateralCall = 0;
    let creditCapacityReduction = 0;
    if (id === 'commodity') {
      const flatLoss = risk.netFlatExposure * .12;
      const basisLoss = state.activeDeals.reduce((sum,deal)=>sum + physicalNotional(getOpportunity(deal.opportunityId),deal.quantity,deal.capital)*.012,0);
      components=[['Residual flat-price exposure',flatLoss],['Basis widening',basisLoss]];
      loss=flatLoss+basisLoss;
      collateralCall=risk.marginRequirement*.24;
    } else if (id === 'freight') {
      const freightLoss=oceanCapital*.018;
      const delayFunding=state.activeDeals.reduce((sum,d)=>sum+(d.borrowed||0)*.075*14/360,0);
      components=[['Freight repricing',freightLoss],['Extended financing',delayFunding]];
      loss=freightLoss+delayFunding;
    } else if (id === 'fx') {
      const fxLoss=risk.netFxExposure*.10;
      const settlementMismatch=receivables*.015;
      components=[['Unhedged FX exposure',fxLoss],['Receivable mismatch',settlementMismatch]];
      loss=fxLoss+settlementMismatch;
    } else if (id === 'credit') {
      const defaultLoss=receivables*.20;
      const concentrationLoss=Math.max(0,risk.concentration-.30)*stats.creditUsed*.08;
      components=[['Unsecured receivable loss',defaultLoss],['Concentration penalty',concentrationLoss]];
      loss=defaultLoss+concentrationLoss;
      creditCapacityReduction=effectiveCreditLimit()*.15;
    } else if (id === 'liquidity') {
      collateralCall=risk.marginRequirement*.45 + risk.netFlatExposure*.035;
      const fundingSpread=stats.creditUsed*.025;
      const receivableDelay=receivables*.06;
      components=[['Variation margin call',collateralCall],['Funding spread shock',fundingSpread],['Delayed collections',receivableDelay]];
      loss=fundingSpread+receivableDelay;
      creditCapacityReduction=effectiveCreditLimit()*.25;
    }
    const cashImpact = loss + collateralCall;
    const postStressCash = state.cash - cashImpact;
    const postStressNav = stats.nav - loss;
    const postStressCreditAvailable = stats.creditAvailable - creditCapacityReduction;
    const reserve = minimumCashReserve();
    return {
      id, label:scenario.label, date:state.date, dayIndex:state.dayIndex, loss:Math.round(loss), collateralCall:Math.round(collateralCall),
      cashImpact:Math.round(cashImpact), postStressCash:Math.round(postStressCash), postStressNav:Math.round(postStressNav),
      postStressCreditAvailable:Math.round(postStressCreditAvailable), reserve,
      liquidityBreach:postStressCash<reserve, creditBreach:postStressCreditAvailable<0,
      components:components.map(([label,value])=>({label,value:Math.round(value)}))
    };
  }

  function runStressTest(id) {
    const result = calculateStressScenario(id);
    if (!result) return;
    state.lastStressTest = result;
    state.stressTestsRun = (state.stressTestsRun || 0) + 1;
    state.stressTestHistory = [result, ...(state.stressTestHistory || [])].slice(0,12);
    recordJournal('Risk', `${result.label} stress test`, `Projected loss ${money(result.loss)} · post-stress cash ${money(result.postStressCash)}${result.liquidityBreach?' · liquidity breach':''}`, 0, id);
    evaluateMissions();
    evaluateAchievements();
    saveState(); renderAll();
    showToast(`${result.label}: projected cash impact ${money(result.cashImpact)}.`);
  }

  function renderPerformance() {
    const summary=$('#performanceSummary'), attribution=$('#pnlAttribution'), policies=$('#capitalPolicyList'), scenarios=$('#stressScenarioList'), resultBox=$('#stressResult');
    if (!summary || !attribution || !policies || !scenarios || !resultBox) return;
    const stats=portfolioStats(); const risk=riskStats(); const score=performanceScore(); const reserve=minimumCashReserve(); const policy=activeCapitalPolicy();
    const closed=state.history||[]; const winRate=closed.length ? closed.filter(item=>(item.pnl||0)>0).length/closed.length*100 : 0;
    summary.innerHTML=`
      <div class="performance-score-card"><span>Board performance score</span><strong>${score.score}</strong><small>${score.score>=80?'Institutional quality':score.score>=65?'Scalable platform':score.score>=50?'Developing desk':'Board intervention required'}</small></div>
      <div><span>Realized P&amp;L</span><strong class="${(state.realizedPnl||0)>=0?'positive':'negative'}">${money(state.realizedPnl||0,true)}</strong><small>${closed.length} closed cargoes</small></div>
      <div><span>Win rate</span><strong>${winRate.toFixed(0)}%</strong><small>Profitable settlements</small></div>
      <div><span>Liquidity reserve</span><strong>${money(reserve,true)}</strong><small>${Math.round(policy.reserveRatio*100)}% of NAV policy</small></div>
      <div><span>Reserve headroom</span><strong class="${capitalPolicyHeadroom()>=0?'positive':'negative'}">${money(capitalPolicyHeadroom(),true)}</strong><small>Cash above board minimum</small></div>
      <div><span>Desk risk</span><strong>${Math.round(risk.riskScore)}/100</strong><small>${risk.riskScore<35?'Controlled':risk.riskScore<65?'Elevated':'High'}</small></div>`;
    const items=performanceAttribution(); const max=Math.max(1,...items.map(item=>Math.abs(item.value)));
    attribution.innerHTML=items.map(item=>`<div class="attribution-row"><div><span>${item.label}</span><strong class="${item.value>=0?'positive':'negative'}">${money(item.value,true)}</strong></div><div class="attribution-track"><i class="${item.value>=0?'positive':'negative'}" style="width:${Math.max(2,Math.abs(item.value)/max*100)}%"></i></div></div>`).join('') || emptyState('P&amp;L attribution will appear after the first settlement.', { label: 'Browse the opportunity market', type: 'module', id: 'opportunities' });
    policies.innerHTML=Object.values(capitalPolicyCatalog).map(item=>`<button class="capital-policy-card ${item.id===state.capitalPolicy?'active':''}" data-capital-policy="${item.id}" ${item.id!==state.capitalPolicy&&!canChangeCapitalPolicy()?'disabled':''}><div><i>${item.icon}</i><span><strong>${item.label}</strong><small>${item.description}</small></span></div><div class="policy-metrics"><em>${Math.round(item.reserveRatio*100)}% reserve</em><em>${item.pnlFactor>1?'+':''}${Math.round((item.pnlFactor-1)*100)}% deal margin</em><em>${item.riskAdjustment>0?'+':''}${item.riskAdjustment} risk</em></div><b>${item.id===state.capitalPolicy?'Active':canChangeCapitalPolicy()?'Adopt':'Board locked'}</b></button>`).join('');
    scenarios.innerHTML=Object.values(stressScenarioCatalog).map(item=>{const preview=calculateStressScenario(item.id); return `<button class="stress-scenario-card" data-stress-scenario="${item.id}"><i>${item.icon}</i><span><strong>${item.label}</strong><small>${item.subtitle}</small><em>${item.description}</em></span><b>${money(preview?.cashImpact||0,true)} impact</b></button>`;}).join('');
    const result=state.lastStressTest;
    resultBox.innerHTML=result?`<div class="stress-result-head"><div><span>Latest stress test</span><strong>${result.label}</strong></div><b class="${result.liquidityBreach||result.creditBreach?'negative':'positive'}">${result.liquidityBreach||result.creditBreach?'Limit breach':'Within limits'}</b></div><div class="stress-result-grid"><div><span>Projected loss</span><strong class="negative">${money(result.loss,true)}</strong></div><div><span>Cash impact</span><strong class="negative">${money(result.cashImpact,true)}</strong></div><div><span>Post-stress cash</span><strong>${money(result.postStressCash,true)}</strong></div><div><span>Post-stress NAV</span><strong>${money(result.postStressNav,true)}</strong></div></div><div class="stress-components">${(result.components||[]).map(item=>`<div><span>${item.label}</span><strong>${money(item.value)}</strong></div>`).join('')}</div>`:'<div class="empty-card">Select a scenario to produce a board-level loss and liquidity estimate.</div>';
    $$('[data-capital-policy]',policies).forEach(button=>button.addEventListener('click',()=>changeCapitalPolicy(button.dataset.capitalPolicy)));
    $$('[data-stress-scenario]',scenarios).forEach(button=>button.addEventListener('click',()=>runStressTest(button.dataset.stressScenario)));
  }

  // v45 — prima ogni renderAll() ricostruiva l'innerHTML di TUTTE e 22 le sezioni
  // del pannello, anche quelle nascoste, a ogni giorno di gioco (fino a 2,3 volte
  // al secondo a velocita' 5x). Ora si disegna solo la sezione visibile; le altre
  // vengono marcate come da aggiornare e ridisegnate quando si apre la scheda.
  const leftSectionRenderers = {
    portfolio:      () => { renderActiveDeals(); renderHistory(); },
    inventory:      () => renderInventory(),
    operations:     () => renderOperations(),
    supply:         () => renderSupplyChain(),
    contracts:      () => renderContracts(),
    fleet:          () => renderFleet(),
    risk:           () => renderRiskDashboard(),
    opportunities:  () => renderOpportunityList(),
    rivals:         () => renderRivals(),
    strategy:       () => renderStrategy(),
    expansion:      () => renderExpansion(),
    counterparties: () => renderCounterparties(),
    compliance:     () => renderCompliance(),
    events:         () => renderWorldEvents(),
    finance:        () => renderFinance(),
    performance:    () => renderPerformance(),
    academy:        () => renderAcademy(),
    empire:         () => renderEmpire(),
    shop:           () => renderShop(),
    hq:             () => renderHQ(),
    career:         () => renderCareer(),
    leaderboard:    () => renderLeaderboard(),
  };
  let _renderedLeftTab = null;

  function renderSection(tab, options = {}) {
    const renderer = leftSectionRenderers[tab];
    if (!renderer) return;
    try { renderer(); }
    catch (error) { console.error(`[WoT] render della sezione "${tab}" non riuscito`, error); }
    // v46 - le card entrano in sequenza, ma solo quando si apre la scheda:
    // rianimarle a ogni giorno di gioco sarebbe fastidioso.
    if (options.animate) staggerSection(tab);
  }

  // Assegna --i ai figli delle liste cosi' il CSS puo' scaglionarne l'entrata.
  const STAGGER_CONTAINERS = '.deal-list, .history-list, .inventory-list, .operations-list, .opportunity-list, .fleet-list, .counterparty-list, .world-event-list, .finance-list, .investment-list, .shop-catalog-list, .management-list, .mission-list, .academy-list, .contract-list, .receivable-list, .route-condition-list, .procurement-agreement-list, .supply-cargo-list, .rival-opportunity-list, .doctrine-list, .desk-specialisation-list, .commercial-framework-list, .compliance-queue, .trade-journal-list, .glossary-list, .achievement-grid, .leaderboard-rows, .stress-scenario-list, .capital-policy-list';
  function staggerSection(tab) {
    if (!motionEnabled()) return;
    const section = document.getElementById(`left-${tab}`);
    if (!section) return;
    section.querySelectorAll(STAGGER_CONTAINERS).forEach(container => {
      const children = [...container.children].slice(0, 14);
      if (children.length < 2) return;
      container.classList.add('stagger-in');
      children.forEach((child, index) => child.style.setProperty('--i', index));
      // rimuove la classe a fine animazione: cosi' i render successivi non rianimano
      clearTimeout(container._staggerTimer);
      container._staggerTimer = setTimeout(() => container.classList.remove('stagger-in'), 900);
    });
  }

  function renderAllLists(force = false) {
    // I contatori sulla barra comandi devono restare aggiornati anche a scheda chiusa
    renderShopRailBadge();
    if (force) { Object.keys(leftSectionRenderers).forEach(renderSection); _renderedLeftTab = activeLeftTab; return; }
    renderSection(activeLeftTab);
    _renderedLeftTab = activeLeftTab;
  }

  function renderShopRailBadge() {
    const orders = state.shopOrders || [];
    const queueCount = $('#shopQueueCount'); if (queueCount) queueCount.textContent = orders.length;
    const badge = $('#shopBadge'); if (badge) { badge.textContent = orders.length; badge.classList.toggle('hidden', !orders.length); }
  }

  function hubInspector(hub) {
    const related = opportunities.filter(o => isOpportunityUnlocked(o) && opportunityAvailable(o) && [o.origin,o.destination,...(o.via||[])].includes(hub.id));
    return `
      <div class="location-badge">${hub.type === 'hq' ? '● Headquarters' : hub.type}</div>
      <h2>${hub.name}</h2>
      <div class="inspector-subtitle">${hub.country} · ${hub.subtitle}</div>
      <p class="inspector-subtitle" style="margin-top:12px">${hub.description}</p>
      <div class="inspector-grid">
        <div class="inspector-stat"><span>Risk level</span><strong>${hub.risk}</strong></div>
        <div class="inspector-stat"><span>Available routes</span><strong>${related.length}</strong></div>
        <div class="inspector-stat"><span>WoT presence</span><strong>${officeOwned(hub.id) ? 'Regional office active' : activeOfficeProject(hub.id) ? `Opening in ${activeOfficeProject(hub.id).daysRemaining}d` : hub.id === 'geneva' ? 'Headquarters' : 'No office'}</strong></div>
        <div class="inspector-stat"><span>Commodity access</span><strong>${hub.commodities.length}</strong></div>
      </div>
      <div class="inspector-section"><h3>Local market</h3>
        <div class="tag-row">${hub.commodities.map(c => `<span class="tag">${c}</span>`).join('')}</div>
        ${(()=>{
          const basis = state.hubBasis?.[hub.id];
          if (!basis || !Object.keys(basis).length) return '';
          const rows = Object.entries(basis).map(([key,val]) => {
            const sign = val >= 0 ? '+' : '';
            const fmt = Math.abs(val) < 5 ? val.toFixed(2) : Math.round(val);
            const col = val > 2 ? 'var(--green)' : val < -2 ? 'var(--red)' : 'var(--muted)';
            const unit = key === 'crude' ? '/bbl' : '/t';
            return `<div class="basis-row"><span>${key.charAt(0).toUpperCase()+key.slice(1)} local basis</span><strong style="color:${col}">${sign}${fmt}${unit}</strong></div>`;
          }).join('');
          return `<div class="basis-grid">${rows}</div>`;
        })()}
      </div>
      ${related.length ? `<div class="inspector-section"><h3>Related opportunities</h3>${related.map(o => `<button class="event-choice" data-open-opportunity="${o.id}"><strong>${o.title}</strong><small>${getHub(o.origin).name} → ${getHub(o.destination).name} · ${money(opportunityEconomics(o).basePnl)} expected</small></button>`).join('')}</div>` : ''}
      ${!countryUnlocked(hub.country) ? `<div class="warning-box"><strong>${hub.country} locked</strong><br>Reach company level ${countryRequiredLevel(hub.country)} to access this market. Commodity-rich and capital-intensive origins unlock later.</div>` : hub.locked && related.length === 0 ? '<div class="warning-box">Hub accessible by level, but a regional office, stronger balance sheet or higher reputation is still required.</div>' : ''}
    `;
  }

  function opportunityInspector(opp) {
    const stats = portfolioStats();
    const origin = getHub(opp.origin);
    const destination = getHub(opp.destination);
    const negotiation = negotiationFor(opp.id);
    const economics = opportunityEconomics(opp, negotiation);
    const requiredEquity = economics.equity;
    const borrowed = economics.borrowed;
    const totalCashRequirement = requiredEquity + economics.initialMargin;
    const cashCoverage = totalCashRequirement ? state.cash / totalCashRequirement : 10;
    const creditCoverage = borrowed ? stats.creditAvailable / borrowed : 10;
    const canStart = canStartOpportunity(opp);
    const buyerId = partiesForOpportunity(opp).buyerId;
    const buyerLimit = buyerId ? counterpartyCreditLimit(buyerId) : 0;
    const buyerExposure = buyerId ? counterpartyExposure(buyerId) : 0;
    const requiredBuyerLimit = buyerId ? prospectiveCreditExposure(opp, economics) : 0;
    const buyerLimitClear = !buyerId || buyerLimit - buyerExposure >= requiredBuyerLimit;
    const selectedHedge = Number(selectedHedgeRatios[opp.id] ?? opp.recommendedHedge ?? 100);
    const dealNotional = physicalNotional(opp, economics.quantity, economics.capital);
    const residualExposure = dealNotional * Math.max(0, 1 - selectedHedge / 100);
    const compatibleFleet = availableFleetForOpportunity(opp);
    const carrierStrategy = selectedCarrierStrategies[opp.id] || 'spot';
    const selectedFleet = carrierStrategy.startsWith('fleet:') ? getFleetAsset(carrierStrategy.slice(6)) : null;
    const selectedVessel = selectedFleet ? getVesselCatalog(selectedFleet.catalogId) : null;
    const adjustedPnl = economics.expectedPnl + (selectedVessel?.bonusPnl || 0) + (selectedFleet && hasStaff('freight-charterer') ? 5_000 : 0);
    const adjustedDuration = Math.max(10, economics.duration - (selectedVessel?.durationBonus || 0));
    const parties = partiesForOpportunity(opp);
    const supplier = getCounterparty(parties.supplierId);
    const buyer = getCounterparty(parties.buyerId);
    const supplierState = getCounterpartyState(parties.supplierId);
    const buyerState = getCounterpartyState(parties.buyerId);
    const accepted = negotiation.status === 'accepted';
    const rejected = negotiation.status === 'rejected';
    const consumed = negotiation.status === 'consumed';
    const structure = economics.structure;
    const fundsReady = state.cash >= totalCashRequirement && stats.creditAvailable >= borrowed && financingAvailable(structure.financingId);
    const compliance = complianceProfileForOpportunity(opp);
    return `
      <div class="location-badge">◎ Live market offer · ${economics.expiresIn}d</div>
      <h2>${opp.title}</h2>
      <div class="inspector-subtitle">${origin.name} → ${destination.name}${opp.via?.length ? ` via ${opp.via.map(id=>getHub(id).name).join(', ')}` : ''}</div>
      <p class="inspector-subtitle" style="margin-top:12px">${opp.description}</p>
      ${unlockChecklistHtml(opp)}
      ${economics.crisisLabels.length ? `<div class="global-impact-box"><strong>Global disruption impact</strong><span>${economics.crisisLabels.join(' · ')}</span></div>` : ''}
      ${economics.verticalSources?.length ? `<div class="vertical-impact-box"><strong>Vertical integration advantage</strong><span>${economics.verticalSources.join(' · ')}</span></div>` : ''}
      <div class="supply-impact-box ${economics.routeCondition.severity.toLowerCase()}"><div><span>Supply-chain capacity</span><strong>${economics.routeCondition.severity} · ${economics.routeCondition.score}/100</strong></div><small>${economics.routeCondition.bottleneck} · +${economics.routeCondition.delayDays} days · ${money(economics.routeCondition.freightCost)} capacity cost${economics.procurementAgreement ? ` · strategic agreement active with ${getCounterparty(economics.procurementAgreement.supplierId)?.name || 'supplier'}` : ''}</small></div>
      <div class="competitive-impact-box"><div><span>Competitive tender</span><strong>${economics.tenderLeader?.name || 'Rival desk'} · ${economics.tenderPressure}% pressure</strong></div><small>${economics.marketRegime.label} · estimated margin compression ${money(economics.competitionCost)}</small></div>
      <div class="inspector-grid">
        <div class="inspector-stat"><span>Expected P&amp;L</span><strong style="color:var(--green)">${money(adjustedPnl)}</strong></div>
        <div class="inspector-stat"><span>Duration</span><strong>${adjustedDuration} days</strong></div>
        <div class="inspector-stat"><span>Total capital</span><strong>${money(economics.capital, true)}</strong></div>
        <div class="inspector-stat"><span>Offer quantity</span><strong>${economics.quantity} t</strong></div>
      </div>
      <div class="compliance-impact-box ${compliance.status === 'Blocked' ? 'blocked' : compliance.canTrade ? 'clear' : 'review'}">
        <div><span>Compliance clearance</span><strong>${compliance.status} · score ${compliance.score}/100</strong></div>
        <small>${compliance.flags.length ? compliance.flags.join(' · ') : 'Standard KYC, jurisdiction and route screening completed.'}</small>
        ${compliance.requiresReview && !compliance.reviewed && compliance.status !== 'Blocked' ? `<button class="button secondary compact" id="runComplianceReviewButton">Run enhanced due diligence · ${money(compliance.cost)}</button>` : ''}
      </div>
      ${buyerId ? `<div class="inspector-section"><h3>Buyer credit capacity</h3><div class="timeline-mini-row"><i></i><span>Approved limit</span><strong>${money(buyerLimit,true)}</strong></div><div class="timeline-mini-row"><i></i><span>Current exposure</span><strong>${money(buyerExposure,true)}</strong></div><div class="timeline-mini-row"><i></i><span>Required for this structure</span><strong style="color:${buyerLimitClear?'var(--green)':'var(--red)'}">${money(requiredBuyerLimit,true)}</strong></div>${buyerLimitClear?'<div class="success-box">Buyer credit capacity is available.</div>':`<div class="warning-box">Credit limit is insufficient for the selected payment terms.</div><button class="button secondary" id="requestBuyerLimitButton">Request credit limit increase</button>`}</div>` : ''}
      <div class="inspector-section"><h3>Commercial counterparties</h3>
        <div class="party-pair">
          <div class="party-mini"><span>Supplier · ${supplier?.country || ''}</span><strong>${supplier?.name || 'Supplier'}</strong><small>Credit ${supplier?.credit || 0} · relationship ${supplierState.relationship}</small></div>
          <div class="party-mini"><span>Buyer · ${buyer?.country || ''}</span><strong>${buyer?.name || 'Buyer'}</strong><small>Credit ${buyer?.credit || 0} · relationship ${buyerState.relationship}</small></div>
        </div>
      </div>
      <div class="negotiation-box">
        <div class="negotiation-heading"><div><span class="eyebrow">Contract negotiation</span><h3>Build your offer</h3></div><strong>${Math.round(economics.acceptance)}%</strong></div>
        <div class="acceptance-meter"><span style="width:${economics.acceptance}%"></span></div>
        <label>Commercial quote<select id="commercialTermSelect">
          ${Object.entries(negotiationProfiles.commercial).map(([id,item])=>`<option value="${id}" ${negotiation.commercial===id?'selected':''}>${item.label}</option>`).join('')}
        </select></label>
        <label>Payment terms<select id="paymentTermSelect">
          ${Object.entries(negotiationProfiles.payment).map(([id,item])=>`<option value="${id}" ${negotiation.payment===id?'selected':''}>${item.label}</option>`).join('')}
        </select></label>
        <label>Pricing formula<select id="pricingTermSelect">
          ${Object.entries(negotiationProfiles.pricing).map(([id,item])=>`<option value="${id}" ${(negotiation.pricing||'fixed')===id?'selected':''}>${item.label}</option>`).join('')}
        </select></label>
        <label>Delivery window<select id="deliveryTermSelect">
          ${Object.entries(negotiationProfiles.delivery).map(([id,item])=>`<option value="${id}" ${negotiation.delivery===id?'selected':''}>${item.label}</option>`).join('')}
        </select></label>
        <label>Incoterm<select id="incotermSelect">
          ${Object.entries(negotiationProfiles.incoterm).map(([id,item])=>`<option value="${id}" ${(negotiation.incoterm||'fob')===id?'selected':''}>${item.label}</option>`).join('')}
        </select></label>
        <div class="incoterm-note">${negotiationProfiles.incoterm[negotiation.incoterm||'fob']?.description || ''}</div>
        <div class="negotiation-result ${accepted?'accepted':rejected?'rejected':''}">
          ${accepted ? 'Offer accepted: terms are locked until the market refresh.' : rejected ? 'Offer rejected: change at least one term and submit it again.' : 'The probability combines price, payment terms, reputation, buyer relationship and live rival pressure.'}
        </div>
        <button class="button secondary" id="submitNegotiationButton" ${consumed ? 'disabled' : ''}>${accepted ? 'Renegotiate terms' : rejected ? 'Submit a new offer' : 'Submit offer to buyer'}</button>
      </div>
      <div class="inspector-section"><h3>Capital structure</h3>
        <div class="timeline-mini-row"><i></i><span>Required equity</span><strong>${money(requiredEquity)}</strong></div>
        <div class="capital-bar"><span style="width:${clamp(cashCoverage*100,0,100)}%"></span></div>
        <div class="timeline-mini-row" style="margin-top:12px"><i></i><span>Credit facility</span><strong>${money(borrowed)}</strong></div>
        <div class="capital-bar"><span style="width:${clamp(creditCoverage*100,0,100)}%"></span></div>
        <div class="timeline-mini-row" style="margin-top:12px"><i></i><span>Initial futures margin</span><strong>${money(economics.initialMargin)}</strong></div>
        <div class="capital-bar margin"><span style="width:${clamp(state.cash/Math.max(1,economics.initialMargin)*100,0,100)}%"></span></div>
      </div>
      <div class="deal-structure-box">
        <span class="eyebrow">Deal structuring</span><h3>Funding, insurance and controls</h3>
        <label>Trade finance<select id="financingStrategySelect">
          ${Object.entries(financingProfiles).map(([id,item])=>`<option value="${id}" ${structure.financingId===id?'selected':''} ${financingAvailable(id)?'':'disabled'}>${item.label}${financingAvailable(id)?'':' · requires Trade Finance Manager'}</option>`).join('')}
        </select><small>${structure.financing.description}</small></label>
        <label>Cargo insurance<select id="insuranceStrategySelect">
          ${Object.entries(insuranceProfiles).map(([id,item])=>`<option value="${id}" ${structure.insuranceId===id?'selected':''}>${item.label}</option>`).join('')}
        </select><small>${structure.insurance.description}</small></label>
        <label>Quality control<select id="inspectionStrategySelect">
          ${Object.entries(inspectionProfiles).map(([id,item])=>`<option value="${id}" ${structure.inspectionId===id?'selected':''}>${item.label}</option>`).join('')}
        </select><small>${structure.inspection.description}</small></label>
        <div class="hedge-control compact">
          <label for="fxHedgeRatioInput"><span>FX hedge ratio</span><strong id="fxHedgeRatioValue">${structure.fxHedgeRatio}%</strong></label>
          <input id="fxHedgeRatioInput" type="range" min="0" max="100" step="10" value="${structure.fxHedgeRatio}">
          <div class="hedge-scale"><span>Open FX</span><span>${money(dealNotional*fxExposureShare(opp),true)} gross exposure</span><span>Fully hedged</span></div>
        </div>
      </div>
      ${transportClassForOpportunity(opp) !== 'land' ? `<div class="shipping-control">
        <label for="carrierStrategySelect"><span>Shipping strategy</span><strong>${selectedVessel ? selectedVessel.name : 'Spot carrier'}</strong></label>
        <select id="carrierStrategySelect">
          <option value="spot" ${carrierStrategy === 'spot' ? 'selected' : ''}>Spot / voyage booking</option>
          ${compatibleFleet.map(asset => { const vessel = getVesselCatalog(asset.catalogId); return `<option value="fleet:${asset.id}" ${carrierStrategy === `fleet:${asset.id}` ? 'selected' : ''}>Internal fleet · ${vessel.name}</option>`; }).join('')}
        </select>
        <div class="shipping-benefit">${selectedVessel ? `Freight advantage +${money(selectedVessel.bonusPnl)} · ETA -${selectedVessel.durationBonus} days` : `Freight index ${state.freightIndex.toFixed(1)} · third-party carrier`}</div>
        ${carrierStrategy === 'spot' ? (() => {
          const avClasses = availableVesselClasses(opp);
          const curClass  = vesselClassFor(opp.id);
          return `<label for="vesselClassSelect" style="margin-top:6px"><span>Vessel class</span><strong>${curClass.label}</strong></label>
          <select id="vesselClassSelect">
            ${avClasses.map(vc => `<option value="${vc.id}" ${vc.id === curClass.id ? 'selected' : ''}>${vc.label}</option>`).join('')}
          </select>
          <div class="shipping-benefit">${curClass.desc}${curClass.pnlMod !== 0 ? ' · Freight P&amp;L: ' + (curClass.pnlMod > 0 ? '+' : '') + Math.round(curClass.pnlMod * 100) + '%' : ''}${curClass.durationMod !== 0 ? ' · Transit: ' + (curClass.durationMod > 0 ? '+' : '') + curClass.durationMod + 'd' : ''}</div>`;
        })() : ''}
        ${compatibleFleet.length ? '' : '<small>No compatible vessel at the origin port. Open the Fleet Desk to charter one.</small>'}
      </div>` : ''}
      <div class="hedge-control">
        <label for="hedgeRatioInput"><span>Futures hedge ratio</span><strong id="hedgeRatioValue">${selectedHedge}%</strong></label>
        <input id="hedgeRatioInput" type="range" min="0" max="100" step="10" value="${selectedHedge}">
        <div class="hedge-scale"><span>0% speculative</span><span>${opp.recommendedHedge}% recommended</span><span>100% protected</span></div>
        <div class="timeline-mini-row" style="margin-top:12px;margin-bottom:0"><i></i><span>Margin posted at this hedge</span><strong id="marginPostedValue">${money(economics.initialMargin, true)}</strong></div>
        <div class="timeline-mini-row" style="margin-bottom:0"><i></i><span>Residual flat-price exposure</span><strong id="residualExposureValue">${money(residualExposure, true)}</strong></div>
        ${(() => {
          // v49 - il margine iniziale scala con la copertura: se il cargo non e'
          // finanziabile al livello scelto, si offre il livello sostenibile.
          const affordable = affordableHedgeRatio(opp);
          if (affordable === null || affordable >= selectedHedge) return '';
          return `<button type="button" class="hedge-fit-button" id="fitHedgeButton">Fit to liquidity \u00b7 ${affordable}% hedge</button>`;
        })()}
      </div>
      ${accepted && fundsReady
        ? '<div class="success-box">Contract accepted and funding available. You can open the deal.</div>'
        : accepted
          ? `<div class="warning-box"><strong>Cannot open yet</strong><ul class="blocker-list">${startBlockers(opp).filter(item => item.code !== 'terms').map(item => `<li>${item.message}</li>`).join('') || '<li>Structure or facility capacity is insufficient.</li>'}</ul></div>`
          : '<div class="warning-box">The deal cannot start until the buyer accepts the terms.</div>'}
      ${opp.tender ? `
      <div class="inspector-section tender-section">
        <h3>Competitive tender</h3>
        <p style="font-size:8px;color:var(--muted);margin:6px 0 10px">This opportunity is awarded via competitive bidding. Lower your margin offer to improve win probability, but protect your economics.</p>
        <div class="tender-bid-row">
          <span>Margin concession</span>
          <input id="tenderBidInput" type="range" min="${Math.round(-opp.basePnl*0.7)}" max="0" step="${Math.round(opp.basePnl*0.05)}" value="0">
          <strong id="tenderBidVal">$0</strong>
        </div>
        <div class="tender-preview">
          <div><span>Your offered margin</span><strong id="tenderMarginPreview">${money(opp.basePnl)}</strong></div>
          <div><span>Win probability</span><strong id="tenderWinPct">~${Math.round(Math.min(95, Math.max(5, 30 - Math.max(0, ((rivalTenderFor(opp.id)?.pressure) || 0) - 35) * 0.5)))}%</strong></div>
        </div>
        <button class="button primary" id="submitTenderBtn" ${canStart ? '' : 'disabled'}>Submit competitive bid</button>
      </div>` : `<button class="button primary" id="startDealButton" ${canStart ? '' : 'disabled'}>Open the physical deal</button>`}
      <button class="button secondary" id="focusOriginButton">Go to supplier</button>
    `;
  }

  function dealInspector(deal) {
    deal = updateDealOperations(deal);
    const opp = getOpportunity(deal.opportunityId);
    const progress = computeDealProgress(deal);
    const pnl = computeUnrealizedPnl(deal);
    const phase = dealPhase(deal);
    const marketImpact = computeMarketImpact(deal);
    const grossNotional = physicalNotional(opp, deal.quantity || opp.quantity, deal.capital);
    const residualExposure = grossNotional * Math.max(0, 1 - (deal.hedgeRatio || 0) / 100);
    const fxImpact = computeFxImpact(deal);
    const marginRequirement = currentMarginRequirement(deal);
    const financeProfile = financingProfiles[deal.financingStrategy || 'revolver'] || financingProfiles.revolver;
    const insuranceProfile = insuranceProfiles[deal.insuranceStrategy || 'basic'] || insuranceProfiles.basic;
    const inspectionProfile = inspectionProfiles[deal.inspectionStrategy || 'standard'] || inspectionProfiles.standard;
    const currentPoint = pointOnRoute(opp, progress);
    const nearestHub = [opp.origin, ...(opp.via||[]), opp.destination].map(getHub).sort((a,b) => Math.hypot(a.lat-currentPoint.lat,a.lon-currentPoint.lon)-Math.hypot(b.lat-currentPoint.lat,b.lon-currentPoint.lon))[0];
    const eventHtml = deal.pendingDecision && opp.event ? `
      <div class="event-box"><span class="eyebrow">Operational event</span><h3>${opp.event.title}</h3><p>${opp.event.text}</p>
      ${opp.event.choices.map(choice => `<button class="event-choice" data-event-choice="${choice.id}"><strong>${choice.label}</strong><small>${choice.hint}</small></button>`).join('')}</div>` : '';
    const paymentThirty = deal.commercialTerms?.payment === 'thirty';
    const receivableLifecycle = deal.delivered ? `<div class="inspector-section"><h3>Invoice &amp; collection</h3><div class="timeline-mini-row"><i></i><span>Invoice status</span><strong>${deal.invoiceStatus || 'Outstanding'}</strong></div><div class="timeline-mini-row"><i></i><span>Invoice amount</span><strong>${money(deal.invoiceAmount || 0,true)}</strong></div><div class="timeline-mini-row"><i></i><span>${deal.invoiceStatus === 'Overdue' ? 'Collection delay' : 'Payment due'}</span><strong>${deal.invoiceStatus === 'Overdue' ? Math.max(0,deal.collectionDelayDays||0) : Math.max(0,deal.paymentDaysRemaining||0)} days</strong></div><div class="timeline-mini-row"><i></i><span>Buyer limit used</span><strong>${deal.buyerId ? Math.round(counterpartyExposure(deal.buyerId)/Math.max(1,counterpartyCreditLimit(deal.buyerId))*100) : 0}%</strong></div></div>` : '';
    const creditTools = paymentThirty ? `<div class="inspector-section"><h3>Receivable risk</h3>${deal.receivableProtection?`<div class="success-box">${deal.receivableProtection.label} active · cost ${money(deal.receivableProtection.cost)}</div>`:`<p class="inspector-subtitle">The buyer pays 30 days after delivery. Protect the receivable or retain the credit exposure.</p><div class="ops-actions"><button class="button secondary" id="creditInsuranceButton">Credit insurance</button><button class="button secondary" id="factorReceivableButton">Factor receivable</button></div>`}</div>` : '';
    const storageTool = deal.commercialTerms?.delivery === 'flexible' && (deal.operations?.storage?.active || deal.storageOptionUsed) ? `<div class="inspector-section"><h3>Warehouse optionality</h3>${deal.storageOptionUsed?`<div class="success-box">20% flexible parcel held in storage. Current optionality value ${money(storageOptionalityPnl(deal))}.</div>`:'<p class="inspector-subtitle">Use the flexible delivery window to hold 20% of the parcel for seven days and capture a favourable price move.</p><button class="button secondary" id="storageOptionButton">Exercise 7-day storage option</button>'}</div>` : '';
    const routeCondition = deal.routeCondition || routeConditionFor(opp);
    const routeTool = `<div class="inspector-section"><h3>Supply-chain condition</h3><div class="timeline-mini-row"><i></i><span>Congestion score</span><strong>${routeCondition.score}/100 · ${routeCondition.severity}</strong></div><div class="timeline-mini-row"><i></i><span>Primary bottleneck</span><strong>${routeCondition.bottleneck}</strong></div><div class="timeline-mini-row"><i></i><span>Capacity impact at booking</span><strong>+${routeCondition.delayDays}d · ${money(routeCondition.freightCost)}</strong></div><div class="timeline-mini-row"><i></i><span>Procurement structure</span><strong>${deal.procurementAgreementId ? 'Strategic framework' : 'Spot supply'}</strong></div>${deal.routeMitigated ? `<div class="success-box">Priority capacity secured · ${deal.routeMitigationDays} days protected · cost ${money(deal.routeMitigationCost)}.</div>` : (!deal.delivered && routeCondition.delayDays > 0 ? '<button class="button secondary" id="mitigateRouteButton">Secure priority capacity</button>' : '')}</div>`;
    return `
      <div class="location-badge">↗ Active shipment</div>
      <h2>${opp.title}</h2>
      <div class="inspector-subtitle">${getHub(opp.origin).name} → ${getHub(opp.destination).name} · ${Math.round(progress*100)}% complete</div>
      <div class="inspector-grid">
        <div class="inspector-stat"><span>Unrealized P&amp;L</span><strong style="color:${pnl>=0?'var(--green)':'var(--red)'}">${money(pnl)}</strong></div>
        <div class="inspector-stat"><span>ETA</span><strong>${Math.max(0,deal.duration-deal.elapsed)} days</strong></div>
        <div class="inspector-stat"><span>Hedge ratio</span><strong>${deal.hedgeRatio || 0}%</strong></div>
        <div class="inspector-stat"><span>Physical phase</span><strong>${phase.label}</strong></div>
      </div>
      ${(()=>{
        const entryPx = deal.entryMarketPrice;
        const currentPx = marketPriceForOpportunity(opp);
        if (!entryPx || !currentPx) return '';
        const movePct = (currentPx - entryPx) / entryPx * 100;
        const moveColor = movePct >= 0 ? 'var(--green)' : 'var(--red)';
        const commodity = opp.commodity || opp.priceKey || '';
        const ts = state.termStructure?.[opp.priceKey || 'copper'] || 0;
        const tsLabel = ts < -0.06 ? 'Backwardation' : ts > 0.06 ? 'Contango' : 'Flat';
        return `<div class="mtm-card">
          <div class="mtm-label">Mark-to-Market · ${commodity.toUpperCase()}</div>
          <div class="mtm-row">
            <div><span>Entry price</span><strong>${entryPx < 200 ? '$'+entryPx.toFixed(2) : money(entryPx, true)}</strong></div>
            <div><span>Current price</span><strong>${currentPx < 200 ? '$'+currentPx.toFixed(2) : money(currentPx, true)}</strong></div>
            <div><span>Move since inception</span><strong style="color:${moveColor}">${movePct>=0?'+':''}${movePct.toFixed(2)}%</strong></div>
            <div><span>Term structure</span><strong style="color:${ts<-0.06?'var(--orange)':ts>0.06?'var(--blue)':'var(--muted)'}">${tsLabel}</strong></div>
          </div>
          <div class="mtm-impact-row"><span>Price impact on P&amp;L</span><strong style="color:${marketImpact>=0?'var(--green)':'var(--red)'}">${money(marketImpact)}</strong></div>
        </div>`;
      })()}
      <div class="inspector-section"><h3>Commercial execution</h3>
        <div class="timeline-mini-row"><i></i><span>Supplier</span><strong>${getCounterparty(deal.supplierId)?.name || 'N/A'}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Buyer</span><strong>${getCounterparty(deal.buyerId)?.name || 'N/A'}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Quantity</span><strong>${deal.quantity || opp.quantity} t</strong></div>
        <div class="timeline-mini-row"><i></i><span>Payment</span><strong>${negotiationProfiles.payment[deal.commercialTerms?.payment]?.label || 'Contract terms'}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Pricing formula</span><strong>${negotiationProfiles.pricing[deal.commercialTerms?.pricing || 'fixed']?.label || 'Fixed price'}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Incoterm</span><strong>${negotiationProfiles.incoterm[deal.commercialTerms?.incoterm || 'fob']?.label || 'FOB · Free On Board'}</strong></div>
        ${(deal.globalEventImpacts||[]).length ? `<div class="global-impact-box"><strong>Global events affecting this cargo</strong><span>${deal.globalEventImpacts.map(id=>globalEventCatalog.find(e=>e.id===id)?.title||id).join(' · ')}</span></div>` : ''}
      </div>
      ${routeTool}
      <div class="inspector-section"><h3>Risk, treasury &amp; hedge liquidity</h3>
        <div class="timeline-mini-row"><i></i><span>Residual flat-price exposure</span><strong>${money(residualExposure, true)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Commodity impact to date</span><strong style="color:${marketImpact>=0?'var(--green)':'var(--red)'}">${money(marketImpact)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>FX impact · hedge ${deal.fxHedgeRatio || 0}%</span><strong style="color:${fxImpact>=0?'var(--green)':'var(--red)'}">${money(fxImpact)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Equity locked</span><strong>${money(deal.equity, true)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Debt funded · ${(deal.financingRate*100).toFixed(1)}%</span><strong>${money(deal.borrowed, true)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Interest accrued</span><strong style="color:var(--orange)">${money(deal.financingAccrued || 0)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Futures collateral</span><strong>${money(deal.marginCollateral || 0)} / ${money(marginRequirement)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Margin calls funded</span><strong>${deal.marginCalls || 0}</strong></div>
        ${deal.hedgeRatio < 100 ? '<button class="button secondary" id="increaseHedgeButton">Increase hedge to 100%</button>' : '<div class="success-box">Flat-price exposure is fully hedged. Continue monitoring variation margin and basis risk.</div>'}
      </div>
      <div class="inspector-section"><h3>Deal protection</h3>
        <div class="contract-card"><div class="contract-card-head"><strong>${financeProfile.label}</strong><span>Funding</span></div><p>${financeProfile.description}</p></div>
        <div class="contract-card"><div class="contract-card-head"><strong>${insuranceProfile.label}</strong><span>Insurance</span></div><p>${insuranceProfile.description}</p></div>
        <div class="contract-card"><div class="contract-card-head"><strong>${inspectionProfile.label}</strong><span>Quality</span></div><p>${inspectionProfile.description}</p></div>
      </div>

      <div class="inspector-section"><h3>Contracts &amp; execution</h3>
        <div class="contract-card"><div class="contract-card-head"><strong>Purchase contract</strong><span>${deal.operations.purchaseContract.status}</span></div><p>${deal.operations.purchaseContract.terms}</p></div>
        <div class="contract-card"><div class="contract-card-head"><strong>Sales contract</strong><span>${deal.operations.salesContract.status}</span></div><p>${deal.operations.salesContract.terms}</p></div>
        <div class="asset-banner"><span>Carrier / vessel</span><strong>${deal.operations.transport.carrier}</strong><small>${deal.operations.transport.mode} · ${deal.operations.transport.booking} · ${deal.operations.transport.status}</small></div>
        <div class="shipping-ledger">
          <div><span>Charter type</span><strong>${deal.operations.transport.charterType}</strong></div>
          <div><span>Laycan</span><strong>${deal.operations.transport.laycan}</strong></div>
          <div><span>Laytime</span><strong>${deal.operations.transport.laytimeUsed}/${deal.operations.transport.laytimeAllowed} days</strong></div>
          <div><span>Demurrage</span><strong style="color:${deal.operations.transport.demurrageAccrued ? 'var(--red)' : 'var(--green)'}">${money(deal.operations.transport.demurrageAccrued)}</strong></div>
        </div>
        <div class="asset-banner"><span>Storage plan</span><strong>${deal.operations.storage.name}</strong><small>${deal.operations.storage.reserved ? 'Reserved' : 'Not reserved'} · ${deal.operations.storage.days} buffer days${deal.operations.storage.active ? ' · currently active' : ''}</small></div>
      </div>
      <div class="inspector-section"><h3>Document readiness · ${Math.round(operationsReadiness(deal))}%</h3>
        <div class="document-list">${deal.operations.documents.map(doc=>`<div class="document-row ${doc.status}"><i></i><span>${doc.name}</span><strong>${doc.status}</strong></div>`).join('')}</div>
        <div class="ops-actions">
          <button class="button secondary" id="expediteDocsButton" ${deal.operations.expedited?'disabled':''}>Expedite docs</button>
          <button class="button secondary" id="upgradeTransportButton" ${deal.operations.transport.upgraded || progress>.7?'disabled':''}>Priority transport</button>
        </div>
        <button class="button secondary" id="emergencyStorageButton" ${deal.operations.storage.emergency?'disabled':''}>Book emergency storage</button>
      </div>
      <div class="inspector-section"><h3>Shipment timeline</h3>
        <div class="timeline-mini">
          <div class="timeline-mini-row done"><i></i><span>Contracts signed</span><strong>Day 0</strong></div>
          <div class="timeline-mini-row ${progress>.18?'done':'current'}"><i></i><span>Cargo loaded</span><strong>${progress>.18?'Done':'Pending'}</strong></div>
          <div class="timeline-mini-row ${progress>.18&&progress<.9?'current':progress>=.9?'done':''}"><i></i><span>In transit · near ${nearestHub.name}</span><strong>${Math.round(progress*100)}%</strong></div>
          <div class="timeline-mini-row ${progress>=1?'done':''}"><i></i><span>Delivery &amp; settlement</span><strong>${progress>=1?'Done':'Pending'}</strong></div>
        </div>
      </div>
      ${receivableLifecycle}${creditTools}
      ${storageTool}
      ${deal.eventResult ? `<div class="inspector-section"><h3>Latest event</h3><p>${deal.eventResult}</p></div>` : ''}
      ${eventHtml}
      ${progress > 0.12 && progress < 0.88 ? `
      <div class="inspector-section"><h3>Hedge management</h3>
        <div class="rehedge-row">
          <span>Current: <strong>${deal.hedgeRatio || 0}%</strong></span>
          <input id="rehedgeInput" type="range" min="0" max="110" step="5" value="${deal.hedgeRatio || 0}" style="flex:1">
          <span id="rehedgeVal">${deal.hedgeRatio || 0}%</span>
        </div>
        <p style="font-size:8px;color:var(--muted);margin:6px 0">Execution cost: $8,000 + $200 per % change. Only available in transit.</p>
        <button class="button secondary" id="rehedgeBtn">Adjust hedge</button>
      </div>` : ''}
      <button class="button secondary" id="focusShipmentButton">Focus shipment</button>
    `;
  }


  function historyInspector(item) {
    const opp = getOpportunity(item.opportunityId);
    const breakdown = item.pnlBreakdown || { commercial: item.pnl, operations: 0, financing: 0, market: 0, fx: 0 };
    const rows = [
      ['Commercial / route margin', breakdown.commercial || 0],
      ['Operations, claims & shipping', breakdown.operations || 0],
      ['Financing cost', breakdown.financing || 0],
      ['Commodity hedge / residual', breakdown.market || 0],
      ['FX result', breakdown.fx || 0],
      ['Storage optionality', breakdown.storage || 0],
      ['Credit / receivable result', breakdown.credit || 0]
    ];
    const maxAbs = Math.max(1,...rows.map(([,value])=>Math.abs(value)));
    return `<div class="location-badge">✓ Settled cargo</div><h2>${opp.title}</h2><div class="inspector-subtitle">${getHub(opp.origin).name} → ${getHub(opp.destination).name} · closed ${formatDate(new Date(item.completed))}</div>
      <div class="settlement-hero ${item.pnl>=0?'positive':'negative'}"><span>Realized P&amp;L</span><strong>${money(item.pnl)}</strong><small>${item.quantity||opp.quantity} t · ${item.days} days · ops ${Math.round(item.operationalReadiness||0)}%</small></div>
      <div class="inspector-section"><h3>P&amp;L attribution</h3><div class="pnl-waterfall">${rows.map(([label,value])=>`<div class="pnl-row"><div><span>${label}</span><strong style="color:${value>=0?'var(--green)':'var(--red)'}">${money(value)}</strong></div><div class="pnl-bar"><span class="${value>=0?'positive':'negative'}" style="width:${Math.max(3,Math.abs(value)/maxAbs*100)}%"></span></div></div>`).join('')}</div></div>
      <div class="inspector-section"><h3>Execution scorecard</h3><div class="inspector-grid"><div class="inspector-stat"><span>Hedge</span><strong>${item.hedgeRatio||0}%</strong></div><div class="inspector-stat"><span>FX hedge</span><strong>${item.fxHedgeRatio||0}%</strong></div><div class="inspector-stat"><span>Margin calls</span><strong>${item.marginCalls||0}</strong></div><div class="inspector-stat"><span>Demurrage</span><strong>${money(item.demurrage||0)}</strong></div></div></div>
      <div class="inspector-section"><h3>Structure used</h3><div class="timeline-mini-row"><i></i><span>Funding</span><strong>${financingProfiles[item.financingStrategy||'revolver']?.label||'N/A'}</strong></div><div class="timeline-mini-row"><i></i><span>Insurance</span><strong>${insuranceProfiles[item.insuranceStrategy||'basic']?.label||'N/A'}</strong></div><div class="timeline-mini-row"><i></i><span>Inspection</span><strong>${inspectionProfiles[item.inspectionStrategy||'standard']?.label||'N/A'}</strong></div><div class="timeline-mini-row"><i></i><span>Pricing</span><strong>${negotiationProfiles.pricing[item.pricingStrategy||'fixed']?.label||'Fixed price'}</strong></div><div class="timeline-mini-row"><i></i><span>Receivable</span><strong>${item.receivableProtection||'Open account / contract terms'}</strong></div></div>
      ${item.eventResult?`<div class="inspector-section"><h3>Operational outcome</h3><p>${item.eventResult}</p></div>`:''}`;
  }

  function vesselInspector(asset) {
    const vessel = getVesselCatalog(asset.catalogId);
    const deal = asset.assignedDealId ? getActiveDeal(asset.assignedDealId) : null;
    return `
      <div class="location-badge">◆ ${asset.ownership==='owned'?'Owned vessel':'Chartered asset'}</div>
      <h2>${vessel.name}</h2>
      <div class="inspector-subtitle">${vessel.vesselClass} · ${vessel.capacity.toLocaleString('en-US')} t DWT</div>
      <p class="inspector-subtitle" style="margin-top:12px">${vessel.description}</p>
      <div class="inspector-grid">
        <div class="inspector-stat"><span>Status</span><strong>${asset.status}</strong></div>
        <div class="inspector-stat"><span>Position</span><strong>${getHub(asset.positionHub)?.name || 'At sea'}</strong></div>
        <div class="inspector-stat"><span>${asset.ownership==='owned'?'Ownership':'Days remaining'}</span><strong>${asset.ownership==='owned'?'Permanent':asset.daysRemaining}</strong></div>
        <div class="inspector-stat"><span>${asset.ownership==='owned'?'Purchase cost':'Charter cost'}</span><strong>${money(asset.ownership==='owned'?(asset.purchaseCost||0):(asset.charterCost + (asset.extensionCost || 0)))}</strong></div>
      </div>
      <div class="inspector-section"><h3>Commercial employment</h3>
        ${deal ? `<div class="success-box">Assigned to ${getOpportunity(deal.opportunityId).title}. The vessel will be released at settlement.</div><button class="button secondary" id="openAssignedDealButton">Open assigned deal</button>` : '<div class="success-box">Available for a compatible opportunity departing from this location.</div>'}
      </div>
      <div class="inspector-section"><h3>${asset.ownership==='owned'?'Ownership profile':'Charter profile'}</h3>
        <div class="timeline-mini-row"><i></i><span>Transport class</span><strong>${vessel.transportClass}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Expected freight advantage</span><strong>${money(vessel.bonusPnl)}</strong></div>
        <div class="timeline-mini-row"><i></i><span>Execution advantage</span><strong>-${vessel.durationBonus} days</strong></div>
      </div>
      <button class="button secondary" id="focusVesselButton">Focus vessel</button>
      <button class="button danger" id="releaseVesselButton" ${asset.status === 'assigned' ? 'disabled' : ''}>${asset.ownership==='owned'?'Sell vessel (45% recovery)':'Terminate charter'}</button>`;
  }

  function selectInvestment(id,focus=true){const asset=investmentDefinition(id);if(!asset)return;selected={type:'investment',id};activeLeftTab='empire';if(focus)focusOnHub(asset.hub);renderTabs();renderInspector();renderEmpire();openInspector();}
  function investmentInspector(asset){const r=investmentRecord(asset.id),level=r.level||0,target=level+1,max=level>=asset.maxLevel,cost=max?0:investmentCost(asset,target),days=max?0:investmentBuildDays(asset,target);return `<div class="location-badge chain-${asset.chain}">${asset.chain} asset</div><h2>${asset.name}</h2><div class="inspector-subtitle">${getHub(asset.hub)?.name} · Level ${level}/${asset.maxLevel}</div><p class="inspector-subtitle" style="margin-top:12px">${asset.description}</p><div class="economics-grid"><div><span>Daily income</span><strong>${money((asset.dailyIncome||0)*level)}</strong></div><div><span>Deal P&L edge</span><strong>${money((asset.pnlBonus||0)*level)}</strong></div><div><span>Book value</span><strong>${money((r.totalSpent||0)*.88,true)}</strong></div><div><span>Status</span><strong>${r.buildingTo?`Building L${r.buildingTo}`:level?'Operational':'Greenfield'}</strong></div></div>${r.buildingTo?`<div class="success-box">Project team at work · ${r.daysRemaining} days remaining.</div>`:`<button class="button primary" id="inspectorBuildInvestment" ${max||!investmentUnlocked(asset)||state.cash<cost||activeProjectCount()>=builderSlots()?'disabled':''}>${max?'Maximum level':`Invest ${money(cost)} · ${days} days`}</button>`}<button class="button secondary" id="focusInvestmentHub">Focus location</button>`;}

  function renderInspector() {
    const eyebrow = $('#inspectorEyebrow');
    const container = $('#inspectorContent');
    if (selected.type === 'hub') {
      const hub = getHub(selected.id) || getHub('geneva');
      eyebrow.textContent = hub.type === 'hq' ? 'Headquarters' : 'Market location';
      container.innerHTML = hubInspector(hub);
      $$('[data-open-opportunity]', container).forEach(b => b.addEventListener('click', () => selectOpportunity(b.dataset.openOpportunity)));
    } else if (selected.type === 'investment') {
      const asset=investmentDefinition(selected.id); if(!asset)return selectHub('geneva'); eyebrow.textContent='Industrial asset'; container.innerHTML=investmentInspector(asset); $('#inspectorBuildInvestment')?.addEventListener('click',()=>startInvestment(asset.id)); $('#focusInvestmentHub')?.addEventListener('click',()=>focusOnHub(asset.hub));
    } else if (selected.type === 'opportunity') {
      const opp = getOpportunity(selected.id);
      // v45 — unico ramo che non aveva la guardia: un id non risolvibile bloccava
      // ogni renderAll() successivo, quindi anche la simulazione.
      if (!opp) return selectHub('geneva');
      eyebrow.textContent = 'Opportunity analysis';
      container.innerHTML = opportunityInspector(opp);
      const hedgeInput = $('#hedgeRatioInput');
      hedgeInput?.addEventListener('input', () => {
        selectedHedgeRatios[opp.id] = Number(hedgeInput.value);
        $('#hedgeRatioValue').textContent = `${hedgeInput.value}%`;
        const econ = opportunityEconomics(opp);
        const exposure = physicalNotional(opp, econ.quantity, econ.capital) * Math.max(0, 1 - Number(hedgeInput.value) / 100);
        $('#residualExposureValue').textContent = money(exposure, true);
        const postedEl = $('#marginPostedValue');
        if (postedEl) postedEl.textContent = money(econ.initialMargin, true);
      });
      $('#fitHedgeButton')?.addEventListener('click', () => {
        const affordable = affordableHedgeRatio(opp);
        if (affordable === null) return showToast('Even an unhedged cargo exceeds your liquidity right now.', 'warning');
        selectedHedgeRatios[opp.id] = affordable;
        renderInspector();
        showToast(`Hedge set to ${affordable}% \u2014 the highest your liquidity supports.`, 'success');
      });
      ['commercial','payment','pricing','delivery','incoterm'].forEach(field => {
        const id = field === 'commercial' ? '#commercialTermSelect' : field === 'payment' ? '#paymentTermSelect' : field === 'pricing' ? '#pricingTermSelect' : field === 'delivery' ? '#deliveryTermSelect' : '#incotermSelect';
        $(id)?.addEventListener('change', event => {
          setNegotiationDraft(opp.id, field, event.target.value);
          renderInspector();
          renderOpportunityList();
        });
      });
      $('#submitNegotiationButton')?.addEventListener('click', () => submitNegotiation(opp.id));
      $('#runComplianceReviewButton')?.addEventListener('click', () => runComplianceReview(opp.id));
      $('#carrierStrategySelect')?.addEventListener('change', (event) => {
        selectedCarrierStrategies[opp.id] = event.target.value;
        renderInspector();
      });
      $('#vesselClassSelect')?.addEventListener('change', (event) => {
        selectedVesselClasses[opp.id] = event.target.value;
        renderInspector();
      });
      $('#financingStrategySelect')?.addEventListener('change', event => { selectedFinancingStrategies[opp.id] = event.target.value; renderInspector(); renderOpportunityList(); });
      $('#insuranceStrategySelect')?.addEventListener('change', event => { selectedInsuranceStrategies[opp.id] = event.target.value; renderInspector(); renderOpportunityList(); });
      $('#inspectionStrategySelect')?.addEventListener('change', event => { selectedInspectionStrategies[opp.id] = event.target.value; renderInspector(); renderOpportunityList(); });
      $('#fxHedgeRatioInput')?.addEventListener('input', event => { selectedFxHedgeRatios[opp.id] = Number(event.target.value); $('#fxHedgeRatioValue').textContent = `${event.target.value}%`; });
      $('#startDealButton')?.addEventListener('click', () => startOpportunity(opp.id));
      $('#requestBuyerLimitButton')?.addEventListener('click', () => { const buyerId=partiesForOpportunity(opp).buyerId; if(buyerId) requestCreditLimit(buyerId); });
      const tenderInput = $('#tenderBidInput');
      if (tenderInput) {
        const tenderBidVal = $('#tenderBidVal');
        const tenderMarginPreview = $('#tenderMarginPreview');
        const tenderWinPct = $('#tenderWinPct');
        tenderInput.addEventListener('input', () => {
          const adj = Number(tenderInput.value);
          if (tenderBidVal) tenderBidVal.textContent = adj === 0 ? '$0' : (adj > 0 ? '+' : '') + money(adj);
          if (tenderMarginPreview) tenderMarginPreview.textContent = money(opp.basePnl + adj);
          // Rough win probability estimate based on concession depth
          const concessionRatio = Math.abs(adj) / Math.max(1, opp.basePnl);
          const pressurePenalty = Math.max(0, ((rivalTenderFor(opp.id)?.pressure) || 0) - 35) * 0.5;
          const winPct = Math.round(Math.min(95, Math.max(5, 30 + concessionRatio * 120 - pressurePenalty)));
          if (tenderWinPct) tenderWinPct.textContent = `~${winPct}%`;
        });
        $('#submitTenderBtn')?.addEventListener('click', () => submitTenderBid(opp.id, Number(tenderInput.value)));
      }
      $('#focusOriginButton')?.addEventListener('click', () => selectHub(opp.origin));
    } else if (selected.type === 'history') {
      const item = getHistoryDeal(selected.id);
      if (!item) return selectHub('geneva');
      eyebrow.textContent = 'Deal review';
      container.innerHTML = historyInspector(item);
    } else if (selected.type === 'vessel') {
      const asset = getFleetAsset(selected.id);
      if (!asset) return selectHub('geneva');
      eyebrow.textContent = 'Fleet asset';
      container.innerHTML = vesselInspector(asset);
      $('#focusVesselButton')?.addEventListener('click', () => focusOnHub(asset.positionHub));
      $('#releaseVesselButton')?.addEventListener('click', () => releaseVessel(asset.id));
      $('#openAssignedDealButton')?.addEventListener('click', () => selectDeal(asset.assignedDealId));
    } else if (selected.type === 'deal') {
      const deal = getActiveDeal(selected.id);
      if (!deal) return selectHub('geneva');
      eyebrow.textContent = deal.pendingDecision ? 'Decision required' : 'Live operation';
      container.innerHTML = dealInspector(deal);
      $$('[data-event-choice]', container).forEach(b => b.addEventListener('click', () => resolveEvent(deal.id, b.dataset.eventChoice)));
      $('#increaseHedgeButton')?.addEventListener('click', () => increaseHedge(deal.id));
      $('#expediteDocsButton')?.addEventListener('click', () => expediteDocuments(deal.id));
      $('#upgradeTransportButton')?.addEventListener('click', () => upgradeTransport(deal.id));
      $('#emergencyStorageButton')?.addEventListener('click', () => bookEmergencyStorage(deal.id));
      $('#creditInsuranceButton')?.addEventListener('click', () => protectReceivable(deal.id, 'insurance'));
      $('#factorReceivableButton')?.addEventListener('click', () => protectReceivable(deal.id, 'factor'));
      $('#storageOptionButton')?.addEventListener('click', () => exerciseStorageOption(deal.id));
      $('#mitigateRouteButton')?.addEventListener('click', () => mitigateRouteCongestion(deal.id));
      $('#focusShipmentButton')?.addEventListener('click', () => focusOnDeal(deal.id));
      const rehedgeInput = $('#rehedgeInput');
      if (rehedgeInput) {
        const rehedgeVal = $('#rehedgeVal');
        rehedgeInput.addEventListener('input', () => { if (rehedgeVal) rehedgeVal.textContent = rehedgeInput.value + '%'; });
        $('#rehedgeBtn')?.addEventListener('click', () => rehedgeDeal(deal.id, Number(rehedgeInput.value)));
      }
    }
  }

  function renderEventBanner() {
    const pending = state.activeDeals.find(d => d.pendingDecision);
    const banner = $('#eventBanner');
    if (!pending) {
      banner.classList.add('hidden');
      return;
    }
    const opp = getOpportunity(pending.opportunityId);
    $('#eventBannerText').textContent = opp?.event?.title || pending.eventResult || 'Treasury decision required';
    banner.classList.remove('hidden');
    $('#openEventButton').onclick = () => selectDeal(pending.id);
  }

  function renderWorldTicker() {
    const ticker = $('#worldEventTicker');
    const active = activeCrisisDefinitions();
    if (!ticker || !active.length) {
      ticker?.classList.add('hidden');
      return;
    }
    $('#worldEventTickerText').textContent = active.map(event => `${event.title} (${event.remaining}d)`).join(' · ');
    ticker.classList.remove('hidden');
    $('#openWorldEventsButton').onclick = () => openLeftDrawer('events');
  }

  function renderLayers() {
    $$('.layer-button[data-layer]').forEach(button => button.classList.toggle('active', layers[button.dataset.layer]));
    $$('.layer-button[data-globe-option]').forEach(button => button.classList.toggle('active', globeOptions[button.dataset.globeOption]));
    document.body.classList.toggle('cinematic-mode', globeOptions.cinematic);
  }

  function renderAll() {
    renderMetrics();
    renderEquityChart();
    renderTabs();
    renderAllLists();
    renderInspector();
    renderEventBanner();
    renderWorldTicker();
    renderLayers();
    renderBriefing();
    renderTutorialCoach();
    renderOfficeRailStatus();
  }

  function configureDifficulty(level) {
    state.difficulty = level;
    // v53 - il fido iniziale deve coprire il prestito richiesto dal primo cargo
    // (~1,42 M): con 1,25 M Expert non permetteva di aprire alcun deal, mai.
    // Le tre difficolta' restano distinte su margine, perdite e liquidita'.
    if (level === 'guided') { state.cash = prestigeStartCash(680_000); state.creditLimit = prestigeStartCredit(2_200_000); state.reputation = prestigeStartReputation(16); state.nextGlobalEventDay = 18; }
    else if (level === 'expert') { state.cash = prestigeStartCash(520_000); state.creditLimit = prestigeStartCredit(1_800_000); state.reputation = prestigeStartReputation(12); state.nextGlobalEventDay = 10; }
    else { state.cash = prestigeStartCash(560_000); state.creditLimit = prestigeStartCredit(2_000_000); state.reputation = prestigeStartReputation(14); state.nextGlobalEventDay = 14; }
    state.startingCapital = state.cash;
    state.xp = 0; state.xpLevel = 1;
    state.riskPnlImpact = 0; state.riskLedger = [];
    state.unlockedCountriesSeen = ['Switzerland','Estonia','Italy'];
    state.unlockedCommoditiesSeen = ['Copper'];
    state.hqTier = 1; state.hqUpgrade = null;
    state.deskSpecialization = 'generalist'; state.specializationChosen = false; state.specializationChangedDay = -99;
    state.marketReputation = { countries:{ Switzerland:50, Estonia:35, Italy:35 }, commodities:{ Copper:35 } };
    state.commercialFrameworks = {}; state.crisisResponses = {};
    state.navHistory = [state.cash,state.cash,state.cash];
    state.marketRegime = generateMarketRegime(1);
    initializeCompetitiveMarket(true);
    state.onboardingComplete = true;
    saveState();
  }

  function openOnboarding() {
    const dialog = $('#onboardingDialog');
    if (!dialog || state.onboardingComplete || dialog.open) return;
    dialog.showModal();
  }

  function openVictoryDialog() {
    const dialog = $('#victoryDialog');
    if (!dialog || dialog.open) return;
    const val = tradingHouseValuation();
    const nextLevel = loadPrestige() + 1;
    const stats = portfolioStats();
    const statsEl = $('#victoryStats');
    if (statsEl) {
      statsEl.innerHTML = `
        <div><span>Enterprise value</span><strong>${money(val.value, true)}</strong></div>
        <div><span>Net asset value</span><strong>${money(stats.nav, true)}</strong></div>
        <div><span>Deals closed</span><strong>${state.completedDeals}</strong></div>
        <div><span>Reputation</span><strong>${Math.round(state.reputation)}</strong></div>`;
    }
    const note = $('#victoryPrestigeNote');
    if (note) {
      note.innerHTML = `Prestige level ${loadPrestige()} → <strong>${nextLevel}</strong> · new careers start with <strong>+${12*nextLevel}% capital</strong>, <strong>+${8*nextLevel}% credit</strong> and higher reputation.`;
    }
    try { Sound.play('victory'); } catch (e) {}
    dialog.showModal();
  }

  function claimPrestige() {
    const newLevel = loadPrestige() + 1;
    savePrestige(newLevel);
    showToast(`Prestige ${newLevel} claimed! Your legacy carries into a new career.`, 'success');
    resetCareer();
  }

  function checkVictory() {
    if (!state || state.victoryClaimed) return;
    const val = tradingHouseValuation();
    if (val.value >= VICTORY_VALUATION) {
      state.victoryClaimed = true;
      saveState();
      setTimeout(openVictoryDialog, 400);
    }
  }

  // ── v31 XP / experience levels (Clash-of-Clans-style) ──────────────────────
  function xpForLevel(level) { return Math.round(300 * Math.pow(1.16, Math.max(0, level - 1))); }
  function xpLevelProgress() {
    const need = xpForLevel(state.xpLevel || 1);
    return { have: state.xp || 0, need, pct: Math.min(100, Math.round(((state.xp || 0) / need) * 100)) };
  }
  let _pendingLevelUps = 0;
  let _lastUnlockMessage = '';
  function addXp(amount, reason) {
    if (!amount || amount <= 0) return;
    state.xp = (state.xp || 0) + Math.round(amount);
    state.xpLevel = state.xpLevel || 1;
    let leveled = false;
    while (state.xp >= xpForLevel(state.xpLevel)) {
      state.xp -= xpForLevel(state.xpLevel);
      state.xpLevel += 1;
      // v50 - il messaggio di livello prometteva "Unlocked: Urea market" anche
      // quando la rotta restava chiusa perche' mancavano ufficio, cargo chiusi o
      // reputazione. Ora distingue le rotte che si aprono davvero dalle licenze.
      const unlockedNow = newlyUnlockedAtLevel(state.xpLevel);
      const routesOpened = opportunities.filter(opp => {
        if (!isOpportunityUnlocked(opp)) return false;
        const progression = opportunityProgressionRequirements(opp);
        return progression.requiredLevel === state.xpLevel;   // si e' aperta proprio adesso
      }).map(opp => opp.title);
      const licences = [...unlockedNow.commodities.map(x => `${x} licence`), ...unlockedNow.countries.map(x => `${x} corridor`)];
      // v51 - i moduli che si aprono a questo livello vengono annunciati per primi:
      // sono la ricompensa piu' tangibile del salire di livello.
      const modulesNow = modulesUnlockedAtLevel(state.xpLevel);
      _lastUnlockMessage = modulesNow.length
        ? `New module${modulesNow.length === 1 ? '' : 's'}: ${modulesNow.join(' · ')}`
        : routesOpened.length
          ? `Now tradable: ${routesOpened.join(' · ')}`
          : licences.length
            ? `${licences.join(' · ')} licensed \u2014 an office is still required`
            : (unlockedNow.offices || []).join(' \u00b7 ');
      leveled = true;
      const reward = 4000 + state.xpLevel * 2500;
      state.cash += reward;
      state.goldBars = (state.goldBars || 0) + 5;
      _pendingLevelUps++;
      _lastLevelReward = reward;
    }
    if (leveled && !_soundSuppressed) {
      try { Sound.play('victory'); } catch (e) {}
      setTimeout(() => celebrateLevelUp(), 60);
    }
    // pop the xp chip
    if (!_soundSuppressed) { const chip = document.getElementById('xpChip'); if (chip) { chip.classList.remove('xp-pop'); void chip.offsetWidth; if (motionEnabled()) chip.classList.add('xp-pop'); } }
  }
  let _lastLevelReward = 0;
  function addGold(n, reason) { if (!n) return; state.goldBars = Math.max(0, (state.goldBars || 0) + Math.round(n)); if (!_soundSuppressed) { const c = document.getElementById('goldChip'); if (c && motionEnabled()) { c.classList.remove('xp-pop'); void c.offsetWidth; c.classList.add('xp-pop'); } } }
  function celebrateLevelUp() {
    const overlay = document.getElementById('levelUpOverlay');
    if (!overlay) { showToast(`Level ${state.xpLevel} reached! +${money(_lastLevelReward)} bonus.`, 'success'); return; }
    const numEl = document.getElementById('levelUpNumber');
    const rwEl = document.getElementById('levelUpReward');
    if (numEl) numEl.textContent = state.xpLevel;
    if (rwEl) rwEl.textContent = `+${money(_lastLevelReward)} cash bonus${_lastUnlockMessage ? ` · Unlocked: ${_lastUnlockMessage}` : ''}`;
    overlay.classList.add('show');
    overlay.setAttribute('aria-hidden', 'false');
    clearTimeout(overlay._t);
    overlay._t = setTimeout(() => { overlay.classList.remove('show'); overlay.setAttribute('aria-hidden','true'); }, 2600);
  }

  // ── v32 daily login reward (streak) ────────────────────────────────────────
  function dailyRewardFor(streakDay) {
    const d = Math.min(7, Math.max(1, streakDay));
    return { cash: 20000 * d, xp: 15 * d, gold: 2 + d };
  }
  let _pendingDailyReward = null;
  function checkDailyReward() {
    const today = new Date().toISOString().slice(0, 10);
    // v45 — 'streakDay' registra il giorno in cui lo streak e' stato calcolato:
    // prima bastava chiudere il dialog e ricaricare per farlo salire di 1 ogni volta.
    if (state.lastRewardDay === today || state.streakDay === today) return;
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    state.loginStreak = (state.lastRewardDay === yesterday) ? (state.loginStreak || 0) + 1 : 1;
    state.streakDay = today;
    _pendingDailyReward = today;
    setTimeout(openDailyReward, 700);
  }
  function openDailyReward() {
    const dialog = $('#dailyRewardDialog');
    const streak = state.loginStreak || 1;
    const reward = dailyRewardFor(streak);
    if (!dialog) { // fallback: auto-grant
      claimDailyReward();
      return;
    }
    const sub = $('#dailyStreakSub'); if (sub) sub.textContent = `Day ${streak} in a row`;
    const row = $('#dailyDaysRow');
    if (row) {
      row.innerHTML = Array.from({ length: 7 }, (_, i) => {
        const day = i + 1; const r = dailyRewardFor(day);
        const cls = day < streak ? 'done' : day === Math.min(7, streak) ? 'active' : '';
        return `<div class="daily-day ${cls}"><span>D${day}</span><b>${r.gold}⬤</b></div>`;
      }).join('');
    }
    const line = $('#dailyRewardLine');
    if (line) line.innerHTML = `Today: <strong>${money(reward.cash)}</strong> · <strong>${reward.xp} XP</strong> · <strong>${reward.gold} gold bars</strong>`;
    try { Sound.play('purchase'); } catch (e) {}
    if (!dialog.open) dialog.showModal();
  }
  function claimDailyReward() {
    const streak = state.loginStreak || 1;
    const reward = dailyRewardFor(streak);
    state.cash += reward.cash;
    addGold(reward.gold, 'daily');
    state.lastRewardDay = _pendingDailyReward || new Date().toISOString().slice(0, 10);
    addXp(reward.xp, 'daily');
    saveState(true);
    renderAll();
    showToast(`Daily bonus claimed: ${money(reward.cash)} + ${reward.gold} gold bars.`, 'success');
  }

  // ── v46 · riepilogo di chiusura operazione ──────────────────────────────────
  // Prima un cargo si chiudeva con un semplice toast: il risultato piu' importante
  // della partita passava inosservato. Ora compare un pannello con la scomposizione
  // del P&L, le barre che crescono e il totale che scorre.
  let _settlementQueue = [];
  let _settlementTimer = null;

  function queueSettlementSummary(opp, deal, figures) {
    if (!opp) return;
    _settlementQueue.push({
      title: opp.title,
      route: `${getHub(opp.origin)?.name || '—'} → ${getHub(opp.destination)?.name || '—'}`,
      days: deal.elapsed,
      hedge: deal.hedgeRatio || 0,
      readiness: Math.round(figures.readiness || 0),
      total: figures.pnl,
      lines: [
        { label: 'Trading margin',     value: figures.basePnl || 0 },
        { label: 'Market exposure',    value: figures.marketPnl || 0 },
        { label: 'FX result',          value: figures.fxPnl || 0 },
        { label: 'Operations & claims', value: figures.adjustments || 0 },
        { label: 'Financing cost',     value: -(figures.financingCost || 0) },
        { label: 'Storage optionality', value: figures.storagePnl || 0 },
        { label: 'Credit result',      value: figures.creditPnl || 0 },
      ].filter(line => Math.abs(line.value) >= 1),
    });
    if (!_settlementTimer) _settlementTimer = setTimeout(showNextSettlement, 420);
  }

  function showNextSettlement() {
    _settlementTimer = null;
    const item = _settlementQueue.shift();
    const dialog = $('#settlementDialog');
    if (!item) return;
    if (!dialog) { showToast(`${item.title} settled: ${money(item.total)}.`, item.total >= 0 ? 'success' : 'warning'); return; }
    if (dialog.open) { _settlementQueue.unshift(item); _settlementTimer = setTimeout(showNextSettlement, 900); return; }

    const positive = item.total >= 0;
    dialog.classList.toggle('loss', !positive);
    $('#settlementTitle').textContent = item.title;
    $('#settlementRoute').textContent = `${item.route} · ${item.days} days · hedge ${item.hedge}% · ops ${item.readiness}%`;
    $('#settlementVerdict').textContent = positive ? 'Cargo settled in profit' : 'Cargo settled at a loss';

    const max = Math.max(1, ...item.lines.map(line => Math.abs(line.value)));
    $('#settlementLines').innerHTML = item.lines.map((line, index) => `
      <div class="settlement-line" style="--i:${index}">
        <span>${line.label}</span>
        <div class="settlement-track"><i class="${line.value >= 0 ? 'positive' : 'negative'}" style="width:${Math.max(3, Math.abs(line.value) / max * 100)}%"></i></div>
        <strong class="${line.value >= 0 ? 'positive' : 'negative'}">${line.value >= 0 ? '+' : ''}${money(line.value)}</strong>
      </div>`).join('');

    const totalEl = $('#settlementTotal');
    totalEl.className = `settlement-total ${positive ? 'positive' : 'negative'}`;
    totalEl.textContent = money(0);
    dialog.showModal();
    // il totale scorre dopo che le barre sono cresciute
    setTimeout(() => animateCounter(totalEl, item.total, v => money(v)), motionEnabled() ? 520 : 0);
    try { Sound.play(positive ? 'deal' : 'warning'); } catch (e) {}
  }

  function switchToSlot(n) {
    if (n === activeSlot) { $('#slotDialog')?.close(); return; }
    saveState(true); // persist current slot first
    setActiveSlot(n);
    // v45 — va letto PRIMA del saveState finale, altrimenti la condizione e' sempre
    // falsa e chi apre uno slot vuoto non vede mai onboarding e scelta difficolta'.
    let isNewCareer = false;
    try { isNewCareer = !localStorage.getItem(currentStorageKey()); } catch (e) {}
    state = loadState();
    initializeCounterparties();
    initializeCompetitiveMarket(true);
    selected = { type: 'hub', id: 'geneva' };
    activeLeftTab = 'portfolio';
    runningSpeed = 0;
    if (state.reduceMotion) document.body.classList.add('reduce-motion'); else document.body.classList.remove('reduce-motion');
    cleanGlobeView();
    updateClock();
    saveState(true);
    view = { lon: 6, lat: 18, zoom: 1, targetLon: 6, targetLat: 18 };
    renderAll();
    $('#slotDialog')?.close();
    const meta = readSlotMeta(n);
    showToast(`Switched to slot ${n}${meta ? ' · ' + meta.companyName : ' (new career)'}.`, 'success');
    if (isNewCareer) setTimeout(openOnboarding, 80);
  }

  function deleteSlot(n) {
    try {
      localStorage.removeItem(slotKey(n));
      localStorage.removeItem(`${slotKey(n)}-backup`);
    } catch (e) {}
    if (n === activeSlot) {
      // v45 — prima l'orologio continuava a girare sulla "carriera cancellata"
      // e la selezione restava puntata su un deal ormai inesistente.
      state = defaultState();
      state.onboardingComplete = false;
      initializeCounterparties();
      initializeCompetitiveMarket(true);
      selected = { type: 'hub', id: 'geneva' };
      activeLeftTab = 'portfolio';
      runningSpeed = 0;
      view = { lon: 6, lat: 18, zoom: 1, targetLon: 6, targetLat: 18 };
      cleanGlobeView();
      updateClock();
      saveState(true);
      renderAll();
      setTimeout(openOnboarding, 120);
    }
    showToast(`Slot ${n} cleared.`, 'warning');
    renderSlotManager();
  }

  function renderSlotManager() {
    const list = $('#slotList');
    if (!list) return;
    const cards = [];
    for (let n = 1; n <= SLOT_COUNT; n++) {
      const meta = (n === activeSlot) ? {
        empty: false, companyName: state.companyName, profileName: state.profileName,
        completedDeals: state.completedDeals, cash: state.cash, prestigeLevel: state.prestigeLevel,
        date: state.date, lastSavedAt: state.lastSavedAt
      } : readSlotMeta(n);
      const isActive = n === activeSlot;
      if (!meta) {
        cards.push(`<div class="slot-card empty">
          <div class="slot-head"><strong>Slot ${n}</strong><span class="slot-tag">Empty</span></div>
          <p class="slot-empty-copy">No career here yet.</p>
          <div class="slot-actions"><button class="button primary" data-slot-switch="${n}">Start career</button></div>
        </div>`);
      } else if (meta.corrupt) {
        // v45 — uno slot illeggibile veniva mostrato come vuoto e l'utente lo
        // cancellava, distruggendo una carriera che il backup poteva recuperare.
        cards.push(`<div class="slot-card damaged">
          <div class="slot-head"><strong>Slot ${n}</strong><span class="slot-tag">Damaged</span></div>
          <p class="slot-empty-copy">This save could not be read.${meta.hasBackup ? ' A backup copy is available and will be restored on load.' : ' No backup is available.'}</p>
          <div class="slot-actions">
            ${meta.hasBackup ? `<button class="button primary" data-slot-switch="${n}">Restore backup</button>` : ''}
            <button class="button danger" data-slot-delete="${n}">Delete</button>
          </div>
        </div>`);
      } else {
        const val = meta.date ? new Intl.DateTimeFormat('en-GB',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(meta.date)) : '—';
        cards.push(`<div class="slot-card ${isActive?'active':''}">
          <div class="slot-head"><strong>Slot ${n}${isActive?' <span class="slot-tag current">Current</span>':''}</strong>${meta.prestigeLevel?`<span class="slot-prestige">★ ${meta.prestigeLevel}</span>`:''}</div>
          <div class="slot-company">${esc(meta.companyName || 'World of Trade Co.')}</div>
          <div class="slot-meta"><span>${meta.completedDeals} deals</span><span>${money(meta.cash,true)}</span><span>${val}</span></div>
          <div class="slot-actions">
            ${isActive?'<button class="button secondary" disabled>Active</button>':`<button class="button primary" data-slot-switch="${n}">Load</button>`}
            <button class="button danger" data-slot-delete="${n}">Delete</button>
          </div>
        </div>`);
      }
    }
    list.innerHTML = cards.join('');
    list.querySelectorAll('[data-slot-switch]').forEach(b => b.addEventListener('click', () => switchToSlot(Number(b.dataset.slotSwitch))));
    list.querySelectorAll('[data-slot-delete]').forEach(b => b.addEventListener('click', () => {
      if (confirm(`Delete the career in slot ${b.dataset.slotDelete}? This cannot be undone.`)) deleteSlot(Number(b.dataset.slotDelete));
    }));
  }

  function openSlotManager() {
    const dialog = $('#slotDialog');
    if (!dialog) return;
    renderSlotManager();
    if (!dialog.open) dialog.showModal();
  }

  function resetCareer() {
    state = defaultState();
    initializeCounterparties();
    initializeCompetitiveMarket(true);
    selected = { type: 'hub', id: 'geneva' };
    activeLeftTab = 'portfolio';
    selectedLeaderboardMode = 'overall';
    runningSpeed = 0;
    cleanGlobeView();
    updateClock();
    saveState();
    view = { lon: 6, lat: 18, zoom: 1, targetLon: 6, targetLat: 18 };
    renderAll();
    showToast('A new World of Trade career is ready. Choose the difficulty and onboarding mode.');
    setTimeout(openOnboarding,80);
  }

  const wotIcons = {
    openDeskButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M3 9h18M9 9v11"/></svg>',
    openShopButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8h12l-1 12H7L6 8z"/><path d="M9 8a3 3 0 0 1 6 0"/></svg>',
    openOfficesButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 21V8l8-5 8 5v13"/><path d="M8 21v-6h8v6M8 10h.01M12 10h.01M16 10h.01"/></svg>',
    toggleOverviewButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v9l7 4"/><circle cx="12" cy="12" r="9"/></svg>',
    toggleMarketsButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 5v14M5 9h4M9 6v10M12 5v14M12 8h4M16 6v9M19 5v14"/></svg>',
    toggleLayersButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/></svg>',
    openSearchButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    openBriefingButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l3 3v15H6z"/><path d="M9 9h6M9 13h6M9 17h4"/></svg>',
    openShortcutsButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M7 10h.01M11 10h.01M15 10h.01M7 14h10"/></svg>',
    openGlossaryButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5a2 2 0 0 1 2-2h5v17H6a2 2 0 0 0-2 2z"/><path d="M20 5a2 2 0 0 0-2-2h-5v17h5a2 2 0 0 1 2 2z"/></svg>',
    installButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11m0 0l-4-4m4 4l4-4"/><path d="M5 19h14"/></svg>',
    openNotificationsButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>',
    resetButton: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 1 2.3 5.6"/><path d="M4 20v-5h5"/></svg>',
  };
  const metricCoinIcons = {
    navMetric: '<svg viewBox="0 0 24 24" fill="none" stroke="#3a1e6e" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 16l5-5 3 3 6-7"/><path d="M15 7h4v4"/></svg>',
    cashMetric: '<svg viewBox="0 0 24 24" fill="none" stroke="#0a3d1a" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M9.5 9.5a2.5 2 0 0 1 5 0c0 1.5-5 1.5-5 3a2.5 2 0 0 0 5 0"/></svg>',
    creditMetric: '<svg viewBox="0 0 24 24" fill="none" stroke="#0a2d5e" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10l9-5 9 5"/><path d="M5 10v8M12 10v8M19 10v8M3 19h18"/></svg>',
    repMetric: '<svg viewBox="0 0 24 24" fill="#5a3600" stroke="#5a3600" stroke-width="1.5" stroke-linejoin="round"><path d="M12 3l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.2l5.9-.9z"/></svg>',
  };
  function injectIcons() {
    Object.entries(wotIcons).forEach(([id, svg]) => {
      const btn = document.getElementById(id);
      if (!btn) return;
      let holder = btn.querySelector('span');
      if (!holder) { holder = document.createElement('span'); btn.insertBefore(holder, btn.firstChild); }
      holder.classList.add('wot-icon');
      holder.innerHTML = svg;
    });
    // Metric resource coins
    Object.entries(metricCoinIcons).forEach(([id, svg]) => {
      const strong = document.getElementById(id);
      const metric = strong ? strong.closest('.top-metric') : null;
      if (!metric || metric.querySelector('.metric-coin')) return;
      // Wrap existing label/value/sub into a column body
      const body = document.createElement('div');
      body.className = 'metric-body';
      while (metric.firstChild) body.appendChild(metric.firstChild);
      const coin = document.createElement('span');
      coin.className = 'metric-coin coin-' + id;
      coin.innerHTML = svg;
      metric.appendChild(coin);
      metric.appendChild(body);
    });
  }

  function bindEvents() {
    injectIcons();
    // v45 — nessun salvataggio avveniva alla chiusura della scheda sul web:
    // con l'autosave a debounce si potevano perdere gli ultimi secondi di partita.
    window.addEventListener('pagehide', () => { try { saveState(); } catch (e) {} });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') { try { saveState(); } catch (e) {} }
    });
    // v45 — un solo handler per chiudere il popup della forward curve: prima se ne
    // registrava uno nuovo a ogni apertura e non venivano mai consumati.
    document.addEventListener('click', () => document.getElementById('fwdCurvePopup')?.remove());
    // Unlock Web Audio on the first user gesture (autoplay policy)
    const _unlockAudio = () => { try { Sound.unlock(); } catch (e) {} window.removeEventListener('pointerdown', _unlockAudio); window.removeEventListener('keydown', _unlockAudio); };
    window.addEventListener('pointerdown', _unlockAudio, { once: false });
    window.addEventListener('keydown', _unlockAudio, { once: false });
    window.addEventListener('resize', resizeCanvas);
    new ResizeObserver(resizeCanvas).observe($('#globeStage'));

    canvas.addEventListener('pointerdown', (event) => {
      dragging = true;
      dragMoved = false;
      followCargo = false;
      lastInteractionTime = performance.now();
      dragStart = { x: event.clientX, y: event.clientY, lon: view.lon, lat: view.lat };
      view.targetLon = null;
      canvas.setPointerCapture(event.pointerId);
      canvas.classList.add('dragging');
      updateGlobeTooltip(null, 0, 0);
      $('#globeHint').classList.add('dismissed');
    });
    canvas.addEventListener('pointermove', (event) => {
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      lastPointerPosition = { x, y };
      if (!dragging) {
        updateGlobeTooltip(findGlobeTarget(x, y), x, y);
        return;
      }
      const dx = event.clientX - dragStart.x;
      const dy = event.clientY - dragStart.y;
      if (Math.abs(dx)+Math.abs(dy) > 3) dragMoved = true;
      view.lon = ((dragStart.lon - dx * .28 / view.zoom + 540) % 360) - 180;
      view.lat = clamp(dragStart.lat + dy * .20 / view.zoom, -70, 70);
    });
    canvas.addEventListener('pointerup', (event) => {
      dragging = false;
      lastInteractionTime = performance.now();
      canvas.releasePointerCapture(event.pointerId);
      canvas.classList.remove('dragging');
      if (!dragMoved) {
        const rect = canvas.getBoundingClientRect();
        const target = findGlobeTarget(event.clientX - rect.left, event.clientY - rect.top);
        if (target?.type === 'investment') return selectInvestment(target.id, false);
        if (target?.type === 'vessel') return selectVessel(target.id, false);
        if (target?.type === 'deal') return trackLiveDeal(target.id, false);
        if (target?.type === 'hub') return selectHub(target.id, false);
      }
    });
    canvas.addEventListener('pointerleave', () => updateGlobeTooltip(null, 0, 0));
    canvas.addEventListener('wheel', (event) => {
      event.preventDefault();
      followCargo = false;
      lastInteractionTime = performance.now();
      view.zoom = clamp(view.zoom * (event.deltaY > 0 ? .93 : 1.07), .72, 1.45);
      $('#globeHint').classList.add('dismissed');
    }, { passive: false });

    $$('.panel-tab').forEach(button => button.addEventListener('click', () => {
      activeLeftTab = button.dataset.leftTab;
      leftDrawerOpen = true;
      renderTabs();
      syncOverlayUI();
    }));

    $$('.layer-button[data-layer]').forEach(button => button.addEventListener('click', () => {
      layers[button.dataset.layer] = !layers[button.dataset.layer];
      renderLayers();
    }));
    $$('.layer-button[data-globe-option]').forEach(button => button.addEventListener('click', () => {
      const option = button.dataset.globeOption;
      globeOptions[option] = !globeOptions[option];
      if (option === 'cinematic' && globeOptions.cinematic) {
        leftDrawerOpen = false; inspectorOpen = false; briefingOpen = false; overviewOpen = false; marketsOpen = false; layersOpen = false;
        syncOverlayUI();
      }
      lastInteractionTime = performance.now();
      renderLayers();
    }));

    $('#pauseButton').addEventListener('click', () => { runningSpeed = 0; updateClock(); });
    $$('.time-button[data-speed]').forEach(button => button.addEventListener('click', () => {
      runningSpeed = Number(button.dataset.speed);
      updateClock();
    }));
    $('#nextDayButton').addEventListener('click', () => advanceDay());
    $('#nextEventButton').addEventListener('click', advanceToNextEvent);
    $('#closeInspector').addEventListener('click', closeInspectorPanel);
    $('#closeLeftPanel')?.addEventListener('click', closeLeftDrawer);
    $('#openDeskButton')?.addEventListener('click', () => leftDrawerOpen ? closeLeftDrawer() : openLeftDrawer(activeLeftTab));
    $('#openShopButton')?.addEventListener('click', () => openLeftDrawer('shop'));
    $('#openOfficesButton')?.addEventListener('click', openOfficeNetwork);
    $('#toggleOverviewButton')?.addEventListener('click', () => { overviewOpen = !overviewOpen; marketsOpen = false; syncOverlayUI(); });
    $('#toggleMarketsButton')?.addEventListener('click', () => { marketsOpen = !marketsOpen; overviewOpen = false; syncOverlayUI(); });
    $('#toggleLayersButton')?.addEventListener('click', () => { layersOpen = !layersOpen; syncOverlayUI(); });
    $('#openSearchButton')?.addEventListener('click', openGlobalSearch);
    $('#openBriefingButton')?.addEventListener('click', () => briefingOpen ? closeBriefing() : openBriefing());
    $('#closeBriefingButton')?.addEventListener('click', closeBriefing);
    $('#cleanViewButton')?.addEventListener('click', cleanGlobeView);
    $('#drawerBackdrop')?.addEventListener('click', cleanGlobeView);
    $('#closeTrackerButton')?.addEventListener('click', closeLiveTracker);
    $('#followCargoButton')?.addEventListener('click', () => { followCargo = !followCargo; lastInteractionTime = performance.now(); renderLiveTracker(); });
    $('#openCargoButton')?.addEventListener('click', () => trackingDealId && selectDeal(trackingDealId, false));
    $('#tutorialActionButton')?.addEventListener('click', runTutorialAction);
    $('#tutorialBackButton')?.addEventListener('click', () => {
      state.tutorialStep = Math.max(0, currentTutorialStep() - 1);
      saveState();
      renderTutorialCoach();
    });
    // v52 - il mentore si puo' richiamare in qualsiasi momento sul modulo aperto
    $('#askMentorButton')?.addEventListener('click', () => showMentorBriefing(activeLeftTab, 'reference'));
    $('#mentorDialog')?.addEventListener('close', () => {
      if (_mentorQueue.length && !_mentorTimer) _mentorTimer = setTimeout(showNextMentorBriefing, 320);
    });
    $('#skipTutorialButton')?.addEventListener('click', () => {
      state.tutorialEnabled = false;
      state.tutorialDismissed = true;
      saveState();
      renderTutorialCoach();
      showToast('Guided tour skipped. You can restart it from your profile.');
    });
    $('#globalSearchInput')?.addEventListener('input', event => { searchActiveIndex = 0; renderGlobalSearch(event.target.value); });
    $('#searchDialog')?.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); $('#searchDialog')?.close(); return; }
      if (!searchItems.length) return;
      if (event.key === 'ArrowDown') { event.preventDefault(); searchActiveIndex = (searchActiveIndex + 1) % searchItems.length; renderGlobalSearch($('#globalSearchInput')?.value || ''); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); searchActiveIndex = (searchActiveIndex - 1 + searchItems.length) % searchItems.length; renderGlobalSearch($('#globalSearchInput')?.value || ''); }
      else if (event.key === 'Enter') { event.preventDefault(); executeSearchItem(searchItems[searchActiveIndex]); }
    });
    document.addEventListener('keydown', event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); return openGlobalSearch(); }
      if (!['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName)) {
        if (event.key.toLowerCase() === 'b') { event.preventDefault(); return briefingOpen ? closeBriefing() : openBriefing(); }
        if (event.key.toLowerCase() === 'm') { event.preventDefault(); return openLeftDrawer('opportunities'); }
        if (event.key.toLowerCase() === 'r') { event.preventDefault(); return openLeftDrawer('risk'); }
        if (event.key.toLowerCase() === 'p') { event.preventDefault(); return openLeftDrawer('performance'); }
        if (event.key.toLowerCase() === 's') { event.preventDefault(); return openLeftDrawer('shop'); }
        if (event.key.toLowerCase() === 'o') { event.preventDefault(); return openOfficeNetwork(); }
        if (event.key.toLowerCase() === 'n') { event.preventDefault(); return advanceDay(); }
        if (event.key === '?' || (event.shiftKey && event.key === '/')) { event.preventDefault(); return toggleShortcutsOverlay(); }
        if (event.key.toLowerCase() === 'g') { event.preventDefault(); return openGlossaryDialog(); }
      }
      if (event.key.toLowerCase() === 'f' && !['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName)) {
        globeOptions.cinematic = !globeOptions.cinematic;
        if (globeOptions.cinematic) { leftDrawerOpen=false; inspectorOpen=false; briefingOpen=false; overviewOpen=false; marketsOpen=false; layersOpen=false; syncOverlayUI(); }
        renderLayers();
        return;
      }
      if (event.key === 'Escape' && $('#shortcutsOverlay')?.classList.contains('open')) { closeShortcutsOverlay(); return; }
      if (event.key === 'Escape' && !$('#searchDialog')?.open) cleanGlobeView();
    });
    $('#profileButton')?.addEventListener('click', openProfileDialog);
    $('#openShortcutsButton')?.addEventListener('click', toggleShortcutsOverlay);
    $('#openGlossaryButton')?.addEventListener('click', openGlossaryDialog);
    $('#openNotificationsButton')?.addEventListener('click', openNotificationsDialog);
    $('#manageSlotsButton')?.addEventListener('click', () => { $('#profileDialog')?.close(); setTimeout(openSlotManager, 60); });
    $('#installButton')?.addEventListener('click', async () => {
      if (!_deferredInstallPrompt) { showToast('Install is not available right now. Use your browser menu → Install / Add to Home Screen.', 'info'); return; }
      _deferredInstallPrompt.prompt();
      try { await _deferredInstallPrompt.userChoice; } catch (e) {}
      _deferredInstallPrompt = null;
      $('#installButton')?.classList.add('hidden');
    });
    bindTermTooltips();
    $('#shortcutsCloseButton')?.addEventListener('click', closeShortcutsOverlay);
    $('#shortcutsOverlay')?.addEventListener('click', event => { if (event.target === $('#shortcutsOverlay')) closeShortcutsOverlay(); });
    $('#exportCareerButton')?.addEventListener('click', exportCareer);
    $('#importCareerButton')?.addEventListener('click', () => $('#importCareerInput')?.click());
    $('#importCareerInput')?.addEventListener('change', event => importCareerFile(event.target.files?.[0]));
    $('#restartTutorialButton')?.addEventListener('click', () => {
      state.tutorialEnabled = true;
      state.tutorialDismissed = false;
      state.tutorialStep = 0;
      saveState(true);
      $('#profileDialog')?.close();
      cleanGlobeView();
      renderTutorialCoach();
      showToast('Guided first-deal tour restarted.');
    });
    $('#profileDialog')?.addEventListener('close', () => {
      if ($('#profileDialog')?.returnValue === 'save') applyProfileChanges();
    });

    const dialog = $('#confirmDialog');
    $('#resetButton').addEventListener('click', () => dialog.showModal());
    dialog.addEventListener('close', () => { if (dialog.returnValue === 'confirm') resetCareer(); });
    const onboarding = $('#onboardingDialog');
    onboarding?.addEventListener('close', () => {
      if (onboarding.returnValue === 'start') {
        state.tutorialEnabled = $('#guidedTourToggle')?.checked !== false;
        state.tutorialDismissed = !state.tutorialEnabled;
        state.tutorialStep = 0;
        configureDifficulty($('#difficultySelect')?.value || 'standard');
        renderAll();
        showToast(state.tutorialEnabled ? `${state.difficulty} career started. Follow the guided first deal.` : `${state.difficulty} career started. Open Market and negotiate your first deal.`);
      } else if (!state.onboardingComplete) setTimeout(openOnboarding,80);
    });
    // v46 - alla chiusura del riepilogo mostra l'eventuale operazione successiva
    const settlementDialog = $('#settlementDialog');
    settlementDialog?.addEventListener('close', () => {
      if (_settlementQueue.length && !_settlementTimer) _settlementTimer = setTimeout(showNextSettlement, 320);
    });
    const dailyDialog = $('#dailyRewardDialog');
    dailyDialog?.addEventListener('close', () => { if (dailyDialog.returnValue === 'claim') claimDailyReward(); });
    const victoryDialog = $('#victoryDialog');
    victoryDialog?.addEventListener('close', () => {
      if (victoryDialog.returnValue === 'prestige') claimPrestige();
    });
  }

  let _deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    _deferredInstallPrompt = e;
    const btn = $('#installButton');
    if (btn) btn.classList.remove('hidden');
  });
  window.addEventListener('appinstalled', () => {
    _deferredInstallPrompt = null;
    const btn = $('#installButton');
    if (btn) btn.classList.add('hidden');
    showToast('World of Trade installed as an app.', 'success');
  });

  if (!window.__WOT_NATIVE_APP__ && 'serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' }).catch(() => {}));
  }

  const bootWarnings = [];
  const bootStep = (label, progress, callback) => {
    window.__WOT_SET_BOOT_STATUS__?.(label, progress);
    try {
      return callback();
    } catch (error) {
      bootWarnings.push({ label, message: error?.message || String(error) });
      console.error(`[World of Trade boot] ${label}`, error);
      return undefined;
    }
  };

  bootStep('Applying player settings…', 46, () => {
    if (state.reduceMotion) document.body.classList.add('reduce-motion');
    applyLanguage(state.language || 'en');
  });
  bootStep('Starting the globe…', 58, initEarthRenderer);
  bootStep('Sizing the world map…', 68, resizeCanvas);
  bootStep('Connecting controls…', 76, bindEvents);
  bootStep('Building the trading desk…', 88, renderAll);
  bootStep('Synchronising the interface…', 94, () => {
    syncOverlayUI();
    updateClock();
  });

  // Non-critical resources must never block the player from entering the game.
  deferNonCritical(() => {
    try { loadGeoBorders(); } catch (error) { console.warn('Country borders unavailable', error); }
  }, 1600);

  // v45 - il loop girava anche a scheda nascosta, consumando CPU e batteria
  _animationHandle = requestAnimationFrame(animate);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      if (_animationHandle !== null) { cancelAnimationFrame(_animationHandle); _animationHandle = null; }
    } else if (_animationHandle === null) {
      lastDrawTime = 0;
      _animationHandle = requestAnimationFrame(animate);
    }
  });
  setTimeout(openOnboarding, 120);
  setTimeout(() => { if (state.onboardingComplete) checkDailyReward(); }, 1400);

  window.__WOT_BOOT_WARNINGS__ = bootWarnings;
  window.__WOT_APP_READY__ = true;
  window.__WOT_SET_BOOT_STATUS__?.(bootWarnings.length ? 'Ready — some optional features were repaired' : 'Ready', 100);
  window.dispatchEvent(new CustomEvent('wot-ready', { detail: { warnings: bootWarnings } }));
  try { window.WorldOfTradeNative?.appReady?.(); } catch (error) {}
})();
})().catch(error => {
  console.error('World of Trade failed to start', error);
  window.__WOT_BOOT_FAIL__?.(error);
});
